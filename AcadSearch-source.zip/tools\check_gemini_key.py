"""Check the Gemini key flow: paste, reveal, and save.

The reported problem was not a broken key: Preferences opened with focus on the
language combo, so Ctrl+V changed nothing, and the field masks its contents, so
a successful paste looked like a single dot. This check drives the real dialog
with a temporary config and verifies that the key is focused on open, that
pasting lands in the field, that "Show" reveals it, and that Save persists it.

    python -X utf8 tools/check_gemini_key.py
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import app.config as config_module

FAILED: list[str] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if condition else 'FAIL'}] {label}"
          + (f" -- {detail}" if detail else ""))
    if not condition:
        FAILED.append(label)


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="acad-gemini-"))
    (tmp / "config.json").write_text(
        json.dumps({"geminiKey": "old-key", "geminiModel": "gemini-2.5-flash"}),
        encoding="utf-8",
    )
    # Never touch the real config.json, in the project or in %LOCALAPPDATA%.
    config_module.app_dir = lambda: tmp
    config_module._config = None

    print("== a retired model is upgraded ==")
    cfg = config_module.Config()
    check("2.5-flash is replaced on load",
          cfg.gemini_model == "gemini-3.5-flash", cfg.gemini_model)

    (tmp / "config.json").write_text(
        json.dumps({"geminiKey": "old-key", "geminiModel": "gemini-3-pro-preview"}),
        encoding="utf-8",
    )
    config_module._config = None
    custom = config_module.Config()
    check("a custom model is left alone",
          custom.gemini_model == "gemini-3-pro-preview", custom.gemini_model)

    print("== a config saved with a BOM still loads ==")
    (tmp / "config.json").write_bytes(
        b"\xef\xbb\xbf"
        + json.dumps(
            {"geminiKey": "bom-key", "geminiModel": "gemini-3.5-flash"}
        ).encode("utf-8")
    )
    config_module._config = None
    bom = config_module.Config()
    check("the key survives a BOM", bom.gemini_key == "bom-key", bom.gemini_key)

    (tmp / "config.json").write_text(
        json.dumps({"geminiKey": "old-key", "geminiModel": "gemini-3.5-flash"}),
        encoding="utf-8",
    )
    config_module._config = None

    print("== the dialog opens on the Gemini field ==")
    from PySide6.QtCore import Qt
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QLineEdit

    from app import i18n
    from app.core import doc_ai
    from qt_prototype.preferences import PreferencesDialog

    app = QApplication.instance() or QApplication([])
    dialog = PreferencesDialog(focus_key="gemini")
    dialog.show()
    app.processEvents()
    check("the key field has focus", dialog.gemini_key.hasFocus(),
          type(dialog.focusWidget()).__name__ if dialog.focusWidget() else "None")
    check("the saved key is selected, so a paste replaces it",
          dialog.gemini_key.selectedText() == "old-key",
          repr(dialog.gemini_key.selectedText()))

    print("== Ctrl+V lands in the key field ==")
    QApplication.clipboard().setText("  AIzaTestKey123\n")
    QTest.keyClick(dialog.gemini_key, Qt.Key_V, Qt.ControlModifier)
    app.processEvents()
    check("pasted text is in the field",
          dialog.gemini_key.text() == "AIzaTestKey123",
          repr(dialog.gemini_key.text()))

    print("== Show reveals the key, hiding it restores the dots ==")
    dialog.gemini_show.setChecked(True)
    check("Show uses plain text",
          dialog.gemini_key.echoMode() == QLineEdit.Normal)
    check("the key is readable while shown",
          dialog.gemini_key.text() == "AIzaTestKey123")
    dialog.gemini_show.setChecked(False)
    check("hiding returns to Password mode",
          dialog.gemini_key.echoMode() == QLineEdit.Password)

    print("== the Paste button works even without focus in the field ==")
    QApplication.clipboard().setText("  AIzaSecondKey  ")
    dialog.gemini_key.clearFocus()
    dialog.gemini_paste.click()
    app.processEvents()
    check("Paste inserts the clipboard",
          dialog.gemini_key.text() == "AIzaSecondKey",
          repr(dialog.gemini_key.text()))
    check("Paste says how many characters arrived",
          dialog.key_status.text()
          == i18n.t("prefs.paste.done", n=len("AIzaSecondKey")),
          dialog.key_status.text())
    check("Paste puts focus back in the field", dialog.gemini_key.hasFocus())

    print("== an empty clipboard is explained, not ignored ==")
    before = dialog.gemini_key.text()
    QApplication.clipboard().setText("   ")
    dialog.gemini_paste.click()
    check("the empty clipboard is named",
          dialog.key_status.text() == i18n.t("prefs.paste.empty"),
          dialog.key_status.text())
    check("the existing key is not wiped",
          dialog.gemini_key.text() == before)

    print("== Save writes the key and the new model ==")
    dialog.gemini_key.setText("AIzaSavedKey456")
    dialog.apply_to_config()
    saved = json.loads((tmp / "config.json").read_text(encoding="utf-8"))
    check("geminiKey is in config.json",
          saved.get("geminiKey") == "AIzaSavedKey456",
          str(saved.get("geminiKey")))
    check("geminiModel is the current model",
          saved.get("gemini_model") == "gemini-3.5-flash",
          str(saved.get("gemini_model")))
    check("the running config sees the key",
          config_module.get_config().gemini_key == "AIzaSavedKey456")
    check("the assistant is available",
          doc_ai.available())
    check("the default model is not the retired one",
          doc_ai.DEFAULT_MODEL != "gemini-2.5-flash", doc_ai.DEFAULT_MODEL)
    check("there is at least one fallback",
          len(doc_ai.FALLBACK_MODELS) >= 1, str(doc_ai.FALLBACK_MODELS))

    dialog.close()
    print()
    if FAILED:
        print(f"FAILED: {len(FAILED)} -> {FAILED}")
        return 1
    print("ALL GEMINI-KEY CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
