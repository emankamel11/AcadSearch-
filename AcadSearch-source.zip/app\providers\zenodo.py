"""Zenodo — CERN's open research platform (datasets, papers, software, theses).

Docs: https://developers.zenodo.org
Public search needs no token. Zenodo stores research artefacts that journals
never see — datasets, software, notebooks — each carrying a DOI, plus the PDF
when it is available. That makes it the natural sibling of DataCite with more
of the actual files.
"""

from __future__ import annotations

import threading

from app.core.text_utils import (
    as_int,
    clean_text,
    extract_doi,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://zenodo.org/api/records"

#: Zenodo ``resource_type.subtype`` (or .type) labels routed per tab.
ARTICLE_SUBTYPES = ("article", "journal-article", "conference-paper", "preprint")
BOOK_SUBTYPES = ("book", "section")


@register
class ZenodoProvider(BaseProvider):
    provider_id = "zenodo"
    display_name = "Zenodo"
    categories = (Category.RESEARCH, Category.ARTICLE, Category.BOOK)
    weight = 40
    homepage = "https://zenodo.org"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        params: dict[str, object] = {
            "q": query.text,
            "size": min(query.per_source, 20),
            "sort": "bestmatch",
        }
        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        hits = (payload.get("hits") or {}).get("hits") or []
        return [self._to_result(record) for record in hits]

    # -- mapping ----------------------------------------------------------
    def _to_result(self, record: dict) -> Result:
        meta = record.get("metadata") or {}
        title = clean_text(meta.get("title"))

        creators: list[str] = []
        for creator in (meta.get("creators") or []):
            name = clean_text(creator.get("name"))
            if not name:
                people = creator.get("person_or_org") or {}
                name = clean_text(people.get("name"))
            if name:
                creators.append(name)

        published = clean_text(meta.get("publication_date"))
        year = as_int(published[:4]) if published else None

        rtype = (meta.get("resource_type") or {})
        subtype = clean_text(rtype.get("subtype")).lower()
        type_label = clean_text(rtype.get("type")).lower()
        kind = subtype or type_label
        if kind in ARTICLE_SUBTYPES:
            category = Category.ARTICLE
        elif kind in BOOK_SUBTYPES:
            category = Category.BOOK
        else:
            category = Category.RESEARCH

        doi = extract_doi(meta.get("doi") or record.get("doi"))
        recid = as_int(record.get("id"))
        links = record.get("links") or {}

        identifiers: dict[str, str] = {}
        if doi:
            identifiers["doi"] = doi
        if recid:
            identifiers["zenodo"] = str(recid)

        subjects = [
            clean_text(s.get("term"))
            for s in (meta.get("subjects") or [])
            if s.get("term")
        ][:6]

        downloads = self._downloads(record, recid)
        landing = clean_text(links.get("html")) or (
            f"https://doi.org/{doi}" if doi else ""
        )

        return Result(
            category=category,
            title=title,
            source=self.provider_id,
            authors=creators,
            year=year,
            abstract=truncate_words(clean_text(meta.get("description")), 320),
            venue=clean_text(((meta.get("journal") or {}).get("title"))
                             or "Zenodo"),
            publisher="Zenodo",
            language=normalise_language(clean_text(meta.get("language"))),
            subjects=subjects,
            identifiers=identifiers,
            access=Access.DOWNLOAD if downloads else (
                Access.LANDING if landing else Access.METADATA
            ),
            downloads=downloads,
            landing_url=landing,
            item_type=kind.replace("-", " ").title() or "Dataset",
            raw=record,
        )

    @staticmethod
    def _downloads(record: dict, recid: int | None) -> list:
        """Direct links to the deposited files, preferring PDFs."""
        out: list = []
        files = record.get("files") or []
        pdf_keys = [
            clean_text(f.get("key"))
            for f in files
            if clean_text(f.get("key")).lower().endswith(".pdf")
        ]
        for key in pdf_keys:
            if not recid:
                continue
            url = f"https://zenodo.org/records/{recid}/files/{key}"
            out.append(target(url, DownloadFormat.PDF, label=key, open_access=True))
        if out:
            return out[:2]
        for f in files:
            key = clean_text(f.get("key"))
            if not key or not recid:
                continue
            url = f"https://zenodo.org/records/{recid}/files/{key}?download=1"
            out.append(
                target(
                    url,
                    DownloadFormat.SOURCE,
                    label=key,
                    open_access=True,
                )
            )
        return out[:1]