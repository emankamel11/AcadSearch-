"""Check that "Search by" really narrows results to title, author or ISBN.

The menu is only useful if the records that do not belong to the chosen field
are gone from the response, not merely ranked lower. These checks exercise the
merge step directly, so they prove the backend behaviour without a network.

Run:  python -X utf8 tools/check_search_field.py
"""

from __future__ import annotations

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))

from app.core.search_engine import _finalise  # noqa: E402
from app.models import Category, Result, SearchQuery, SearchResponse  # noqa: E402

FAILED: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if condition else 'FAIL'}] {name}"
          + (f" -- {detail}" if detail else ""))
    if not condition:
        FAILED.append(name)


def book(
    title: str,
    authors: list[str],
    *,
    isbn: str = "",
) -> Result:
    return Result(
        category=Category.BOOK,
        title=title,
        source="open_library",
        authors=list(authors),
        identifiers={"isbn": isbn} if isbn else {},
    )


RECORDS = [
    book("Deep Learning", ["Ian Goodfellow"], isbn="9780262035613"),
    book("Learning Python", ["Mark Lutz"], isbn="9781491946008"),
    book("Machine Learning", ["Tom Mitchell"], isbn="9780070428072"),
]


def run(text: str, field: str, records: list[Result] | None = None):
    response = SearchResponse(
        query=SearchQuery(text=text, field=field),
        results={Category.BOOK: list(records if records is not None else RECORDS)},
    )
    return _finalise(response)


def titles(response: SearchResponse) -> list[str]:
    return [item.title for item in response.results[Category.BOOK]]


def main() -> int:
    print("== title only ==")
    response = run("deep learning", "title")
    check("only the matching title survives",
          titles(response) == ["Deep Learning"], str(titles(response)))
    check("a title search is not flagged empty", not response.field_empty,
          str(response.field_empty))

    response = run("quantum gravity", "title")
    check("a title that matches nothing shows no records",
          titles(response) == [], str(titles(response)))
    check("the empty title search is explained",
          response.field_empty is True, str(response.field_empty))

    print()
    print("== author only ==")
    response = run("Goodfellow", "author")
    check("the author match survives even though the title does not contain it",
          titles(response) == ["Deep Learning"], str(titles(response)))
    response = run("Ian Goodfellow", "author")
    check("a full name matches", titles(response) == ["Deep Learning"],
          str(titles(response)))

    # Two-letter names are real ("Li", "Wu", "Ho"), so the field matcher must
    # not drop them the way the ranking tokeniser does.
    short = [book("A short name", ["Li Wei"]), book("Someone else", ["Ada Lovelace"])]
    response = run("Li", "author", short)
    check("a two-letter author name still matches",
          titles(response) == ["A short name"], str(titles(response)))

    response = run("Mark Lutz", "author")
    check("another author narrows to their book",
          titles(response) == ["Learning Python"], str(titles(response)))

    print()
    print("== ISBN ==")
    response = run("978-0-262-03561-3", "isbn")
    check("hyphens and spaces do not matter",
          titles(response) == ["Deep Learning"], str(titles(response)))
    response = run("978 1 4919 4600 8", "isbn")
    check("a spaced ISBN matches",
          titles(response) == ["Learning Python"], str(titles(response)))
    response = run("9780262035614", "isbn")
    check("a wrong ISBN matches nothing", titles(response) == [], str(titles(response)))
    check("the wrong ISBN is explained",
          response.field_empty is True, str(response.field_empty))

    print()
    print("== any field keeps the broad search ==")
    response = run("deep learning", "any")
    check("all records remain reachable",
          len(titles(response)) == 3, str(titles(response)))
    check("any-field search is never flagged empty", not response.field_empty,
          str(response.field_empty))

    print()
    print("== the cache cannot confuse two field modes ==")
    title_sig = SearchQuery(text="deep learning", field="title").cache_signature()
    any_sig = SearchQuery(text="deep learning", field="any").cache_signature()
    author_sig = SearchQuery(text="deep learning", field="author").cache_signature()
    check("title and any have different signatures", title_sig != any_sig,
          f"{title_sig} / {any_sig}")
    check("author and title have different signatures", author_sig != title_sig,
          f"{author_sig} / {title_sig}")
    check("an unknown field falls back to any",
          SearchQuery(text="x", field="nonsense").field == "any",
          SearchQuery(text="x", field="nonsense").field)

    print()
    if FAILED:
        print(f"FAILED: {len(FAILED)} check(s): {FAILED}")
        return 1
    print("ALL SEARCH-FIELD CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
