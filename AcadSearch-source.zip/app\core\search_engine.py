"""Concurrent search orchestration.

Design notes
------------
* Every provider runs on its own worker thread; the Tk main thread is never
  blocked and the user can keep typing or cancel mid-search.
* Workers never touch widgets. They push :class:`SearchEvent` objects onto a
  queue that the UI drains with ``root.after(...)``, which is the only
  thread-safe way to mutate a Tk widget tree.
* A provider failure degrades to a status chip; it never aborts the search.
"""

from __future__ import annotations

import logging
import queue
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from enum import Enum
from typing import Iterable

from app.core.http_client import ProviderError
from app.core.text_utils import fold
from app.config import get_config
from app.models import (
    Access,
    Category,
    ProviderReport,
    ProviderStatus,
    Result,
    SearchQuery,
    SearchResponse,
    dedupe,
)
from app.providers import BaseProvider, all_providers, providers_for_category

log = logging.getLogger(__name__)


class SearchEventType(str, Enum):
    STARTED = "started"
    PROVIDER_UPDATE = "provider_update"
    PARTIAL_RESULTS = "partial_results"
    FINISHED = "finished"
    CANCELLED = "cancelled"
    FAILED = "failed"


@dataclass
class SearchEvent:
    type: SearchEventType
    response: SearchResponse | None = None
    report: ProviderReport | None = None
    message: str = ""
    payload: object = None


class SearchHandle:
    """Cancels one search run and exposes its event stream."""

    def __init__(self, query: SearchQuery, events: "queue.Queue[SearchEvent]"):
        self.query = query
        self.events = events
        self.cancel_event = threading.Event()
        self._done = threading.Event()
        self.started_at = time.monotonic()

    def cancel(self) -> None:
        self.cancel_event.set()

    @property
    def cancelled(self) -> bool:
        return self.cancel_event.is_set()

    @property
    def done(self) -> bool:
        return self._done.is_set()

    def _finish(self) -> None:
        self._done.set()

    @property
    def elapsed(self) -> float:
        return time.monotonic() - self.started_at


class SearchEngine:
    """Runs the enabled providers for a query concurrently."""

    def __init__(self, max_workers: int = 0):
        # Every planned provider needs a slot, otherwise adding a source makes
        # searches slower instead of wider. 0 means "one per known provider".
        self.max_workers = max_workers or max(4, len(all_providers()))
        self.config = get_config()
        self._executor = ThreadPoolExecutor(
            max_workers=self.max_workers, thread_name_prefix="acadsearch"
        )
        self._active: SearchHandle | None = None

    # -- public API ------------------------------------------------------
    def start(self, query: SearchQuery) -> SearchHandle:
        """Begin a search and return immediately with its handle."""
        self.cancel_current()
        events: "queue.Queue[SearchEvent]" = queue.Queue()
        handle = SearchHandle(query, events)
        self._active = handle
        events.put(SearchEvent(SearchEventType.STARTED, response=SearchResponse(query=query)))
        threading.Thread(
            target=self._run_guarded, args=(handle,), name="acadsearch-coord",
            daemon=True,
        ).start()
        return handle

    def _run_guarded(self, handle: SearchHandle) -> None:
        """Run a search, turning any crash into a FAILED event.

        Without this, an exception inside the coordinator thread kills it
        silently: ``handle.done`` never becomes True, so the UI waits forever
        with no message. That is far worse than reporting the error.
        """
        try:
            self._run(handle)
        except BaseException as exc:  # noqa: BLE001 - must not escape the thread
            log.exception("search coordinator crashed")
            handle.events.put(
                SearchEvent(
                    SearchEventType.FAILED,
                    response=SearchResponse(query=handle.query),
                    message=f"{type(exc).__name__}: {exc}",
                )
            )
            handle._finish()

    def cancel_current(self) -> bool:
        handle = self._active
        if handle is None or handle.done:
            return False
        handle.cancel()
        return True

    def shutdown(self) -> None:
        self.cancel_current()
        self._executor.shutdown(wait=False, cancel_futures=True)

    # -- orchestration ---------------------------------------------------
    def _run(self, handle: SearchHandle) -> None:
        query = handle.query
        response = SearchResponse(query=query)
        started = time.monotonic()

        plan = self._plan(query)
        if not plan:
            handle.events.put(
                SearchEvent(
                    SearchEventType.FINISHED,
                    response=response,
                    message="no providers enabled",
                )
            )
            handle._finish()
            return

        # Seed reports so the UI can draw a placeholder chip per provider right away.
        for provider in plan:
            report = ProviderReport(provider_id=provider.provider_id)
            response.reports.append(report)
            handle.events.put(
                SearchEvent(
                    SearchEventType.PROVIDER_UPDATE,
                    response=response,
                    report=report,
                )
            )

        # Workers publish onto `completed` in true completion order rather than
        # submission order, so a slow provider cannot hold up the fast ones.
        completed: "queue.Queue[tuple[ProviderReport, list[Result]]]" = queue.Queue()
        for provider in plan:
            self._executor.submit(self._safe_run, provider, query, handle, completed)

        # Deadline for the whole run. Configured rather than hard-coded because
        # it trades two real costs against each other: too short and a slow but
        # working source (SUDOC, OpenAIRE) is thrown away, too long and one
        # stalled source holds a search hostage for the whole retry budget
        # (timeout x max_retries + back-off, ~80s) even though the other eleven
        # sources finished in seconds. Providers still running when the deadline
        # passes are reported as timeouts below and their results discarded.
        deadline = time.monotonic() + self.config.search_deadline
        collected = 0
        while collected < len(plan):
            if handle.cancelled or time.monotonic() > deadline:
                break
            try:
                report, results = completed.get(timeout=0.25)
            except queue.Empty:
                continue
            collected += 1
            self._apply(response, report, results)
            handle.events.put(
                SearchEvent(
                    SearchEventType.PROVIDER_UPDATE,
                    response=response,
                    report=report,
                )
            )
            # Stream partial results so cards appear as soon as they are ready.
            handle.events.put(
                SearchEvent(
                    SearchEventType.PARTIAL_RESULTS,
                    response=snapshot(response),
                    report=report,
                )
            )

        if handle.cancelled:
            handle.events.put(
                SearchEvent(SearchEventType.CANCELLED, response=response)
            )
            handle._finish()
            if self._active is handle:
                self._active = None
            return

        # Any provider that never reported back is shown as a timeout chip
        # rather than silently disappearing from the status bar.
        for provider in plan:
            if not any(
                r.provider_id == provider.provider_id and r.status is not ProviderStatus.PENDING
                for r in response.reports
            ):
                report = ProviderReport(
                    provider_id=provider.provider_id,
                    status=ProviderStatus.ERROR,
                    message="timeout",
                )
                _store_report(response, report)
                response.errors.append(f"{provider.provider_id}: timeout")
                handle.events.put(
                    SearchEvent(
                        SearchEventType.PROVIDER_UPDATE,
                        response=response,
                        report=report,
                    )
                )

        # Tell the stragglers to stop before finishing the run. Their results are
        # discarded anyway, but nobody else would: the executor has exactly one
        # slot per provider, so a worker still grinding through its retry budget
        # after the deadline holds a slot that the next search needs. A handful of
        # stalled sources would then block every later search, which is far worse
        # than the timeout chip this run already reports.
        handle.cancel_event.set()

        response.elapsed = time.monotonic() - started
        response = _finalise(response)
        handle.events.put(SearchEvent(SearchEventType.FINISHED, response=response))
        handle._finish()
        if self._active is handle:
            self._active = None

    def _plan(self, query: SearchQuery) -> list[BaseProvider]:
        """Pick the providers that serve the requested categories, in priority order."""
        chosen: list[BaseProvider] = []
        seen: set[str] = set()
        for category in (Category.BOOK, Category.ARTICLE, Category.RESEARCH):
            if category not in query.categories:
                continue
            for provider in providers_for_category(category):
                if provider.provider_id in seen:
                    continue
                if not provider.available():
                    continue
                seen.add(provider.provider_id)
                chosen.append(provider)
        return chosen

    def _safe_run(
        self,
        provider: BaseProvider,
        query: SearchQuery,
        handle: SearchHandle,
        completed: "queue.Queue[tuple[ProviderReport, list[Result]]]",
    ) -> None:
        """Run one provider in isolation and always report back exactly once."""
        report = ProviderReport(provider_id=provider.provider_id)
        results: list[Result] = []
        started = time.monotonic()
        try:
            results = provider.run(query, handle.cancel_event)
            report.count = len(results)
            report.status = ProviderStatus.OK if results else ProviderStatus.EMPTY
        except ProviderError as exc:
            report.status = ProviderStatus.ERROR
            report.message = exc.kind
            log.info("provider %s failed: %s", provider.provider_id, exc)
        except Exception:  # unexpected: never let one source kill the search
            report.status = ProviderStatus.ERROR
            report.message = "error"
            log.exception("provider %s crashed", provider.provider_id)
        finally:
            report.seconds = time.monotonic() - started
            completed.put((report, results))

    def _apply(
        self, response: SearchResponse, report: ProviderReport, results: Iterable[Result]
    ) -> None:
        _store_report(response, report)

        if report.failed:
            response.errors.append(f"{report.provider_id}: {report.message}")
            return

        for item in results:
            if item.category not in response.results:
                response.results[item.category] = []
            response.results[item.category].append(item)


def _store_report(response: SearchResponse, report: ProviderReport) -> None:
    """Keep exactly one report per provider.

    The run seeds a PENDING placeholder for every planned source so the UI can
    draw its chip immediately, then fills it in. Appending instead of updating
    would leave a timed-out source in the list twice -- once as "pending",
    forever -- and every count taken over ``reports`` would then overstate how
    many sources actually answered.
    """
    for existing in response.reports:
        if existing.provider_id == report.provider_id:
            existing.status = report.status
            existing.count = report.count
            existing.seconds = report.seconds
            existing.message = report.message
            return
    response.reports.append(report)


# ---------------------------------------------------------------------------
# Post-processing
# ---------------------------------------------------------------------------
def _book_key(item: Result) -> tuple[str, str] | None:
    """Identify a book by title plus first author, ignoring the year.

    Books rarely share a DOI or even an ISBN across catalogues: Open Library
    gives an OL work id, Internet Archive gives its own item id, OpenAlex gives
    a DOI. So identifier de-duplication never merges them, and the same book
    shows up three times. Titles and authors are what catalogues agree on.

    The year is deliberately excluded because catalogues disagree by years on
    the same title (Open Library listed Alpaydin 2004, Internet Archive 2010).
    """
    title = fold(item.title or "").strip()
    if not title:
        return None
    surname = ""
    if item.authors:
        raw = item.authors[0].strip()
        # Catalogues disagree on the order: Open Library says
        # "Mitchell, Tom M. (Tom Michael), 1951- author", others say
        # "John Paul Mueller". Try surname-first, then surname-last.
        parts = [p for p in raw.replace("(", " ").split() if p]
        comma = raw.split(",")[0].strip()
        if "," in raw and comma:
            surname = comma.split()[0]
        elif parts:
            surname = parts[-1]
        surname = fold(surname).strip(" .,;:")
    if not surname:
        # No author at all: fall back to the title alone so two records that
        # agree on a distinctive title still merge.
        return ("t", title)
    return (surname, title)


def _merge_book_duplicates(items: list[Result]) -> list[Result]:
    """Collapse the same book coming from several catalogues into one card.

    Keeps the copy that can actually be downloaded, then attaches every other
    source's links so the reader is not sent to a dead end.
    """
    merged: dict[tuple[str, str], Result] = {}
    order: list[tuple[str, str]] = []

    for item in items:
        key = _book_key(item)
        if key is None:
            continue
        existing = merged.get(key)
        if existing is None:
            merged[key] = item
            order.append(key)
            continue

        def file_count(res: Result) -> tuple[int, int, int]:
            real = sum(
                1
                for t in res.downloads
                if t.open_access and t.fmt.value in ("pdf", "epub")
            )
            return (real, res.access == Access.DOWNLOAD, len(res.downloads))

        keep, drop = existing, item
        if file_count(item) > file_count(existing):
            keep, drop = item, existing

        urls = {t.url for t in keep.downloads}
        for candidate in drop.downloads:
            if candidate.url not in urls:
                keep.downloads.append(candidate)
                urls.add(candidate.url)

        keep.identifiers = {**drop.identifiers, **keep.identifiers}
        keep.subjects = list(dict.fromkeys(keep.subjects + drop.subjects))
        keep.authors = keep.authors or drop.authors
        keep.abstract = keep.abstract or drop.abstract
        keep.cover_url = keep.cover_url or drop.cover_url
        keep.year = keep.year or drop.year
        keep.venue = keep.venue or drop.venue
        keep.score = max(keep.score, drop.score)
        merged[key] = keep

    return [merged[k] for k in order]


def _finalise(response: SearchResponse) -> SearchResponse:
    """De-duplicate, sort and trim the merged result set."""
    query_words = {
        w for w in _tokenise(response.query.text) if len(w) > 2
    }

    for category, items in list(response.results.items()):
        merged = dedupe(items)
        if category is Category.BOOK:
            merged = _merge_book_duplicates(merged)

        # Rank: provider weight, then citations for papers, then recency.
        def sort_key(item: Result) -> tuple:
            return (
                item.score,
                item.citations or 0,
                item.year or 0,
            )

        merged.sort(key=sort_key, reverse=True)

        # The chosen language filter is a ranking preference, not a hard cut.
        # Most providers cannot filter server-side, and dropping every foreign
        # record would empty whole tabs for an Arabic query, which reads as
        # "the app is broken" rather than "nothing matched". So matching
        # records rise to the top and everything else stays reachable below.
        chosen = response.query.language
        if chosen and chosen != "any":
            for item in merged:
                if item.language == chosen:
                    item.score += 1.0
            merged.sort(key=sort_key, reverse=True)

        # A title the user typed in full should sit at the very top, even when
        # the provider ranked it low. Otherwise searching for a book title looks
        # like it missed, because the exact match is buried further down.
        if query_words:
            for item in merged:
                item.score += _title_affinity(item, query_words)

            merged.sort(key=sort_key, reverse=True)

            # A record written in the language the user typed in is almost
            # always the one they wanted, even when a provider ranked the
            # foreign-language version higher because it matched the provider's
            # own default index. Small nudge, not a filter: nothing is hidden.
            wanted = _query_language(response.query.text)
            if wanted:
                for item in merged:
                    if item.language == wanted:
                        item.score += 0.75
                merged.sort(key=sort_key, reverse=True)

            # Push weak matches to the back rather than deleting them: Sudoc
            # matches on subject headings, so a French dissertation can surface
            # for an English query. The user may still want to see it.
            merged = _demote_weak_matches(merged, query_words)

        # The per-tab ceiling. Configurable because a blind user scrolling 150 rows
        # with the arrow keys pays a real cost, so the default is a compromise
        # rather than "everything the providers returned".
        from app.config import get_config

        cap = get_config().max_results_per_tab
        if len(merged) > cap:
            merged = merged[:cap]
            response.truncated = True
        response.results[category] = merged
    return response


def _demote_weak_matches(
    items: list[Result], query_words: set[str]
) -> list[Result]:
    """Keep only titles that share a word with the query, when enough do.

    If very little matches, the ranking is left alone rather than emptying the
    category: a weak result beats no result.
    """
    if not query_words or len(items) < 4:
        return items

    # Europe PMC translates a non-Latin query into English before searching, so
    # its titles legitimately share no word with what the user typed. Judging
    # those by title overlap would bury the best answer to an Arabic query, so
    # they are exempt and ranked on their own merits.
    latin_query = all(word.isascii() for word in query_words)
    exempt = set() if latin_query else set(_TRANSLATING_PROVIDERS)

    strong = [
        item
        for item in items
        if item.source in exempt
        or any(w in " ".join(_tokenise(item.title)) for w in query_words)
    ]
    if len(strong) < 3:
        return items

    return strong + [item for item in items if item not in strong]


#: Providers that run a cross-language query expansion, so their result titles
#: are not expected to contain the user's original words.
_TRANSLATING_PROVIDERS = frozenset({"europe_pmc"})

#: Words that are French and not English. Deliberately excludes the shared ones
#: ("de", "la", "un", "par", "sur") because those would mark every English and
#: Spanish query as French, and the content words are the ones that survive
#: accent folding, so "théorie" is stored as "theorie".
_FRENCH_MARKERS = frozenset(
    {
        "aux",
        "avec",
        "dans",
        "des",
        "du",
        "elle",
        "elles",
        "entre",
        "est",
        "et",
        "etre",
        "leurs",
        "une",
        "ainsi",
        "aussi",
        "leur",
        "son",
        "sont",
        "theorie",
        "theories",
        "modele",
        "modeles",
        "modelisation",
        "apprentissage",
        "automatique",
        "donnees",
        "reseaux",
        "intelligence",
        "artificielle",
        "recherche",
        "systeme",
        "methode",
        "methodes",
        "memoire",
        "these",
        "thesee",
        "mots",
        "cle",
    }
)


def _query_language(text: str) -> str:
    """Best guess at the language the user typed in, or "" when unsure.

    Arabic is decided by script, which is reliable. French is decided by
    vocabulary, because French is written in Latin script and looks exactly
    like English to the eye. Anything ambiguous returns "" so the ranking is
    left alone rather than skewed towards the wrong language.
    """
    from app.core.text_utils import has_arabic

    if has_arabic(text):
        return "ar"

    words = _tokenise(text, min_length=2)
    if not words:
        return ""
    hits = sum(1 for w in words if w in _FRENCH_MARKERS)
    # One marker in a two-word query can be an English word that happens to
    # look French ("et al", "ia" as initials), so a single hit needs at least
    # one more word to agree with it.
    if hits >= 2 or (hits == 1 and len(words) >= 3):
        return "fr"
    return ""


def _tokenise(text: str, min_length: int = 3) -> list[str]:
    """Split a query into comparable words, keeping Arabic and Latin alike.

    Accents are dropped so that "modelisation" matches "modelization", and
    Arabic prefixes such as "ال" are stripped so an Arabic query is not
    compared against them.

    ``min_length`` exists for language detection: French is identified partly by
    its short function words ("de", "un", "la"), which the default cut-off
    throws away.
    """
    import unicodedata

    words: list[str] = []
    current: list[str] = []
    for ch in text:
        if ch.isalnum():
            current.append(ch)
        elif current:
            words.append("".join(current))
            current = []
    if current:
        words.append("".join(current))

    out: list[str] = []
    for word in words:
        folded = "".join(
            c
            for c in unicodedata.normalize("NFD", word.lower())
            if not unicodedata.combining(c)
        )
        folded = _strip_arabic_definite(folded)
        if len(folded) >= min_length:
            out.append(folded)
    return out


def _strip_arabic_definite(word: str) -> str:
    """Turn "الذكاء" into "ذكاء" so the article "ال" does not block a match."""
    for prefix in ("وال", "بال", "كال", "فال", "ال"):
        if word.startswith(prefix) and len(word) - len(prefix) >= 3:
            return word[len(prefix):]
    return word


def _title_affinity(item: Result, query_words: set[str]) -> float:
    """How strongly a result matches what was typed, 0.0 to 1.5.

    An exact whole-title match must win, so it gets the largest bonus. A result
    that merely mentions the words gets a smaller one.

    A title that shares no word with the query gets a negative score: some
    providers (Sudoc in particular) match on subject headings rather than on
    the title, so French dissertations surface for an English query even though
    the title never mentions the words.
    """
    title = " ".join(_tokenise(item.title))
    if not title:
        return -0.5

    if title == " ".join(sorted(query_words)):
        return 1.5

    title_words = set(title.split())
    hits = len(title_words & query_words)
    if not hits:
        return -0.6

    coverage = hits / max(len(query_words), 1)
    precision = hits / max(len(title_words), 1)

    if item.title.strip().lower() == " ".join(query_words):
        return 1.5
    if coverage >= 1.0 and precision >= 0.6:
        return 1.0
    return 0.3 * coverage * precision


def snapshot(response: SearchResponse) -> SearchResponse:
    """A cheap, immutable-enough copy for the partial-results events."""
    return SearchResponse(
        query=response.query,
        results={k: list(v) for k, v in response.results.items()},
        reports=list(response.reports),
        errors=list(response.errors),
        elapsed=response.elapsed,
        truncated=response.truncated,
    )


_engine: SearchEngine | None = None


def get_engine() -> SearchEngine:
    global _engine
    if _engine is None:
        _engine = SearchEngine()
    return _engine
