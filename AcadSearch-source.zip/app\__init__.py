"""Package root for AcadSearch."""

from app.config import APP_NAME, APP_VERSION, get_config  # noqa: F401

__all__ = ["APP_NAME", "APP_VERSION", "get_config"]
__version__ = APP_VERSION
