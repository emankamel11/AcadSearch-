"""Springer Nature Metadata API — journals, books and chapters.

Dev portal: https://dev.springernature.com. A free api_key is required; it can
go in the query string (documented) which keeps this provider free of header
hacks. ``fulltextLink`` is subscription-dependent, so results are sent to the
landing page instead of straight on to a PDF.
"""

from __future__ import annotations

import re
import threading

from app.core.text_utils import as_int, clean_text, extract_doi, truncate_words
from app.models import Access, Category, Result, SearchQuery
from app.providers.base import BaseProvider, register

ENDPOINT = "https://api.springernature.com/meta/v2/json"
YEAR_RE = re.compile(r"\b(\d{4})\b")

ARTICLE_TYPES = ("journal article", "review", "brief communication",
                 "originalpaper", "research")
BOOK_TYPES = ("book", "book chapter", "reference work entry",
              "encyclopedia", "chapter")


@register
class SpringerProvider(BaseProvider):
    provider_id = "springer"
    display_name = "Springer"
    categories = (Category.BOOK, Category.ARTICLE, Category.RESEARCH)
    weight = 45
    requires_key = "springer_key"
    homepage = "https://link.springer.com"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        if not self.config.springer_key:
            return []
        params: dict[str, object] = {
            "q": query.text,
            "p": min(query.per_source, 50),
            "s": 1,
            "api_key": self.config.springer_key,
        }
        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        return [self._to_result(r) for r in (payload.get("records") or [])]

    def _to_result(self, record: dict) -> Result:
        title = clean_text(record.get("title"))
        creators = [
            clean_text(c.get("creator"))
            for c in (record.get("creators") or [])
            if clean_text(c.get("creator"))
        ]

        date = clean_text(record.get("publicationDate")) or clean_text(
            record.get("onlineDate")
        )
        year = None
        if date:
            match = YEAR_RE.search(date)
            if match:
                year = as_int(match.group(1))

        doi = extract_doi(record.get("doi"))
        kind = clean_text(record.get("contentType")).lower()
        if kind in BOOK_TYPES or record.get("bookTitle"):
            category = Category.BOOK
        elif kind in ARTICLE_TYPES:
            category = Category.ARTICLE
        else:
            category = Category.RESEARCH

        venue = (clean_text(record.get("publicationName"))
                 or clean_text(record.get("bookTitle")) or "Springer")
        landing = clean_text(record.get("url"))

        identifiers: dict[str, str] = {}
        if doi:
            identifiers["doi"] = doi
        isbn = clean_text(record.get("isbn"))
        if isbn:
            identifiers["isbn"] = isbn

        return Result(
            category=category,
            title=title,
            source=self.provider_id,
            authors=creators,
            year=year,
            abstract=truncate_words(clean_text(record.get("abstract")), 320),
            venue=venue,
            language="en",
            identifiers=identifiers,
            access=Access.LANDING if landing else Access.METADATA,
            downloads=[],
            landing_url=landing,
            item_type=kind.title() or "Record",
            raw=record,
        )