"""Crossref — DOI registry metadata for journal articles.

Docs: https://api.crossref.org/swagger-ui/index.html
Free, generous limits, and the ``/works?query.bibliographic=`` endpoint has good
Arabic coverage. The polite pool is joined by sending ``mailto``.
"""

from __future__ import annotations

import re
import threading

from app.core.text_utils import (
    as_int,
    clean_text,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://api.crossref.org/works"

#: Crossref indexes book front/back matter, which is never a useful hit.
JUNK_TITLES = frozenset(
    {
        "front matter",
        "back matter",
        "index",
        "contents",
        "table of contents",
        "preface",
        "foreword",
        "acknowledgments",
        "acknowledgements",
        "cover",
        "title page",
        "copyright",
        "about the author",
        "list of illustrations",
        "list of tables",
        "erratum",
        "corrigendum",
        "editorial board",
        "erratum:",
    }
)

#: Suffixes Crossref appends to a book-level DOI to address one part of it.
_PART_SUFFIXES = (
    ".fmatter",
    ".fmatter",
    ".index",
    ".toc",
    ".cover",
    ".frontmatter",
    ".backmatter",
    ".epub",
    ".pdf",
)


def _is_junk(title: str, doi: str) -> bool:
    if not title or title.strip().lower().rstrip(".:") in JUNK_TITLES:
        return True
    lowered = doi.lower()
    # `10.xxxx/12345.fmatter` is a fragment of another record already in the list.
    return any(lowered.endswith(suffix) for suffix in _PART_SUFFIXES)


@register
class CrossrefProvider(BaseProvider):
    provider_id = "crossref"
    display_name = "Crossref"
    categories = (Category.ARTICLE,)
    weight = 60  # ranked last: it is the metadata safety net, not a discovery tool
    homepage = "https://www.crossref.org"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        params: dict[str, object] = {
            "query.bibliographic": query.text,
            "rows": min(query.per_source, 30),
            # Only fields the /works route actually exposes may be selected;
            # an unknown name makes Crossref reject the whole request with 400.
            "select": (
                "DOI,title,abstract,author,issued,container-title,publisher,type,"
                "page,volume,issue,is-referenced-by-count,URL"
            ),
        }
        if self.config.contact_email:
            params["mailto"] = self.config.contact_email
        if query.year_from or query.year_to:
            filters = []
            if query.year_from:
                filters.append(f"from-pub-date:{query.year_from}-01-01")
            if query.year_to:
                filters.append(f"until-pub-date:{query.year_to}-12-31")
            if filters:
                params["filter"] = ",".join(filters)

        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        items = (payload.get("message") or {}).get("items") or []
        out: list[Result] = []
        for item in items:
            mapped = self._to_result(item)
            if mapped is not None:
                out.append(mapped)
        return out

    # -- mapping ----------------------------------------------------------
    def _to_result(self, item: dict) -> Result | None:
        titles = item.get("title") or []
        title = clean_text(titles[0] if titles else "")
        doi = clean_text(item.get("DOI")).lower()
        if _is_junk(title, doi):
            return None

        subtitle = clean_text((item.get("subtitle") or [""])[0])
        if subtitle and subtitle.lower() not in title.lower():
            title = f"{title}: {subtitle}"

        doi = clean_text(item.get("DOI")).lower()
        authors = []
        for person in item.get("author") or []:
            name = clean_text(" ".join(filter(None, [person.get("given"), person.get("family")])))
            if not name:
                name = clean_text(person.get("name"))
            if name:
                authors.append(name)

        containers = item.get("container-title") or []
        venue = clean_text(containers[0] if containers else "")
        subjects = [clean_text(s) for s in (item.get("subject") or [])[:6] if s]

        issued = (item.get("issued") or {}).get("date-parts") or [[]]
        year = as_int((issued[0] or [None])[0]) if issued and issued[0] else None

        landing = clean_text(item.get("URL")) or (f"https://doi.org/{doi}" if doi else "")

        # Crossref ``link`` entries are often publisher text-mining endpoints that
        # require a licence, so they are offered as landing pages, never as files.
        downloads = []
        for link in (item.get("link") or [])[:2]:
            url = clean_text(link.get("URL"))
            if url:
                downloads.append(
                    target(url, DownloadFormat.HTML, label="Publisher full text", open_access=True)
                )
        if landing:
            downloads.append(
                target(landing, DownloadFormat.HTML, label="DOI", open_access=False)
            )

        identifiers: dict[str, str] = {"doi": doi} if doi else {}
        issn = [clean_text(i) for i in (item.get("ISSN") or []) if i]
        if issn:
            identifiers["issn"] = ", ".join(issn)

        return Result(
            category=Category.ARTICLE,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=year,
            abstract=truncate_words(clean_text(item.get("abstract")), 500),
            venue=venue,
            publisher=clean_text(item.get("publisher")),
            language=normalise_language(first_str(item.get("language"))),
            subjects=subjects,
            identifiers=identifiers,
            access=Access.LANDING if landing else Access.METADATA,
            downloads=downloads,
            landing_url=landing,
            citations=as_int(item.get("is-referenced-by-count")),
            pages=_first_page(item.get("page")),
            volume=clean_text(item.get("volume")),
            issue=clean_text(item.get("issue")),
            item_type=clean_text(item.get("type")).title(),
            raw=item,
        )


def _first_page(value: object) -> int | None:
    """Crossref ``page`` is a free-text range like ``"145-162"`` or ``"e145"``.

    ``Result.pages`` is a single integer, so only a leading plain number is
    kept; a range or an article ID leaves the field empty rather than
    truncating it into something that would read as a real page.
    """
    text = clean_text(value)
    if not text:
        return None
    head = re.split(r"[-–—,]", text, maxsplit=1)[0].strip()
    return as_int(head)


def first_str(values: object) -> str:
    if isinstance(values, (list, tuple)):
        return clean_text(values[0]) if values else ""
    return clean_text(values)
