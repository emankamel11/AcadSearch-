"""Thèses.fr — French theses and dissertations.

Thèses.fr (https://www.theses.fr) is the French national portal for
doctoral and habilitation theses. It references theses from French
universities and provides links to full texts when available.

This provider searches Thèses.fr and normalises results to the app's
Result model.
"""

from __future__ import annotations

import re
import threading
from urllib.parse import quote_plus

from app.core.text_utils import clean_text, truncate_words
from app.models import (
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

SEARCH_URL = "https://www.theses.fr/"

_TAG_RE = re.compile(r"<[^>]+>")


@register
class ThesesFrProvider(BaseProvider):
    provider_id = "thesesfr"
    display_name = "Thèses.fr (أطروحات فرنسية)"
    categories = (Category.RESEARCH,)
    weight = 38
    homepage = "https://www.theses.fr/"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = query.text.strip()
        if not text:
            return []

        if cancel is not None and cancel.is_set():
            return []

        wanted = max(10, min(query.per_source, 40))

        # Thèses.fr search endpoint (JSON-like / API style)
        params = {
            "q": text,
            "format": "json",
        }

        try:
            payload = self.http.get_json(
                SEARCH_URL + "api/v1/theses/recherche/",
                params=params,
                provider=self.provider_id,
                cancel=cancel,
            )
        except ProviderError:
            # Try alternative search path if API shape differs
            try:
                params_alt = {"q": text}
                payload = self.http.get_json(
                    SEARCH_URL + "api/v1/theses/",
                    params=params_alt,
                    provider=self.provider_id,
                    cancel=cancel,
                )
            except ProviderError:
                raise
        except Exception as exc:
            raise ProviderError(
                f"thesesfr: {type(exc).__name__}", kind="error"
            ) from exc

        if cancel is not None and cancel.is_set():
            return []

        items = []
        if isinstance(payload, dict):
            items = (
                payload.get("theses")
                or payload.get("items")
                or payload.get("results")
                or payload.get("response")
                or []
            )
            if isinstance(items, dict):
                items = items.get("docs") or items.get("items") or []
        elif isinstance(payload, list):
            items = payload

        out: list[Result] = []
        for item in items[:wanted]:
            built = self._to_result(item)
            if built is not None:
                out.append(built)
                if len(out) >= wanted:
                    break
        return out

    def _to_result(self, item: dict) -> Result | None:
        if not isinstance(item, dict):
            return None

        title = clean_text(
            item.get("titre")
            or item.get("title")
            or item.get("titrePrincipal")
            or item.get("intitule")
            or ""
        )
        if not title:
            return None

        authors = []
        for key in ("auteurs", "auteur", "authors", "author", "directeurs"):
            val = item.get(key)
            if isinstance(val, list):
                for a in val:
                    if isinstance(a, str):
                        authors.append(clean_text(a))
                    elif isinstance(a, dict):
                        authors.append(
                            clean_text(
                                a.get("nom")
                                or a.get("name")
                                or a.get("prenomNom")
                                or a.get("label")
                                or ""
                            )
                        )
            elif isinstance(val, str):
                authors.append(clean_text(val))
            elif isinstance(val, dict):
                authors.append(
                    clean_text(val.get("nom") or val.get("name") or val.get("label") or "")
                )
        authors = [a for a in authors if a]

        year = None
        for key in ("dateSoutenue", "date", "year", "annee", "dateSoutenance"):
            val = item.get(key)
            if val:
                m = re.search(r"(\d{4})", str(val))
                if m:
                    year = int(m.group(1))
                    break

        ident = clean_text(
            item.get("id")
            or item.get("numSujet")
            or item.get("numeroNationalThese")
            or ""
        )

        url = clean_text(item.get("url") or item.get("lien") or item.get("permalink") or "")
        if not url and ident:
            url = f"https://www.theses.fr/{ident}"

        abstract = clean_text(
            item.get("resume")
            or item.get("abstract")
            or item.get("description")
            or ""
        )
        abstract = truncate_words(_strip_html(abstract), 90)

        discipline = clean_text(item.get("discipline") or item.get("domaine") or "")
        etab = clean_text(item.get("etablissement") or item.get("university") or "")
        venue = discipline or etab

        language = clean_text(item.get("langue") or item.get("language") or "fr")

        identifiers: dict[str, str] = {"source": self.provider_id}
        if ident:
            identifiers["thesesfr"] = ident
        doi = clean_text(item.get("doi") or "")
        if doi:
            identifiers["doi"] = doi

        downloads = []
        pdf_url = clean_text(item.get("pdf") or item.get("urlPdf") or item.get("fichier") or "")
        if pdf_url:
            downloads.append(target(pdf_url, DownloadFormat.PDF, label="PDF", open_access=True))
        if url:
            downloads.append(target(url, DownloadFormat.HTML, label="Thèses.fr", open_access=True))

        return Result(
            category=Category.RESEARCH,
            title=title,
            source=self.provider_id,
            authors=authors[:12],
            year=year,
            abstract=abstract,
            venue=venue,
            language=language,
            identifiers=identifiers,
            downloads=downloads,
            landing_url=url or "",
        )


def _strip_html(value: str) -> str:
    if "<" not in value:
        return value
    text = _TAG_RE.sub(" ", value)
    return clean_text(text.replace("&nbsp;", " "))
