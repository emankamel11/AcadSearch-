"""Persée — French humanities and social sciences archive.

Persée (persee.fr) provides open access to many French journals in
humanities and social sciences. Results are extracted from HTML search.
"""

from __future__ import annotations

import re
import threading
from urllib.parse import urljoin

from app.core.text_utils import clean_text, truncate_words
from app.models import (
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

SEARCH_URL = "https://www.persee.fr/search"

_TAG_RE = re.compile(r"<[^>]+>")
_A_RE = re.compile(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', re.I | re.S)
_PDF_RE = re.compile(r'href=[\'"]([^\'"]+\.pdf[^\'"]*)[\'"]', re.I)


@register
class PerseeProvider(BaseProvider):
    provider_id = "persee"
    display_name = "Persée (أرشيف فرنسي)"
    categories = (Category.ARTICLE, Category.RESEARCH)
    weight = 36
    homepage = "https://www.persee.fr/"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = query.text.strip()
        if not text:
            return []

        if cancel is not None and cancel.is_set():
            return []

        wanted = max(10, min(query.per_source, 40))

        params = {"q": text}

        try:
            html = self.http.get_text(
                SEARCH_URL,
                params=params,
                provider=self.provider_id,
                cancel=cancel,
            )
        except ProviderError:
            raise
        except Exception as exc:
            raise ProviderError(f"persee: {type(exc).__name__}", kind="error") from exc

        if cancel is not None and cancel.is_set():
            return []

        out: list[Result] = []
        seen = set()

        # Look for doc links
        for m in _A_RE.finditer(html):
            href = m.group(1)
            if '/doc/' not in href:
                continue
            title = clean_text(_strip_html(m.group(2)))
            if not title or len(title) < 10:
                continue
            url = urljoin(SEARCH_URL, href)
            if url in seen:
                continue
            seen.add(url)
            # Try to find context
            start = max(0, m.start() - 200)
            end = min(len(html), m.end() + 400)
            block = html[start:end]

            authors = []
            for am in re.finditer(r'class=["\'][^"\']*(?:author|auteur)[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S):
                a = clean_text(_strip_html(am.group(1)))
                if a and len(a) < 80:
                    authors.append(a)

            year = None
            ym = re.search(r'\b(1[0-9]{3}|20[0-9]{2})\b', block)
            if ym:
                year = int(ym.group(1))

            journal = ""
            for jm in re.finditer(r'class=["\'][^"\']*(?:revue|journal|collection)[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S):
                journal = clean_text(_strip_html(jm.group(1)))
                if journal:
                    break

            pdf_url = ""
            pm = _PDF_RE.search(block)
            if pm:
                pdf_url = urljoin(SEARCH_URL, pm.group(1))

            downloads = []
            if pdf_url:
                downloads.append(target(pdf_url, DownloadFormat.PDF, label="PDF", open_access=True))
            downloads.append(target(url, DownloadFormat.HTML, label="Persée", open_access=True))

            out.append(
                Result(
                    category=Category.ARTICLE,
                    title=title,
                    source=self.provider_id,
                    authors=authors[:12],
                    year=year,
                    abstract="",
                    venue=journal or "Persée",
                    language="fr",
                    identifiers={"source": self.provider_id},
                    downloads=downloads,
                    landing_url=url,
                )
            )
            if len(out) >= wanted:
                break

        return out


def _strip_html(value: str) -> str:
    if "<" not in value:
        return value
    text = _TAG_RE.sub(" ", value)
    return clean_text(text.replace("&nbsp;", " "))
