"""Regression checks for the book sources behind a normal novel search.

What broke, and what this file pins down:

* Google Books' JSON API answered 429 for anonymous use, so the provider
  reported an error and the Books tab lost a whole source. The GData Atom feed
  still works; these checks prove the fallback triggers, parses a real feed
  entry and only offers a file for a volume Google marks as fully open.
* Internet Archive dropped real novels because their uploader left ``creator``
  empty. The rescue is deliberately narrow (books-by-language collection *and*
  the title contains the query); these checks prove it rescues the novel and
  still rejects a stray upload.
* Arabic spelling variants (أ/ا, ة/ه, ى/ي) made a "title only" search miss the
  book the user typed. Folding is checked through the real field matcher.
* ``field_empty`` was set when *one* tab was empty, so a title search with book
  hits still told the reader nothing matched. And on a score tie the landing
  copy used to outrank the downloadable one.

Run:  python -X utf8 tools/check_book_sources.py
"""

from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))

from app.core.http_client import HttpClient, ProviderError  # noqa: E402
from app.core.search_engine import _finalise, _matches_field  # noqa: E402
from app.core.text_utils import fold, fold_word, strip_arabic_definite  # noqa: E402
from app.models import (  # noqa: E402
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
    SearchResponse,
)
from app.providers.base import target  # noqa: E402
from app.providers.asjp import AsjpProvider  # noqa: E402
from app.providers.google_books import (  # noqa: E402
    GoogleBooksProvider,
    parse_gdata,
)
from app.providers.hindawi import HindawiProvider, _dotted  # noqa: E402
from app.providers.internet_archive import (  # noqa: E402
    InternetArchiveProvider,
    _mentions_words,
    _query_words,
)
from app.providers.noorbook import NoorBookProvider  # noqa: E402
from app.providers.wikisource import WikisourceProvider  # noqa: E402

FAILED: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if condition else 'FAIL'}] {name}"
          + (f" -- {detail}" if detail else ""))
    if not condition:
        FAILED.append(name)


# ---------------------------------------------------------------------------
# GData feed fixture (the shape Google actually returns)
# ---------------------------------------------------------------------------
def _entry(
    volume_id: str,
    title: str,
    *,
    creator: str = "",
    language: str = "en",
    date: str = "1905",
    identifiers: tuple[str, ...] = (),
    open_access: bool = False,
    viewability: str = "view_partial",
    with_pdf_link: bool = False,
    description: str = "",
) -> str:
    parts = [
        f"<entry>"
        f"<id>http://www.google.com/books/feeds/volumes/{volume_id}</id>"
        f"<title type='text'>{title}</title>",
        "<link rel='http://schemas.google.com/books/2008/thumbnail' "
        f"type='image/x-unknown' href='http://books.google.com/books/content?id={volume_id}"
        "&amp;printsec=frontcover&amp;img=1&amp;zoom=5&amp;edge=curl'/>",
        "<link rel='http://schemas.google.com/books/2008/info' type='text/html' "
        f"href='http://books.google.com/books?id={volume_id}'/>",
    ]
    if with_pdf_link:
        parts.append(
            "<link rel='http://schemas.google.com/books/2008/pdfdownload' "
            f"type='application/pdf' href='http://books.google.com/books/download/"
            f"{volume_id}.pdf?id={volume_id}&amp;output=pdf'/>"
        )
    parts.append(
        f"<gbs:openAccess value='http://schemas.google.com/books/2008#"
        f"{'enabled' if open_access else 'disabled'}'/>"
        f"<gbs:viewability value='http://schemas.google.com/books/2008#{viewability}'/>"
    )
    if creator:
        parts.append(f"<dc:creator>{creator}</dc:creator>")
    if date:
        parts.append(f"<dc:date>{date}</dc:date>")
    if description:
        parts.append(f"<dc:description>{description}</dc:description>")
    parts.append("<dc:format>318 pages</dc:format><dc:format>book</dc:format>")
    for value in (volume_id,) + identifiers:
        parts.append(f"<dc:identifier>{value}</dc:identifier>")
    parts.append(f"<dc:language>{language}</dc:language>")
    parts.append("<dc:publisher>Test Press</dc:publisher>")
    parts.append("<dc:subject>Fiction</dc:subject>")
    parts.append("</entry>")
    return "".join(parts)


def _feed(*entries: str) -> str:
    return (
        "<?xml version='1.0' encoding='UTF-8'?>"
        "<feed xmlns='http://www.w3.org/2005/Atom' "
        "xmlns:openSearch='http://a9.com/-/spec/opensearchrss/1.0/' "
        "xmlns:gbs='http://schemas.google.com/books/2008' "
        "xmlns:gd='http://schemas.google.com/g/2005' "
        "xmlns:dc='http://purl.org/dc/terms'>"
        "<openSearch:totalResults>2</openSearch:totalResults>"
        + "".join(entries)
        + "</feed>"
    )


OPEN_ENTRY = _entry(
    "OPEN1",
    "Pride and Prejudice, Volume 2",
    creator="Jane Austen",
    identifiers=("ISBN:9781234567897",),
    open_access=True,
    viewability="view_all_pages",
    with_pdf_link=True,
)
ARABIC_ENTRY = _entry(
    "AR1",
    "ذاكرة الجسد",
    creator="أحلام مستغانمي",
    language="ar",
    date="2013-12-13",
    identifiers=("ISBN:9786144381342",),
    description="ذاكرة الجسد &amp;nbsp; رواية",
)
FEED = _feed(OPEN_ENTRY, ARABIC_ENTRY)


class FakeHttp:
    """Just enough of HttpClient for the provider's two endpoints."""

    def __init__(
        self,
        *,
        json_payload: dict | None = None,
        json_error: ProviderError | None = None,
        gdata: str = "",
    ) -> None:
        self.json_payload = json_payload or {}
        self.json_error = json_error
        self.gdata = gdata
        self.json_calls = 0
        self.text_calls = 0
        self.last_text_params: dict = {}

    def get_json(self, url, params=None, **kwargs):
        self.json_calls += 1
        if self.json_error is not None:
            raise self.json_error
        return self.json_payload

    def get_text(self, url, params=None, **kwargs):
        self.text_calls += 1
        self.last_text_params = dict(params or {})
        return self.gdata


def provider(http: FakeHttp, *, key: str = "") -> GoogleBooksProvider:
    return GoogleBooksProvider(http=http, config=SimpleNamespace(google_books_key=key))


# ---------------------------------------------------------------------------
# checks
# ---------------------------------------------------------------------------
def check_gdata_parser() -> None:
    print("== GData Atom parser ==")
    items = parse_gdata(FEED)
    check("both entries parsed", len(items) == 2, str(len(items)))
    if len(items) != 2:
        return

    open_book, arabic_book = items

    check("title survives", open_book.title == "Pride and Prejudice, Volume 2",
          open_book.title)
    check("author survives", open_book.authors == ["Jane Austen"],
          str(open_book.authors))
    check("year comes from dc:date", open_book.year == 1905, str(open_book.year))
    check("page count comes from dc:format", open_book.pages == 318,
          str(open_book.pages))
    check("ISBN is cleaned of its prefix",
          open_book.identifiers.get("isbn") == "9781234567897",
          str(open_book.identifiers))
    check("volume id is kept", open_book.identifiers.get("gbid") == "OPEN1",
          str(open_book.identifiers))
    check("open + full view is downloadable", open_book.access is Access.DOWNLOAD,
          open_book.access.value)
    check("PDF target is open access",
          any(t.fmt is DownloadFormat.PDF and t.open_access
              for t in open_book.downloads),
          str([t.fmt.value for t in open_book.downloads]))
    check("every link is https",
          all(t.url.startswith("https://") for t in open_book.downloads),
          str([t.url[:40] for t in open_book.downloads]))
    check("cover is https and enlarged",
          (open_book.cover_url or "").startswith("https://")
          and "zoom=2" in (open_book.cover_url or ""),
          (open_book.cover_url or "")[:80])

    check("Arabic language is normalised", arabic_book.language == "ar",
          arabic_book.language)
    check("Arabic year parsed", arabic_book.year == 2013, str(arabic_book.year))
    check("copyrighted volume is a landing page, not a download",
          arabic_book.access is Access.LANDING, arabic_book.access.value)
    check("no PDF is promised for a closed volume",
          not any(t.fmt is DownloadFormat.PDF for t in arabic_book.downloads),
          str([t.fmt.value for t in arabic_book.downloads]))
    check("HTML entities are removed from the description",
          "nbsp" not in arabic_book.abstract, arabic_book.abstract)

    check("an HTML error page does not crash the parser",
          parse_gdata("<html><body>429</body></html>") == [])
    check("empty text is not an error", parse_gdata("") == [])


def check_fallback() -> None:
    print()
    print("== Google Books fallback to the feed ==")
    rate_limited = ProviderError("quota", kind="rate_limited", status=429)
    http = FakeHttp(json_error=rate_limited, gdata=FEED)
    items = provider(http).fetch(
        SearchQuery(text="ذاكرة الجسد", language="ar", per_source=40)
    )
    check("429 triggers the Atom fallback", http.text_calls == 1,
          f"text calls={http.text_calls}")
    check("fallback returns the feed records", len(items) == 2, str(len(items)))
    check("the Arabic record is ranked first for an Arabic query",
          bool(items) and items[0].language == "ar",
          items[0].language if items else "none")

    http = FakeHttp(json_payload={}, gdata=FEED)
    items = provider(http).fetch(SearchQuery(text="x", per_source=10))
    check("an empty keyless JSON answer also falls back",
          http.text_calls == 1 and len(items) == 2,
          f"text calls={http.text_calls}, items={len(items)}")

    http = FakeHttp(json_error=rate_limited, gdata=FEED)
    items = provider(http, key="configured").fetch(SearchQuery(text="x", per_source=10))
    check("an exhausted personal key also falls back instead of failing",
          http.text_calls == 1 and len(items) == 2,
          f"text calls={http.text_calls}, items={len(items)}")

    http = FakeHttp(json_error=ProviderError("offline", kind="offline"))
    try:
        provider(http).fetch(SearchQuery(text="x", per_source=10))
    except ProviderError as exc:
        check("an offline error is not retried through the feed",
              exc.kind == "offline" and http.text_calls == 0, exc.kind)
    else:
        check("an offline error is not retried through the feed", False, "no error")

    page1 = _feed(*[_entry(f"A{i}", f"Book {i}") for i in range(1, 21)])
    page2 = _feed(*[_entry(f"B{i}", f"Book {i}") for i in range(21, 41)])

    class PagedHttp(FakeHttp):
        def get_text(self, url, params=None, **kwargs):
            self.text_calls += 1
            start = int((params or {}).get("start-index", 1))
            return page1 if start == 1 else page2

    paged = PagedHttp(json_error=rate_limited)
    items = provider(paged).fetch(SearchQuery(text="book", per_source=40))
    check("the feed is paged with start-index",
          paged.text_calls == 2 and len(items) == 40,
          f"calls={paged.text_calls}, items={len(items)}")


def check_ia_query_variants() -> None:
    """A reader's spelling must not hide the book on archive.org.

    Uploaded scans disagree on final ة/ه/ا and on ى/ي, and readers add
    "رواية"/"كتاب" to the query. The Solr query has to cover those, otherwise
    "رواية نادية يوسف السباعي" finds nothing while the PDF sits right there.
    """
    print()
    print("== Internet Archive Arabic query variants ==")
    provider = InternetArchiveProvider.__new__(InternetArchiveProvider)

    title = provider._title_query("رواية نادية يوسف السباعي")
    check("a leading 'رواية' is not required in the title",
          "رواية نادية يوسف السباعي\") OR" in title and
          " AND رواية" not in title, title)
    check("نادية is also searched as ناديا", "ناديا" in title, title)
    check("the exact phrase is still tried first",
          title.startswith('(title:("رواية نادية يوسف السباعي")'), title)
    check("only texts are searched", title.endswith("AND mediatype:texts"), title)

    broad = provider._broad_query("يوسف السباعي")
    check("the author field is searched as well", "creator:(" in broad, broad)
    check("author spellings vary too", "السباعى" in broad, broad)

    single = provider._title_query("نادية")
    check("one-word searches expand their endings",
          "ناديه" in single and "ناديا" in single, single)

    check("hamza forms are folded for matching",
          _query_words("أرض النفاق") == ("ارض", "نفاق"),
          str(_query_words("أرض النفاق")))
    check("ة/ا endings match in the rescue gate",
          _mentions_words("ناديا يوسف السباعي", _query_words("نادية يوسف")))


def check_ia_rescue() -> None:
    print()
    print("== Internet Archive no-creator rescue ==")
    words = _query_words("ذاكرة الجسد")
    check("query words are folded", words == ("ذاكره", "جسد"), str(words))
    check("an Arabic title matches across spelling variants",
          _mentions_words("ذاكره الجسد", words))

    keep = InternetArchiveProvider._is_scrape(
        "ذاكرة الجسد", [], "diwan_1", {"booksbylanguage_arabic"}, words
    )
    check("a no-creator novel in booksbylanguage is kept", keep is False, str(keep))

    rescued_by_description = InternetArchiveProvider._is_scrape(
        "365lionsyeleqbk", [], "365lionsyeleqbk",
        {"booksbylanguage_arabic"}, words, "ذاكرة الجسد رواية",
    )
    check("a transliterated upload is kept when its description names the book",
          rescued_by_description is False, str(rescued_by_description))

    dropped = InternetArchiveProvider._is_scrape(
        "ذاكرة الجسد", [], "diwan_1", set(), words
    )
    check("the same record outside that collection is still dropped",
          dropped is True, str(dropped))

    unrelated = InternetArchiveProvider._is_scrape(
        "كورس تعلم البرمجة", [], "diwan_2", {"booksbylanguage_arabic"}, words
    )
    check("an unrelated no-creator upload is not rescued", unrelated is True,
          str(unrelated))

    report = InternetArchiveProvider._is_scrape(
        "ذاكرة الجسد", [], "nasa_techdoc_1", {"booksbylanguage_arabic"}, words
    )
    check("a report-shaped identifier is still rejected", report is True, str(report))

    with_author = InternetArchiveProvider._is_scrape(
        "ذاكرة الجسد", ["أحلام مستغانمي"], "diwan_3", set(), ()
    )
    check("a normal authored record is unaffected", with_author is False,
          str(with_author))

    no_words = InternetArchiveProvider._is_scrape(
        "ذاكرة الجسد", [], "diwan_4", {"booksbylanguage_arabic"}, ()
    )
    check("the rescue needs a query to prove the match", no_words is True,
          str(no_words))


def check_arabic_field_match() -> None:
    print()
    print("== Arabic spelling variants in 'title only' ==")
    check("fold unifies hamza forms", fold_word("الأسود") == fold_word("الاسود"),
          f"{fold_word('الأسود')} / {fold_word('الاسود')}")
    check("fold unifies ة and ه", fold("ذاكرة") == fold("ذاكره"))
    check("the article is stripped", strip_arabic_definite("الحرافيش") == "حرافيش")

    item = Result(category=Category.BOOK, title="الأسود يليق بك", source="google_books")
    check("a title typed with ا matches a title written with أ",
          _matches_field(item, "title", "الاسود يليق بك"))
    item = Result(category=Category.BOOK, title="ذاكره الجسد", source="google_books")
    check("a title typed with ة matches a title written with ه",
          _matches_field(item, "title", "ذاكرة الجسد"))


def check_field_empty() -> None:
    print()
    print("== field_empty is about the whole search, not one tab ==")
    book = Result(
        category=Category.BOOK, title="Deep Learning", source="open_library",
        authors=["Ian Goodfellow"],
    )
    response = _finalise(
        SearchResponse(
            query=SearchQuery(text="deep learning", field="title"),
            results={Category.BOOK: [book], Category.ARTICLE: []},
        )
    )
    check("a hit in one tab keeps field_empty False",
          response.field_empty is False and len(response.results[Category.BOOK]) == 1,
          f"empty={response.field_empty} books={len(response.results[Category.BOOK])}")

    response = _finalise(
        SearchResponse(
            query=SearchQuery(text="quantum gravity", field="title"),
            results={
                Category.BOOK: [book],
                Category.ARTICLE: [],
            },
        )
    )
    check("no hit anywhere sets field_empty True",
          response.field_empty is True
          and not any(response.results.values()),
          f"empty={response.field_empty}")


def check_download_tie_break() -> None:
    print()
    print("== a downloadable copy wins a score tie ==")
    landing = Result(
        category=Category.BOOK, title="Alpha", source="open_library",
        authors=["Author One"], access=Access.LANDING,
    )
    landing.score = 20.0
    downloadable = Result(
        category=Category.BOOK, title="Alpha", source="internet_archive",
        authors=["Author Two"], access=Access.DOWNLOAD,
        downloads=[
            target(
                "https://archive.org/download/x/book.pdf",
                DownloadFormat.PDF,
                label="PDF",
                open_access=True,
            )
        ],
    )
    downloadable.score = 20.0
    response = _finalise(
        SearchResponse(
            query=SearchQuery(text="alpha"),
            results={Category.BOOK: [landing, downloadable]},
        )
    )
    titles = [(item.authors[0], item.access.value)
              for item in response.results[Category.BOOK]]
    check("the file copy is first on an otherwise equal score",
          titles and titles[0][1] == "download", str(titles))
    check("both copies stay reachable", len(titles) == 2, str(len(titles)))


def check_noorbook_cards() -> None:
    """The revived Noor-Book search: cards, review links and the PDF handshake."""
    print()
    print("== Noor-Book HTML search and PDF handshake ==")

    class FakeHttp:
        def __init__(self) -> None:
            self.text_urls: list[str] = []
            self.post_urls: list[str] = []

        def get_text(self, url, params=None, **kwargs):
            self.text_urls.append(url)
            if "noor-book.com" in url and url.rstrip("/") == "https://www.noor-book.com":
                return NOOR_SEARCH_HTML
            return NOOR_BOOK_HTML

        def post_text(self, url, data=None, **kwargs):
            self.post_urls.append(url)
            if "check_user" in url:
                return '{"osf":"session-token","ls":"ls-token"}'
            return (
                "<div class='download_links'><h3><a href="
                "'/book/internal_download/abc123/1/session-token'>"
                "رابط التحميل (PDF)</a></h3></div>"
            )

    http = FakeHttp()
    items = NoorBookProvider(http).fetch(
        SearchQuery(text="بداية ونهاية", categories={Category.BOOK}, per_source=10)
    )
    check("book cards are parsed", len(items) == 1, str(len(items)))
    if not items:
        return
    book = items[0]
    check("title comes from the item-name heading", book.title == "بداية ونهاية", book.title)
    check("author comes from schema.org markup", book.authors == ["نجيب محفوظ"],
          str(book.authors))
    check("landing page is the book page", book.landing_url.endswith("-pdf"),
          book.landing_url)
    check("cover is made absolute",
          (book.cover_url or "").startswith("https://www.noor-book.com/publice/"),
          book.cover_url or "")
    check("a review card is not offered as a book",
          all("/book/review/" not in item.landing_url for item in items),
          str([item.landing_url for item in items]))
    check("the landing page becomes a real PDF",
          any(t.fmt is DownloadFormat.PDF for t in book.downloads),
          str([t.fmt.value for t in book.downloads]))
    check("the PDF is the internal download URL",
          any("internal_download/abc123" in t.url for t in book.downloads),
          str([t.url for t in book.downloads]))
    check("a resolved PDF marks the card downloadable",
          book.access is Access.DOWNLOAD, book.access.value)
    check("the handshake ran check_user then get_download_links",
          any("check_user" in url for url in http.post_urls)
          and any("get_download_links" in url for url in http.post_urls),
          str(http.post_urls))


def check_safahat_search() -> None:
    """Hindawi moved to safahat.org: HTML search, direct Hindawi files."""
    print()
    print("== Hindawi / Safahat HTML search ==")
    check("spaces become dots", _dotted("بداية ونهاية") == "بداية.ونهاية",
          _dotted("بداية ونهاية"))

    class FakeHttp:
        def __init__(self) -> None:
            self.urls: list[str] = []

        def get_text(self, url, params=None, **kwargs):
            self.urls.append(url)
            return SAFAHAT_HTML

    http = FakeHttp()
    items = HindawiProvider(http).fetch(
        SearchQuery(text="بداية ونهاية", categories={Category.BOOK}, per_source=10)
    )
    check("title search endpoint is used",
          "/search/title/" in http.urls[0], http.urls[0])
    check("the dotted query is percent-encoded",
          "%D8%A8%D8%AF%D8%A7%D9%8A%D8%A9.%D9%88%D9%86%D9%87%D8%A7%D9%8A%D8%A9" in http.urls[0],
          http.urls[0])
    check("one book parsed", len(items) == 1, str(len(items)))
    if items:
        book = items[0]
        check("title parsed", book.title == "بداية ونهاية", book.title)
        check("author parsed", book.authors == ["نجيب محفوظ"], str(book.authors))
        check("Arabic script sets the language", book.language == "ar", book.language)
        check("a free PDF is offered",
              any(t.url == "https://downloads.hindawi.org/books/81514680.pdf"
                  and t.fmt is DownloadFormat.PDF for t in book.downloads),
              str([t.url for t in book.downloads]))
        check("an EPUB is offered too",
              any(t.fmt is DownloadFormat.EPUB for t in book.downloads),
              str([t.fmt.value for t in book.downloads]))
        check("card is downloadable", book.access is Access.DOWNLOAD, book.access.value)

    http = FakeHttp()
    HindawiProvider(http).fetch(
        SearchQuery(text="نجيب محفوظ", field="author", categories={Category.BOOK})
    )
    check("an author search uses the contributor index",
          "/search/contributor/" in http.urls[0] and "/search/title/" not in http.urls[0],
          str(http.urls))

    http = FakeHttp()
    HindawiProvider(http).fetch(
        SearchQuery(text="بداية ونهاية", field="title", categories={Category.BOOK})
    )
    check("a title search does not fall through to contributors",
          len(http.urls) == 1 and "/search/contributor/" not in http.urls[0],
          str(http.urls))


def check_post_text() -> None:
    """HttpClient must be able to POST an HTML form, not only JSON."""
    print()
    print("== HttpClient.post_text ==")

    class RecorderSession:
        def __init__(self) -> None:
            self.calls: list[tuple[str, dict, dict]] = []
            self.headers: dict[str, str] = {}

        def post(self, url, data=None, headers=None, timeout=None):
            self.calls.append((url, dict(data or {}), dict(headers or {})))
            return SimpleNamespace(status_code=200, text="form-ok", headers={})

    from app.config import get_config

    client = HttpClient(get_config())
    recorder = RecorderSession()
    client._local.session = recorder
    text = client.post_text(
        "https://example.test/form",
        {"Title": "بداية ونهاية"},
        provider="check",
        headers={"X-Requested-With": "XMLHttpRequest"},
    )
    check("the response text is returned", text == "form-ok", text)
    check("the body is sent as form data, not JSON",
          recorder.calls and recorder.calls[0][1] == {"Title": "بداية ونهاية"},
          str(recorder.calls[0][1] if recorder.calls else None))
    check("extra headers are merged",
          recorder.calls and recorder.calls[0][2].get("X-Requested-With")
          == "XMLHttpRequest",
          str(recorder.calls[0][2] if recorder.calls else None))


NOOR_SEARCH_HTML = """
<div class="row book_rows">
    <div class="book-restult" itemscope itemtype="http://schema.org/Book">
        <a class="img-a" title="بداية ونهاية" href="/كتاب-بداية-ونهاية-pdf">
            <img itemprop="image" src="/publice/covers_cache_jpg/6/d/7/2/937.jpg.jpg">
        </a>
        <a href="/كتاب-بداية-ونهاية-pdf"><h3 itemprop="name">بداية ونهاية</h3></a>
        <span itemprop="author" itemscope itemtype="http://schema.org/Person">
            <a itemprop="url" title="نجيب محفوظ" href="/كتب-نجيب-محفوظ-pdf">
                <p itemprop="name">نجيب محفوظ</p></a>
        </span>
    </div>
    <div class="book-restult" itemscope itemtype="http://schema.org/Book">
        <a href="/book/review/517857"><h3 itemprop="name">بداية ونهاية</h3></a>
        <span itemprop="author"><a href="/u/someone"><p itemprop="name">مراجع</p></a></span>
    </div>
</div>
"""

NOOR_BOOK_HTML = """
<html><body><script>
var csrf_token = 'csrf123';
var crypto_token = 'crypto123';
var book_hash = 'hash123';
var b_h = 'signed123';
</script></body></html>
"""

SAFAHAT_HTML = """
<div class="searchResults">
    <h2>نتائج البحث</h2>
    <h2>الكتب</h2>
    <ul class="list">
        <li>
            <a href='/books/81514680/'>بداية ونهاية</a>
                &middot;
بقلم <a href='/contributors/71616385/'>نجيب محفوظ</a>
        </li>
    </ul>
</div>
<!--searchResults-->
"""

ASJP_HOME_HTML = """
<form method="post" action="https://asjp.cerist.dz/en/rechercheGeneral">
    <input type="hidden" name="_token" value="csrf-token-123">
    <input id="recherche" name="rechercheG" type="text">
</form>
"""

ASJP_SEARCH_HTML = """
<div class="col-md-12">
<div class="full-width-media-text" id="resultatRecherche">
<table class="table">
<thead><tr><th scope="col" colspan="12"><h4 style="font-size: 1em;">
<a href="https://asjp.cerist.dz/en/article/9125"> توظيف السيرة الشعبية في الرواية العربية المعاصرة رواية
<span Class="surligne1"> ملحمة</span> <span Class="surligne1"> الحرافيش</span> أنموذجا. </a>
</h4></th></tr></thead>
<tbody>
<tr><th scope="row"> الملخص </th><td><p>إن المتأمل في تاريخ الرواية العربية يدرك
<oooo class="point">....</oooo> أن هذا الفن فن مستحدث.
<a class="read" id="Ar"><b> اقرأ المزيد</b></a></p></td></tr>
<tr><th scope="row"><b> كلمات مفتاحية </b></th><td><p>السيرة الشعبية - الرواية العربية - التراث.</p></td></tr>
<tr><th scope="row"><b> المؤلف </b></th><td><p> لواتي وردة , </p></td></tr>
<tr><td></td><td><a class="dateart"><b> تاريخ النشر: </b>
<class class="sss"> 06-02-2017</class>
<span class="btnText"> ص 271-289. </span></a></td></tr>
</tbody></table>
</div>
<div class="full-width-media-text" id="resultatRecherche">
<table class="table">
<thead><tr><th scope="col" colspan="12"><h4>
<a href="https://asjp.cerist.dz/en/article/235830"> الأبعاد الجمالية لتوظيف الموروث الشعبي </a>
</h4></th></tr></thead>
<tbody>
<tr><th scope="row"> Résumé </th><td><p>Cet article étudie le folklore dans le roman.</p></td></tr>
<tr><th scope="row"><b> Mots clés </b></th><td><p>folklore - roman</p></td></tr>
<tr><th scope="row"><b> Auteur </b></th><td><p> Martin Camille , </p></td></tr>
<tr><td></td><td><a class="dateart"><b> Date de publication: </b>
<class class="sss"> 15-03-2019</class>
<span class="btnText"> p. 10-20. </span></a></td></tr>
</tbody></table>
</div>
</div>
"""

ASJP_ARTICLE_HTML = """
<html><head>
<meta name="citation_publisher" content="ASJP">
<meta name="citation_title" content="توظيف السيرة الشعبية في الرواية العربية المعاصرة رواية ملحمة الحرافيش أنموذجا.">
<meta name="citation_doi" content="10.1234/asjp.9125">
<meta name="citation_language" content="ar">
<meta name="citation_pdf_url" content="https://asjp.cerist.dz/en/downArticle/238/6/1/9125">
<meta name="citation_firstpage" content="271">
<meta name="citation_lastpage" content="289">
<meta name="citation_author" content="لواتي, وردة">
<meta name="citation_publication_date" content="2017/02/06">
<meta name="citation_journal_title" content="مجلة إشكالات في اللغة و الأدب">
<meta name="citation_volume" content="6">
<meta name="citation_issue" content="1">
<meta name="citation_issn" content="2600-6634">
</head><body></body></html>
"""

WIKISOURCE_SEARCH_JSON = {
    "query": {
        "search": [
            {"title": "كليلة ودمنة", "snippet": "كتاب <span>كليلة ودمنة</span>", "size": 2789},
            {"title": "كليلة ودمنة/باب الفحص عن أمر دمنة", "snippet": "باب", "size": 33171},
            {"title": "مجلة الرسالة/العدد 999/مقال", "snippet": "مقال", "size": 9701},
            {"title": "ألف ليلة وليلة", "snippet": "حكايات", "size": 1153},
            {"title": "مخطوطة بلا بيانات", "snippet": "نص قديم", "size": 500},
        ]
    }
}

WIKISOURCE_PROPS_JSON = {
    "query": {
        "normalized": [],
        "pages": [
            {
                "title": "كليلة ودمنة",
                "pageprops": {"wikibase_item": "Q12064127"},
                "extract": "كتاب كليلة ودمنة من أشهر كتب الأدب العالمي.",
            },
            {"title": "ألف ليلة وليلة", "pageprops": {"wikibase_item": "Q8258"}},
        ],
    }
}

WIKIDATA_WORKS_JSON = {
    "entities": {
        "Q12064127": {
            "labels": {"ar": {"value": "كليلة ودمنة"}},
            "claims": {
                "P50": [{"mainsnak": {"datavalue": {"value": {"id": "Q1060637"}}}}],
                "P577": [{"mainsnak": {"datavalue": {"value": {"time": "+0750-00-00T00:00:00Z"}}}}],
                "P1104": [{"mainsnak": {"datavalue": {"value": {"amount": "+318"}}}}],
            },
        },
        "Q8258": {
            "labels": {"ar": {"value": "ألف ليلة وليلة"}},
            "claims": {
                "P50": [{"mainsnak": {"datavalue": {"value": {"id": "Q2818964"}}}}],
            },
        },
    }
}

WIKIDATA_AUTHORS_JSON = {
    "entities": {
        "Q1060637": {"labels": {"ar": {"value": "عبد الله بن المقفع"}}},
        "Q2818964": {"labels": {"ar": {"value": "مؤلف مجهول"}}},
    }
}


def check_asjp_search() -> None:
    """ASJP: CSRF form search, card fields and citation-meta PDF."""
    print()
    print("== ASJP Algerian journals ==")

    class FakeHttp:
        def __init__(self, *, home: str = ASJP_HOME_HTML) -> None:
            self.home = home
            self.get_calls: list[tuple[str, dict]] = []
            self.post_calls: list[tuple[str, dict]] = []

        def get_text(self, url, params=None, **kwargs):
            self.get_calls.append((url, kwargs))
            if url.rstrip("/") == "https://asjp.cerist.dz/en":
                return self.home
            if "article/9125" in url:
                return ASJP_ARTICLE_HTML
            return "<html><head></head><body>no metadata</body></html>"

        def post_text(self, url, data=None, **kwargs):
            self.post_calls.append((url, dict(data or {})))
            return ASJP_SEARCH_HTML

    http = FakeHttp()
    items = AsjpProvider(http).fetch(
        SearchQuery(text="ملحمة الحرافيش", categories={Category.ARTICLE}, per_source=10)
    )
    check("the home page is fetched uncached for the token",
          http.get_calls and http.get_calls[0][0].rstrip("/") == "https://asjp.cerist.dz/en"
          and http.get_calls[0][1].get("use_cache") is False,
          str(http.get_calls[:1]))
    check("the search posts the token and the query",
          http.post_calls
          and http.post_calls[0][0] == "https://asjp.cerist.dz/en/rechercheGeneral"
          and http.post_calls[0][1].get("_token") == "csrf-token-123"
          and http.post_calls[0][1].get("rechercheG") == "ملحمة الحرافيش",
          str(http.post_calls[:1]))
    check("both result cards are parsed", len(items) == 2, str(len(items)))
    if not items:
        return
    arabic, french = items

    check("title is cleaned of highlight spans",
          arabic.title == "توظيف السيرة الشعبية في الرواية العربية المعاصرة رواية ملحمة الحرافيش أنموذجا.",
          arabic.title)
    check("the author is swapped from 'family, given'",
          arabic.authors == ["وردة لواتي"], str(arabic.authors))
    check("the abstract keeps the text around the fold",
          "فن مستحدث" in arabic.abstract
          and "اقرأ المزيد" not in arabic.abstract
          and "<" not in arabic.abstract,
          arabic.abstract)
    check("keywords become subjects",
          "السيرة الشعبية" in arabic.subjects and "التراث" in arabic.subjects,
          str(arabic.subjects))
    check("the year comes from the card date", arabic.year == 2017, str(arabic.year))
    check("the page range comes from citation meta", arabic.pages == 19, str(arabic.pages))
    check("the journal comes from citation meta",
          arabic.venue == "مجلة إشكالات في اللغة و الأدب", arabic.venue)
    check("volume and issue are kept",
          arabic.volume == "6" and arabic.issue == "1",
          f"{arabic.volume}/{arabic.issue}")
    check("DOI and ISSN are kept",
          arabic.identifiers.get("doi") == "10.1234/asjp.9125"
          and arabic.identifiers.get("issn") == "2600-6634",
          str(arabic.identifiers))
    check("the real PDF is offered first",
          arabic.downloads
          and arabic.downloads[0].fmt is DownloadFormat.PDF
          and arabic.downloads[0].url.endswith("/downArticle/238/6/1/9125"),
          str([(d.fmt.value, d.url) for d in arabic.downloads]))
    check("an enriched card is downloadable",
          arabic.access is Access.DOWNLOAD, arabic.access.value)

    check("French labels are understood",
          french.abstract.startswith("Cet article")
          and french.authors == ["Martin Camille"]
          and french.year == 2019
          and french.pages == 11,
          f"{french.abstract[:30]} | {french.authors} | {french.year} | {french.pages}")
    check("a card without metadata stays a landing page",
          french.access is Access.LANDING
          and all(t.fmt is not DownloadFormat.PDF for t in french.downloads),
          french.access.value)

    http = FakeHttp(home="<html><body>no form</body></html>")
    items = AsjpProvider(http).fetch(SearchQuery(text="ملحمة الحرافيش"))
    check("a missing token stops before the POST", items == [] and not http.post_calls,
          f"items={len(items)} posts={len(http.post_calls)}")


def check_wikisource_search() -> None:
    """Wikisource: main-namespace search, Wikidata metadata and EPUB export."""
    print()
    print("== Arabic Wikisource public-domain books ==")

    class FakeHttp:
        def __init__(self) -> None:
            self.calls: list[tuple[str, dict]] = []

        def get_json(self, url, params=None, **kwargs):
            params = dict(params or {})
            self.calls.append((url, params))
            if "wikisource.org" in url:
                if params.get("list") == "search":
                    return WIKISOURCE_SEARCH_JSON
                if "pageprops" in str(params.get("prop", "")):
                    return WIKISOURCE_PROPS_JSON
                return {}
            if "wikidata.org" in url:
                if "claims" in str(params.get("props", "")):
                    return WIKIDATA_WORKS_JSON
                return WIKIDATA_AUTHORS_JSON
            return {}

    http = FakeHttp()
    items = WikisourceProvider(http).fetch(
        SearchQuery(text="كليلة ودمنة", categories={Category.BOOK}, per_source=10)
    )
    check("subpages and magazine issues are dropped",
          len(items) == 3 and all("/" not in item.title for item in items),
          str([item.title for item in items]))
    search_call = next(
        (params for url, params in http.calls if params.get("list") == "search"), {}
    )
    check("search stays in the main namespace",
          search_call.get("srnamespace") == 0, str(search_call))
    check("search asks for a JSON v2 answer",
          search_call.get("format") == "json"
          and search_call.get("formatversion") == 2,
          str(search_call))
    if len(items) < 2:
        return
    kalila, nights, orphan = items

    check("a clean lead extract replaces the raw snippet",
          kalila.abstract == "كتاب كليلة ودمنة من أشهر كتب الأدب العالمي.", kalila.abstract)
    check("the author label is resolved from Wikidata",
          kalila.authors == ["عبد الله بن المقفع"], str(kalila.authors))
    check("the publication year is parsed from P577",
          kalila.year == 750, str(kalila.year))
    check("the page count comes from P1104", kalila.pages == 318, str(kalila.pages))
    check("a Wikidata id is kept",
          kalila.identifiers.get("wikidata") == "Q12064127", str(kalila.identifiers))
    check("the EPUB export link is built for the exact title",
          any(t.fmt is DownloadFormat.EPUB
              and "ws-export.wmcloud.org" in t.url
              and "format=epub" in t.url
              and "%D9%83%D9%84%D9%8A%D9%84%D8%A9" in t.url
              for t in kalila.downloads),
          str([(t.fmt.value, t.url) for t in kalila.downloads]))
    check("the page link stays on ar.wikisource.org",
          kalila.landing_url.startswith("https://ar.wikisource.org/wiki/"),
          kalila.landing_url)
    check("an EPUB export makes the card downloadable",
          kalila.access is Access.DOWNLOAD, kalila.access.value)
    check("a second book keeps its own author",
          nights.authors == ["مؤلف مجهول"], str(nights.authors))
    check("a page without Wikidata still yields a book",
          orphan.authors == [] and orphan.year is None
          and any(t.fmt is DownloadFormat.EPUB for t in orphan.downloads),
          f"{orphan.authors} | {orphan.year}")

    class OfflineHttp:
        def get_json(self, url, params=None, **kwargs):
            raise ProviderError("offline", kind="offline")

    check("a search failure returns no results, not an exception",
          WikisourceProvider(OfflineHttp()).fetch(SearchQuery(text="كليلة ودمنة")) == [])


def main() -> int:
    check_gdata_parser()
    check_fallback()
    check_ia_rescue()
    check_ia_query_variants()
    check_arabic_field_match()
    check_field_empty()
    check_download_tie_break()
    check_noorbook_cards()
    check_safahat_search()
    check_asjp_search()
    check_wikisource_search()
    check_post_text()

    print()
    if FAILED:
        print(f"FAILED: {len(FAILED)} check(s): {FAILED}")
        return 1
    print("ALL BOOK-SOURCE CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
