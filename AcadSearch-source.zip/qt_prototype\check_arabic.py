"""Diagnose why an Arabic topic query returns nothing.

Runs several Arabic queries and reports what each provider returned, so the
reason is measured rather than guessed.
"""

from __future__ import annotations

import queue
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.search_engine import SearchEngine, SearchEventType
from app.models import Category, SearchQuery

QUERIES = [
    "الذكاء الاصطناعي",
    "التعلم الآلي",
    "machine learning",
    "فيزياء",
]

CATS = {Category.BOOK, Category.ARTICLE, Category.RESEARCH}


def run(engine: SearchEngine, text: str) -> tuple[int, dict]:
    query = SearchQuery(text=text, categories=CATS, per_source=10)
    handle = engine.start(query)
    per_provider: dict[str, tuple[str, int, str]] = {}
    total = 0
    while not handle.done:
        time.sleep(0.2)
        try:
            while True:
                event = handle.events.get_nowait()
                if event.report is not None:
                    per_provider[event.report.provider_id] = (
                        event.report.status.value,
                        event.report.count,
                        event.report.message,
                    )
                if event.type == SearchEventType.FINISHED:
                    total = event.response.total()
                    by_cat = {
                        c.value: len(v) for c, v in event.response.results.items()
                    }
        except queue.Empty:
            pass
    return total, per_provider, by_cat


def main() -> int:
    engine = SearchEngine()
    for text in QUERIES:
        print("=" * 62)
        print(f'QUERY: "{text}"')
        total, per, by_cat = run(engine, text)
        print(f"  TOTAL = {total}   per category = {by_cat}")
        for pid, (status, count, msg) in sorted(per.items()):
            flag = "ok " if status == "ok" else "ERR"
            print(f"    {flag} {pid:20} count={count:3d}  {msg}")
        print()
        time.sleep(1)
    engine.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())