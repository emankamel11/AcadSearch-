"""Lens.org scholarly search (Papers + Scholar).

Docs: https://docs.lens.org. A free access token from the Lens profile is
required; POST a JSON query and read the records back. The Lens index covers
scholarly works and patents; only scholarly records map onto the app's tabs,
and results with a visible open-access PDF can be downloaded.
"""

from __future__ import annotations

import threading

from app.core.text_utils import as_int, clean_text, extract_doi, truncate_words
from app.models import Access, Category, DownloadFormat, Result, SearchQuery
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://api.lens.org/scholarly/search"

ARTICLE_TYPES = ("journal article", "review", "conference proceeding", "preprint")
BOOK_TYPES = ("book", "book chapter")
RESEARCH_TYPES = ("thesis", "report", "dataset", "working paper")
SKIP_TYPES = ("patent",)


@register
class LensProvider(BaseProvider):
    provider_id = "lens"
    display_name = "Lens.org"
    categories = (Category.ARTICLE, Category.RESEARCH, Category.BOOK)
    weight = 45
    requires_key = "lens_key"
    homepage = "https://www.lens.org"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        token = self.config.lens_key
        if not token:
            return []
        payload_body = {
            "query": {"query_string": {"query": query.text}},
            "size": min(query.per_source, 50),
        }
        payload = self.http.post_json(
            ENDPOINT,
            payload_body,
            provider=self.provider_id,
            auth_token=token,
            cancel=cancel,
        )
        out: list[Result] = []
        for record in (payload.get("data") or []):
            result = self._to_result(record)
            if result is not None:
                out.append(result)
        return out

    def _to_result(self, record: dict) -> Result | None:
        kind = clean_text(record.get("publication_type")).lower()
        if kind in SKIP_TYPES:
            return None
        if kind in BOOK_TYPES or "book" in kind:
            category = Category.BOOK
        elif kind in ARTICLE_TYPES:
            category = Category.ARTICLE
        else:
            category = Category.RESEARCH

        title = clean_text(record.get("title"))
        if not title:
            return None

        authors: list[str] = []
        for author in (record.get("authors") or []):
            name = (
                f"{clean_text(author.get('first_name'))} "
                f"{clean_text(author.get('last_name'))}"
            ).strip()
            name = name or clean_text(author.get("collective_name"))
            if name:
                authors.append(name)
        authors = authors[:12]

        doi = ""
        for ident in (record.get("external_ids") or []):
            if str(ident.get("type", "")).lower() == "doi":
                doi = extract_doi(ident.get("value"))
                break

        landing = ""
        pdf = ""
        opening = record.get("open_access") or {}
        locations = opening.get("locations") or {}
        page_urls = locations.get("landing_page_urls") or []
        pdf_urls = locations.get("pdf_urls") or []
        if page_urls:
            landing = clean_text(page_urls[0])
        if pdf_urls:
            pdf = clean_text(pdf_urls[0])
        landing = landing or (f"https://doi.org/{doi}" if doi else "")

        source = record.get("source") or {}
        languages = record.get("languages") or []

        identifiers: dict[str, str] = {}
        if doi:
            identifiers["doi"] = doi
        lens_id = clean_text(record.get("lens_id"))
        if lens_id:
            identifiers["lens"] = lens_id

        downloads: list = []
        if pdf:
            downloads.append(target(pdf, DownloadFormat.PDF, label="PDF",
                                    open_access=True))

        return Result(
            category=category,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=as_int(record.get("year_published")),
            abstract=truncate_words(clean_text(record.get("abstract")), 320),
            venue=clean_text(source.get("title")),
            language="en" if languages else "",
            identifiers=identifiers,
            access=Access.DOWNLOAD if downloads else (
                Access.LANDING if landing else Access.METADATA
            ),
            downloads=downloads,
            landing_url=landing,
            item_type=kind.title() or "Scholarly Work",
            raw=record,
        )