# AcadSearch — محرك البحث الأكاديمي

> **AcadSearch** — بحث علمي موحّد في 21 مصدرًا: كتب وأبحاث وأطروحات، مع تنزيل مباشر، وتوثيق بسبع صيغ، وملخصات تُجلب عند الطلب — بلا تسجيل وبلا مفاتيح.

Desktop academic search engine for graduate students. One window, **twenty-one
data sources**, Arabic and English interface, built for both a sighted reader and a
screen-reader user (NVDA).

![Platform](https://img.shields.io/badge/platform-Windows-0078D4)
![Python](https://img.shields.io/badge/python-3.10%2B-3776AB)
![License](https://img.shields.io/badge/license-MIT-green)

---

## المميزات | Features

### البحث | Search
- **21 مصدراً** في بحث واحد:

  | التصنيف | المصادر |
  | --- | --- |
  | كتب | Open Library، Google Books، Internet Archive، OpenAlex، **HAL**، **DataCite**، **Zenodo**، **BASE**، **Springer** |
  | مقالات | Semantic Scholar، OpenAlex، OpenAIRE، HAL، Europe PMC، DOAJ، Crossref، **CORE**، **DataCite**، **Zenodo**، **BASE**، **PubMed**، **Lens.org**، **Scilit**، **Scinapse**، **Springer** |
  | أبحاث وأطروحات | arXiv، Semantic Scholar، OpenAlex، OpenAIRE، Sudoc، HAL، Europe PMC، DOAJ، **CORE**، **DataCite**، **Zenodo**، **BASE**، **PubMed**، **Lens.org**، **Scilit**، **Scinapse**، **Springer** |

- **HAL** (hal.science) هو الأرشيف الفرنسي المفتوح: يغطي المقالات والرسائل
  الجامعية والكتب، ومعظم نتائجه ملف PDF حقيقي جاهز للتنزيل.
- **Sudoc** (sudoc.abes.fr) فهرس المكتبة الوطنية الفرنسية: رسائل جامعية
  وأطروحات وكتب.
- ثلاث نتائج منفصلة: **كتب**، **مقالات**، **أبحاث** — لأن صيغة توثيق كل نوع تختلف.
- **عدّاد على كل تبويب**: كل تصنيف يعرض عدد نتيجته بجانب اسمه — «كتب (3)»,
  «مقالات (12)», «أبحاث (7)» — يُحدَّث فور انتهاء البحث، ويظهر `(0)` للتصنيف
  الذي لم يُصِب هذا البحث شيئاً.
- البحث في الخلفية؛ الواجهة لا تتجمد أبداً، وتظهر النتائج تدريجياً حسب وصول كل مصدر.
- مصدر واحد يفشل أو يحدّ من طلباته ← تظهر بقية النتائج وتُشرح المشكلة في شريط الحالة.
- **فلاتر في صف مستقل أسفل مربع البحث** (لا داخل قائمة الإعدادات):
  - **لغة النتائج**: كل اللغات / العربية / الفرنسية / الإنجليزية.
  - **سنة النشر**: من … إلى …، والخانة الفارغة تعني كل السنوات.
  - الاختيار يُحفظ تلقائياً في `config.json` فيبقى للبحث القادم.
- فلاتر اللغة **ترفع** النتائج المطابقة إلى الأعلى بدل حذف الباقي، حتى لا تفرغ
  تبويب كامل ولا يبدو البرنامج معطلاً.
- **ترتيب يراعي اللغة**: نتيجة بنفس لغة الاستعلام تترقّب. العربية تُكتشف من خط
  النص، والفرنسية من مفردات لا ت ambiguة مع الإنجليزية.
- اختصارات: `Enter` بحث، `Esc` مسح، `Ctrl+K` التركيز على مربع البحث،
  `F1` يعرض نافذة المساعدة (تشرح كل الاختصارات)،
  `Ctrl+1`/`Ctrl+2`/`Ctrl+3` للانتقال السريع بين التصنيفات، وزر `القائمة`
  (Application) على النتيجة التي تقف عليها يفتح قائمة النتيجة: أول عنصر
  يتبدّل حسب ما تملكه النتيجة — «تنزيل» لو فيها ملف، و«قراءة» لو قراءة
  فقط — ثم نسخ التوثيق ونسخ الملخص، (و«فتح للقراءة على الموقع» بجوار
  التنزيل حين يوجد ملف).
- **قائمة النتيجة مثل أي قائمة في ويندوز**: بعد فتحها بزر القائمة تنقل بين
  عناصرها بالأسهم وتُفعّل ما اخترته بـ `Enter`. يمين الفأرة لا يفتح شيئاً.
- **`Enter` يعمل مع أي زر عليه التركيز**: الإعدادات، التنزيل، نسخ التوثيق،
  البحث. قبل ذلك كان `Enter` يُبتلع ولا يفعل شيئاً، والوصول للزر كان بمسافة
  فقط، لأن Qt يعطي `Enter` للزر الافتراضي (البحث) لا للزر المركّز عليه.
- داخل نافذة الإعدادات: `Enter` في أي حقل = **حفظ وإغلاق**.

### التوثيق | Citation
- سبع صيغ جاهزة: **APA 7، MLA 9، Chicago 17، Harvard، IEEE، BibTeX، RIS**.
- **ملخص يُجلَب عند الطلب**: كثير من المصادر يعود بلا ملخص (Crossref، وGoogle
  Books، وSemantic Scholar حين يحدّ الطلبات)، فعند `Alt+M` أو «نسخ الملخص» يسأل
  البرنامج DOI عبر **OpenAlex ثم Crossref ثم Semantic Scholar** ويجلب النص
  فعلياً (طلب واحد
  غير متزامن لا يُبطئ الواجهة)، مع حفظ النتيجة لتكرار الطلب بلا شبكة. وبدون
  DOI يقول «لا يوجد ملخص» بصدق بدل نسخ سطر عنوان ومدّعياً أنه ملخص.
- تفرّع تلقائي حسب نوع المصدر: الكتاب، المقال، فصل كتاب، الأطروحة، preprint، dataset.
- **APA 7 مُصحَّحة على أساس مواصفتها**:
  - الكتاب: `المؤلفون (السنة). *العنوان*. الناشر.` — الناشر comes من حقل
    `publisher` ثم `venue`، فلم تعد المرجع ناقصة.
  - المقال: `*المجلة*، المجلد(العدد)، الصفحات. DOI` — والصفحة بشرطة
    إنداش `436–444` لا هجين.
  - **20 مؤلفاً كاملاً**؛ ومن 21 فصاعداً: أول 19 + `...` + الأخير (وليس `et al.`).
  - **فصل الكتاب** لم يعد يُطبع ككتاب كامل: `العنوان. In *الكتاب* (pp. 45–60).`
  - الأطروحة: `[الدرجة، الجامعة]`، والرسالة بلا جامعة تبقى `[الدرجة]`.
  - `n.d.` تظهر مرة واحدة فقط، والـ`URL` يبقى لو لا يوجد DOI (عدا الكتاب).
- **عكس أسماء المؤلفين** بشكل صحيح (APA/Harvard) مع دعم `van / de / bin`
  واللواحق `Jr.`: «Carl Ludwig van der Waals» تُطبع `van der Waals, C. L.`
- إجراءات النتيجة كلها خلف زر `القائمة` (Application) على الصف المركّز عليه،
  ولا تحمل البطاقة أي أزرار ظاهرة، لتبقى الشاشة خالية من الزحمة.
- اختصارات: `Alt+C` نسخ توثيق النتيجة المركّز عليها.

### التنزيل | Download
- يختار التطبيق **الملف المفتوح فعلياً** (PDF ثم EPUB/ZIP) لا صفحة HTML.
- **تنزيل واحد واضح لكل نتيجة**، وفي الحالات الثلاث (عبر قائمة القائمة/Alt+D):
  - فيه ملف ← يُنزَّل الملف.
  - ما فيه ملف لكن فيه صفحة مصدر ← «فتح للقراءة على الموقع».
  - `Enter` على الصف لا يبدأ تنزيلاً، حتى لا يحدث تنزيل مزدوج بالخطأ.
- التمييز بين `مفتوح` و`مستعارة` و`بيانات فقط` — بوضوح، قبل الضغط.
- **لا يتجاوز أي paywall أو تسجيل دخول**.
- **إثراء الكتب عند الطلب**: نتيجة كتاب في «قراءة» (لا تمر مرفقةً بملف) تُحلّ
  لحظياً عبر بنية Internet Archive — إن وُجد ملف مفتوح (**PDF/EPUB**) يُنزَّل
  فعلياً بدل فتح صفحة المصدر، ما يجعل كتب Open Library و Internet Archive
  قابلة للتنزيل في أغلبها دون إبطاء أي بحث (التحليل يحدث فقط حين تطلب أنت).
- شريط تقدّم + سرعة + حجم، وإلغاء، وحماية من الكتابة فوق ملف موجود.
- اختصارات: `Alt+D` تنزيل المحدّد.

### الواجهة والوصولية | Interface & accessibility
- **عربي/إنجليزي** كاملان، مع اتجاه RTL صحيح.
- مبنية على **PySide6 (Qt)**، وكل عنصر له اسم مقروء لقارئ الشاشة.
- **بطاقة النتيجة صامتة**: لا أزرار ظاهرة عليها إطلاقاً (هذا مطلوب صراحةً
  لإزالة الزحمة)؛ الإجراءات تظهر فقط عبر زر `القائمة` (Application).
- `Ctrl++` / `Ctrl+-` / `Ctrl+0` لتغيير حجم الخط، **والحجم يُحفظ** لل launching القادم.
- بطاقات بارتفاع حقيقي (`130px`)، لأن `QListWidget` كان يعطي محتوى الصف
  ارتفاعاً بصرياً صفرياً.
- ألوان مميّزة للتصنيفات: الكتب بنّي، المقالات أزرق، الأبحاث بنفسجي.
- صور أغلفة اختيارية تُحمّل بشكل غير متزامن بعد ظهور البطاقة.
- شريط حالة ملوّن المعنى (نجاح/تحذير)، ونصّه نفسه يقول المعنى لقارئ الشاشة.
- دعم الشاشات: 125%/150%/200%، والشاشات الأصغر من 1366×768.

---

## التشغيل من المصدر | Run from source

```bat
python -m pip install -r requirements.txt
python qt_prototype\run_app.py
```

`run_app.py` هو launcher الإنتاج: نافذة فارغة تبدأ البحث الحقيقي.
`run_main.py` نسخة عرض ببيانات `FAKE` للتجربة فقط.

| الملف | الوظيفة |
| --- | --- |
| `qt_prototype\main_window.py` | النافذة الرئيسية، البطاقات، البحث، الوصولية |
| `qt_prototype\theme.py` | الألوان والخطوط والأيقونات |
| `qt_prototype\preferences.py` | الإعدادات: لغة الواجهة، أسلوب التوثيق، مفاتيح API |
| `qt_prototype\check_*.py` | فحوص البطاقة، الشكل، ترتيب Tab، الفلاتر |
| `main.py` | نقطة الدخول للنسخة المبنية (PyInstaller) |

---

## بناء ملف exe | Build the executable

```bat
build_exe.bat                :: dist\AcadSearch.exe  (~46 MB)
build_exe.bat installer      :: dist\AcadSearch-Setup-2.0.0.exe  (~48 MB)
build_exe.bat verify         :: فحص الـ exe عبر UI Automation
build_exe.bat clean          :: حذف build\ و dist\
```

السكربت يشغّل قبل البناء: فحص الصياغة، `tools/smoke_ui`،
`check_card`، `check_visual`، `check_tab_order`، `check_filters`، ويمتنع عن بناء
ملف معطوب.

### نسخة توزيع بمفاتيح مدمجة | A build that ships API keys

المفاتيح تُقرأ من `app/private_keys.py` (مفاتيح موزّع الملف تُدمج في الـ exe
عند البناء). المستودع يحمل نسخة **فارغة وآمنة**؛ من يريد توزيع النسخة
بمفاتيحه يملأ `BUNDLED_KEYS` في هذا الملف ثم يشغّل `build_exe.bat` / `installer`
فيحصل الجميع على الستة مصادر المقيّدة فورًا دون فتح التفضيلات.

الأولوية عند التشغيل: متغيّر البيئة ← ملف إعدادات المستخدم ← المفاتيح المدمجة.

> **تحذير:** أي مفتاح تُدمجه في النسخة يصل إلى كل من استلمها. المفاتيح
> المجانية في هذه المصادر مخصصة للاستخدام الشخصي، ومشاركتها في ملف موزَّع قد
> تُساءلها أو تُخالِف شروط الخدمة — وزّعها في دائرة موثوقة فقط، ولا ترفع
> `private_keys.py` المعبّأ إلى أي مستودع.

> **ملاحظة:** البناء one-file يفكّ الضغط في `%TEMP%` عند كل تشغيل.

### أين تُحفظ بيانات المستخدم | Where data lives

الـ exe **لا يكتب** في مجلده. كل شيء في:

```
%LOCALAPPDATA%\AcadSearch\
    config.json      الإعدادات (اللغة، الفلاتر، حجم الخط، المصادر، المفاتيح)
    cache\           استجابات API المخزّنة
    downloads\       الملفات المنزّلة
    acadsearch.log   الأخطاء
```

---

## الفحص والاختبار | Testing

```bat
python -X utf8 -m tools.smoke_ui        :: فحص الواجهة السريع
python -X utf8 qt_prototype\check_card.py      :: البطاقة صامتة بلا أزرار
python -X utf8 qt_prototype\check_context_menu.py :: قائمة القائمة: تنقّل بالأسهم وتوجيه العناصر
python -X utf8 qt_prototype\check_visual.py     :: الهندسة والتباين والأيقونات والفلاتر
python -X utf8 qt_prototype\check_tab_order.py :: الأسهم وTab وAlt+D/C
python -X utf8 qt_prototype\check_filters.py    :: اللغة والسنة والحفظ بعد إعادة التشغيل
python -X utf8 qt_prototype\check_prefs.py     :: الإعدادات والمفاتيح
python -X utf8 tools\check_book_dl.py          :: إثراء الكتب: قراءة تُحلّ إلى تنزيل
python -X utf8 tools\check_abstracts.py        :: الملخص يُجلَب عبر DOI عند الطلب
python -X utf8 qt_prototype\check_citations.py  :: صحة APA 7 + Enter على الأزرار
powershell -File qt_prototype\check_exe_uia.ps1 :: الـ exe المبني عبر UI Automation
```

`check_exe_uia.ps1` يتحقق من وجود كل عنصر في النسخة المبنية: زر البحث، مربع
البحث، زر الإعدادات، combo اللغة، وحقلي السنة. (شغّل الـ exe أولاً، ثم السكربت:
السكربت يبحث عن النافذة ولا يشغّل البرنامج.)

`check_citations.py` يكتب صيغ APA 7 المتوقعة **نصاً** بدل إعادة حسابها
بالدوال نفسها، وإلا لكن أي غلط في الدوال يوافق نفسه.

---

## مفاتيح API | API keys

| المتغير | المصدر |
| --- | --- |
| `GOOGLE_BOOKS_KEY` | Google Books |
| `S2_KEY` | Semantic Scholar |
| `OPENALEX_KEY` | OpenAlex |
| `CORE_KEY` | CORE (مرجع كامل) |
| `BASE_KEY` | BASE (أدب رمادي) |
| `PUBMED_KEY` | PubMed (اختياري — يرفع حد الطلبات) |
| `LENS_KEY` | Lens.org |
| `SCILIT_KEY` | Scilit |
| `SCINAPSE_KEY` | Scinapse |
| `SPRINGER_KEY` | Springer Nature |
| `CONTACT_EMAIL` | OpenAlex (يُرفع حد الطلبات) |

أو من **الإعدادات ← الشبكة**، أو في `config.json`.

**15 مصدراً لا تحتاج أي مفتاح**: Open Library، Internet Archive، HAL، Crossref،
arXiv، OpenAIRE، Sudoc، Europe PMC، DOAJ، DataCite، Zenodo، PubMed، Google Books،
Semantic Scholar، OpenAlex. مفاتيح PubMed و Google Books و Semantic Scholar و
OpenAlex اختيارية — ترفع حد الطلبات فقط، لا أكثر.

**6 مصادر تتطلب مفتاحاً مجانياً** من مواقعها، وإلا ترجع بلا نتائج: CORE، BASE،
Lens.org، Scilit، Scinapse، Springer. وقد تردّ `400` / `401` لطلبات بلا مفتاح من
عناوين IP مشتركة.

---

## بنية المشروع | Layout

```
main.py                 نقطة الدخول + حارس stdio لنسخة بلا console
app/
  config.py             الإعدادات + متغيرات البيئة + مسارات frozen
  models.py             Result, SearchQuery, DownloadTarget, ProviderReport, LANGUAGES
  i18n.py               النصوص عربية/إنجليزية
  core/
    citation.py         الصيغ السبع
    downloader.py       التنزيل بالتوازي + شريط التقدم
    http_client.py      retries, backoff, cache, TLS
    search_engine.py    التوزيع + البث + الترتيب + دمج تكرار الكتب + ترجيح اللغة
    text_utils.py       تنظيف النصوص، كشف اللغة، DOI، ...
  providers/            adapter لكل مصدر (21 مصدراً)
    hal.py              الأرشيف الفرنسي: OUV/ART/THESE عبر 3 طلبات موجّهة
    pubmed.py           E-utilities: esearch→esummary→efetch XML للنبذات (بلا مفتاح)
    springer.py         Springer Nature API بترخيص X-ApiKey
    internet_archive.py كتب برواية General search + metadata + فلترة الدورن/التقارير
    sudoc.py             رسائل عبر SRU/ABES بمخطط PICA
qt_prototype/           واجهة Qt (النافذة، الثيم، التفضيلات، الفحوص، اللقطات)
tools/                  smoke_ui وغيرها
installer/              سكربت Inno Setup
```

### تفاصيل HAL | HAL notes
- الـ API مبني على Solr، فالنوع جزء من الاستعلام لا معامل منفصل:
  `docType_s:OUV AND (title_t:"…" OR abstract_t:"…")`.
- `docType_s:MEM` (رسائل ماجستير) و`docType_s:THESE` (دكتوراه) →
  **أبحاث**، و`ART` → **مقالات**، و`OUV` → **كتب**.
- السجل قد يحمل عناوين متعددة (ترجمة)، فيُختار العنوان بنفس `language_s`.
- فلتر السنة يُرسل `producedDateY_i:[من TO إلى]`، وفلتر اللغة `language_s:xx`.

---

## القيود المعروفة | Known limitations

- **Google Books و Semantic Scholar** قد يردّان `429`/`400` من عناوين IP مشتركة؛
  باقي المصادر تعمل، والشيفرة تضيف مفتاحاً من الإعدادات لرفع الحد.
- فلتر اللغة **يرفع** المطابق ولا يحذف غير المطابق، لأن معظم المصادر لا تدعم
  فلترة اللغة على الخادم وحذف الباقي كان يفرغ تبويبات كاملة.
- `volume` و`issue` يُقرآن من **Crossref** فقط؛ بعض المقالات تظل بلا `320(3)`.
- `pages` يُخزَّن كعدد صحيح واحد، فمدى مثل `"145-162"` يُحفظ `145`.
- **CORE و BASE و Lens.org و Scilit و Scinapse و Springer** ترجع صفر نتائج بدون
  مفتاح؛ أدخل مفاتيحها من «الإعدادات ← الشبكة» وهي مجانية.

---

## التثبيت | Installing

`dist\AcadSearch-Setup-2.0.0.exe` مثبّت كامل: اختصار في قائمة ابدأ، مدخل في
«إضافة أو إزالة البرامج»، ومُزيل. التثبيت بدون صلاحيات مدير (per-user) افتراضياً.

**البناء غير موقّع رقمياً**، فـWindows SmartScreen سيعرض تحذيراً عند أول تشغيل:
«مزيد من المعلومات» ← «تشغيل على أي حال».

بدون مثبّت، `dist\AcadSearch.exe` نسخة portable: انسخها وشغّلها مباشرة.

---

## الترخيص | License

MIT.
