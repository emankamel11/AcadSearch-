"""DOAJ — Directory of Open Access Journals (no API key).

DOAJ indexes only fully open-access journals, which makes it different from the
big aggregators: everything it returns is readable and downloadable without a
subscription. That is exactly what a student who cannot pay for access needs.

Endpoint: https://doaj.org/api/search/articles/{query}
Auth:     none.
Licence:  CC BY-SA for the metadata.

The payload is BibJSON, so the field paths are nested (``bibjson.title``,
``bibjson.author[].name``) rather than flat.
"""

from __future__ import annotations

import threading
import urllib.parse

from app.core.text_utils import as_int, clean_text, truncate_words
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

ENDPOINT = "https://doaj.org/api/search/articles"


@register
class DoajProvider(BaseProvider):
    provider_id = "doaj"
    display_name = "DOAJ (دوريات مفتوحة)"
    categories = (Category.ARTICLE, Category.RESEARCH)
    weight = 55
    homepage = "https://doaj.org"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = query.text.strip()
        if not text:
            return []

        # Scoping to the title cuts the hit pool from ~204k to ~68k for
        # "machine learning" and removes the papers that merely mention the
        # phrase in the abstract, which is what made this source look noisy.
        scoped = f"bibjson.title:({text})"
        params = {
            "pageSize": str(max(10, min(query.per_source * 2, 50))),
        }
        url = f"{ENDPOINT}/{urllib.parse.quote(scoped)}?{urllib.parse.urlencode(params)}"

        try:
            payload = self.http.get_json(
                url, provider=self.provider_id, cancel=cancel
            )
        except ProviderError:
            raise
        except Exception as exc:  # pragma: no cover - network
            raise ProviderError(f"doaj: {type(exc).__name__}", kind="error") from exc

        if cancel is not None and cancel.is_set():
            return []

        results: list[Result] = []
        for entry in (payload or {}).get("results", []):
            built = self._to_result(entry)
            if built is not None:
                results.append(built)
        return results

    # -- mapping -----------------------------------------------------------
    def _to_result(self, entry: dict) -> Result | None:
        bib = entry.get("bibjson") or {}
        title = clean_text(bib.get("title") or "")
        if not title:
            return None

        authors = [
            clean_text(a.get("name") or "")
            for a in bib.get("author", []) or []
        ]
        authors = [a for a in authors if a]

        journal = ""
        journal_info = bib.get("journal") or {}
        if isinstance(journal_info, dict):
            journal = clean_text(journal_info.get("title") or "")

        year = as_int(bib.get("year"))

        identifiers: dict[str, str] = {"source": self.provider_id}
        links = []
        for ident in bib.get("identifier", []) or []:
            kind = (ident.get("type") or "").lower()
            value = clean_text(ident.get("id") or "")
            if not value:
                continue
            if kind == "doi":
                identifiers["doi"] = value
            else:
                links.append(value)

        landing = ""
        pdf = ""
        for link in bib.get("link", []) or []:
            link_type = (link.get("type") or "").lower()
            value = clean_text(link.get("url") or "")
            if not value:
                continue
            if link_type == "fulltext":
                landing = landing or value
            elif link_type == "pdf":
                pdf = pdf or value

        downloads = []
        if pdf:
            downloads.append(
                target(pdf, DownloadFormat.PDF, label="PDF", open_access=True)
            )

        # DOAJ papers are pre-publication records, so they read as research.
        result = Result(
            category=Category.RESEARCH,
            title=title,
            source=self.provider_id,
            authors=authors[:12],
            year=year,
            abstract=truncate_words(clean_text(bib.get("abstract") or ""), 90),
            venue=journal,
            subjects=[
                clean_text(s.get("term") or "")
                for s in (bib.get("subject") or [])
                if isinstance(s, dict)
            ][:8],
            identifiers=identifiers,
            downloads=downloads,
            landing_url=landing or (f"https://doi.org/{identifiers['doi']}"
                                    if "doi" in identifiers else ""),
        )
        result.access = Access.DOWNLOAD if downloads else Access.LANDING
        return result