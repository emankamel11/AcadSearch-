"""Does a plain book title (no academic jargon) return readable books?

    python -X utf8 -m tools.verify_books
"""

from __future__ import annotations

import queue
import time

from app.config import Config
from app.core.search_engine import SearchEventType, get_engine
from app.models import Category, SearchQuery

CASES = [
    ("Sapiens", "a single famous popular book title"),
    ("harry potter", "a fiction series title"),
    ("clean code", "a general software book"),
    ("atomic habits", "a recent popular non-fiction book"),
    ("atomic habits", None),
    ("	The Art of War", "leading whitespace + mixed case"),
    ("موسوعة علم النفس", "an Arabic general title"),
    ("history of the arab world", "a broad topic, no author"),
]


def run(text: str, language: str = "any") -> tuple[list, object]:
    query = SearchQuery(
        text=text,
        language=language,
        categories={Category.BOOK},
        per_source=5,
    )
    engine = get_engine()
    handle = engine.start(query)
    while not handle.done and time.monotonic() - handle.started_at < 90:
        try:
            handle.events.get_nowait()
        except queue.Empty:
            time.sleep(0.05)
    final = None
    while True:
        try:
            ev = handle.events.get_nowait()
        except queue.Empty:
            break
        if ev.type is SearchEventType.FINISHED and ev.response:
            final = ev.response
    if final is None:
        return [], None
    return list(final.results.get(Category.BOOK, [])), final


def main() -> int:
    cfg = Config()
    print("Testing plain, everyday book queries in the BOOK section.")
    print("=" * 74)
    failures = 0
    seen: set[str] = set()
    for entry in CASES:
        text, note = entry[0], entry[1]
        if text in seen:
            continue
        seen.add(text)
        books, response = run(text)
        status = "OK " if books else "NONE"
        if not books:
            failures += 1
        print(f"\n[{status}] {text!r}   ({note})")
        print(f"        {len(books)} book(s) in {response.elapsed:.1f}s"
              if response else "        no response")
        if response:
            errs = [f"{r.provider_id}:{r.status.value}" for r in response.reports
                    if r.status.value in ("error", "empty")]
            if errs:
                print(f"        providers: {', '.join(errs)}")
        for b in books[:4]:
            authors = ", ".join(b.authors[:2]) or "?"
            access = b.access.value
            print(f"        - {b.title[:48]!r} by {authors[:28]} "
                  f"[{b.source}, {b.year or '?'}, {access}]")

    print("\n" + "=" * 74)
    if failures:
        print(f"{failures} query/queries returned NO books.")
    else:
        print("Every plain query returned at least one book.")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
