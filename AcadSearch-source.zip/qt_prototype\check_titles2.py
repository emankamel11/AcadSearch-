"""Check what the window shows for a title query, and for clear afterwards.

The engine returns plenty of results, so this isolates the display layer.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

import main_window


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()

    def go() -> None:
        win.query.setText("introduction to machine learning")
        win.start_search()

    def report() -> None:
        counts = {c.value: p.list.count() for c, p in win.pages.items()}
        print()
        print('=== after "introduction to machine learning" ===')
        print("  per tab:", counts, "total =", sum(counts.values()))
        print("  open tab:", win.tabs.tabText(win.tabs.currentIndex()))
        print("  status  :", win.status.accessibleName())

        page = win.pages[list(win.pages)[0]]
        if page.list.count():
            print()
            print("  first 3 rows in books:")
            for r in range(min(3, page.list.count())):
                print("   ", page.list.item(r).text()[:95])
            print("  row count:", page.list.count())
        print()

        print("=== now press clear ===")
        win._clear()
        print("  search box :", repr(win.query.text()))
        print("  per tab    :", {c.value: p.list.count() for c, p in win.pages.items()})
        print("  status     :", win.status.accessibleName())
        app.quit()

    QTimer.singleShot(500, go)
    QTimer.singleShot(30000, report)
    QTimer.singleShot(60000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())