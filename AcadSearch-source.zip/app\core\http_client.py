"""Polite HTTP layer: retries, back-off, rate-limit handling and a disk cache.

Every outbound request in the application goes through :class:`HttpClient`.
Centralising it means we only have to get User-Agent politeness, timeout
handling and 429/5xx recovery right once.
"""

from __future__ import annotations

import hashlib
import json
import logging
import random
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import requests

from app.config import Config, get_config

log = logging.getLogger(__name__)

#: Status codes that are worth retrying.
RETRY_STATUS = {408, 425, 429, 500, 502, 503, 504}


class ProviderError(RuntimeError):
    """Raised when a provider cannot produce results.

    ``kind`` drives the user-facing message so the UI can distinguish
    "rate limited" from "no network" from "bad API key".
    """

    def __init__(
        self,
        message: str,
        kind: str = "error",
        status: int | None = None,
        retry_after: float | None = None,
    ):
        super().__init__(message)
        self.kind = kind  # error | rate_limited | key_missing | offline | bad_request | cancelled
        self.status = status
        self.retry_after = retry_after


@dataclass
class Response:
    """A minimal response wrapper so callers never touch ``requests`` types."""

    url: str
    status: int
    text: str
    headers: Mapping[str, str]

    def json(self) -> Any:
        if not self.text:
            return {}
        try:
            return json.loads(self.text)
        except json.JSONDecodeError as exc:
            raise ProviderError(
                f"{self.url} returned malformed JSON", kind="error"
            ) from exc


def _normalise_params(params: Any) -> list[tuple[str, Any]]:
    """Flatten query parameters into sorted, de-duplicated pairs.

    Accepts a mapping *or* a sequence of pairs, because some APIs (Solr, which
    Internet Archive uses) need a key to repeat, e.g. ``fl[]=a&fl[]=b``.
    """
    if not params:
        return []
    items = params.items() if isinstance(params, Mapping) else params
    # Keep multiplicity (repeated ``fl[]``) but ignore ordering.
    return sorted((str(k), v) for k, v in items if v not in (None, ""))


class _DiskCache:
    """Tiny TTL JSON cache.

    Keeps repeated searches (and re-renders) free, and dramatically reduces the
    chance of hitting a provider's rate limit.
    """

    def __init__(self, folder: Path, ttl: int, enabled: bool = True):
        self.folder = folder
        self.ttl = ttl
        self.enabled = enabled
        self._memory: dict[str, tuple[float, str]] = {}
        self._lock = threading.Lock()

    @staticmethod
    def key_for(method: str, url: str, params: Mapping[str, Any] | None, body: Any) -> str:
        blob = json.dumps(
            {
                "m": method.upper(),
                "u": url,
                # Accept both a mapping and a sequence of pairs: Solr-style
                # endpoints need repeated keys such as ``fl[]``.
                "p": sorted(_normalise_params(params)),
                "b": body,
            },
            sort_keys=True,
            default=str,
        )
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()

    def get(self, key: str) -> str | None:
        if not self.enabled:
            return None
        with self._lock:
            hit = self._memory.get(key)
        if hit and (time.time() - hit[0]) < self.ttl:
            return hit[1]

        path = self.folder / f"{key}.json"
        try:
            if path.is_file() and (time.time() - path.stat().st_mtime) < self.ttl:
                text = path.read_text(encoding="utf-8")
                with self._lock:
                    self._memory[key] = (time.time(), text)
                return text
        except OSError:
            return None
        return None

    def set(self, key: str, text: str) -> None:
        if not self.enabled:
            return
        with self._lock:
            self._memory[key] = (time.time(), text)
        try:
            path = self.folder / f"{key}.json"
            tmp = path.with_suffix(".tmp")
            tmp.write_text(text, encoding="utf-8")
            tmp.replace(path)
        except OSError as exc:  # disk full / permissions must not break a search
            log.debug("cache write failed: %s", exc)

    def clear(self) -> int:
        removed = 0
        with self._lock:
            self._memory.clear()
        try:
            for path in self.folder.glob("*.json"):
                path.unlink(missing_ok=True)
                removed += 1
        except OSError:
            pass
        return removed


class HttpClient:
    """Thread-safe ``requests`` wrapper with retries and caching."""

    def __init__(self, config: Config | None = None):
        self.config = config or get_config()
        self._local = threading.local()
        self.cache = _DiskCache(
            self.config.cache_folder,
            self.config.cache_ttl_seconds,
            self.config.use_cache,
        )
        # Small polite delay between hits on the same host.
        self._host_lock: dict[str, threading.Lock] = {}
        self._registry_lock = threading.Lock()
        self._last_call: dict[str, float] = {}

    # -- session ---------------------------------------------------------
    @property
    def session(self) -> requests.Session:
        session = getattr(self._local, "session", None)
        if session is None:
            session = requests.Session()
            session.headers.update(
                {
                    "User-Agent": self.config.user_agent,
                    "Accept-Language": "ar,en;q=0.8",
                }
            )
            adapter = requests.adapters.HTTPAdapter(pool_connections=16, pool_maxsize=16)
            session.mount("https://", adapter)
            session.mount("http://", adapter)
            self._local.session = session
        return session

    def _host_gate(self, host: str) -> threading.Lock:
        with self._registry_lock:
            return self._host_lock.setdefault(host, threading.Lock())

    # -- public API ------------------------------------------------------
    def get_json(
        self,
        url: str,
        params: Mapping[str, Any] | None = None,
        *,
        provider: str = "",
        use_cache: bool = True,
        cancel: threading.Event | None = None,
    ) -> Any:
        text = self.get_text(
            url, params, provider=provider, use_cache=use_cache, cancel=cancel
        )
        if not text.strip():
            return {}
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise ProviderError(
                f"{provider or url}: استجابة JSON غير صالحة / malformed JSON response",
                kind="error",
            ) from exc

    def get_text(
        self,
        url: str,
        params: Mapping[str, Any] | None = None,
        *,
        provider: str = "",
        use_cache: bool = True,
        cancel: threading.Event | None = None,
        encoding: str | None = None,
    ) -> str:
        key = _DiskCache.key_for("GET", url, params, None)
        if use_cache:
            cached = self.cache.get(key)
            if cached is not None:
                log.debug("cache hit %s %s", provider, url)
                return cached

        headers = self._headers_for(provider, params)
        params = self._clean_params(params, provider)
        last_error: Exception | None = None

        for attempt in range(1, self.config.max_retries + 1):
            if cancel is not None and cancel.is_set():
                raise ProviderError("cancelled", kind="cancelled")
            try:
                self._respect_host_gate(url)
                response = self.session.get(
                    url, params=params, headers=headers, timeout=self.config.timeout
                )
            except requests.exceptions.Timeout:
                last_error = ProviderError(
                    f"{provider or url}: انتهت مهلة الطلب / request timed out",
                    kind="error",
                )
            except requests.exceptions.ConnectionError as exc:
                last_error = ProviderError(
                    f"{provider or url}: تعذّر الاتصال / connection error ({exc})",
                    kind="offline",
                )
            except requests.exceptions.RequestException as exc:
                last_error = ProviderError(
                    f"{provider or url}: {exc}", kind="error"
                )
            else:
                if response.status_code == 200:
                    if encoding:
                        # RFC 2616: a text/* type without charset makes requests
                        # fall back to ISO-8859-1, which mangles UTF-8 (Sudoc SRU
                        # serves French/Arabic XML this way). Setting .encoding
                        # before touching .text overrides that guess.
                        response.encoding = encoding
                    text = response.text
                    if use_cache:
                        self.cache.set(key, text)
                    return text

                kind = self._classify(response)
                if kind in ("rate_limited", "key_missing", "bad_request"):
                    raise ProviderError(
                        self._error_message(provider, response, kind),
                        kind=kind,
                        status=response.status_code,
                        retry_after=self._retry_after(response),
                    )
                if response.status_code not in RETRY_STATUS:
                    raise ProviderError(
                        f"{provider or url}: HTTP {response.status_code}",
                        kind="bad_request",
                        status=response.status_code,
                    )
                last_error = ProviderError(
                    self._error_message(provider, response, kind),
                    kind=kind,
                    status=response.status_code,
                    retry_after=self._retry_after(response),
                )

            if attempt < self.config.max_retries:
                delay = self._backoff_delay(attempt, last_error)
                log.info(
                    "retry %s/%s for %s in %.1fs (%s)",
                    attempt,
                    self.config.max_retries,
                    provider or url,
                    delay,
                    last_error,
                )
                if self._sleep(delay, cancel):
                    raise ProviderError("cancelled", kind="cancelled")

        raise last_error or ProviderError(f"{provider or url}: فشل الطلب / request failed")

    def post_json(
        self,
        url: str,
        payload: Any,
        *,
        provider: str = "",
        use_cache: bool = False,
        cancel: threading.Event | None = None,
        auth_token: str | None = None,
    ) -> Any:
        if use_cache:
            key = _DiskCache.key_for("POST", url, None, payload)
            cached = self.cache.get(key)
            if cached is not None:
                return json.loads(cached)
        for attempt in range(1, self.config.max_retries + 1):
            if cancel is not None and cancel.is_set():
                raise ProviderError("cancelled", kind="cancelled")
            try:
                self._respect_host_gate(url)
                headers = self._headers_for(provider, None)
                if auth_token:
                    headers["Authorization"] = f"Bearer {auth_token}"
                response = self.session.post(
                    url,
                    json=payload,
                    headers=headers,
                    timeout=self.config.timeout,
                )
            except requests.exceptions.RequestException as exc:
                if attempt == self.config.max_retries:
                    raise ProviderError(f"{provider or url}: {exc}") from exc
                if self._sleep(self._backoff_delay(attempt, None), cancel):
                    raise ProviderError("cancelled", kind="cancelled")
                continue

            if response.status_code == 200:
                try:
                    data = response.json()
                except ValueError as exc:
                    raise ProviderError(
                        f"{provider or url}: استجابة غير صالحة", kind="error"
                    ) from exc
                if use_cache:
                    self.cache.set(_DiskCache.key_for("POST", url, None, payload), response.text)
                return data

            kind = self._classify(response)
            if kind in ("rate_limited", "key_missing", "bad_request") or attempt == self.config.max_retries:
                raise ProviderError(
                    self._error_message(provider, response, kind),
                    kind=kind,
                    status=response.status_code,
                    retry_after=self._retry_after(response),
                )
            if self._sleep(self._backoff_delay(attempt, None), cancel):
                raise ProviderError("cancelled", kind="cancelled")

        raise ProviderError(f"{provider or url}: فشل الطلب / request failed")

    def clear_cache(self) -> int:
        return self.cache.clear()

    # -- internals -------------------------------------------------------
    def _headers_for(self, provider: str, params: Any) -> dict[str, str]:
        headers: dict[str, str] = {}
        # arXiv asks for a descriptive UA and returns 403 for generic agents.
        if provider == "arxiv":
            headers["User-Agent"] = self.config.user_agent
        pairs = dict(_normalise_params(params))
        if any(k.lower() == "x-api-key" for k in pairs):
            headers["x-api-key"] = str(pairs["x-api-key"])
        if any(k.lower() == "x-scilit-token" for k in pairs):
            headers["X-Scilit-Token"] = str(pairs["x-scilit-token"])
        if any(k.lower() == "authorization" for k in pairs):
            headers["Authorization"] = f"Bearer {pairs['authorization']}"
        return headers

    @staticmethod
    def _clean_params(params: Any, provider: str) -> Any:
        """Drop empty values, preserving repeated keys (``fl[]``)."""
        if not params:
            return None
        out: list[tuple[str, Any]] = []
        for key, value in _normalise_params(params):
            if value is None or value == "":
                continue
            # Secrets ride in headers, never in the URL: they would leak into
            # logs, caches and access logs otherwise.
            if key.lower() in ("x-api-key", "x-scilit-token", "authorization"):
                continue
            if provider == "arxiv" and key == "x-api-key":
                continue  # not a real query parameter
            out.append((key, value))
        return out or None

    def _classify(self, response: requests.Response) -> str:
        if response.status_code == 429:
            return "rate_limited"
        if response.status_code in (401, 403):
            body = response.text.lower()
            if "key" in body or "api" in body:
                return "key_missing"
            return "bad_request"
        if response.status_code == 400:
            return "bad_request"
        if response.status_code in RETRY_STATUS:
            return "error"
        return "bad_request"

    @staticmethod
    def _error_message(provider: str, response: requests.Response, kind: str) -> str:
        name = provider or "HTTP"
        retry_after = response.headers.get("Retry-After")
        if kind == "rate_limited":
            extra = f" (Retry-After: {retry_after})" if retry_after else ""
            return f"{name}: تم تجاوز حد الطلبات / rate limited{extra}"
        if kind == "key_missing":
            return f"{name}: مفتاح API مطلوب أو غير صالح / invalid or missing API key"
        return f"{name}: HTTP {response.status_code}"

    @staticmethod
    def _retry_after(response: requests.Response) -> float | None:
        raw = response.headers.get("Retry-After")
        if not raw:
            return None
        try:
            return float(raw)
        except ValueError:
            return None  # HTTP-date form; fall back to exponential back-off

    def _backoff_delay(self, attempt: int, error: Exception | None) -> float:
        delay = self.config.backoff_base * (2 ** (attempt - 1))
        retry_after = getattr(error, "retry_after", None) if error is not None else None
        if retry_after:
            delay = max(delay, float(retry_after))
        # Jitter avoids a thundering herd when several providers fail at once.
        return min(delay, 20.0) * (0.7 + random.random() * 0.6)

    @staticmethod
    def _sleep(seconds: float, cancel: threading.Event | None) -> bool:
        """Sleep in slices so cancellation stays responsive. Returns True if cancelled."""
        end = time.time() + seconds
        while time.time() < end:
            if cancel is not None and cancel.is_set():
                return True
            time.sleep(min(0.2, max(0.0, end - time.time())))
        return cancel is not None and cancel.is_set()

    def _respect_host_gate(self, url: str) -> None:
        host = url.split("/")[2] if "//" in url else url
        gate = self._host_gate(host)
        with gate:
            previous = self._last_call.get(host, 0.0)
            wait = 0.12 - (time.time() - previous)
            if wait > 0:
                time.sleep(wait)
            self._last_call[host] = time.time()


_client: HttpClient | None = None
_client_lock = threading.Lock()


def get_http() -> HttpClient:
    global _client
    with _client_lock:
        if _client is None:
            _client = HttpClient()
    return _client
