"""ASJP — the Algerian Scientific Journal Platform.

https://asjp.cerist.dz

ASJP indexes Algerian open-access journals in Arabic, French and English. Its
search is a Laravel form: a query has to POST a CSRF ``_token`` that is minted
on the home page and tied to the session cookie, so the token is fetched with
the same thread-local session that sends the search. The result page is plain
HTML, and each article page publishes ``citation_*`` meta tags -- including the
real ``citation_pdf_url`` -- which is where the journal name, DOI, volume,
issue and page range come from.

Only the first few hits are enriched: the search card already carries the
title, abstract, authors and date, and one extra request per enriched hit is
enough to turn a landing link into a downloadable PDF.
"""

from __future__ import annotations

import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urljoin

from app.core.text_utils import (
    clean_text,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target


BASE = "https://asjp.cerist.dz"
HOME_URL = f"{BASE}/en"
SEARCH_URL = f"{BASE}/en/rechercheGeneral"
ARTICLE_BASE = f"{BASE}/en/article"

#: How many result pages are opened for their citation meta tags.
MAX_ENRICHED = 4

_TOKEN_RE = re.compile(r'name=["\']_token["\']\s+value=["\']([^"\']+)["\']', re.I)
#: Every card is wrapped in a ``div`` that (invalidly) reuses the same id.
_CARD_SPLIT = re.compile(r'id=["\']resultatRecherche["\']', re.I)
_TITLE_RE = re.compile(
    r"<h4[^>]*>\s*<a[^>]+href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", re.S | re.I
)
_ROW_RE = re.compile(
    r"<th[^>]*>(.*?)</th>\s*<td[^>]*>(.*?)</td>", re.S | re.I
)
_DATE_RE = re.compile(r"\b(\d{1,2})-(\d{1,2})-(\d{4})\b")
#: ``ص 271-289`` / ``p. 271-289`` in the date row.
_PAGES_RE = re.compile(r"(?:ص|p\.?)\s*(\d+)\s*[-–]\s*(\d+)", re.I)
_META_TAG_RE = re.compile(r"<meta\b[^>]*>", re.I)
_ATTR_RE = re.compile(
    r"""([A-Za-z_:][-A-Za-z0-9_:.]*)\s*=\s*(?:"([^"]*)"|'([^']*)')"""
)
_ARTICLE_ID_RE = re.compile(r"/article/(\d+)", re.I)

#: Row labels, kept in the languages ASJP actually renders.
_ABSTRACT_LABELS = ("ملخص", "résumé", "resume", "abstract")
_AUTHOR_LABELS = ("مؤلف", "auteur", "author")
_KEYWORD_LABELS = ("مفتاح", "mot clé", "mot cle", "keyword")


def _plain(value: str) -> str:
    """Strip ASJP's markup and the collapsed-abstract placeholder."""
    text = value or ""
    # The search page truncates abstracts with <oooo class="point">....</oooo>.
    text = re.sub(r"<o{2,}[^>]*>.*?</o{2,}>", " ", text, flags=re.S | re.I)
    text = re.sub(r"</?o+[^>]*>", " ", text, flags=re.I)
    text = re.sub(
        r"<a[^>]*class=[\"']read[\"'][^>]*>.*?</a>", " ", text, flags=re.S | re.I
    )
    text = clean_text(text)
    return text.replace("\ufffd", " ").strip()


def _label_has(label: str, needles: tuple[str, ...]) -> bool:
    label = (label or "").casefold()
    return any(needle in label for needle in needles)


def _parse_meta(html: str) -> dict[str, list[str]]:
    """Collect ``citation_*`` meta tags, keeping repeated authors in order."""
    meta: dict[str, list[str]] = {}
    for tag in _META_TAG_RE.findall(html):
        attrs: dict[str, str] = {}
        for match in _ATTR_RE.finditer(tag):
            key = match.group(1).lower()
            value = match.group(2) if match.group(2) is not None else match.group(3)
            attrs[key] = value or ""
        name = attrs.get("name", "").strip().lower()
        if not name.startswith("citation_"):
            continue
        content = clean_text(attrs.get("content", ""))
        if content:
            meta.setdefault(name, []).append(content)
    return meta


def _first(meta: dict[str, list[str]], key: str) -> str:
    values = meta.get(key) or []
    return values[0] if values else ""


def _author_name(value: str) -> str:
    """ASJP writes ``Family, Given``; readers expect ``Given Family``."""
    name = _plain(value).rstrip(" ,")
    if "," in name:
        family, given = name.split(",", 1)
        family, given = family.strip(), given.strip()
        if family and given:
            return f"{given} {family}"
    return name


def _year_from(value: str) -> int | None:
    match = re.search(r"(1[5-9]\d{2}|20\d{2}|21\d{2})", value or "")
    return int(match.group(1)) if match else None


def _split_keywords(value: str) -> list[str]:
    words = re.split(r"\s*[-–،,;]\s*", _plain(value))
    out: list[str] = []
    for word in words:
        word = word.strip(" .")
        if len(word) > 1 and word not in out:
            out.append(word)
    return out[:10]


@register
class AsjpProvider(BaseProvider):
    provider_id = "asjp"
    display_name = "ASJP (دوريات جزائرية)"
    categories = (Category.ARTICLE,)
    weight = 28
    homepage = BASE

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = (query.text or "").strip()
        if not text:
            return []

        try:
            # The token is bound to this thread's session cookie, so it must
            # come from an uncached GET on the same thread.
            home = self.http.get_text(
                HOME_URL,
                provider=self.provider_id,
                use_cache=False,
                cancel=cancel,
            )
        except Exception:
            return []
        token_match = _TOKEN_RE.search(home)
        if not token_match:
            return []

        try:
            html = self.http.post_text(
                SEARCH_URL,
                data={"_token": token_match.group(1), "rechercheG": text},
                headers={"Referer": HOME_URL},
                provider=self.provider_id,
                cancel=cancel,
            )
        except Exception:
            return []

        results = self._parse_cards(html)
        if not results:
            return []

        if cancel is not None and cancel.is_set():
            return results[: query.per_source]

        self._enrich(results, cancel)
        return results[: query.per_source]

    # -- search page ----------------------------------------------------
    def _parse_cards(self, html: str) -> list[Result]:
        results: list[Result] = []
        seen: set[str] = set()

        for chunk in _CARD_SPLIT.split(html)[1:]:
            title_match = _TITLE_RE.search(chunk)
            if not title_match:
                continue
            href, raw_title = title_match.group(1), title_match.group(2)
            title = _plain(raw_title)
            if not title:
                continue
            landing = urljoin(BASE + "/", href)
            if landing in seen:
                continue
            seen.add(landing)

            abstract = ""
            authors: list[str] = []
            keywords: list[str] = []
            for raw_label, raw_value in _ROW_RE.findall(chunk):
                label = _plain(raw_label)
                if not label:
                    continue
                if _label_has(label, _ABSTRACT_LABELS):
                    abstract = truncate_words(_plain(raw_value), 700)
                elif _label_has(label, _AUTHOR_LABELS):
                    names = [
                        _plain(name).rstrip(" ,")
                        for name in re.split(r"\s*[،,;]\s*", _plain(raw_value))
                    ]
                    for name in names:
                        name = name.rstrip(" ,")
                        if name and name not in authors:
                            authors.append(name)
                elif _label_has(label, _KEYWORD_LABELS):
                    keywords = _split_keywords(raw_value)

            plain_chunk = _plain(chunk)
            year = None
            date_match = _DATE_RE.search(plain_chunk)
            if date_match:
                year = int(date_match.group(3))
            pages = None
            page_match = _PAGES_RE.search(plain_chunk)
            if page_match:
                first, last = int(page_match.group(1)), int(page_match.group(2))
                if last >= first:
                    pages = last - first + 1

            article_id = ""
            id_match = _ARTICLE_ID_RE.search(landing)
            if id_match:
                article_id = id_match.group(1)

            identifiers = {"source": self.provider_id}
            if article_id:
                identifiers["asjp"] = article_id

            results.append(
                Result(
                    category=Category.ARTICLE,
                    title=title,
                    source=self.provider_id,
                    authors=authors[:10],
                    year=year,
                    abstract=abstract,
                    venue="ASJP",
                    language="",
                    subjects=keywords,
                    identifiers=identifiers,
                    access=Access.LANDING,
                    downloads=[
                        target(
                            landing,
                            DownloadFormat.HTML,
                            label="ASJP",
                            open_access=True,
                        )
                    ],
                    landing_url=landing,
                    pages=pages,
                    item_type="JournalArticle",
                    raw={"asjp_id": article_id},
                )
            )
        return results

    # -- article page -> citation metadata and real PDF ------------------
    def _enrich(
        self, results: list[Result], cancel: threading.Event | None
    ) -> None:
        limit = min(MAX_ENRICHED, len(results))
        if not limit:
            return
        with ThreadPoolExecutor(max_workers=limit, thread_name_prefix="asjp") as pool:
            futures = {
                pool.submit(self._fetch_meta, item.landing_url, cancel): item
                for item in results[:limit]
            }
            for future in as_completed(futures):
                item = futures[future]
                try:
                    meta = future.result()
                except Exception:
                    continue
                if meta:
                    self._apply_meta(item, meta)

    def _fetch_meta(
        self, article_url: str, cancel: threading.Event | None
    ) -> dict[str, list[str]]:
        if not article_url:
            return {}
        try:
            html = self.http.get_text(
                article_url,
                provider=self.provider_id,
                cancel=cancel,
            )
        except Exception:
            return {}
        return _parse_meta(html)

    def _apply_meta(self, item: Result, meta: dict[str, list[str]]) -> None:
        title = _first(meta, "citation_title")
        if title:
            item.title = title

        authors: list[str] = []
        for value in meta.get("citation_author", []):
            name = _author_name(value)
            if name and name not in authors:
                authors.append(name)
        if authors:
            item.authors = authors[:10]

        journal = _first(meta, "citation_journal_title")
        if journal:
            item.venue = journal
            item.publisher = journal

        year = _year_from(
            _first(meta, "citation_publication_date") or _first(meta, "citation_date")
        )
        if year:
            item.year = year

        item.volume = _first(meta, "citation_volume") or item.volume
        item.issue = _first(meta, "citation_issue") or item.issue

        language = normalise_language(_first(meta, "citation_language"))
        if language:
            item.language = language

        doi = _first(meta, "citation_doi")
        if doi:
            item.identifiers["doi"] = doi
        issn = _first(meta, "citation_issn")
        if issn:
            item.identifiers["issn"] = issn

        first_page = _first(meta, "citation_firstpage")
        last_page = _first(meta, "citation_lastpage")
        if first_page.isdigit() and last_page.isdigit():
            first, last = int(first_page), int(last_page)
            if last >= first:
                item.pages = last - first + 1

        pdf = _first(meta, "citation_pdf_url")
        if pdf:
            if pdf.startswith("/"):
                pdf = urljoin(BASE + "/", pdf)
            item.downloads = [
                target(pdf, DownloadFormat.PDF, label="PDF (ASJP)", open_access=True),
                target(
                    item.landing_url,
                    DownloadFormat.HTML,
                    label="ASJP",
                    open_access=True,
                ),
            ]
            item.access = Access.DOWNLOAD
