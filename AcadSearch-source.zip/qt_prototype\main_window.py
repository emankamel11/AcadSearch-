﻿"""The new Qt interface, built piece by piece.

Piece 1 (search box + search button) is done and verified.
This file is piece 2: it adds the three category tabs on top of piece 1,
with the real backend from app.core.search_engine.

Accessibility rules for everything in here:
  * every interactive widget gets accessibleName and accessibleDescription
  * every status change is pushed through announce() so a screen reader is told
  * focus always lands somewhere predictable after an action
  * arrow keys move between results, Enter activates
"""

from __future__ import annotations

import queue
import re
import sys
from pathlib import Path

from PySide6.QtCore import QSize, Qt, QThread, QTimer, QUrl, Signal
from PySide6.QtGui import (
    QAccessible,
    QAccessibleEvent,
    QContextMenuEvent,
    QDesktopServices,
    QImage,
    QKeySequence,
    QPixmap,
    QShortcut,
)
from PySide6.QtNetwork import (
    QNetworkAccessManager,
    QNetworkReply,
    QNetworkRequest,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

# When this file is run directly (``python qt_prototype/main_window.py`` or one
# of the check_*.py scripts), it has no package, so the imports of its sibling
# modules further down cannot resolve. The parent directory on sys.path plus the
# real package name lets them resolve identically in both cases.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import i18n
from app.config import get_config
from app.core.citation import format_citation
from app.core.downloader import DownloadEventType, DownloadManager
from app.core.search_engine import SearchEngine, SearchEventType
from app.sounds import play as play_sound
from app.models import (
    Access,
    Category,
    DownloadFormat,
    DownloadTarget,
    LANGUAGES,
    Result,
    SearchQuery,
)

# Imported from a named package rather than as bare ``import theme``.
# PyInstaller analyses ``import theme`` as a top-level module and then cannot
# find it, because the file lives inside qt_prototype; the packaged app came up
# with an unstyled window and a settings button that raised ImportError. Naming
# the package resolves identically from source and from the frozen archive.
try:
    from qt_prototype import a11y_keys, theme
    from qt_prototype.preferences import PreferencesDialog
    from qt_prototype.help_dialog import HelpDialog
    from qt_prototype.about_dialog import AboutDialog
except ImportError:  # running as a plain script from inside qt_prototype
    import a11y_keys  # type: ignore[no-redef]
    import theme  # type: ignore[no-redef]
    from preferences import PreferencesDialog  # type: ignore[no-redef]
    from help_dialog import HelpDialog  # type: ignore[no-redef]
    from about_dialog import AboutDialog  # type: ignore[no-redef]

TAB_KEYS = [
    (Category.BOOK, "tab.books", "tab.books.desc"),
    (Category.ARTICLE, "tab.articles", "tab.articles.desc"),
    (Category.RESEARCH, "tab.research", "tab.research.desc"),
]

CATEGORY_TAB_INDEX = {c: n for n, (c, _, _) in enumerate(TAB_KEYS)}

#: Plain (un-badged) tab title for each category, so the (n) count badge can be
#: rebuilt from the title instead of being stacked on top of itself.
CATEGORY_TITLE_KEY = {c: key for c, key, _ in TAB_KEYS}

#: Card metrics. ``CARD_MIN_HEIGHT`` has to be a real number rather than a
#: sizeHint: a widget parked in a ``QListWidget`` cell is laid out inside a row
#: whose height the list decides, and when the row is shorter than the card the
#: card's buttons end up with zero height. They still take focus, so the
#: keyboard path worked while the buttons were invisible on screen and unclickable
#: by mouse.
COVER_W = 74
COVER_H = 100
#: 200 rather than the old 126: three action buttons at ~54px each plus the
#: two-line summary snippet need the room, and at 126 the buttons overlapped
#: each other by 16px (check_visual caught it).
CARD_MIN_HEIGHT = 200

COVER_UA = "AcadSearch/1.0 (+Qt book cover fetcher)"
COVER_TIMEOUT_MS = 12000


# --------------------------------------------------------------------------
# accessibility helpers
# --------------------------------------------------------------------------

def name_widget(widget, name: str, description: str = "") -> None:
    widget.setAccessibleName(name)
    widget.setAccessibleDescription(description)


def announce(widget, text: str | None = None) -> None:
    """Fire accessibility events so a screen reader speaks the change.

    The event kinds live on QAccessible.Event, not on QAccessibleEvent.
    """
    if text is not None:
        widget.setAccessibleName(text)
    iface = QAccessible.queryAccessibleInterface(widget)
    if iface is not None:
        try:
            iface.textChangeSignal()
        except (RuntimeError, AttributeError):
            pass
    for kind in (
        QAccessible.Event.NameChanged,
        QAccessible.Event.Alert,
        QAccessible.Event.Focus,
    ):
        try:
            QAccessible.updateAccessibility(QAccessibleEvent(widget, kind))
        except (RuntimeError, TypeError):
            pass


def year_text(result: Result) -> str:
    return str(result.year) if result.year else i18n.t("result.venue.unknown")


def has_download(result: Result) -> bool:
    """True when this result has a file the reader can save offline.

    One rule, shared by the menu and the badge: the menu's first action says
    تنزيل for exactly the results availability() calls متاح للتنزيل, so the
    menu can never promise a file that does not exist.
    """
    return any(
        t.fmt in (DownloadFormat.PDF, DownloadFormat.EPUB, DownloadFormat.ZIP)
        for t in result.downloads
    )


def availability(result: Result) -> str:
    """Plain words for what the user can do with this result.

    Deliberately a sentence rather than an enum name: this string is read
    aloud, and it is also the text inside the coloured badge, so a sighted user
    sees the same thing the screen reader says.
    """
    if has_download(result):
        return i18n.t("win.avail.download")
    if result.access == Access.BORROW:
        return i18n.t("win.avail.borrow")
    if result.access == Access.LANDING:
        return i18n.t("win.avail.landing")
    return i18n.t("win.avail.metadata")


def source_label(provider_id: str) -> str:
    """Readable name for a source id, in the interface language.

    The raw id ("open_library") is read out as an underscore-separated
    identifier by some screen readers, which is useless in a sentence, so every
    id gets a readable label. They are deliberately one or two words: this text
    is read out on every arrow-key press, and a long name turns moving through
    results into a lecture. Unknown ids fall back to the id itself.
    """
    label = i18n.t(f"win.source.{provider_id}")
    return label if not label.startswith("win.source.") else provider_id


def style_label(style: str) -> str:
    """Spoken name for a citation style key, in the interface language."""
    label = i18n.t(f"win.style.{style}")
    return label if not label.startswith("win.style.") else style


def _sep() -> str:
    """List separator matching the interface language (Arabic comma or Latin)."""
    return "، " if i18n.get_language() == "ar" else ", "


def _snippet(text: str, limit: int = 180) -> str:
    """A card-sized preview of an abstract: two lines of text, cut at a word.

    QLabel has no elide, and a hard 180-character cut can land mid-word,
    which reads badly in Arabic as in any language. If anything was
    dropped an ellipsis says so instead of the sentence just stopping.
    """
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= limit:
        return text
    cut = text[:limit]
    space = cut.rfind(" ")
    if space > limit // 2:
        cut = cut[:space]
    return cut.rstrip() + "…"


def spoken_line(result: Result) -> str:
    """The one short line read when the arrow key lands on a row.

    Five facts and nothing else: title, first author, year, whether a file can
    be downloaded, and which database it came from. The full author list, the
    journal name and the DOI stay visible on the card for anyone who moves the
    mouse or reads the row in NVDA's browse mode -- but they are not pushed
    down the user's ear on every single keypress, which is what made this feel
    like a program that talks too much.
    """
    parts = [result.title or i18n.t("win.untitled")]
    if result.authors:
        parts.append(str(result.authors[0]).strip())
    parts.append(year_text(result))
    parts.append(availability(result))
    if result.source:
        parts.append(source_label(result.source))
    return ". ".join(p for p in parts if p)


# --------------------------------------------------------------------------
# result card
# --------------------------------------------------------------------------

class CoverImage(QLabel):
    """Book/paper cover, loaded in the background.

    A failed or slow fetch is not a problem: the coloured placeholder stays and
    nothing is announced, because a cover is decoration. The label is marked
    ignored by the screen reader so NVDA does not read a filename as a result.
    """

    def __init__(self, result: Result, parent=None):
        super().__init__(parent)
        self.result = result
        self.setFixedSize(COVER_W, COVER_H)
        self.setAlignment(Qt.AlignCenter)
        self.setAccessibleName("")
        # Decoration only: keep it out of the screen reader's tree entirely.
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self._apply_placeholder()

    def _apply_placeholder(self) -> None:
        key = self.result.category.name if self.result.category else "ARTICLE"
        self.setPixmap(
            theme.placeholder_icon(key, max(COVER_W, COVER_H)).pixmap(
                QSize(COVER_W, COVER_H)
            )
        )

    def load(self) -> None:
        url = self.result.cover_url
        if not url or not url.lower().startswith(("http://", "https://")):
            return
        manager = CoverImage._manager()
        if manager is None:
            return
        request = QNetworkRequest(QUrl(url))
        request.setHeader(QNetworkRequest.KnownHeaders.UserAgentHeader, COVER_UA)
        request.setAttribute(
            QNetworkRequest.Attribute.FollowRedirectsAttribute, True
        )
        request.setTransferTimeout(COVER_TIMEOUT_MS)
        self._reply = manager.get(request)
        self._reply.finished.connect(self._on_done)

    def _on_done(self) -> None:
        reply = getattr(self, "_reply", None)
        if reply is None:
            return
        try:
            if reply.error() == QNetworkReply.NetworkError.NoError:
                image = QImage()
                if image.loadFromData(reply.readAll()):
                    scaled = image.scaled(
                        COVER_W,
                        COVER_H,
                        Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                        Qt.TransformationMode.SmoothTransformation,
                    )
                    # Centre the crop so a cover is not cut off at one edge.
                    x = max(0, (scaled.width() - COVER_W) // 2)
                    y = max(0, (scaled.height() - COVER_H) // 2)
                    cropped = scaled.copy(x, y, COVER_W, COVER_H)
                    self.setPixmap(
                        QPixmap.fromImage(cropped).scaled(
                            COVER_W,
                            COVER_H,
                            Qt.AspectRatioMode.IgnoreAspectRatio,
                            Qt.TransformationMode.SmoothTransformation,
                        )
                    )
        except Exception:  # noqa: BLE001 - decoration must never break a search
            pass
        finally:
            reply.deleteLater()
            self._reply = None

    _shared_manager: "QNetworkAccessManager | None" = None

    @classmethod
    def _manager(cls) -> "QNetworkAccessManager | None":
        if cls._shared_manager is None:
            try:
                cls._shared_manager = QNetworkAccessManager()
            except Exception:  # noqa: BLE001
                return None
        return cls._shared_manager


class ResultCard(QFrame):
    """One search hit, read-only.

    There are deliberately no buttons on the card: the actions a user can take
    (تنزيل، نسخ التوثيق، نسخ الملخص، فتح للقراءة) live behind the Application
    key on the focused row, so a screen of results stays quiet and the actions
    appear exactly where the user asked for them.
    """

    def __init__(self, result: Result, parent=None):
        super().__init__(parent)
        self.result = result
        self.setObjectName("ResultCard")
        self.setFrameShape(QFrame.NoFrame)

        key = result.category.name if result.category else "ARTICLE"
        strong, soft = theme.category_colors(key)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(12)

        # ---- cover on the right, because Arabic reads right to left ----
        self.cover = CoverImage(result)
        outer.addWidget(self.cover, 0, Qt.AlignTop)

        # ---- the text column ----
        column = QVBoxLayout()
        column.setSpacing(5)
        outer.addLayout(column, 1)

        title = QLabel(result.title or i18n.t("win.untitled"))
        title.setObjectName("ResultTitle")
        title.setWordWrap(True)
        title.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        title.setAccessibleName("")
        column.addWidget(title)

        meta_bits = []
        if result.authors:
            meta_bits.append(_sep().join(result.authors[:4]))
        meta_bits.append(year_text(result))
        if result.venue:
            meta_bits.append(result.venue)
        meta_line = " • ".join(meta_bits)
        meta = QLabel(meta_line)
        meta.setObjectName("ResultMeta")
        meta.setWordWrap(True)
        meta.setAccessibleName("")
        column.addWidget(meta)

        # ---- badges: colour plus the same information as text ----
        badges = QHBoxLayout()
        badges.setSpacing(6)

        source_name = source_label(result.source)
        source = QLabel(f"  {source_name}  ")
        source.setObjectName("SourceBadge")
        source.setStyleSheet(
            f"#SourceBadge {{ background: {strong}; color: #ffffff; }}"
        )
        source.setAccessibleName("")
        badges.addWidget(source)

        access = availability(result)
        access_icon = {
            Access.DOWNLOAD: "download",
            Access.BORROW: "borrow",
            Access.LANDING: "open",
            Access.METADATA: "pin",
        }.get(result.access, "pin")
        state = QLabel(f"  {access}  ")
        state.setObjectName("AvailabilityBadge")
        tone = {
            Access.DOWNLOAD: ("#cde9d8", "#10492a"),
            Access.BORROW: ("#fbeecd", "#7a4d00"),
            Access.LANDING: ("#dbe8f9", "#123a6b"),
        }.get(result.access, (theme.SURFACE_ALT, theme.INK_SOFT))
        state.setStyleSheet(
            f"#AvailabilityBadge {{ background: {tone[0]}; color: {tone[1]}; "
            f"border: 1px solid {tone[1]}; }}"
        )
        state.setAccessibleName("")
        badges.addWidget(state)
        badges.addStretch(1)
        column.addLayout(badges)

        # ---- two-line preview of the abstract ----
        # Shown only when the provider actually gave an abstract, and kept
        # out of the row's spoken text on purpose: the short spoken_line is
        # what the reader hears per arrow key, and an abstract per keypress
        # would drown it. Alt+M opens the full text in a read-only field.
        abstract = (result.abstract or "").strip()
        self.snippet = None
        if abstract:
            snippet = QLabel(_snippet(abstract))
            snippet.setObjectName("SummarySnippet")
            snippet.setWordWrap(True)
            snippet.setTextFormat(Qt.PlainText)
            snippet.setAccessibleName("")
            snippet.setToolTip(i18n.t("win.snippet.tooltip"))
            column.addWidget(snippet)
            self.snippet = snippet

        column.addStretch(1)

        # No action buttons on the card on purpose (see the class docstring);
        # the Application key on the focused row opens them.
        self.setMinimumHeight(CARD_MIN_HEIGHT)

    def start_cover_load(self) -> None:
        """Called once the card is on screen, so images never block the search."""
        self.cover.load()

    def download_target(self) -> DownloadTarget | None:
        """The real file this row can download, if there is one.

        A landing-page URL is not a download, so returning it here would make
        Alt+D start a fetch that cannot succeed while there is no real file.
        """
        return next(
            (
                t
                for t in self.result.downloads
                if t.fmt is DownloadFormat.PDF
            ),
            next(
                (
                    t
                    for t in self.result.downloads
                    if t.fmt in (DownloadFormat.EPUB, DownloadFormat.ZIP)
                ),
                None,
            ),
        )


# -- search filters ----------------------------------------------------
def _filter_label(text: str) -> QLabel:
    """A caption for a filter control, read as part of the control's name."""
    label = QLabel(text)
    label.setObjectName("CountLabel")
    label.setAccessibleName("")
    return label


def _year_spin(value: int | None) -> QSpinBox:
    """Year box where empty means "any year".

    A ``QSpinBox`` cannot be empty, so 0 stands for "no bound". That keeps the
    control to a single tab stop and lets a screen reader user hear the year
    directly, instead of a combo box listing "أي / الكل" as an extra item.
    """
    spin = QSpinBox()
    spin.setObjectName("FilterCombo")
    spin.setRange(0, 2100)
    spin.setSpecialValueText(i18n.t("win.spin.any"))
    spin.setValue(int(value or 0))
    spin.setMaximumWidth(96)
    return spin


# --------------------------------------------------------------------------
# one tab = one category
# --------------------------------------------------------------------------

class ResultList(QListWidget):
    """A results list that opens its actions only via the Application key.

    Only the keyboard context-menu event (reason ``Keyboard``) opens the menu,
    so a right click stays a no-op. That keeps the actions exactly where the
    user asked for them: on the row the arrow keys are already standing on,
    and nowhere else, leaving the results screen free of button clutter.
    """

    context_requested = Signal(int, object)  # row, global position

    def contextMenuEvent(self, event) -> None:  # noqa: N802 - Qt naming
        if event.reason() != QContextMenuEvent.Reason.Keyboard:
            event.ignore()
            return
        # The Application key can arrive with the list itself as ``self`` or,
        # if the scroll area forwards the Python override, with the viewport.
        # Both must resolve back to the same list before touching its API.
        view = self if isinstance(self, QListWidget) else self.parentWidget()
        if not isinstance(view, QListWidget):
            event.ignore()
            return
        row = view.currentRow()
        if row < 0:
            event.ignore()
            return
        view.context_requested.emit(row, event.globalPos())


class CategoryTab(QWidget):
    download_requested = Signal(object)
    download_unavailable = Signal(int)
    citation_requested = Signal(object)
    summary_requested = Signal(object)
    open_requested = Signal(object)
    result_activated = Signal(object)

    def __init__(self, category: Category, title: str, description: str, parent=None):
        super().__init__(parent)
        self.category = category
        self._cards: list[ResultCard] = []

        lay = QVBoxLayout(self)

        # Count strip above the list. It used to carry the keyboard cheat-sheet
        # ("الأسهم للتنقل • Tab ...") as visible text, which made the app look
        # like a tool built for one specific user rather than a normal program.
        # The shortcuts now live in the tooltips, the README and the window's
        # own help, where a sighted user looks for them too.
        head = QHBoxLayout()
        head.setSpacing(8)

        self.count = QLabel(i18n.t("win.count.initial"))
        self.count.setObjectName("CountLabel")
        self.count.setAccessibleName(i18n.t("win.count.initial"))
        self.count.setToolTip(i18n.t("win.count.tooltip"))
        head.addWidget(self.count)

        head.addStretch(1)

        lay.addLayout(head)

        self.list = ResultList()
        self.list.setObjectName("ResultList")
        self.list.setSelectionMode(QAbstractItemView.SingleSelection)
        # The list itself must be the single place that knows which result is
        # selected. No row was marked "current" when a button stole focus, so
        # Alt+D appeared to do nothing.
        self.list.setFocusPolicy(Qt.StrongFocus)
        self.list.setUniformItemSizes(False)
        self.list.setSpacing(2)
        self.list.setWordWrap(True)
        self.list.setAccessibleName(i18n.t("win.list.accessible", title=title))
        self.list.setToolTip(i18n.t("win.list.tooltip"))
        self.list.context_requested.connect(self._show_context_menu)
        self.list.currentRowChanged.connect(self._on_row_changed)
        lay.addWidget(self.list, 1)

    def clear(self) -> None:
        self.list.clear()
        self._cards.clear()

    def add(self, result: Result) -> None:
        # Stagger cover requests; see the note in add().
        cover_delay = min(len(self._cards) * 90, 4000)
        card = ResultCard(result)
        # The item text is what the screen reader reads for the row itself, so
        # it must carry the whole result, not just the title.
        item = QListWidgetItem(spoken_line(result))
        self.list.addItem(item)
        self.list.setItemWidget(item, card)
        # Tell the list how tall this row has to be. Without an explicit hint the
        # row keeps the default single-line height and the card gets squeezed
        # into it.
        item.setSizeHint(QSize(0, CARD_MIN_HEIGHT + 8))
        # A widget placed in a list cell is not shown until the row is actually
        # on screen, so any child widgets report visible=False and stay out of
        # the tab
        # chain on a freshly filled, scrolled-to-top list. Without this the
        # download and citation buttons are unreachable by Tab, which is the
        # only way a screen-reader user gets to them.
        self.list.scrollToItem(item)
        self._cards.append(card)
        # Covers fetch over the network, so they start only once the row exists,
        # and one at a time keeps eleven providers' worth of images from
        # arriving at once.
        QTimer.singleShot(cover_delay, card.start_cover_load)

    def _on_row_changed(self, row: int) -> None:
        if row < 0 or row >= len(self._cards):
            return
        # Keeping the list in focus makes arrow navigation predictable, and it
        # gives a single, unambiguous "current" row for Alt+D/Alt+C. A card
        # button can steal focus on mouse-over/press, which left no row
        # selected and made shortcuts act on "nothing" -- it just did not look
        # like it, because screen readers often switch on focus, but the
        # underlying selection was lost.
        if self.list.hasFocus():
            pass
        else:
            self.list.setFocus()
        self.list.setCurrentRow(row)
        self.result_activated.emit(self._cards[row].result)

    def act_on_current(self) -> bool:
        """Alt+D: download the result under the caret, without Tab walking."""
        card = self.focused_card()
        if card is None:
            return False
        if card.download_target() is None:
            self.download_unavailable.emit(self.list.currentRow())
            return False
        self.download_requested.emit(card.result)
        return True

    def cite_current(self) -> bool:
        card = self.focused_card()
        if card is None:
            return False
        self.citation_requested.emit(card.result)
        return True

    def update_count(self) -> None:
        n = self.list.count()
        text = i18n.t("win.count.zero") if n == 0 else i18n.t("win.count.n", n=n)
        self.count.setText(text)
        self.count.setAccessibleName(text)

    def focus_first(self) -> bool:
        if self.list.count() == 0:
            return False
        self.list.setFocus()
        self.list.setCurrentRow(0)
        # Each add() scrolls to whatever item was just added, so by the time a
        # search finishes the list is parked at the bottom and the caret sits on
        # a row that visually is not there (the reader hears it, the eye does
        # not see it). Snap the first row to the top of the viewport instead of
        # trusting setCurrentRow to scroll, which it does not do in scroll-per-
        # item mode when the row is already current.
        self.list.scrollToItem(
            self.list.item(0), QAbstractItemView.PositionAtTop
        )
        return True

    def focused_card(self) -> ResultCard | None:
        row = self.list.currentRow()
        if 0 <= row < len(self._cards):
            return self._cards[row]
        return None

    def cards_result(self, row: int) -> Result | None:
        if 0 <= row < len(self._cards):
            return self._cards[row].result
        return None

    def _show_context_menu(self, row: int, global_pos) -> None:
        """The Application key on a result row: act on that one result directly.

        The first action is the one this result can actually perform: تنزيل
        when there is a file to save, قراءة when the record can only be read
        online -- a read-only record never gets a dead تنزيل, and a file never
        gets a redundant قراءة. The site link is offered only next to تنزيل,
        because on a read-only record قراءة already *is* the site link. The
        other two verbs (cite, summary) stay in a steady order, so a sighted
        user and a reader user meet the same middle of the menu every time.
        The popup keeps its standard Windows wording -- a context menu ("قائمة
        السياق" / "Context") -- so the reader hears what they always hear; the
        window-side handlers speak the outcome of each action.
        """
        card = self._cards[row] if 0 <= row < len(self._cards) else None
        if card is None:
            return
        downloadable = has_download(card.result)
        menu = QMenu(self)
        download = menu.addAction(
            i18n.t("action.download") if downloadable else i18n.t("action.read"))
        cite = menu.addAction(i18n.t("citation.copy"))
        summary = menu.addAction(i18n.t("win.action.copy_summary"))
        if downloadable:
            open_page = menu.addAction(i18n.t("win.action.open_on_site"))
        play_sound("menu_open")
        chosen = menu.exec(global_pos)
        self._run_context_action(chosen, card)

    def _run_context_action(self, chosen, card: ResultCard) -> None:
        """Dispatch the chosen menu action to the window-side routes.

        Split from the popup itself so the check scripts can exercise every
        action without having to click inside a live modal menu. The action's
        text is the only hand the popup gives back, so it is matched against
        the same localised labels the menu is built with.
        """
        if chosen is None:
            return
        routes = {
            i18n.t("action.download"): "download",
            i18n.t("action.read"): "open",
            i18n.t("citation.copy"): "cite",
            i18n.t("win.action.copy_summary"): "summary",
            i18n.t("win.action.open_on_site"): "open",
        }
        route = routes.get(chosen.text())
        if route == "download":
            self.download_requested.emit(card.result)
        elif route == "cite":
            self.citation_requested.emit(card.result)
        elif route == "summary":
            self.summary_requested.emit(card.result)
        elif route == "open":
            self.open_requested.emit(card.result)


# --------------------------------------------------------------------------
# search worker
# --------------------------------------------------------------------------

class SearchWorker(QThread):
    done_ok = Signal(object, str)
    done_fail = Signal(str)

    def __init__(self, engine: SearchEngine, query: SearchQuery, parent=None):
        super().__init__(parent)
        self._engine = engine
        self._query = query

    def run(self) -> None:
        import queue as _queue

        handle = self._engine.start(self._query)
        response = None
        message = ""
        while not handle.done:
            self.msleep(60)
            try:
                while True:
                    event = handle.events.get_nowait()
                    # results is a dict keyed by Category, so "has results" is
                    # "has at least one non-empty category list".
                    if event.response is not None and event.response.total() > 0:
                        response = event.response
                    if event.type in (
                        SearchEventType.FINISHED,
                        SearchEventType.FAILED,
                        SearchEventType.CANCELLED,
                    ):
                        if event.response is not None:
                            response = event.response
                        message = event.message
            except _queue.Empty:
                pass
        if response is None:
            self.done_fail.emit(message or "no response")
        else:
            self.done_ok.emit(response, message)


# --------------------------------------------------------------------------
# main window
# --------------------------------------------------------------------------

class MainWindow(QMainWindow):
    #: A background DOI lookup finished; carries the result it was asked for.
    summary_ready = Signal(object)
    def __init__(self) -> None:
        super().__init__()
        # Enter must click whatever button has the focus (settings, download,
        # citation). Installed before the first widget exists so the very first
        # Tab already behaves.
        a11y_keys.install()
        self.setWindowTitle(i18n.t("win.window_title"))
        self.resize(960, 700)
        self._engine = SearchEngine()
        self._worker: SearchWorker | None = None

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(10)

        # ---- header: says what the program is, for a sighted user ----
        header = QLabel(i18n.t("win.header"))
        header.setObjectName("Header")
        header.setAlignment(Qt.AlignCenter)
        header.setMinimumHeight(56)
        # Decoration for the eye; the window title already carries the name, so
        # announcing this again would just repeat it on every focus change.
        header.setAccessibleName("")
        root.addWidget(header)

        # Downloads manager + drain timer so real file downloads happen.
        self._downloads = DownloadManager()
        self._download_timer = QTimer(self)
        self._download_timer.timeout.connect(self._drain_downloads)
        self._download_timer.start(250)

        self.setStyleSheet(theme.stylesheet())

        # ---- piece 1: search row ----
        row = QHBoxLayout()

        self.query = QLineEdit()
        self.query.setObjectName("SearchBox")
        self.query.setPlaceholderText(i18n.t("search.placeholder"))
        self.query.setClearButtonEnabled(True)
        self.query.setAccessibleName(i18n.t("search.button"))
        self.query.returnPressed.connect(self.start_search)
        row.addWidget(self.query, 1)

        provider_count = len(get_config().enabled_providers)
        self.search_btn = QPushButton(i18n.t("search.button"))
        self.search_btn.setObjectName("PrimaryButton")
        self.search_btn.setIcon(theme.icon("search", "#ffffff", 18))
        self.search_btn.setIconSize(QSize(18, 18))
        self.search_btn.setDefault(True)
        self.search_btn.setAccessibleName(i18n.t("search.button"))
        self.search_btn.setToolTip(i18n.t("win.tool.search", count=provider_count))
        self.search_btn.clicked.connect(self.start_search)
        row.addWidget(self.search_btn)

        clear_btn = QPushButton(i18n.t("search.clear"))
        clear_btn.setIcon(theme.icon("clear", theme.INK_SOFT, 18))
        clear_btn.setIconSize(QSize(18, 18))
        clear_btn.setAccessibleName(i18n.t("search.clear"))
        clear_btn.setToolTip(i18n.t("win.tool.clear"))
        clear_btn.clicked.connect(self._clear)
        row.addWidget(clear_btn)

        # The download folder lives under %LOCALAPPDATA%\\AcadSearch, which nobody
        # thinks to look in, so a finished download read as "nothing happened".
        # Alt+O did the same job but a keyboard shortcut nobody knows about is
        # not a way to find a file.
        self.downloads_btn = QPushButton(i18n.t("download.title"))
        self.downloads_btn.setObjectName("DownloadsButton")
        self.downloads_btn.setIcon(theme.icon("folder", theme.INK_SOFT, 18))
        self.downloads_btn.setIconSize(QSize(18, 18))
        self.downloads_btn.setAccessibleName(i18n.t("download.title"))
        self.downloads_btn.setToolTip(i18n.t("win.tool.downloads"))
        self.downloads_btn.clicked.connect(self.open_downloads_folder)
        row.addWidget(self.downloads_btn)

        self.prefs_btn = QPushButton(i18n.t("win.settings"))
        self.prefs_btn.setIcon(theme.icon("settings", theme.INK_SOFT, 18))
        self.prefs_btn.setIconSize(QSize(18, 18))
        self.prefs_btn.setAccessibleName(i18n.t("win.settings"))
        self.prefs_btn.setToolTip(i18n.t("win.tool.settings"))
        self.prefs_btn.clicked.connect(self.open_preferences)
        row.addWidget(self.prefs_btn)

        self.about_btn = QPushButton(i18n.t("win.about"))
        self.about_btn.setIcon(theme.icon("info", theme.INK_SOFT, 18))
        self.about_btn.setIconSize(QSize(18, 18))
        self.about_btn.setAccessibleName(i18n.t("win.about"))
        self.about_btn.setToolTip(i18n.t("win.tool.about"))
        self.about_btn.clicked.connect(self.open_about)
        row.addWidget(self.about_btn)

        # Escape clears too, so the box can be emptied without reaching the
        # button at all.
        QShortcut(QKeySequence(Qt.Key_Escape), self).activated.connect(self._clear)

        root.addLayout(row)

        root.addLayout(self._build_filter_row())

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(8)
        self.progress.setAccessibleName("")
        root.addWidget(self.progress)

        self.status = QLabel(i18n.t("status.idle"))
        self.status.setObjectName("StatusLabel")
        self.status.setWordWrap(True)
        self.status.setAccessibleName("")
        root.addWidget(self.status)

        # Where the copied citation lands. Hidden until something is copied, so
        # the window looks the same as any other search app the rest of the time,
        # and it is read-only and selectable rather than the search box: pasting
        # a reference into the query field destroyed the search term.
        self.citation_view = QLineEdit()
        self.citation_view.setObjectName("CitationView")
        self.citation_view.setReadOnly(True)
        self.citation_view.setVisible(False)
        self.citation_view.setAccessibleName(i18n.t("win.citation.accessible"))
        self.citation_view.setPlaceholderText(i18n.t("win.citation.placeholder"))
        self.citation_view.setToolTip(i18n.t("win.citation.tooltip"))
        root.addWidget(self.citation_view)

        # The same idea as the citation field, for the abstract: Alt+M puts
        # the summary of the selected result here. A plain-text edit rather
        # than a line edit because an abstract is hundreds of characters and
        # one scrolling line is unreadable. Hidden until it is asked for, so
        # the window looks the same as before during a normal search.
        self.summary_view = QPlainTextEdit()
        self.summary_view.setObjectName("SummaryView")
        self.summary_view.setReadOnly(True)
        self.summary_view.setVisible(False)
        self.summary_view.setMaximumHeight(140)
        self.summary_view.setAccessibleName(i18n.t("win.summary.accessible"))
        self.summary_view.setPlaceholderText(i18n.t("win.summary.placeholder"))
        self.summary_view.setToolTip(i18n.t("win.summary.tooltip"))
        root.addWidget(self.summary_view)

        # ---- piece 2: category tabs ----
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.setAccessibleName(i18n.t("win.tabs.accessible"))
        self.pages: dict[Category, CategoryTab] = {}
        for category, title_key, desc_key in TAB_KEYS:
            title = i18n.t(title_key)
            page = CategoryTab(category, title, i18n.t(desc_key))
            page.download_requested.connect(self._on_download)
            page.download_unavailable.connect(
                lambda row, p=page: self._no_file(p, row)
            )
            page.citation_requested.connect(self._copy_citation)
            page.summary_requested.connect(self._copy_summary)
            page.open_requested.connect(self._open_result_page)
            page.result_activated.connect(self._on_result_focus)
            self.pages[category] = page
            index = self.tabs.addTab(page, title)
            self._style_tab(index, category)
        self.summary_ready.connect(self._on_summary_ready)
        self.tabs.currentChanged.connect(self._on_tab_changed)
        root.addWidget(self.tabs, 1)

        # Ctrl+1 / Ctrl+2 / Ctrl+3 go to the tabs in order, like Ctrl+Tab
        # in a browser moves between pages.
        for category, index in CATEGORY_TAB_INDEX.items():
            key = QShortcut(QKeySequence(f"Ctrl+{index + 1}"), self)
            key.activated.connect(lambda c=category: self._jump_to(c))

        # F1 is the help the comment above the tabs promises.
        self._help: HelpDialog | None = None
        # A summary the record did not carry is fetched by DOI when the user
        # asks for it; these name the request in flight so a late answer from
        # an older press cannot overwrite a newer one.
        self._summary_result: Result | None = None
        self._summary_intent: str = ""
        QShortcut(QKeySequence(Qt.Key_F1), self).activated.connect(self.open_help)

        for combo, slot in (
            ("Alt+D", self.download_current),
            ("Alt+C", self.cite_current),
            ("Alt+S", self.open_preferences),
            # The download folder is not where anyone looks by default, so a
            # finished download nobody can find reads as "nothing happened".
            ("Alt+O", self.open_downloads_folder),
            # Read what the result is about before deciding to download it.
            ("Alt+M", self.show_summary),
            ("Ctrl+K", self._focus_query),
            # Text size, for a low-vision user or a small screen. Ctrl+wheel does
            # the same thing, because that is what people try first.
            ("Ctrl++", lambda: self._zoom(1)),
            ("Ctrl+-", lambda: self._zoom(-1)),
            ("Ctrl+0", lambda: self.apply_font_size(10)),
        ):
            QShortcut(QKeySequence(combo), self).activated.connect(slot)

        self.query.setFocus()

    # -- appearance --------------------------------------------------------
    def _style_tab(self, index: int, category: Category) -> None:
        """Give each tab its own colour so the three lists are told apart.

        The tab text already says which category it is, so this is purely a
        visual cue and the stylesheet rule is scoped to that one tab index, not
        applied to the tab bar.
        """
        key = category.name
        strong, soft = theme.category_colors(key)
        glyph = theme.icon(
            {"BOOK": "book", "ARTICLE": "article", "RESEARCH": "research"}[key],
            strong,
            18,
        )
        self.tabs.setTabIcon(index, glyph)
        # QSS cannot select a single QTabBar::tab, so the colour goes on the tab
        # page's own frame and the glyph carries the identity instead.
        page = self.pages[category]
        page.setStyleSheet(
            f"QTabWidget::tab {{ selected }} "
            f"#ResultCard {{ border-left: 4px solid {strong}; }}"
            f"#SourceBadge {{ background: {strong}; }}"
            f"#StatusLabel {{ background: {soft}; }}"
        )

    def apply_font_size(self, points: int) -> None:
        """Rebuild the whole stylesheet at a new font size.

        Aimed at low-vision users and at anyone on a small screen. Everything
        scales together because the padding in the stylesheet is derived from
        the same number.
        """
        points = max(8, min(20, int(points)))
        self.setStyleSheet(theme.stylesheet(points))
        self._font_points = points
        # Remembered, so the size a reader picked for themselves survives the
        # next launch instead of resetting and being re-picked every time.
        config = get_config()
        if abs(config.font_scale - points / 10.0) > 0.01:
            config.font_scale = round(points / 10.0, 2)
            try:
                config.save()
            except OSError:
                pass

    def _zoom(self, delta: int) -> None:
        self.apply_font_size(getattr(self, "_font_points", 10) + delta)
        self._status(
            i18n.t("win.zoom", points=getattr(self, "_font_points", 10))
        )

    # -- status ------------------------------------------------------------
    # -- search filters ----------------------------------------------------
    def _build_filter_row(self) -> QHBoxLayout:
        """Language and publication-year filters, remembered between sessions.

        Placed on their own row rather than inside the settings dialog on
        purpose: the language is the single most common reason a reader thinks
        the results are wrong, and it has to be reachable with one keystroke
        from the search box, not buried three clicks deep.

        Only the languages that actually matter for this audience are offered.
        ``LANGUAGES`` carries 21 codes, but a blind user tabbing through a long
        combo pays for every one of them, so the common ones come first and the
        full list stays available as "أخرى" in the settings dialog.
        """
        config = get_config()
        row = QHBoxLayout()
        row.setSpacing(8)

        row.addWidget(_filter_label(i18n.t("win.filter.lang.label")))

        self.lang_combo = QComboBox()
        self.lang_combo.setObjectName("FilterCombo")
        # The three languages this app is actually used in, plus everything.
        offered = ("any", "ar", "fr", "en")
        for code, _english, native in LANGUAGES:
            if code in offered:
                self.lang_combo.addItem(native, code)
        if config.search_language not in offered:
            config.search_language = "any"
        self.lang_combo.setCurrentIndex(
            offered.index(config.search_language)
        )
        self.lang_combo.setAccessibleName(i18n.t("win.filter.lang.accessible"))
        self.lang_combo.setToolTip(i18n.t("win.filter.lang.tooltip"))
        row.addWidget(self.lang_combo)

        row.addWidget(_filter_label(i18n.t("search.year_from")))
        self.year_from = _year_spin(config.year_from)
        self.year_from.setAccessibleName(i18n.t("search.year_from"))
        row.addWidget(self.year_from)

        row.addWidget(_filter_label(i18n.t("search.year_to")))
        self.year_to = _year_spin(config.year_to)
        self.year_to.setAccessibleName(i18n.t("search.year_to"))
        row.addWidget(self.year_to)

        row.addStretch(1)

        self.lang_combo.currentIndexChanged.connect(self._filters_changed)
        self.year_from.valueChanged.connect(self._filters_changed)
        self.year_to.valueChanged.connect(self._filters_changed)
        return row

    def _filters_changed(self) -> None:
        """Store the filters so the next search starts with the same settings."""
        config = get_config()
        config.search_language = self.lang_combo.currentData() or "any"
        config.year_from = self.year_from.value() or None
        config.year_to = self.year_to.value() or None
        try:
            config.save()
        except OSError:
            pass

    def _filter_values(self) -> tuple[str, int | None, int | None]:
        return (
            self.lang_combo.currentData() or "any",
            self.year_from.value() or None,
            self.year_to.value() or None,
        )

    def _status(self, text: str, speak: str | None = None) -> None:
        """Put ``text`` in the status bar, and optionally say something short.

        ``speak`` is what the screen reader hears; it defaults to ``text`` so the
        plain short messages stay unchanged. Where the on-screen line is long --
        the per-category breakdown after a search, a download path -- the caller
        passes a short summary instead. The detail is not thrown away: it stays
        on screen for whoever can read it, and every count is reachable with the
        arrow keys anyway. This split is the whole point: NVDA used to read out a
        forty-word paragraph after every single search.
        """
        self.status.setText(text)
        self.status.setAccessibleName("")
        # Tint the status bar by meaning, so a sighted user can see at a glance
        # whether the last thing that happened worked. The wording says the same
        # thing, so this adds no information for a screen reader.
        tone = theme.PRIMARY
        if any(
            word in text
            for word in (
                "انتهى",
                "تم المسح",
                "أهلاً",
                "بنفسك",
                "finished",
                "cleared",
                "welcome",
            )
        ):
            tone = theme.SUCCESS
        if any(
            word in text
            for word in (
                "ما فيش نتائج",
                "بدون أي نتيجة",
                "فاضي",
                "ما اشتغلتش",
                "فشل",
                "خطأ",
                "لا يوجد ملف",
                "لا يوجد ملخص",
                "جاري تغيير",
                "no results",
                "no result",
                "empty",
                "failed",
                "error",
                "no file",
                "no summary",
                "no link",
                "changing",
                "skipped",
                "cancelled",
                "timed out",
                "no connection",
                "did not respond",
                "unavailable",
            )
        ):
            tone = theme.WARNING
        self.status.setStyleSheet(
            f"#StatusLabel {{ border-left: 6px solid {tone}; }}"
        )
        spoken = text if speak is None else speak
        if spoken:
            announce(self.status, spoken)

    # -- actions -----------------------------------------------------------
    def _clear(self) -> None:
        # A pending search must stop too, otherwise its results arrive after the
        # clear and refill the tabs, which looks like the clear never worked.
        if self._worker is not None and self._worker.isRunning():
            self._engine.cancel_current()
            self._worker.wait(4000)
        self._worker = None

        self.query.clear()
        for page in self.pages.values():
            page.clear()
            page.update_count()
        self.progress.setVisible(False)
        self.query.setFocus()
        self.query.setCursorPosition(0)
        self._status(
            i18n.t("win.status.cleared"),
            speak=i18n.t("speak.cleared"),
        )

    def start_search(self) -> None:
        text = self.query.text().strip()
        if not text:
            self._status(i18n.t("win.status.empty_query"))
            self.query.setFocus()
            return
        # A second search while one is running replaced the old one, but it used
        # to cancel and then return: the new term was silently dropped and the
        # window sat on "جاري تغيير البحث" with nothing happening. Now the new
        # search is queued and starts as soon as the old one is out of the way.
        if self._worker is not None and self._worker.isRunning():
            self._engine.cancel_current()
            self._worker.wait(4000)
            self._worker = None

        # Drop the old results immediately, so nothing from the previous query
        # can be mistaken for an answer to this one. The tab titles go back to
        # their plain form: a count from the last search must not outlive it.
        for category, page in self.pages.items():
            page.clear()
            page.update_count()
            self.tabs.setTabText(CATEGORY_TAB_INDEX[category], self._tab_label(category))

        self.progress.setVisible(True)
        self._status(
            i18n.t(
                "win.status.searching",
                term=text,
                count=len(get_config().enabled_providers),
            ),
            speak=i18n.t("speak.searching"),
        )

        language, year_from, year_to = self._filter_values()
        query = SearchQuery(
            text=text,
            categories={c for c, _, _ in TAB_KEYS},
            per_source=get_config().results_per_source,
            language=language,
            year_from=year_from,
            year_to=year_to,
        )
        self._worker = SearchWorker(self._engine, query, self)
        self._worker.done_ok.connect(self._on_results)
        self._worker.done_fail.connect(self._on_failure)
        self._worker.start()
        play_sound("search_start")

    def _on_results(self, response, message: str) -> None:
        self.progress.setVisible(False)
        # response.results is a dict keyed by Category, not a flat list.
        total = 0
        first_cat = None
        for category, items in response.results.items():
            page = self.pages.get(category)
            if page is None:
                continue
            for result in items:
                page.add(result)
                total += 1
                if first_cat is None:
                    first_cat = category
        for page in self.pages.values():
            page.update_count()
        for category, page in self.pages.items():
            self.tabs.setTabText(CATEGORY_TAB_INDEX[category], self._tab_label(category, page.list.count()))

        if total == 0 or first_cat is None:
            failed = [r.provider_id for r in response.reports if r.failed]
            parts = [i18n.t("win.none.prefix", term=response.query.text)]
            if failed:
                readable = _sep().join(source_label(pid) for pid in failed)
                parts.append(i18n.t("win.none.failed", sources=readable))
            else:
                parts.append(i18n.t("win.none.all_ok"))
            self._status(
                _sep().join(parts) + ".",
                # Spoken: the end of the search plus two words. The reasons are
                # on screen, one Tab away.
                speak=i18n.t("speak.done"),
            )
            play_sound("search_empty")
            self.query.setFocus()
            self.query.selectAll()
            return

        # Always open the tab that actually holds results, so the user never
        # stares at an empty category after a search.
        self.tabs.setCurrentIndex(CATEGORY_TAB_INDEX[first_cat])

        # Report every category, including the empty ones. A category with
        # nothing in it used to be listed as a bare "0", which reads as a bug
        # rather than as an answer: an Arabic query genuinely returns no
        # theses, and saying so is more useful than staying silent about it.
        breakdown = []
        empty = []
        for category, page in self.pages.items():
            label = self._tab_label(category)
            count = page.list.count()
            if count:
                breakdown.append(i18n.t("win.cat_count", label=label, n=count))
            else:
                empty.append(label)

        failed = [r.provider_id for r in response.reports if r.failed]
        parts = [i18n.t("win.done.prefix", term=response.query.text)]
        parts.append(
            i18n.t("win.total", n=total, sec=response.elapsed)
        )
        if breakdown:
            parts.append(
                i18n.t("win.results_heading", list=_sep().join(breakdown))
            )

        # Say how well the chosen filters actually matched. Without this the
        # reader cannot tell "French filter found nothing" apart from "the
        # filter is not working", and both look like the same empty tab.
        chosen_lang = response.query.language
        if chosen_lang and chosen_lang != "any":
            matched = sum(
                1
                for items in response.results.values()
                for item in items
                if item.language == chosen_lang
            )
            label = next(
                (native for code, _en, native in LANGUAGES if code == chosen_lang),
                chosen_lang,
            )
            if matched:
                parts.append(i18n.t("win.lang_matched", n=matched, label=label))
            else:
                parts.append(i18n.t("win.lang_none", label=label))
        if response.query.year_from or response.query.year_to:
            low = i18n.t("win.year.oldest") if not response.query.year_from else response.query.year_from
            high = i18n.t("win.year.newest") if not response.query.year_to else response.query.year_to
            parts.append(i18n.t("win.year_range", low=low, high=high))
        if empty:
            parts.append(
                i18n.t("win.empty_cats", list=_sep().join(empty))
            )
        if failed:
            readable = _sep().join(source_label(pid) for pid in failed)
            parts.append(i18n.t("win.failed_sources", list=readable))

        # What is spoken after a search is the total and nothing else. The full
        # breakdown stays in the status bar for the eye, the per-tab counts are
        # one Ctrl+Tab away, and the first result is read out immediately anyway
        # because focus lands on it -- so the reader hears a number, not a
        # paragraph, and then just the result they are on.
        # "انتهى البحث" comes first because it is the part that answers the
        # question the reader is actually holding ("is it still running?").
        # The count follows, and the query is not echoed back: the reader just
        # typed it.
        # NVDA was reading more than the user wanted: only "search finished".
        spoken = i18n.t("speak.done")
        self._status(_sep().join(parts) + ".", speak=spoken)
        play_sound("search_done")

        # Land on the first result so the arrow keys work straight away.
        if not self.pages[first_cat].focus_first():
            self.query.setFocus()

    def _on_failure(self, message: str) -> None:
        self.progress.setVisible(False)
        # Without a ``speak`` the whole line would be read out, and the message
        # carries a provider's raw error text -- the longest string in the app.
        self._status(
            i18n.t("win.status.failed_search", error=message or i18n.t("win.status.error_unknown")),
            speak=i18n.t("speak.failed"),
        )
        play_sound("search_fail")
        self.query.setFocus()

    def _on_tab_changed(self, index: int) -> None:
        """Nothing to say when the category changes.

        NVDA announces the tab it lands on by itself, and the count label inside
        the tab carries the number, so speaking here only produced a duplicate.
        """

    def _focus_query(self) -> None:
        self.query.setFocus()
        self.query.selectAll()

    def _open_result_page(self, result: Result) -> None:
        """Send the "open on website" button to the browser.

        The card used to call ``_open_url`` directly, which does not exist on a
        card: Qt swallowed the AttributeError, so the button looked normal and did
        nothing at all. It goes through the same signal chain as download and
        citation now, and the landing page is the card's own URL -- not a
        re-derived one -- so a record without a landing page says so instead of
        opening a search for its own title.
        """
        url = result.landing_url
        if not url:
            self._status(
                i18n.t("win.no_link", title=result.title),
                speak=i18n.t("speak.no_link"),
            )
            return
        self._open_url(url, result.title)

    def _open_url(self, url: str | None, title: str = "") -> None:
        if not url:
            self._status(
                i18n.t("win.no_url") if not title else i18n.t("win.no_link", title=title),
            )
            return
        try:
            import webbrowser

            # webbrowser.open() returns False when it could not hand the URL to
            # anything -- no browser registered, a blocked file association, a
            # headless session. The old code ignored the answer and told the user
            # the link had opened, which is how "nothing happened" went unnoticed.
            opened = webbrowser.open(url)
        except Exception as exc:  # noqa: BLE001 - webbrowser raises almost anything
            self._status(
                i18n.t("win.open_fail", error=exc),
                speak=i18n.t("speak.open_fail"),
            )
            return
        if opened:
            status = (
                i18n.t("win.open_ok_title", title=title) if title
                else i18n.t("win.open_ok")
            )
            self._status(status, speak=i18n.t("speak.open_ok"))
        else:
            self._status(
                i18n.t("win.open_no", url=url),
                speak=i18n.t("speak.open_no"),
            )

    def _jump_to(self, category: Category) -> None:
        index = CATEGORY_TAB_INDEX[category]
        self.tabs.setCurrentIndex(index)
        page = self.pages[category]
        others = []
        for cat, p in self.pages.items():
            if cat is not category and p.list.count():
                others.append(self._tab_label(cat, p.list.count()))
        msg = i18n.t("win.cat_count", label=self._tab_label(category), n=page.list.count())
        if others:
            msg += i18n.t("win.jump_others", list=_sep().join(others))
        self._status(msg)
        if not page.focus_first():
            page.list.setFocus()

    def _tab_label(self, category: Category, count: int | None = None) -> str:
        """The tab title, with the search's per-category count when known."""
        title = i18n.t(CATEGORY_TITLE_KEY[category])
        if count is None:
            return title
        return f"{title} ({count})"

    def _on_result_focus(self, result: Result) -> None:
        announce(self.tabs, spoken_line(result))

    def _on_download(self, result: Result) -> None:
        """Really download the file for one result.

        Everything about this used to be a status message: the button said
        "download" and nothing was ever fetched. The work is handed to
        DownloadManager, which picks the best open-access target and reports
        progress on a queue drained by ``_drain_downloads``.
        """
        # Asked to download a record that only has a web page, the queue used to
        # accept the task and then report a skip a moment later, so the status
        # line said "تخطي التنزيل" for something the user never asked to skip.
        target = DownloadManager.pick_target(result)
        if target is not None and target.fmt is DownloadFormat.SOURCE:
            # A "read" book that names an Archive.org identifier can usually
            # still give us its real file; resolve it on demand so the user
            # actually *downloads* the book instead of landing on a page.
            if DownloadManager._resolve_book_file(result) is None:
                self._status(
                    i18n.t("win.landing_page", title=result.title),
                    speak=i18n.t("speak.landing_page"),
                )
                return
        task = self._downloads.enqueue(result)
        if task is None:
            self._status(
                i18n.t("win.no_file", title=result.title),
                speak=i18n.t("speak.no_file"),
            )
            return
        if task.error == "landing-page":
            self._status(
                i18n.t("win.landing_page", title=result.title),
                speak=i18n.t("speak.landing_page"),
            )
            return
        if task.error == "not-open-access":
            self._status(
                i18n.t("win.not_open", title=result.title),
                speak=i18n.t("speak.not_open"),
            )
            return
        self._status(i18n.t("win.started", title=result.title), speak=i18n.t("speak.started"))

    def _drain_downloads(self) -> None:
        """Report download progress and completion into the status line."""
        from app.core.downloader import DownloadState

        while True:
            try:
                event = self._downloads.events.get_nowait()
            except queue.Empty:
                return
            task = event.task
            title = task.result.title
            if event.type is DownloadEventType.PROGRESS:
                # Progress ticks arrive four times a second. Announcing each one
                # is what turned a download into a monologue that drowned out
                # everything else, so the bar moves silently and only the end of
                # the download is spoken.
                pct = int(task.percent * 100)
                self._status(
                    i18n.t("win.progress", title=title, pct=pct), speak=""
                )
            elif event.type is DownloadEventType.FINISHED:
                where = task.path
                folder = Path(where).parent.name if where else ""
                self._status(
                    i18n.t("win.finished_status", title=title, where=where),
                    speak=i18n.t("speak.finished_dir", folder=folder) if folder
                    else i18n.t("speak.finished"),
                )
            elif event.type is DownloadEventType.FAILED:
                self._status(
                    i18n.t("win.failed_status", title=title, reason=self._reason(task.error)),
                    speak=i18n.t("speak.failed_dl"),
                )
            elif event.type is DownloadEventType.SKIPPED:
                self._status(
                    i18n.t("win.skipped_status", title=title, reason=self._reason(task.error)),
                    speak=i18n.t("speak.skipped"),
                )

    # Internal error codes, in the words a person would use. The queue stores
    # short English tokens like "landing-page" for the code to stay stable, but
    # they were being shown on screen as they were. The values are i18n keys, so
    # the sentence follows the interface language.
    _REASONS = {
        "landing-page": "win.reason.landing_page",
        "not-open-access": "win.reason.not_open_access",
        "no-target": "win.reason.no_target",
        "cancelled": "win.reason.cancelled",
        "timeout": "win.reason.timeout",
        "html-page": "win.reason.html_page",
    }

    # What a bare HTTP status means for someone who just pressed "download".
    _HTTP = {
        "400": "win.http.400",
        "401": "win.http.401",
        "403": "win.http.403",
        "404": "win.http.404",
        "429": "win.http.429",
        "500": "win.http.500",
        "502": "win.http.502",
        "503": "win.http.503",
    }

    @classmethod
    def _reason(cls, error: str | None) -> str:
        """Turn a stored error code into a sentence a person can act on.

        What used to reach the status line was the raw ``requests`` text, e.g.
        "403 Client Error: Forbidden for url: https://...", which says nothing
        about what to do next. Every sentence comes from i18n, so it reads
        correctly in either interface language.
        """
        code = (error or "").strip()
        if code in cls._REASONS:
            return i18n.t(cls._REASONS[code])
        if not code:
            return i18n.t("win.reason.unknown")
        status = re.match(r"(\d{3})", code)
        if status:
            said = i18n.t(cls._HTTP.get(status.group(1), "win.reason.denied"))
            return f"{said} ({status.group(1)})"
        if "timed out" in code.lower() or "timeout" in code.lower():
            return i18n.t("win.reason.timeout2")
        if "connection" in code.lower() or "resolve" in code.lower():
            return i18n.t("win.reason.conn")
        if "truncated" in code.lower() or "انقطع" in code:
            return i18n.t("win.reason.truncated")
        if "الحد المسموح" in code:
            return code
        if " " in code:
            # Still an internal sentence from requests; keep it short.
            return code.split(":")[0][:60]
        return code

    def _no_file(self, page: CategoryTab, row: int) -> None:
        result = page.cards_result(row)
        title = result.title if result else ""
        self._status(
            i18n.t("win.no_file", title=title),
            speak=i18n.t("speak.no_file"),
        )

    def open_downloads_folder(self) -> None:
        """Alt+O: show the folder the finished files are actually in."""
        folder = self._downloads.config.download_folder
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            self._status(
                i18n.t("win.folder_fail", error=exc),
                speak=i18n.t("speak.folder_fail"),
            )
            return
        opened = QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
        self._status(
            i18n.t("win.folder_status", path=folder),
            speak=i18n.t("speak.folder_ok") if opened else i18n.t("speak.folder"),
        )

    def open_help(self) -> None:
        """F1: a summary of the buttons and shortcuts, in plain text.

        A single shared instance, so pressing F1 twice raises the same window
        instead of stacking copies. It inherits the window stylesheet so the
        font zoom and colours match the main window.
        """
        if self._help is not None and self._help.isVisible():
            self._help.raise_()
            self._help.activateWindow()
            return
        self._help = HelpDialog(self)
        self._help.setStyleSheet(self.styleSheet())
        self._help.show()

    def open_about(self) -> None:
        """The About button: version, build date, sources -- read-only facts.

        Opens with exec(), not show(): a non-modal dialog leaves focus on the
        main window and NVDA says nothing. A modal exec() grabs focus the same
        way Preferences does, so the reader is told the window opened.
        """
        dialog = AboutDialog(self)
        dialog.setStyleSheet(self.styleSheet())
        dialog.exec()

    def open_preferences(self) -> None:
        """Alt+S / the settings button.

        Citation style and API keys take effect immediately. Interface language
        cannot change the widgets already on screen, so it is saved and the
        user is told to restart rather than being left with a half-translated
        window that looks like a bug.
        """
        dialog = PreferencesDialog(self)
        if dialog.exec() != PreferencesDialog.Accepted:
            return
        old_language, language_changed = dialog.apply_to_config()

        style = get_config().citation_style
        self._status(
            i18n.t("win.prefs_saved", style=style_label(style)),
            speak=i18n.t("speak.prefs_saved")
            + (i18n.t("speak.prefs_restart") if language_changed else ""),
        )

    def cite_current(self) -> None:
        """Alt+C: copy the citation of the result under the caret."""
        page = self.pages.get(self._current_category())
        if page is None or not page.cite_current():
            self._status(i18n.t("win.no_selection_cite"))

    def _build_summary(self, result: Result) -> str:
        parts = []
        parts.append(result.title or "")
        if result.authors:
            parts.append(", ".join(result.authors))
        if result.year:
            parts.append(str(result.year))
        if result.venue:
            parts.append(result.venue)
        vparts = []
        if result.volume:
            v = result.volume
            if result.issue:
                v += f"({result.issue})"
            vparts.append(v)
        if result.pages:
            vparts.append(result.pages)
        if vparts:
            parts.append(": ".join(vparts))
        if result.abstract:
            parts.append(result.abstract)
        text = ". ".join(p for p in parts if p)
        return text[:4000]

    def _copy_summary(self, result: Result) -> None:
        if (result.abstract or "").strip():
            self._share_summary_copy(result)
            return
        # Most metadata-only records ship no abstract; ask the DOI sources for
        # it instead of silently copying a title line and claiming a summary.
        if not self._start_abstract_fetch(result, "copy"):
            self._status(
                i18n.t("win.summary_missing", title=result.title),
                speak=i18n.t("speak.summary_missing"),
            )

    def _share_summary_copy(self, result: Result) -> None:
        QApplication.clipboard().setText(self._build_summary(result))
        self._status(
            i18n.t("win.summary_copied"),
            speak=i18n.t("speak.summary_copied"),
        )

    def _start_abstract_fetch(self, result: Result, intent: str) -> bool:
        """Begin a DOI lookup for a record with no abstract. True if started."""
        from app.core.abstracts import has_doi

        if not has_doi(result):
            return False
        self._summary_result = result
        self._summary_intent = intent
        self._status(
            i18n.t("win.summary_fetching"),
            speak=i18n.t("speak.summary_fetching"),
        )
        import threading

        def worker() -> None:
            from app.core.abstracts import fetch_abstract

            try:
                fetch_abstract(result)
            except Exception:  # noqa: BLE001 - the UI falls back to "no summary"
                pass
            self.summary_ready.emit(result)

        threading.Thread(
            target=worker, name="acad-abstract", daemon=True
        ).start()
        return True

    def _on_summary_ready(self, result: Result) -> None:
        """Slot for the DOI lookup: show or copy what came back."""
        if result is not self._summary_result:
            return  # superseded by a newer press; that answer will speak.
        intent = self._summary_intent
        self._summary_result = None
        if not (result.abstract or "").strip():
            self._status(
                i18n.t("win.summary_missing", title=result.title),
                speak=i18n.t("speak.summary_missing"),
            )
            return
        if intent == "copy":
            self._share_summary_copy(result)
        else:
            self.summary_view.setPlainText(self._build_summary(result))
            self.summary_view.setVisible(True)
            self._status(
                i18n.t("win.summary_shown"),
                speak=i18n.t("speak.summary_shown"),
            )

    def show_summary(self) -> None:
        """Alt+M: show the summary of the selected result, read-only.

        Separate from نسخ الملخص on purpose: copying needs the clipboard,
        reading does not, and the reader who just moved to a row wants to
        know what the thing is about before deciding to download it. The
        announcement stays short; the text itself waits in the field.
        """
        page = self.pages.get(self._current_category())
        card = page.focused_card() if page is not None else None
        if card is None:
            self._status(i18n.t("win.no_selection_summary"))
            return
        if not (card.result.abstract or "").strip():
            # No abstract in the record: try the DOI sources first, so most
            # journal results still show a real summary here.
            if self._start_abstract_fetch(card.result, "show"):
                return
            self.summary_view.setVisible(False)
            self._status(
                i18n.t("win.summary_missing", title=card.result.title),
                speak=i18n.t("speak.summary_missing"),
            )
            return
        self.summary_view.setPlainText(self._build_summary(card.result))
        self.summary_view.setVisible(True)
        self._status(
            i18n.t("win.summary_shown"),
            speak=i18n.t("speak.summary_shown"),
        )

    def _copy_citation(self, result: Result) -> None:
        style = get_config().citation_style
        try:
            text = format_citation(result, style)
        except Exception as exc:
            self._status(
                i18n.t("win.cite_failed", error=exc),
                speak=i18n.t("speak.cite_failed"),
            )
            return

        QApplication.clipboard().setText(text)
        self.citation_view.setText(text)
        self.citation_view.setVisible(True)
        self._status(
            i18n.t("win.cite_copied", style=style_label(style)),
            speak=i18n.t("speak.cite_copied"),
        )

    def download_current(self) -> None:
        """Alt+D: download whatever result the caret is on."""
        page = self.pages.get(self._current_category())
        if page is None or not page.act_on_current():
            self._status(i18n.t("win.no_selection_download"))

    def _current_category(self) -> Category | None:
        index = self.tabs.currentIndex()
        for category, position in CATEGORY_TAB_INDEX.items():
            if position == index:
                return category
        return None

    def closeEvent(self, event):
        self._engine.shutdown()
        super().closeEvent(event)


def main() -> int:
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    win.raise_()
    win.activateWindow()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
