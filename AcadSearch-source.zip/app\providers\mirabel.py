"""Mir@bel — French journal directory.

Mir@bel lists French and Francophone journals and links to content.
"""

from __future__ import annotations

import re
import threading
from urllib.parse import urljoin

from app.core.text_utils import clean_text
from app.models import (
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

SEARCH_URL = "https://reseau-mirabel.info/"

_TAG_RE = re.compile(r"<[^>]+>")
_A_RE = re.compile(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', re.I | re.S)


@register
class MirabelProvider(BaseProvider):
    provider_id = "mirabel"
    display_name = "Mir@bel (دليل دوريات فرنسية)"
    categories = (Category.ARTICLE, Category.RESEARCH)
    weight = 33
    homepage = "https://reseau-mirabel.info/"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = query.text.strip()
        if not text:
            return []

        if cancel is not None and cancel.is_set():
            return []

        wanted = max(10, min(query.per_source, 30))

        params = {"recherche": text}

        try:
            html = self.http.get_text(
                SEARCH_URL,
                params=params,
                provider=self.provider_id,
                cancel=cancel,
            )
        except ProviderError:
            raise
        except Exception as exc:
            raise ProviderError(f"mirabel: {type(exc).__name__}", kind="error") from exc

        if cancel is not None and cancel.is_set():
            return []

        out: list[Result] = []
        seen = set()

        for m in _A_RE.finditer(html):
            href = m.group(1)
            if not href.startswith("http"):
                href = urljoin(SEARCH_URL, href)
            if 'reseau-mirabel.info' not in href:
                continue
            if '/revue/' not in href and '/numero/' not in href:
                continue
            title = clean_text(_strip_html(m.group(2)))
            if not title or len(title) < 10:
                continue
            if title.lower() in ('accueil', 'recherche', 'aide'):
                continue
            if href in seen:
                continue
            seen.add(href)

            out.append(
                Result(
                    category=Category.ARTICLE,
                    title=title,
                    source=self.provider_id,
                    authors=[],
                    year=None,
                    abstract="",
                    venue="Mir@bel",
                    language="fr",
                    identifiers={"source": self.provider_id},
                    downloads=[target(href, DownloadFormat.HTML, label="Mir@bel", open_access=True)],
                    landing_url=href,
                )
            )
            if len(out) >= wanted:
                break

        return out


def _strip_html(value: str) -> str:
    if "<" not in value:
        return value
    text = _TAG_RE.sub(" ", value)
    return clean_text(text.replace("&nbsp;", " "))
