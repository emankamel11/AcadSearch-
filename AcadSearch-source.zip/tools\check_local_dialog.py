"""Check the local-file citation dialog without a visible window.

Run:  python -X utf8 tools/check_local_dialog.py
"""

from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))
sys.path.insert(0, str(_ROOT / "qt_prototype"))

from PySide6.QtWidgets import QApplication, QDialog  # noqa: E402

from app import i18n  # noqa: E402
from app.config import get_config  # noqa: E402
from qt_prototype.local_file_dialog import LocalFileDialog  # noqa: E402

failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  ok   {name}")
    else:
        failures.append(name)
        print(f"  FAIL {name}  {detail}")


def make_pdf(folder: Path) -> Path:
    path = folder / "retour.pdf"
    path.write_bytes(
        b"%PDF-1.4\n"
        b"1 0 obj\n"
        b"<< /Title (Le Retour du Roi Jibril) "
        b"/Author (Rams\\351s Kefi; Rachid La\\357reche) "
        b"/CreationDate (D:20250101000000) >>\n"
        b"endobj\n%%EOF\n"
    )
    return path


def main() -> int:
    app = QApplication.instance() or QApplication([])
    config = get_config()
    config.citation_style = "apa"

    with tempfile.TemporaryDirectory() as tmp:
        dialog = LocalFileDialog(make_pdf(Path(tmp)))

        print("== prefilled from the file ==")
        check("title field", dialog.title_edit.text() == "Le Retour du Roi Jibril",
              dialog.title_edit.text())
        check("authors field",
              dialog.authors_edit.text() == "Ramsés Kefi; Rachid Laïreche",
              dialog.authors_edit.text())
        check("year field", dialog.year_edit.text() == "2025", dialog.year_edit.text())
        check("kind defaults to book", dialog.kind_combo.currentData() == "book",
              str(dialog.kind_combo.currentData()))

        print("== preview follows the fields ==")
        preview = dialog.preview.toPlainText()
        check("preview has the title", "Le Retour du Roi Jibril" in preview, preview)
        check("preview has the year", "(2025)" in preview, preview)

        dialog.year_edit.setText("1999")
        check("editing the year refreshes the preview",
              "(1999)" in dialog.preview.toPlainText(),
              dialog.preview.toPlainText())

        print("== switching to article changes the shape ==")
        dialog.kind_combo.setCurrentIndex(list(
            dialog.kind_combo.itemData(i) for i in range(dialog.kind_combo.count())
        ).index("article"))
        dialog.venue_edit.setText("Revue de test")
        check("article keeps the journal",
              "Revue de test" in dialog.preview.toPlainText(),
              dialog.preview.toPlainText())

        print("== copy ==")
        copied: list[tuple[str, str]] = []
        dialog.citation_copied.connect(lambda text, style: copied.append((text, style)))
        dialog._copy()
        clipboard = QApplication.clipboard().text()
        check("clipboard got the citation", clipboard == dialog.preview.toPlainText(),
              clipboard)
        check("signal fired once with the style", len(copied) == 1 and copied[0][1] == "apa",
              repr(copied))

        print("== empty title is refused ==")
        dialog.title_edit.setText("")
        copied.clear()
        dialog._copy()
        check("copy disabled / refused on empty title", not copied, repr(copied))
        check("a hint is shown", dialog.status.text() == i18n.t("local.need_title"),
              dialog.status.text())

        print("== DOI/ISBN lookup fills only empty fields ==")
        bare = Path(tmp) / "bare.pdf"
        bare.write_bytes(b"%PDF-1.4\n%%EOF\n")
        second = LocalFileDialog(bare)
        second._apply_lookup(
            {
                "title": "Deep learning",
                "authors": ["Yann LeCun", "Yoshua Bengio"],
                "year": 2015,
                "venue": "Nature",
                "doi": "10.1038/nature14539",
                "source": "doi",
            }
        )
        check("placeholder title replaced", second.title_edit.text() == "Deep learning",
              second.title_edit.text())
        check("authors filled",
              second.authors_edit.text() == "Yann LeCun; Yoshua Bengio",
              second.authors_edit.text())
        check("year filled", second.year_edit.text() == "2015", second.year_edit.text())
        check("venue filled", second.venue_edit.text() == "Nature", second.venue_edit.text())
        check("doi filled", second.doi_edit.text() == "10.1038/nature14539",
              second.doi_edit.text())
        check("status names the source", "DOI" in second.status.text(),
              second.status.text())
        check("preview follows the lookup", "Deep learning" in second.preview.toPlainText(),
              second.preview.toPlainText())

        second.title_edit.setText("My own title")
        second._apply_lookup({"title": "Other", "authors": ["Someone"], "source": "isbn"})
        check("a user edit is not overwritten", second.title_edit.text() == "My own title",
              second.title_edit.text())
        check("nothing found is announced",
              second.status.text() == i18n.t("local.lookup.none"), second.status.text())
        second.done(0)

        print("== file assistant ==")
        check("answer field exists", dialog.ai_view.isReadOnly())
        check("question field exists", dialog.question_edit.isEnabled())
        old_key = config.gemini_key
        config.gemini_key = ""
        dialog.question_edit.setText("ما موضوع الملف؟")
        dialog._ask()
        check("a missing key is explained",
              dialog.ai_status.text() == i18n.t("local.ai.no_key"),
              dialog.ai_status.text())
        check("the missing key is visible in the answer box",
              dialog.ai_view.toPlainText() == i18n.t("local.ai.no_key"),
              dialog.ai_view.toPlainText())
        check("the add-key button is offered",
              not dialog.ai_setup_btn.isHidden(),
              str(dialog.ai_setup_btn.isHidden()))
        dialog.question_edit.setText("")
        dialog._ask()
        check("an empty question is refused",
              dialog.ai_status.text() == i18n.t("local.ai.empty_question"),
              dialog.ai_status.text())

        config.gemini_key = "test-key"
        from app.core.doc_ai import Answer

        print("== the wait is visible while Gemini works ==")
        dialog._ai_stage = i18n.t("local.ai.thinking")
        dialog._ai_started = time.monotonic() - 65
        dialog._on_ai_progress("ai.progress.part", {"index": 2, "total": 3})
        progress_text = dialog.ai_view.toPlainText()
        check("progress names the part being sent",
              "2" in progress_text and "3" in progress_text, progress_text)
        check("progress shows the elapsed time", "1:05" in progress_text,
              progress_text)
        check("progress replaces the empty box",
              progress_text.strip() != "", progress_text)

        dialog._on_ai_ok(Answer("ملخص تجريبي", images=3, truncated=True))
        answer_text = dialog.ai_view.toPlainText()
        check("the answer is shown", "ملخص تجريبي" in answer_text, answer_text)
        check("the images are disclosed",
              i18n.t("local.ai.images_read", n=3) in answer_text, answer_text)
        check("truncation is disclosed",
              i18n.t("local.ai.truncated") in answer_text, answer_text)
        check("ready is announced",
              dialog.ai_status.text() == i18n.t("local.ai.ready"),
              dialog.ai_status.text())
        dialog._on_ai_fail("ai.error.quota", {})
        check("a failure is spoken",
              dialog.ai_status.text() == i18n.t("ai.error.quota"),
              dialog.ai_status.text())
        check("a failure is shown in the answer box",
              dialog.ai_view.toPlainText() == i18n.t("ai.error.quota"),
              dialog.ai_view.toPlainText())
        config.gemini_key = old_key
        dialog.done(0)

        print("== close button ==")
        closing = LocalFileDialog(make_pdf(Path(tmp)))
        closing.show()
        app.processEvents()
        closing.close_btn.click()
        app.processEvents()
        check("Close hides the dialog", not closing.isVisible(),
              str(closing.isVisible()))
        check("Close is a rejection, not a save",
              closing.result() == QDialog.Rejected, str(closing.result()))
        check("Close has an accessible name",
              closing.close_btn.accessibleName() == i18n.t("local.close"),
              closing.close_btn.accessibleName())

    print()
    if failures:
        print(f"FAILED: {len(failures)} check(s): {failures}")
        return 1
    print("ALL LOCAL-DIALOG CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
