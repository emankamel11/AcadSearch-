"""Visual design system: colour roles, typography and spacing.

CustomTkinter ships with its own light/dark palettes, but a research tool needs
*semantic* roles (surface, muted text, danger…) that stay meaningful in both
modes. This module owns that mapping so widgets never hard-code a hex value.

Two concepts:

* :func:`detect_system_mode` follows the Windows appearance setting, which is
  what "automatic" means for a desktop app.
* :data:`PALETTES` holds the concrete colours; :func:`get_palette` resolves the
  active one. Calling :func:`apply_theme` switches CustomTkinter's global
  appearance mode so stock widgets (scrollbars, entry carets) match.
"""

from __future__ import annotations

import tkinter as tk
from dataclasses import dataclass, field
from tkinter import font as tkfont

import customtkinter as ctk

from app.config import APP_NAME, APP_VERSION

DPI_AWARENESS_SET = False


#: Design size of the main window, in *logical* pixels at 100% scaling.
DEFAULT_WINDOW_W = 1180
DEFAULT_WINDOW_H = 800
MIN_WINDOW_W = 880
MIN_WINDOW_H = 600


def monitor_scale(window: tk.Misc | None = None) -> float:
    """Return the display scaling factor (1.0 at 100%, 1.5 at 150%, …).

    Falls back to Tk's own ``tk scaling`` when CustomTkinter cannot be queried,
    which is what happens on a headless or locked-down session.
    """
    factor = 1.0
    if window is not None:
        try:
            factor = float(ctk.ScalingTracker.get_window_scaling(window))
        except Exception:
            factor = 1.0
    if factor <= 0:
        factor = 1.0
    return factor


def fit_window(
    window: tk.Misc,
    want_w: int = DEFAULT_WINDOW_W,
    want_h: int = DEFAULT_WINDOW_H,
    min_w: int = MIN_WINDOW_W,
    min_h: int = MIN_WINDOW_H,
) -> tuple[int, int]:
    """Size a window for the current monitor and clamp it to the screen.

    Tk geometry is expressed in *physical* pixels. On a 150% or 200% display a
    hard-coded 1180x800 would therefore cover only two thirds or half of the
    logical area it is meant to fill, and on a 1366x768 laptop the 800px
    height is taller than the screen itself. Scaling by the monitor factor and
    clamping to the work area keeps the window the same apparent size on every
    display. Returns the applied ``(width, height)``.
    """
    scale = monitor_scale(window)
    width = max(min_w, round(want_w * scale))
    height = max(min_h, round(want_h * scale))

    try:
        screen_w = window.winfo_screenwidth()
        screen_h = window.winfo_screenheight()
    except Exception:
        screen_w = screen_h = 0
    if screen_w and screen_h:
        # Leave room for the taskbar and the title bar.
        width = min(width, max(min_w, screen_w - 40))
        height = min(height, max(min_h, screen_h - 80))
        # If the minimum itself does not fit, honour the screen instead.
        width = min(width, screen_w)
        height = min(height, screen_h)

    window.geometry(f"{width}x{height}")
    window.minsize(min(min_w, width), min(min_h, height))
    return width, height


def enable_dpi_awareness() -> None:
    """Make the UI crisp on high-DPI screens before the Tk root exists.

    Must run before any window is created, hence the module-level call from
    ``main.py``. CustomTkinter issues the same call when its first window is
    constructed; doing it here just guarantees it happens first.

    ``ctk.deactivate_automatic_dpi_awareness()`` is deliberately *not* called.
    That flag short-circuits
    ``ScalingTracker.get_window_dpi_scaling()`` to a flat ``1.0``, which
    disables every CustomTkinter pixel measurement -- padding, corner radii
    and control sizes all stay at 100% while Windows scales the fonts, so on a
    150% or 200% monitor the layout collapses. Leaving it off is what makes the
    per-monitor scaling below actually apply.
    """
    global DPI_AWARENESS_SET
    if DPI_AWARENESS_SET:
        return
    DPI_AWARENESS_SET = True
    try:
        from ctypes import windll  # type: ignore[attr-defined]

        windll.shcore.SetProcessDpiAwareness(2)  # PROCESS_PER_MONITOR_DPI_AWARE
    except Exception:  # pragma: no cover - best effort on older Windows
        try:
            windll_user32 = __import__("ctypes").windll.user32
            windll_user32.SetProcessDPIAware()
        except Exception:
            pass


def detect_system_mode() -> str:
    """Return ``"dark"`` or ``"light"`` based on the Windows theme."""
    try:
        import winreg

        key_path = r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path) as key:
            value, _ = winreg.QueryValueEx(key, "AppsUseLightTheme")
        return "light" if int(value) else "dark"
    except Exception:
        return "light"  # the safe default on an unknown platform


@dataclass(frozen=True)
class Palette:
    """Semantic colour roles for one appearance mode."""

    name: str
    bg: str
    surface: str
    surface_alt: str
    surface_hover: str
    border: str
    border_strong: str
    text: str
    text_muted: str
    text_faint: str
    text_on_accent: str
    accent: str
    accent_hover: str
    accent_soft: str
    success: str
    warning: str
    danger: str
    info: str
    focus: str
    shadow: str

    # Access-chip colours, keyed by models.Access value.
    access_colors: dict[str, tuple[str, str]] = field(default_factory=dict)


DARK = Palette(
    name="dark",
    bg="#11141a",
    surface="#191e27",
    surface_alt="#212836",
    surface_hover="#28303f",
    border="#2b3444",
    border_strong="#3d4859",
    text="#e8ecf3",
    text_muted="#a4aec0",
    text_faint="#6d7889",
    text_on_accent="#ffffff",
    accent="#5b9bff",
    accent_hover="#4a8bf0",
    accent_soft="#1d2b45",
    success="#3ddc84",
    warning="#f7b955",
    danger="#ff6b6b",
    info="#5b9bff",
    focus="#ffd166",
    shadow="#000000",
    access_colors={
        "download": ("#123524", "#5fe3a1"),
        "landing": ("#15263f", "#8fc0ff"),
        "borrow": ("#3a2f10", "#f7c95c"),
        "metadata": ("#232935", "#9aa5b6"),
    },
)

LIGHT = Palette(
    name="light",
    bg="#f2f5f9",
    surface="#ffffff",
    surface_alt="#eef2f8",
    surface_hover="#e4eaf4",
    border="#dce3ed",
    border_strong="#b8c3d4",
    text="#151b26",
    text_muted="#5b6678",
    text_faint="#8b95a6",
    text_on_accent="#ffffff",
    accent="#2563eb",
    accent_hover="#1d4ed8",
    accent_soft="#dbe8ff",
    success="#15803d",
    warning="#b45309",
    danger="#dc2626",
    info="#2563eb",
    focus="#b45309",
    shadow="#9aa8bd",
    access_colors={
        "download": ("#dcfce7", "#15803d"),
        "landing": ("#dbeafe", "#1d4ed8"),
        "borrow": ("#fef3c7", "#b45309"),
        "metadata": ("#eef1f6", "#5b6678"),
    },
)

PALETTES: dict[str, Palette] = {"dark": DARK, "light": LIGHT}


# ---------------------------------------------------------------------------
# Typography
# ---------------------------------------------------------------------------
#: Windows fonts that shape Arabic correctly.
ARABIC_FONTS = ("Segoe UI", "Tahoma", "Arial")
LATIN_FONTS = ("Segoe UI", "Calibri", "Arial")

#: font role -> (size, weight)
TYPE_SCALE: dict[str, tuple[int, str]] = {
    "display": (20, "bold"),
    "title": (15, "bold"),
    "subtitle": (12, "bold"),
    "body": (12, "normal"),
    "body_bold": (12, "bold"),
    "small": (11, "normal"),
    "small_bold": (11, "bold"),
    "caption": (10, "normal"),
    "mono": (11, "normal"),
}


class Fonts:
    """Caches :class:`customtkinter.CTkFont` instances per role and scale."""

    def __init__(self, family_ui: str = "", scale: float = 1.0):
        self.family_ui = family_ui or _pick_family()
        self.family_content = _pick_family(content=True)
        self.scale = max(0.75, min(1.75, scale))
        self._cache: dict[str, ctk.CTkFont] = {}

    def role(self, name: str) -> ctk.CTkFont:
        key = f"{name}"
        if key in self._cache:
            return self._cache[key]
        size, weight = TYPE_SCALE.get(name, TYPE_SCALE["body"])
        font = ctk.CTkFont(
            family=self.family_ui if name != "mono" else "Consolas",
            size=max(7, round(size * self.scale)),
            weight=weight,
        )
        self._cache[key] = font
        return font

    def content(self, size: int = 12, bold: bool = False) -> ctk.CTkFont:
        return self.role("body_bold" if bold else "body")

    def scaled(self, name: str) -> ctk.CTkFont:
        return self.role(name)

    def set_scale(self, scale: float) -> None:
        self.scale = max(0.75, min(1.75, scale))
        self._cache.clear()

    def set_family(self, family: str) -> None:
        self.family_ui = family or _pick_family()
        self.family_content = _pick_family(content=True)
        self._cache.clear()


def _pick_family(content: bool = False) -> str:
    """Return the first installed family that can render Arabic."""
    try:
        available = set(tkfont.families())
    except Exception:  # pragma: no cover - no Tk yet
        return "Segoe UI"
    for family in ARABIC_FONTS:
        if family in available:
            return family
    return "Segoe UI" if "Segoe UI" in available else "Arial"


# ---------------------------------------------------------------------------
# Theme application
# ---------------------------------------------------------------------------
_active: str = "light"


def active_mode() -> str:
    return _active


def resolve_mode(preference: str) -> str:
    """``system`` -> the concrete light/dark mode in force."""
    if preference in ("dark", "light"):
        return preference
    return detect_system_mode()


def get_palette(mode: str | None = None) -> Palette:
    return PALETTES.get(mode or _active, LIGHT)


def apply_theme(preference: str = "system") -> Palette:
    """Switch CustomTkinter to the resolved mode and return its palette."""
    global _active
    _active = resolve_mode(preference)
    try:
        ctk.set_appearance_mode(_active)
    except Exception:  # pragma: no cover - defensive
        pass
    return get_palette(_active)


def style_palette() -> Palette:
    """The palette matching the appearance CustomTkinter is already in."""
    return get_palette(ctk.get_appearance_mode())


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Metrics:
    """Spacing and sizing tokens (scaled by the user's font-size setting)."""

    scale: float = 1.0
    xs: int = 4
    sm: int = 8
    md: int = 12
    lg: int = 18
    xl: int = 26
    radius: int = 10
    radius_sm: int = 6
    card_pad: int = 14
    row_h: int = 30
    button_h: int = 34
    min_button_w: int = 96

    @classmethod
    def scaled(cls, scale: float) -> "Metrics":
        scale = max(0.75, min(1.75, scale))

        def v(base: int) -> int:
            return max(1, round(base * scale))

        return cls(
            scale=scale,
            xs=v(4),
            sm=v(8),
            md=v(12),
            lg=v(18),
            xl=v(26),
            radius=v(10),
            radius_sm=v(6),
            card_pad=v(14),
            row_h=v(30),
            button_h=v(34),
            min_button_w=v(96),
        )


def app_title() -> str:
    from app import i18n

    return f"{APP_NAME} {APP_VERSION}" if i18n.get_language() == "en" else f"{APP_NAME} {APP_VERSION}"
