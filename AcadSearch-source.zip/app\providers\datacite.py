"""DataCite — DOI metadata for research data, software and other outputs.

Docs: https://support.datacite.org/docs/api
No API key is needed to search. DataCite is the registry behind ``doi.org``
for datasets, software and data-management records, which fills a hole the
article-focused sources leave open: a researcher looking for data will find
it here. Records usually have a repository landing page rather than a file.
"""

from __future__ import annotations

import threading

from app.core.text_utils import (
    as_int,
    clean_text,
    extract_doi,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register

ENDPOINT = "https://api.datacite.org/dois"

#: DataCite ``resourceTypeGeneral`` labels routed to the research tab.
RESEARCH_TYPES = {"dataset", "software", "preprint", "report", "model"}
BOOK_TYPES = {"book", "book-chapter"}


@register
class DataCiteProvider(BaseProvider):
    provider_id = "datacite"
    display_name = "DataCite"
    categories = (Category.RESEARCH, Category.ARTICLE, Category.BOOK)
    weight = 40
    homepage = "https://datacite.org"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        params: dict[str, object] = {
            "query": query.text,
            "page[size]": min(query.per_source, 25),
            "page[number]": 1,
        }
        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        return [self._to_result(record) for record in (payload.get("data") or [])]

    # -- mapping ----------------------------------------------------------
    def _to_result(self, record: dict) -> Result:
        attrs = record.get("attributes") or {}
        titles = attrs.get("titles") or []
        title = clean_text((titles[0] if titles else {}).get("title"))

        creators = [
            clean_text(c.get("name"))
            for c in (attrs.get("creators") or [])
            if c.get("name")
        ]
        creators = [c for c in creators if c]

        rtype = clean_text(
            ((attrs.get("types") or {}).get("resourceTypeGeneral")
             or (attrs.get("types") or {}).get("resourceType"))
        ).lower()
        if any(t in rtype for t in BOOK_TYPES):
            category = Category.BOOK
        elif any(t in rtype for t in RESEARCH_TYPES) or not rtype:
            category = Category.RESEARCH
        else:
            category = Category.ARTICLE

        descriptions = attrs.get("descriptions") or []
        abstract = ""
        for d in descriptions:
            body = clean_text(d.get("description"))
            if body:
                abstract = body
                break

        doi = extract_doi(attrs.get("doi") or record.get("id"))
        landing_url = clean_text(attrs.get("url")) or (
            f"https://doi.org/{doi}" if doi else ""
        )

        identifiers: dict[str, str] = {}
        if doi:
            identifiers["doi"] = doi

        return Result(
            category=category,
            title=title,
            source=self.provider_id,
            authors=creators,
            year=as_int(attrs.get("publicationYear")),
            abstract=truncate_words(abstract, 320),
            venue=clean_text(attrs.get("publisher")) or "DataCite",
            publisher=clean_text(attrs.get("publisher")),
            language=normalise_language(clean_text(attrs.get("language"))),
            identifiers=identifiers,
            access=Access.LANDING if landing_url else Access.METADATA,
            downloads=[],
            landing_url=landing_url,
            item_type=clean_text(((attrs.get("types") or {}).get("resourceType")
                                  or (attrs.get("types") or {}).get("resourceTypeGeneral"))),
            raw=record,
        )