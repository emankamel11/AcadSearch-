"""OpenEdition Journals — French humanities and social sciences open access.

OpenEdition Journals (journals.openedition.org) publishes thousands of
open-access journals in the humanities and social sciences, mostly in
French. Articles are generally free to read and many link directly to
PDF versions.

This provider uses OpenEdition's HTML search and normalises results
to the app's Result model.
"""

from __future__ import annotations

import re
import threading
from urllib.parse import urljoin

from app.core.text_utils import clean_text, truncate_words
from app.models import (
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

SEARCH_URL = "https://journals.openedition.org/"

_TAG_RE = re.compile(r"<[^>]+>")
_HREF_RE = re.compile(r'href=[\'"]([^\'"]+)[\'"]', re.I)
_TITLE_RE = re.compile(r'<h[23][^>]+class=["\'][^"\']*(?:title|titre)[^"\']*["\'][^>]*>.*?<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', re.I | re.S)
_ITEM_RE = re.compile(r'<(?:article|li)[^>]+class=["\'][^"\']*(?:result|item)[^"\']*["\'][^>]*>(.*?)</(?:article|li)>', re.I | re.S)
_A_RE = re.compile(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', re.I | re.S)
_PDF_RE = re.compile(r'href=[\'"]([^\'"]+\.pdf[^\'"]*)[\'"]', re.I)


@register
class OpenEditionProvider(BaseProvider):
    provider_id = "openedition"
    display_name = "OpenEdition Journals (فرنسي/إنسانيات)"
    categories = (Category.ARTICLE, Category.RESEARCH)
    weight = 35
    homepage = "https://journals.openedition.org/"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = query.text.strip()
        if not text:
            return []

        if cancel is not None and cancel.is_set():
            return []

        wanted = max(10, min(query.per_source, 40))

        params = {
            "q": text,
            "lang": "fr",
        }

        try:
            html = self.http.get_text(
                SEARCH_URL,
                params=params,
                provider=self.provider_id,
                cancel=cancel,
            )
        except ProviderError:
            raise
        except Exception as exc:
            raise ProviderError(
                f"openedition: {type(exc).__name__}", kind="error"
            ) from exc

        if cancel is not None and cancel.is_set():
            return []

        out: list[Result] = []
        seen = set()

        for match in _ITEM_RE.finditer(html):
            block = match.group(1)
            item = self._parse_block(block)
            if item is None:
                continue
            key = item.landing_url or item.title
            if key in seen:
                continue
            seen.add(key)
            out.append(item)
            if len(out) >= wanted:
                break

        if out:
            return out

        for match in _TITLE_RE.finditer(html):
            href = match.group(1)
            title_html = match.group(2)
            title = clean_text(_strip_html(title_html))
            if not title or len(title) < 3:
                continue
            url = urljoin(SEARCH_URL, href)
            if url in seen:
                continue
            seen.add(url)
            out.append(
                Result(
                    category=Category.ARTICLE,
                    title=title,
                    source=self.provider_id,
                    authors=[],
                    year=None,
                    abstract="",
                    venue="OpenEdition Journals",
                    language="fr",
                    identifiers={"source": self.provider_id},
                    downloads=[target(url, DownloadFormat.HTML, label="OpenEdition", open_access=True)],
                    landing_url=url,
                )
            )
            if len(out) >= wanted:
                break

        return out

    def _parse_block(self, block: str) -> Result | None:
        title = ""
        url = ""
        for m in _A_RE.finditer(block):
            href = m.group(1)
            text_html = m.group(2)
            t = clean_text(_strip_html(text_html))
            if not t:
                continue
            if len(t) > len(title) and "openedition" in href.lower() or "/journals/" in href or "/documents/" in href or "/index" in href:
                if not href.startswith(("http://", "https://")):
                    href = urljoin(SEARCH_URL, href)
                if any(x in href for x in (".pdf", "javascript:", "mailto:")):
                    continue
                title = t
                url = href
                break

        if not title or not url:
            return None

        authors = []
        for m in re.finditer(r'class=["\'][^"\']*(?:author|auteur)[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S):
            a = clean_text(_strip_html(m.group(1)))
            if a and len(a) < 80:
                authors.append(a)

        year = None
        m = re.search(r'(\b(1[0-9]{3}|20[0-9]{2})\b)', block)
        if m:
            year = int(m.group(1))

        abstract = ""
        for m in re.finditer(r'class=["\'][^"\']*(?:abstract|resume)[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S):
            abstract = clean_text(_strip_html(m.group(1)))
            break
        abstract = truncate_words(abstract, 90)

        journal = ""
        for m in re.finditer(r'class=["\'][^"\']*(?:journal|revue|source)[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S):
            journal = clean_text(_strip_html(m.group(1)))
            break

        pdf_url = ""
        pm = _PDF_RE.search(block)
        if pm:
            pdf_url = urljoin(SEARCH_URL, pm.group(1))

        downloads = []
        if pdf_url:
            downloads.append(target(pdf_url, DownloadFormat.PDF, label="PDF", open_access=True))
        downloads.append(target(url, DownloadFormat.HTML, label="OpenEdition", open_access=True))

        return Result(
            category=Category.ARTICLE,
            title=title,
            source=self.provider_id,
            authors=authors[:12],
            year=year,
            abstract=abstract,
            venue=journal or "OpenEdition Journals",
            language="fr",
            identifiers={"source": self.provider_id},
            downloads=downloads,
            landing_url=url,
        )


def _strip_html(value: str) -> str:
    if "<" not in value:
        return value
    text = _TAG_RE.sub(" ", value)
    return clean_text(text.replace("&nbsp;", " "))
