"""Data-source adapters.

Importing this package registers every bundled provider. Use
:func:`app.providers.base.all_providers` to iterate them.
"""

from app.providers.base import (  # noqa: F401
    BaseProvider,
    ProviderError,
    all_providers,
    get_provider,
    infer_access,
    providers_for_category,
    register,
    target,
)

__all__ = [
    "BaseProvider",
    "ProviderError",
    "all_providers",
    "get_provider",
    "infer_access",
    "providers_for_category",
    "register",
    "target",
]
