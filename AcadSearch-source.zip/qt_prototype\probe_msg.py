import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from app.config import get_config
from app.core.search_engine import SearchEngine, SearchEventType
from app.models import Access, Category, DownloadFormat, DownloadTarget, Result

import main_window

app = QApplication([])
win = main_window.MainWindow()
win.show()

r = Result(
    category=Category.ARTICLE,
    title="A paper",
    source="open_library",
    year=2022,
    authors=["Sara"],
    downloads=[DownloadTarget(url="https://e.org/a.pdf", fmt=DownloadFormat.PDF, open_access=True)],
)


class FakeResponse:
    """Stands in for SearchResponse so _on_results can be checked directly."""

    def __init__(self, text, books, articles, research, elapsed, failed):
        self.query = type("Q", (), {"text": text})()
        self.elapsed = elapsed
        self.truncated = False
        self.reports = [type("R", (), {"provider_id": p, "failed": True})() for p in failed]
        self.results = {
            Category.BOOK: [r] * 0 + [
                Result(category=Category.BOOK, title=f"book {i}", source="open_library", year=2020)
                for i in range(books)
            ],
            Category.ARTICLE: [
                Result(category=Category.ARTICLE, title=f"art {i}", source="crossref", year=2021)
                for i in range(articles)
            ],
            Category.RESEARCH: [
                Result(category=Category.RESEARCH, title=f"res {i}", source="arxiv", year=2022)
                for i in range(research)
            ],
        }

    def total(self):
        return sum(len(v) for v in self.results.values())


print("=== books and articles, no research ===")
win._on_results(FakeResponse("الذكاء الاصطناعي", 20, 30, 0, 4.2, ["google_books"]), "")
print(" ", win.status.text())

print()
print("=== everything present ===")
win._on_results(FakeResponse("machine learning", 62, 111, 114, 2.4, []), "")
print(" ", win.status.text())

print()
print("=== nothing at all ===")
win._on_results(FakeResponse("zzzqqq", 0, 0, 0, 1.0, ["google_books", "semantic_scholar"]), "")
print(" ", win.status.text())

print()
print("=== start message ===")
win.query.setText("machine learning")
win.start_search()
print(" ", win.status.text())
win._worker.wait(120000)
win._worker = None
print()
print("DONE")