"""Check that the Books tab hides records unrelated to the query.

The Books tab merges catalogue records (Open Library, Google Books, Internet
Archive) with academic databases that answer a keyword query with OR semantics
(Zenodo, OpenAlex, CORE). Without a gate, searching for a novel returns literary
criticism, fiqh commentaries and monographs that merely mention one word. These
checks exercise the merge step directly, so they prove the behaviour without a
network.

Run:  python -X utf8 tools/check_books_relevance.py
"""

from __future__ import annotations

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))

from app.core.search_engine import _book_is_relevant, _finalise  # noqa: E402
from app.models import Category, Result, SearchQuery, SearchResponse  # noqa: E402

FAILED: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if condition else 'FAIL'}] {name}"
          + (f" -- {detail}" if detail else ""))
    if not condition:
        FAILED.append(name)


def book(
    title: str,
    authors: list[str] | None = None,
    *,
    abstract: str = "",
    source: str = "open_library",
    category: Category = Category.BOOK,
) -> Result:
    return Result(
        category=category,
        title=title,
        source=source,
        authors=list(authors or []),
        abstract=abstract,
    )


def run(text: str, records: dict[Category, list[Result]], field: str = "any"):
    response = SearchResponse(
        query=SearchQuery(text=text, field=field),
        results={key: list(value) for key, value in records.items()},
    )
    return _finalise(response)


def titles(response: SearchResponse, category: Category = Category.BOOK) -> list[str]:
    return [item.title for item in response.results.get(category, [])]


def main() -> int:
    print("== at least three good matches: the rest is noise ==")
    response = run("atomic habits", {
        Category.BOOK: [
            book("Atomic Habits", ["James Clear"]),
            book("Atomic Habits Workbook", ["James Clear"]),
            book("Atomic Habits Journal", ["James Clear"]),
            book("Sapiens", ["Yuval Noah Harari"]),
            book("Deep Learning", ["Ian Goodfellow"]),
            book("Clean Code", ["Robert C. Martin"]),
        ],
    })
    kept = titles(response)
    check("the three matching books survive", len(kept) == 3, str(kept))
    check("unrelated bestsellers are gone",
          "Sapiens" not in kept and "Clean Code" not in kept, str(kept))

    print()
    print("== fewer than three: fall back instead of an empty tab ==")
    response = run("atomic habits", {
        Category.BOOK: [
            book("Atomic Habits", ["James Clear"]),
            book("Sapiens", ["Yuval Noah Harari"]),
            book("Deep Learning", ["Ian Goodfellow"]),
            book("Clean Code", ["Robert C. Martin"]),
        ],
    })
    kept = titles(response)
    check("all four are kept when only one matches", len(kept) == 4, str(kept))

    print()
    print("== an author search lists that author's novels ==")
    response = run("نجيب محفوظ", {
        Category.BOOK: [
            book("الحرافيش", ["نجيب محفوظ"]),
            book("الثلاثية", ["نجيب محفوظ"]),
            book("أولاد حارتنا", ["نجيب محفوظ"]),
            book("بداية المجتهد ونهاية المقتصد", ["ابن رشد"]),
        ],
    })
    kept = titles(response)
    check("titles that never repeat the author name survive", len(kept) == 3,
          str(kept))
    check("an unrelated fiqh commentary is dropped",
          "بداية المجتهد ونهاية المقتصد" not in kept, str(kept))

    print()
    print("== the novel the reader typed is not buried by a famous namesake ==")
    response = run("بداية ونهاية نجيب محفوظ", {
        Category.BOOK: [
            book("بداية ونهاية", [], source="internet_archive"),
            book("بداية ونهاية نجيب محفوظ", ["عبدالرزاق"],
                 source="internet_archive"),
            book("306805 - بداية ونهاية", ["محفوظ، نجيب"],
                 source="internet_archive"),
            book("لغز الخلود", [], source="zenodo",
                 abstract="دراسة عن نجيب محفوظ ورواياته"),
            book("تاريخ مصر الحديث", [],
                 abstract="السياسة والاقتصاد في القرن العشرين"),
        ],
    })
    kept = titles(response)
    check("the scanned novel is kept", "بداية ونهاية" in kept, str(kept))
    check("the author-named copy is kept",
          "بداية ونهاية نجيب محفوظ" in kept, str(kept))
    check("a Zenodo record that only mentions the author is dropped",
          "لغز الخلود" not in kept, str(kept))
    check("a history book with no query word is dropped",
          "تاريخ مصر الحديث" not in kept, str(kept))

    print()
    print("== a two-word title still survives its own gate ==")
    response = run("بداية ونهاية", {
        Category.BOOK: [
            book("بداية ونهاية", [], source="internet_archive"),
            book("بداية ونهاية نجيب محفوظ", ["عبدالرزاق"],
                 source="internet_archive"),
            book("306805 - بداية ونهاية", ["محفوظ، نجيب"],
                 source="internet_archive"),
            book("لغز الخلود", [], source="zenodo",
                 abstract="رواية بداية ونهاية عند نجيب محفوظ"),
            book("تاريخ مصر الحديث", []),
        ],
    })
    kept = titles(response)
    check("the plain two-word title is first", kept[:1] == ["بداية ونهاية"],
          str(kept))
    check("the unrelated history book is gone", "تاريخ مصر الحديث" not in kept,
          str(kept))

    print()
    print("== a generic word does not filter anything ==")
    response = run("رواية", {
        Category.BOOK: [
            book("الحرافيش", ["نجيب محفوظ"]),
            book("Sapiens", ["Yuval Noah Harari"]),
            book("تاريخ مصر الحديث", []),
        ],
    })
    check("every record stays when the query is only a kind of book",
          len(titles(response)) == 3, str(titles(response)))

    response = run("رواية نادية يوسف السباعي", {
        Category.BOOK: [
            book("ناديا يوسف السباعي", ["يوسف السباعي"]),
            book("نادية 01 [01619]", [], source="internet_archive"),
            book("أرض النفاق", ["يوسف السباعي"]),
            book("Sapiens", ["Yuval Noah Harari"]),
        ],
    })
    kept = titles(response)
    check("the novel is found through its author even when the spelling differs",
          "ناديا يوسف السباعي" in kept, str(kept))
    check("the unrelated foreign book is dropped", "Sapiens" not in kept,
          str(kept))

    print()
    print("== the gate is for books only ==")
    articles = [
        book("Literary criticism of the Arabic novel", [], source="crossref",
             category=Category.ARTICLE),
        book("Naguib Mahfouz and the city", [], source="doaj",
             category=Category.ARTICLE),
    ]
    research = [
        book("A study of narrative space", [], source="openalex",
             category=Category.RESEARCH),
    ]
    response = run("بداية ونهاية نجيب محفوظ", {
        Category.BOOK: [
            book("بداية ونهاية", [], source="internet_archive"),
            book("بداية ونهاية نجيب محفوظ", ["عبدالرزاق"],
                 source="internet_archive"),
            book("306805 - بداية ونهاية", ["محفوظ، نجيب"],
                 source="internet_archive"),
            book("تاريخ مصر الحديث", []),
        ],
        Category.ARTICLE: articles,
        Category.RESEARCH: research,
    })
    check("the Books tab was filtered", len(titles(response)) == 3,
          str(titles(response)))
    check("Articles are untouched",
          titles(response, Category.ARTICLE) == [a.title for a in articles],
          str(titles(response, Category.ARTICLE)))
    check("Research is untouched",
          titles(response, Category.RESEARCH) == [r.title for r in research],
          str(titles(response, Category.RESEARCH)))

    print()
    print("== the relevance rule itself ==")
    words = {"بدايه", "ونهايه", "نجيب", "محفوظ"}
    check("a title word is enough",
          _book_is_relevant(book("بداية ونهاية", []), words))
    check("an author word is enough",
          _book_is_relevant(book("الحرافيش", ["نجيب محفوظ"]), words))
    check("three of four words in an abstract is enough",
          _book_is_relevant(
              book("دراسة", [], abstract="بداية ونهاية عند نجيب"), words))
    check("one word in an abstract is not enough",
          not _book_is_relevant(
              book("لغز الخلود", [], abstract="عن نجيب محفوظ"), words))
    check("two of four words in an abstract is not enough",
          not _book_is_relevant(
              book("لغز الخلود", [], abstract="نجيب محفوظ ورواياته"), words))

    print()
    if FAILED:
        print(f"FAILED: {len(FAILED)} check(s): {FAILED}")
        return 1
    print("ALL BOOKS-RELEVANCE CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
