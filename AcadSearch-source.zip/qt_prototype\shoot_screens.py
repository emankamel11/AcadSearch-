"""Render the window to a PNG so the design can actually be looked at.

Geometry assertions say "the button is 140x54". Only a picture shows whether
the result looks like a program a person would want to use.
"""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from app.models import (
    Access,
    Category,
    DownloadFormat,
    DownloadTarget,
    Result,
)

import main_window

app = QApplication([])
win = main_window.MainWindow()
win.resize(1180, 860)
win.show()
app.processEvents()

SAMPLES = {
    Category.BOOK: [
        ("Hands-On Machine Learning with Scikit-Learn, Keras and TensorFlow",
         ["Aurélien Géron"], 2022, Access.BORROW, None),
        ("Pattern Recognition and Machine Learning",
         ["Christopher M. Bishop"], 2006, Access.DOWNLOAD, "PDF"),
        ("Machine Learning For Dummies",
         ["John Paul Mueller"], 2016, Access.LANDING, None),
    ],
    Category.ARTICLE: [
        ("A Comparative Study of Machine Learning Methods for Arabic Text "
         "Classification",
         ["Sara Ahmed", "Omar Ali", "Nadia Hassan"], 2023,
         Access.DOWNLOAD, "PDF"),
        ("Deep Residual Learning for Image Recognition",
         ["Kaiming He", "Xiangyu Zhang", "Shaoqing Ren"], 2016,
         Access.LANDING, None),
    ],
    Category.RESEARCH: [
        ("Attention Is All You Need",
         ["Ashish Vaswani", "Noam Shazeer"], 2017, Access.DOWNLOAD, "PDF"),
        ("Recommender Systems Handbook",
         ["Francesco Ricci"], 2015, Access.LANDING, None),
    ],
}


def build(category: Category, rows) -> None:
    page = win.pages[category]
    for title, authors, year, access, fmt in rows:
        downloads = []
        if fmt:
            downloads.append(
                DownloadTarget(
                    url=f"https://example.org/{abs(hash(title))}.{fmt.lower()}",
                    fmt=DownloadFormat.PDF,
                    open_access=True,
                )
            )
        page.add(
            Result(
                category=category,
                title=title,
                source={
                    Category.BOOK: "internet_archive",
                    Category.ARTICLE: "doaj",
                    Category.RESEARCH: "arxiv",
                }[category],
                authors=authors,
                year=year,
                venue="Nature" if category is Category.ARTICLE else "",
                access=access,
                downloads=downloads,
                cover_url="",
            )
        )
    page.update_count()


for category, rows in SAMPLES.items():
    build(category, rows)

win.query.setText("machine learning")
win._status(
    "انتهى البحث عن machine learning، الإجمالي 118 نتيجة في 3 ثواني، "
    "النتائج: الكتب: 22، المقالات العلمية: 51، الأبحاث والأطروحات: 45",
    speak=False,
)

out_dir = HERE / "shots"
out_dir.mkdir(exist_ok=True)

for category in SAMPLES:
    win.tabs.setCurrentWidget(win.pages[category])
    for _ in range(4):
        app.processEvents()
    name = {Category.BOOK: "books", Category.ARTICLE: "articles",
            Category.RESEARCH: "research"}[category]
    win.grab().save(str(out_dir / f"{name}.png"))
    print("wrote", out_dir / f"{name}.png")

# Empty state, which is what the window looks like on a fresh start.
for page in win.pages.values():
    page.clear()
    page.update_count()
win.query.clear()
win._status(
    "أهلاً. اكتبي كلمة البحث في المربع ثم اضغطي Enter. "
    "البحث بيجمع من 11 مصدر علمي",
    speak=False,
)
win.tabs.setCurrentIndex(0)
for _ in range(3):
    app.processEvents()
win.grab().save(str(out_dir / "empty.png"))
print("wrote", out_dir / "empty.png")