"""Reusable, screen-reader friendly widgets.

Tk has no ARIA, so accessibility here is built from the primitives that Windows
exposes to assistive technology:

* every control has a **visible text label** (no icon-only buttons);
* every interactive container sets ``takefocus`` so it joins the Tab order;
* focus is drawn with a high-contrast ring rather than relying on a subtle
  colour change;
* a keyboard shortcut and an accessible name are attached to each action;
* status changes are mirrored into a focusable live region that screen readers
  can be moved to with F6.
"""

from __future__ import annotations

import tkinter as tk
import webbrowser
from typing import Callable

import customtkinter as ctk

from app import i18n
from app.core.citation import STYLES
from app.core.text_utils import language_display
from app.models import Access, Category, DownloadFormat, Result
from app.ui.theme import Fonts, Metrics, Palette


# ---------------------------------------------------------------------------
# Primitives
# ---------------------------------------------------------------------------
def set_takefocus(widget: tk.Misc, enabled: bool) -> bool:
    """Set ``-takefocus`` directly in Tcl.

    CustomTkinter validates ``configure()`` against a fixed keyword list and
    rejects ``takefocus``, so it has to go through the underlying Tk widget.
    Returns True when the option was accepted.
    """
    try:
        widget.tk.call(widget._w, "configure", "-takefocus", 1 if enabled else 0)
        return True
    except tk.TclError:
        return False


def bind_tk(widget: tk.Misc, sequence: str, handler, add: str = "+") -> bool:
    """Bind on the real Tk widget, bypassing CustomTkinter's redirect.

    ``CTkFrame.bind()`` forwards every binding to the widget's internal
    ``CTkCanvas`` (see ``ctk_frame.bind``), but keyboard focus is given to the
    frame's own ``._w``. Focus events and card-level shortcuts bound that way
    therefore never fire. This helper talks to Tcl directly.

    Two Tcl details matter here:

    * ``bind`` accepts at most three arguments -- ``bind window pattern
      script`` -- it is not a method on the window, so the path is an argument.
    * Appending rather than replacing is requested by prefixing the *script*
      with ``+``; there is no separate ``add`` argument.
    """
    try:
        command = widget._register(handler)
        script = f"+ {command}" if add == "+" else command
        widget.tk.call("bind", widget._w, sequence, script)
        return True
    except (tk.TclError, AttributeError):
        return False


#: Widget classes that are purely visual. Their internal canvas is the only
#: thing Tk can focus, it has no text and no focus ring, so leaving it in the
#: traversal order is what makes Tab appear to land on invisible buttons.
_DECORATIVE_CLASSES = frozenset({"CTkCanvas", "Canvas"})


def _true_children(widget: tk.Misc) -> list[tk.Misc]:
    """Return the real Tk children, including CustomTkinter's own canvas.

    ``CTkFrame.winfo_children()`` is overridden upstream to *hide* the frame's
    internal background canvas, so walking the tree with it silently misses
    exactly the decorative widgets that must be taken out of the Tab order.
    Calling the unbound ``tkinter.Frame`` method bypasses that override and
    returns the true child list.
    """
    try:
        kids = tk.Frame.winfo_children(widget)
    except tk.TclError:
        return []
    try:
        return [widget.nametowidget(str(k)) for k in kids]
    except Exception:
        return list(kids)


def suppress_canvas_focus(widget: tk.Misc) -> None:
    """Take a CustomTkinter container's decorative canvas out of the Tab order.

    Every ``CTkFrame``/``CTkButton``/``CTkLabel`` is a Tk frame with a
    ``CTkCanvas`` child used to paint the background. That canvas inherits
    Tk's default ``-takefocus ""``, which on Windows means *take focus*, so it
    joins the traversal order even though it draws nothing and announces
    nothing. The user presses Tab and the focus ring appears to vanish.
    """
    for child in _true_children(widget):
        if child.__class__.__name__ in _DECORATIVE_CLASSES:
            set_takefocus(child, False)
        suppress_canvas_focus(child)


def make_focusable(
    widget: tk.Misc, palette: Palette, metrics: Metrics, ring: bool = True
) -> None:
    """Put a control in the Tab order and give it a visible focus ring.

    CustomTkinter hard-codes ``-takefocus 0`` on every button and on its inner
    label, so by default *no* CTkButton can be reached with Tab at all. This
    flips that on the frame, and paints a border while the control is focused
    so keyboard users can see where they are.
    """
    set_takefocus(widget, True)
    if not ring:
        return
    state = {"on": False}

    def _apply() -> None:
        try:
            if not widget.winfo_exists():
                return
            widget.configure(
                border_width=2 if state["on"] else 0,
                border_color=palette.focus,
            )
        except (tk.TclError, ValueError):
            pass

    def _on_in(_event=None) -> None:
        state["on"] = True
        _apply()

    def _on_out(_event=None) -> None:
        state["on"] = False
        _apply()

    bind_tk(widget, "<FocusIn>", _on_in)
    bind_tk(widget, "<FocusOut>", _on_out)


def focusable_button(
    parent: tk.Misc,
    palette: Palette,
    metrics: Metrics,
    fonts: Fonts,
    *,
    text: str,
    command,
    **kwargs,
) -> ctk.CTkButton:
    """Build a ``CTkButton`` that Tab can reach and that shows focus.

    Every button in the app should come from here so the traversal order and
    the focus ring stay consistent; a button made with the raw constructor is
    skipped by Tab.
    """
    kwargs.setdefault("height", metrics.button_h)
    kwargs.setdefault("corner_radius", metrics.radius_sm)
    kwargs.setdefault("font", fonts.role("body_bold"))
    button = ctk.CTkButton(parent, text=text, command=command, **kwargs)
    make_focusable(button, palette, metrics)
    return button


def _focus_border(button: tk.Misc, palette: Palette, width: int) -> None:
    """Repaint a button's border, used for the focus ring."""
    try:
        if not button.winfo_exists():
            return
        button.configure(border_width=width, border_color=palette.focus)
    except (tk.TclError, ValueError):
        pass


def make_all_focusable(root: tk.Misc, palette: Palette) -> int:
    """Walk the whole tree and put every real control in the Tab order.

    CustomTkinter sets ``-takefocus 0`` on each button, on its inner label and
    on the segmented-button's segments, so none of them can be reached with
    Tab. Rather than repeat the fix at every construction site (and miss the
    ones in dialogs), this is applied to the finished tree: a button's resting
    border width and colour are remembered and restored on FocusOut, so the
    focus ring never changes the layout.
    """
    count = 0

    def _install_focus_ring(button: tk.Misc, pal: Palette) -> bool:
        try:
            rest_w = int(button.cget("border_width"))
            rest_c = str(button.cget("border_color"))
        except (tk.TclError, ValueError, TypeError):
            return False
        held = {"w": rest_w, "c": rest_c}

        def _on(_event=None, on: bool = False) -> None:
            try:
                if not button.winfo_exists():
                    return
                if on:
                    button.configure(
                        border_width=max(2, held["w"]), border_color=pal.focus
                    )
                else:
                    button.configure(border_width=held["w"], border_color=held["c"])
            except (tk.TclError, ValueError):
                pass

        bind_tk(button, "<FocusIn>", lambda e=None: _on(e, True))
        bind_tk(button, "<FocusOut>", lambda e=None: _on(e, False))
        return True

    def visit(widget: tk.Misc) -> None:
        nonlocal count
        for child in _true_children(widget):
            cls = child.__class__.__name__
            if cls in _DECORATIVE_CLASSES:
                set_takefocus(child, False)
                visit(child)
                continue
            if cls in ("CTkButton", "CTkCheckBox", "CTkSwitch", "CTkRadioButton"):
                set_takefocus(child, True)
                if _install_focus_ring(child, palette):
                    count += 1
            elif cls in ("CTkOptionMenu", "CTkComboBox"):
                set_takefocus(child, True)
            visit(child)

    visit(root)
    return count


class FocusableFrame(ctk.CTkFrame):
    """A container that can hold keyboard focus and shows a focus ring.

    ``CTkFrame`` is not focusable by default, which means Tab skips straight
    past it and the card-level shortcuts (Ctrl+D, Ctrl+O …) can never fire.
    Setting ``takefocus=1`` puts the frame in the traversal order, and a
    FocusIn/FocusOut pair drives the ring so keyboard users can always see
    where they are. Tk delivers those events to the focused widget *and* every
    ancestor, so the ring also lights up while a child button has focus.
    """

    def __init__(self, master, palette: Palette, metrics: Metrics, **kwargs):
        super().__init__(master, corner_radius=metrics.radius, **kwargs)
        self._palette = palette
        self._metrics = metrics
        self._has_focus = False
        # Created first so it always sits below the card content in stacking
        # order and never swallows clicks aimed at the buttons.
        self._ring = ctk.CTkFrame(
            self, fg_color="transparent", corner_radius=metrics.radius
        )
        self._ring.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.configure(cursor="hand2")
        set_takefocus(self, True)
        bind_tk(self, "<FocusIn>", self._on_focus_in)
        bind_tk(self, "<FocusOut>", self._on_focus_out)
        self._apply_state()

    def _on_focus_in(self, _event=None) -> None:
        self._has_focus = True
        self._apply_state()

    def _on_focus_out(self, _event=None) -> None:
        self._has_focus = False
        self._apply_state()

    def _apply_state(self) -> None:
        if not self.winfo_exists():
            return
        self._ring.configure(
            border_width=2 if self._has_focus else 0,
            border_color=self._palette.focus,
            fg_color="transparent",
        )

    def set_palette(self, palette: Palette) -> None:
        self._palette = palette
        self._apply_state()

    def focus_set(self) -> None:  # noqa: D102 - Tk override
        try:
            super().focus_set()
        except tk.TclError:
            pass


#: Semantic badge kinds -> (background, foreground) role names.
_BADGE_ROLES: dict[str, tuple[str, str]] = {
    "neutral": ("surface_alt", "text_muted"),
    "accent": ("accent_soft", "accent"),
    "success": ("surface_alt", "success"),
    "warning": ("surface_alt", "warning"),
    "muted": ("bg", "text_faint"),
}


def _badge_colors(palette: Palette, kind: str) -> tuple[str, str]:
    """Resolve a badge kind to concrete colours for the active theme.

    ``success`` and ``warning`` reuse the access colours so that "download
    available" chips look the same everywhere.
    """
    if kind == "success":
        return palette.access_colors["download"]
    if kind == "warning":
        return palette.access_colors["borrow"]
    bg_role, fg_role = _BADGE_ROLES.get(kind, _BADGE_ROLES["neutral"])
    return getattr(palette, bg_role), getattr(palette, fg_role)


class Badge(ctk.CTkLabel):
    """A small pill used for metadata (year, venue, access, category)."""

    def __init__(self, master, palette: Palette, fonts: Fonts, text: str, kind: str = "neutral"):
        fg, text_color = _badge_colors(palette, kind)
        super().__init__(
            master,
            text=text,
            fg_color=fg,
            text_color=text_color,
            font=fonts.role("caption"),
            corner_radius=6,
            padx=0,
            pady=0,
            height=20,
        )
        self.bind("<Configure>", self._fit, add="+")

    def _fit(self, _event=None) -> None:
        # Pill width should hug its text without clipping Arabic glyphs.
        self.configure(width=max(28, len(self.cget("text")) * 7 + 12))


class ToolTip:
    """A lightweight hover tooltip. Content also lives in the control's label,
    so it is never the only place information is available."""

    def __init__(self, widget: tk.Misc, text: str, fonts: Fonts, palette: Palette):
        self.widget = widget
        self.text = text
        self.fonts = fonts
        self.palette = palette
        self._window: tk.Toplevel | None = None
        self._after: str | None = None
        self._bind("<Enter>", self._schedule)
        self._bind("<Leave>", self._hide)
        self._bind("<ButtonPress>", self._hide)
        self._bind("<Destroy>", self._hide)

    def _bind(self, sequence: str, handler) -> None:
        """Some CustomTkinter widgets raise on ``bind``; a tooltip is optional."""
        try:
            self.widget.bind(sequence, handler, add="+")
        except (NotImplementedError, tk.TclError, AttributeError):
            pass

    def _schedule(self, _event=None) -> None:
        self._cancel()
        self._after = self.widget.after(550, self._show)

    def _cancel(self) -> None:
        if self._after is not None:
            try:
                self.widget.after_cancel(self._after)
            except tk.TclError:
                pass
            self._after = None

    def _show(self) -> None:
        if self._window is not None or not self.text:
            return
        try:
            x = self.widget.winfo_rootx() + 12
            y = self.widget.winfo_rooty() + self.widget.winfo_height() + 6
            self._window = tk.Toplevel(self.widget)
            self._window.wm_overrideredirect(True)
            self._window.wm_geometry(f"+{x}+{y}")
            frame = ctk.CTkFrame(
                self._window,
                fg_color=self.palette.surface_alt,
                border_width=1,
                border_color=self.palette.border,
                corner_radius=6,
            )
            frame.pack(fill="both", expand=True)
            ctk.CTkLabel(
                frame,
                text=self.text,
                text_color=self.palette.text,
                font=self.fonts.role("caption"),
                justify="left",
                wraplength=420,
            ).pack(padx=8, pady=5)
            self._window.after(6000, self._hide)
        except tk.TclError:
            self._window = None

    def _hide(self, _event=None) -> None:
        self._cancel()
        if self._window is not None:
            try:
                self._window.destroy()
            except tk.TclError:
                pass
            self._window = None


def labelled_entry(
    master,
    palette: Palette,
    fonts: Fonts,
    metrics: Metrics,
    label: str,
    *,
    width: int = 120,
    show: str = "",
    placeholder: str = "",
) -> ctk.CTkEntry:
    """Entry with its own visible label (a placeholder alone is not a label)."""
    holder = ctk.CTkFrame(master, fg_color="transparent")
    ctk.CTkLabel(
        holder,
        text=label,
        text_color=palette.text_muted,
        font=fonts.role("caption"),
        anchor="w",
    ).pack(anchor="w", pady=(0, 2))
    entry = ctk.CTkEntry(
        holder,
        width=width,
        height=metrics.button_h,
        corner_radius=metrics.radius_sm,
        fg_color=palette.surface_alt,
        border_color=palette.border,
        text_color=palette.text,
        font=fonts.role("body"),
        show=show,
        placeholder_text=placeholder,
    )
    entry.pack(fill="x")
    return entry


# ---------------------------------------------------------------------------
# Result card
# ---------------------------------------------------------------------------
class ResultCard(FocusableFrame):
    """One bibliographic record.

    Layout (top to bottom): category + access badges, title, authors, the
    category-specific metadata line, a truncated abstract, and a row of clearly
    labelled action buttons — including a button literally named
    "تنزيل / Download".
    """

    def __init__(
        self,
        master,
        result: Result,
        palette: Palette,
        fonts: Fonts,
        metrics: Metrics,
        *,
        on_download: Callable[[Result, ResultCard], None],
        on_open_source: Callable[[Result, ResultCard], None],
        on_copy_citation: Callable[[Result, ResultCard], None],
        abstract_chars: int = 320,
    ):
        self.result = result
        self.on_download = on_download
        self.on_open_source = on_open_source
        self.on_copy_citation = on_copy_citation
        self._expanded = False

        super().__init__(
            master,
            palette,
            metrics,
            fg_color=palette.surface,
            border_width=1,
            border_color=palette.border,
        )
        self.fonts = fonts
        self._abstract_chars = abstract_chars
        self._build(palette, metrics)

        # Card-level shortcuts, bound straight to the Tk widget: ``self.bind()``
        # would send them to the internal canvas, which never has focus.
        bind_tk(self, "<Return>", self._activate_primary)
        bind_tk(self, "<space>", self._toggle_abstract)
        bind_tk(self, "<Control-d>", self._download)
        bind_tk(self, "<Control-o>", self._open_source)
        bind_tk(self, "<Control-c>", self._copy)

    # -- construction -----------------------------------------------------
    def _build(self, palette: Palette, metrics: Metrics) -> None:
        pad = metrics.card_pad
        grid = ctk.CTkFrame(self, fg_color="transparent")
        grid.pack(fill="x", padx=pad, pady=(pad, metrics.sm))
        grid.grid_columnconfigure(0, weight=1)

        # Every label is registered with a semantic role so ``refresh_theme`` can
        # recolour the card without ever reading a colour back out of a widget
        # (``cget`` returns the *key* name for theme colours, not a hex value).
        self._role_labels: list[tuple[ctk.CTkLabel, str]] = []
        self._plain_labels: list[ctk.CTkLabel] = []

        def role_label(parent, text, role, **kwargs):
            label = ctk.CTkLabel(
                parent, text=text, font=self.fonts.role(role), **kwargs
            )
            self._role_labels.append((label, role))
            return label

        # --- row 1: badges ------------------------------------------------
        badges = ctk.CTkFrame(grid, fg_color="transparent")
        badges.grid(row=0, column=0, sticky="w", pady=(0, metrics.xs))
        self._badges = badges
        self._category_badge = Badge(
            badges, palette, self.fonts, self._category_label(), kind="accent"
        )
        self._category_badge.pack(side="left", padx=(0, metrics.xs))
        self._access_badge = Badge(
            badges, palette, self.fonts, i18n.t(f"access.{self.result.access.value}"),
            kind=self._access_kind(),
        )
        self._access_badge.pack(side="left", padx=(0, metrics.xs))
        if self.result.citations:
            Badge(
                badges, palette, self.fonts,
                f"{i18n.t('result.citations')}: {self.result.citations}",
            ).pack(side="left", padx=(0, metrics.xs))

        # --- row 2: title -------------------------------------------------
        self.title_label = role_label(
            grid, self.result.title, "title",
            text_color=palette.text, anchor="w", justify="left", wraplength=760,
        )
        self.title_label.grid(row=1, column=0, sticky="ew", pady=(0, metrics.xs))

        # --- row 3: authors ----------------------------------------------
        authors = self.result.author_line()
        if authors:
            role_label(
                grid, f"{i18n.t('result.authors')}: {authors}", "small",
                text_color=palette.text_muted, anchor="w", justify="left", wraplength=760,
            ).grid(row=2, column=0, sticky="ew", pady=(0, metrics.xs))

        # --- row 4: category-specific metadata ---------------------------
        meta = self._metadata_line()
        self.meta_label = role_label(
            grid, meta, "small",
            text_color=palette.text_muted, anchor="w", justify="left", wraplength=760,
        )
        if meta:
            self.meta_label.grid(row=3, column=0, sticky="ew", pady=(0, metrics.xs))

        # --- row 5: subjects ---------------------------------------------
        if self.result.subjects:
            subject_text = f"{i18n.t('result.category')}: " + " · ".join(
                self.result.subjects[:5]
            )
            role_label(
                grid, subject_text, "caption",
                text_color=palette.text_faint, anchor="w", justify="left", wraplength=760,
            ).grid(row=4, column=0, sticky="ew", pady=(0, metrics.xs))

        # --- row 6: abstract ---------------------------------------------
        abstract = self.result.abstract or i18n.t("result.no_abstract")
        self.abstract_label = role_label(
            grid, self._trim(abstract), "small",
            text_color=palette.text_muted, anchor="w", justify="left", wraplength=760,
        )
        self.abstract_label.grid(row=5, column=0, sticky="ew", pady=(0, metrics.xs))
        self._abstract_full = abstract

        if len(abstract) > self._abstract_chars:
            self.more_button = ctk.CTkButton(
                grid,
                text=i18n.t("result.show_more"),
                command=self._toggle_abstract,
                width=110,
                height=24,
                corner_radius=metrics.radius_sm,
                fg_color="transparent",
                hover_color=palette.surface_hover,
                text_color=palette.accent,
                font=self.fonts.role("caption"),
            )
            self.more_button.grid(row=6, column=0, sticky="w", pady=(0, metrics.xs))
            make_focusable(self.more_button, palette, metrics)

        # --- row 7: actions ----------------------------------------------
        actions = ctk.CTkFrame(grid, fg_color="transparent")
        actions.grid(row=7, column=0, sticky="ew", pady=(metrics.xs, 0))

        primary = self._primary_label()
        self.download_button = ctk.CTkButton(
            actions,
            text=primary,
            command=self._download,
            width=max(metrics.min_button_w, 8 * len(primary)),
            height=metrics.button_h,
            corner_radius=metrics.radius_sm,
            fg_color=palette.accent,
            hover_color=palette.accent_hover,
            text_color=palette.text_on_accent,
            font=self.fonts.role("body_bold"),
        )
        self.download_button.pack(side="left", padx=(0, metrics.sm))
        make_focusable(self.download_button, palette, metrics)

        self.source_button = ctk.CTkButton(
            actions,
            text=i18n.t("action.open_source"),
            command=self._open_source,
            width=max(metrics.min_button_w, 7 * len(i18n.t("action.open_source"))),
            height=metrics.button_h,
            corner_radius=metrics.radius_sm,
            fg_color=palette.surface_alt,
            hover_color=palette.surface_hover,
            border_width=1,
            border_color=palette.border,
            text_color=palette.text,
            font=self.fonts.role("body"),
        )
        self.source_button.pack(side="left", padx=(0, metrics.sm))
        # Its resting border is part of the design, so the focus ring is drawn
        # on top of it and the width is kept at 1 to avoid the button resizing
        # when focus moves.
        make_focusable(self.source_button, palette, metrics, ring=False)
        set_takefocus(self.source_button, True)
        bind_tk(
            self.source_button,
            "<FocusIn>",
            lambda _e=None, b=self.source_button, p=palette: _focus_border(b, p, 2),
        )
        bind_tk(
            self.source_button,
            "<FocusOut>",
            lambda _e=None, b=self.source_button, p=palette: _focus_border(b, p, 1),
        )

        self.citation_button = ctk.CTkButton(
            actions,
            text=i18n.t("action.copy_citation"),
            command=self._copy,
            width=max(metrics.min_button_w, 7 * len(i18n.t("action.copy_citation"))),
            height=metrics.button_h,
            corner_radius=metrics.radius_sm,
            fg_color="transparent",
            hover_color=palette.surface_hover,
            text_color=palette.text_muted,
            font=self.fonts.role("body"),
        )
        self.citation_button.pack(side="left")
        make_focusable(self.citation_button, palette, metrics)

        ToolTip(
            self.download_button,
            self._download_tooltip(),
            self.fonts,
            palette,
        )

    # -- content helpers --------------------------------------------------
    def _category_label(self) -> str:
        mapping = {
            Category.BOOK: i18n.t("tab.books"),
            Category.ARTICLE: i18n.t("tab.articles"),
            Category.RESEARCH: i18n.t("tab.research"),
        }
        label = mapping.get(self.result.category, self.result.category.value)
        return f"{label}" if not self.result.item_type else f"{label} · {self.result.item_type}"

    def _access_kind(self) -> str:
        return {
            Access.DOWNLOAD: "success",
            Access.LANDING: "accent",
            Access.BORROW: "warning",
            Access.METADATA: "muted",
        }.get(self.result.access, "neutral")

    def _primary_label(self) -> str:
        """The Download button always carries a readable verb, as required."""
        target = self.result.primary_download
        if target is not None and target.fmt is DownloadFormat.PDF:
            return i18n.t("action.download_pdf")
        if target is not None and target.fmt is DownloadFormat.EPUB:
            return i18n.t("action.download_epub")
        return i18n.t("action.download")

    def _download_tooltip(self) -> str:
        target = self.result.primary_download
        if target is None:
            return i18n.t("status.no_results")
        if target.fmt is DownloadFormat.SOURCE:
            return i18n.t("access.landing")
        return f"{target.label or target.fmt.value.upper()} — {target.url}"

    def _metadata_line(self) -> str:
        """Books show category + publisher; papers show year + journal."""
        parts: list[str] = []
        if self.result.year:
            parts.append(f"{i18n.t('result.year')}: {self.result.year}")

        if self.result.category is Category.BOOK:
            publisher = self.result.publisher or self.result.venue
            if publisher:
                parts.append(f"{i18n.t('result.publisher')}: {publisher}")
        else:
            venue = self.result.venue
            label = i18n.t("result.journal")
            if venue:
                # Fold the issue into the journal name, the way a citation
                # would, so a card reads "Journal, 69(1-3)" on one line.
                volume = (self.result.volume or "").strip()
                issue = (self.result.issue or "").strip()
                if volume and issue:
                    parts.append(f"{label}: {venue}, {volume}({issue})")
                elif volume:
                    parts.append(f"{label}: {venue}, {volume}")
                else:
                    parts.append(f"{label}: {venue}")
            if self.result.publisher and self.result.publisher != venue:
                parts.append(f"{i18n.t('result.publisher')}: {self.result.publisher}")

        if self.result.pages:
            parts.append(f"{i18n.t('result.pages')}: {self.result.pages}")
        if self.result.rating:
            parts.append(f"{i18n.t('result.rating')}: {self.result.rating}/5")
        if self.result.language:
            parts.append(f"{i18n.t('result.language')}: {language_display(self.result.language)}")
        identifiers = self.result.identifiers
        if identifiers.get("doi"):
            parts.append(f"DOI: {identifiers['doi']}")
        elif identifiers.get("arxiv"):
            parts.append(f"arXiv: {identifiers['arxiv']}")
        elif identifiers.get("isbn"):
            parts.append(f"ISBN: {identifiers['isbn']}")
        return "   |   ".join(parts)

    def _trim(self, text: str) -> str:
        if self._expanded or len(text) <= self._abstract_chars:
            return text
        cut = text[: self._abstract_chars]
        space = cut.rfind(" ")
        if space > self._abstract_chars * 0.6:
            cut = cut[:space]
        return cut.rstrip() + " …"

    # -- actions ----------------------------------------------------------
    # The ``_event`` parameter is required: bind_tk registers the Tcl script
    # without ``%`` substitutions, so Tk calls these handlers with no
    # arguments at all.
    def _download(self, _event=None) -> str:
        self.on_download(self.result, self)
        return "break"

    def _open_source(self, _event=None) -> str:
        self.on_open_source(self.result, self)
        return "break"

    def _copy(self, _event=None) -> str:
        self.on_copy_citation(self.result, self)
        return "break"

    def _activate_primary(self, _event=None) -> str:
        self._download()
        return "break"

    def _toggle_abstract(self, _event=None) -> str:
        self._expanded = not self._expanded
        self.abstract_label.configure(text=self._trim(self._abstract_full))
        button = getattr(self, "more_button", None)
        if button is not None:
            button.configure(
                text=i18n.t("result.show_less") if self._expanded else i18n.t("result.show_more")
            )
        return "break"

    # -- theme refresh ----------------------------------------------------
    def refresh_theme(self, palette: Palette, fonts: Fonts) -> None:
        """Recolour the card after a theme / language / font change.

        Colours come from the palette object, never from ``cget``, because
        CustomTkinter's ``cget`` returns theme *key names* for theme colours.
        """
        self.set_palette(palette)
        self.fonts = fonts
        self.configure(fg_color=palette.surface, border_color=palette.border)

        role_colors = {
            "title": palette.text,
            "small": palette.text_muted,
            "caption": palette.text_faint,
            "body": palette.text,
            "body_bold": palette.text,
        }
        for label, role in self._role_labels:
            try:
                label.configure(
                    text_color=role_colors.get(role, palette.text),
                    font=fonts.role(role),
                )
            except tk.TclError:  # widget already destroyed
                pass

        self._category_badge.configure(
            text=self._category_label(),
            fg_color=palette.accent_soft,
            text_color=palette.accent,
            font=fonts.role("caption"),
        )
        fg, text_color = _badge_colors(palette, self._access_kind())
        self._access_badge.configure(
            text=i18n.t(f"access.{self.result.access.value}"),
            fg_color=fg,
            text_color=text_color,
            font=fonts.role("caption"),
        )
        self.abstract_label.configure(text=self._trim(self._abstract_full))
        self.meta_label.configure(text=self._metadata_line())

        self.download_button.configure(
            text=self._primary_label(),
            fg_color=palette.accent,
            hover_color=palette.accent_hover,
            text_color=palette.text_on_accent,
            font=fonts.role("body_bold"),
        )
        self.source_button.configure(
            text=i18n.t("action.open_source"),
            fg_color=palette.surface_alt,
            hover_color=palette.surface_hover,
            border_color=palette.border,
            text_color=palette.text,
            font=fonts.role("body"),
        )
        self.citation_button.configure(
            text=i18n.t("action.copy_citation"),
            fg_color="transparent",
            hover_color=palette.surface_hover,
            text_color=palette.text_muted,
            font=fonts.role("body"),
        )
        button = getattr(self, "more_button", None)
        if button is not None:
            button.configure(
                text=i18n.t("result.show_less") if self._expanded
                else i18n.t("result.show_more"),
                fg_color="transparent",
                hover_color=palette.surface_hover,
                text_color=palette.accent,
                font=fonts.role("caption"),
            )


# ---------------------------------------------------------------------------
# Misc chrome
# ---------------------------------------------------------------------------
def open_external(url: str) -> bool:
    """Open a URL in the user's browser, refusing anything unexpected."""
    if not url:
        return False
    lowered = url.lower()
    if not lowered.startswith(("http://", "https://")):
        return False
    try:
        webbrowser.open(url, new=2)
        return True
    except Exception:
        return False


def human_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


#: Provider status -> (background role, foreground role). Resolved per theme.
_STATE_ROLES: dict[str, tuple[str, str]] = {
    "pending": ("surface_alt", "text_faint"),
    "running": ("accent_soft", "accent"),
    "ok": ("surface_alt", "success"),
    "empty": ("surface_alt", "text_muted"),
    "error": ("surface_alt", "danger"),
    "skipped": ("surface_alt", "text_faint"),
    "disabled": ("surface_alt", "text_faint"),
}


def _state_colors(palette: Palette, state: str) -> tuple[str, str]:
    bg_role, fg_role = _STATE_ROLES.get(state, _STATE_ROLES["pending"])
    return getattr(palette, bg_role), getattr(palette, fg_role)


class StatusChip(ctk.CTkLabel):
    """A provider's live state: pending / running / ok / empty / error."""

    def __init__(self, master, palette: Palette, fonts: Fonts, text: str, state: str = "pending"):
        fg, text_color = _state_colors(palette, state)
        super().__init__(
            master,
            text=text,
            fg_color=fg,
            text_color=text_color,
            font=fonts.role("caption"),
            corner_radius=6,
            height=20,
            padx=0,
            pady=0,
        )
        self._state = state
        self.bind("<Configure>", self._fit, add="+")

    def set_state(self, palette: Palette, fonts: Fonts, state: str, text: str) -> None:
        fg, text_color = _state_colors(palette, state)
        self._state = state
        self.configure(
            text=text, fg_color=fg, text_color=text_color, font=fonts.role("caption")
        )

    def _fit(self, _event=None) -> None:
        self.configure(width=max(40, len(self.cget("text")) * 7 + 14))


CITATION_STYLES = STYLES
