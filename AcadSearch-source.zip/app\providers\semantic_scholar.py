"""Semantic Scholar — the richest free academic-graph metadata for papers.

Docs: https://api.semanticscholar.org/api-docs/graph
Runs without a key but the unauthenticated pool is heavily throttled
(HTTP 429). A free key removes the limit.
"""

from __future__ import annotations

import threading

from app.core.text_utils import (
    as_int,
    clean_text,
    extract_doi,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://api.semanticscholar.org/graph/v1/paper/search"
BULK = "https://api.semanticscholar.org/graph/v1/paper/search/bulk"

FIELDS = ",".join(
    [
        "title",
        "abstract",
        "year",
        "venue",
        "publicationVenue",
        "authors",
        "externalIds",
        "openAccessPdf",
        "url",
        "citationCount",
        "publicationTypes",
        "fieldsOfStudy",
        "journal",
        "isOpenAccess",
    ]
)

#: Publication types that belong in the "Research & theses" tab.
THESIS_TYPES = {"thesis", "dissertation", "review", "dataset", "postedcontent"}


@register
class SemanticScholarProvider(BaseProvider):
    provider_id = "semantic_scholar"
    display_name = "Semantic Scholar"
    categories = (Category.ARTICLE, Category.RESEARCH)
    weight = 10
    requires_key = "semantic_scholar_key"
    homepage = "https://www.semanticscholar.org"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        # The anonymous endpoint caps a page at 20 records and throttles hard;
        # an authenticated key raises the page limit, so the same search can
        # actually reach the deeper results instead of dying at the first 20.
        cap = 100 if self.config.semantic_scholar_key else 20
        params: dict[str, object] = {
            "query": query.text,
            "limit": min(query.per_source, cap),
            "fields": FIELDS,
        }
        if self.config.semantic_scholar_key:
            params["x-api-key"] = self.config.semantic_scholar_key
        if query.year_from or query.year_to:
            year_filter = ""
            if query.year_from:
                year_filter += f"{query.year_from}-"
            if query.year_to:
                year_filter += str(query.year_to)
            params["year"] = year_filter
        if query.language and query.language != "any":
            # Semantic Scholar has no language parameter; the engine filters later.
            pass

        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        papers = payload.get("data") or []
        return [self._to_result(p) for p in papers]

    # -- mapping ----------------------------------------------------------
    def _to_result(self, paper: dict) -> Result:
        external = paper.get("externalIds") or {}
        title = clean_text(paper.get("title"))
        abstract = truncate_words(clean_text(paper.get("abstract")), 600)

        pub_types = [
            clean_text(p).lower()
            for p in (paper.get("publicationTypes") or [])
            if p
        ]
        is_thesis = bool({"thesis", "dissertation"} & set(pub_types))

        venue = clean_text(paper.get("venue"))
        journal = paper.get("journal") or {}
        if not venue and journal:
            venue = clean_text(journal.get("name"))
        if not venue:
            venue_obj = paper.get("publicationVenue") or {}
            venue = clean_text(venue_obj.get("name"))

        identifiers: dict[str, str] = {}
        doi = extract_doi(external.get("DOI"))
        if doi:
            identifiers["doi"] = doi
        for key in ("ArXiv", "PubMed", "MAG", "DBLP", "CorpusId", "PMID"):
            value = clean_text(external.get(key))
            if value:
                identifiers[key.lower()] = value

        landing = clean_text(paper.get("url"))
        if not landing and doi:
            landing = f"https://doi.org/{doi}"

        downloads = []
        oa = paper.get("openAccessPdf") or {}
        pdf_url = clean_text(oa.get("url"))
        if pdf_url:
            downloads.append(
                target(
                    pdf_url,
                    DownloadFormat.PDF,
                    label=clean_text(oa.get("status")) or "Open access PDF",
                    open_access=True,
                )
            )
        if landing:
            downloads.append(
                target(landing, DownloadFormat.HTML, label="Semantic Scholar", open_access=False)
            )

        subjects = [clean_text(s) for s in (paper.get("fieldsOfStudy") or []) if s]
        authors = [
            clean_text(a.get("name"))
            for a in (paper.get("authors") or [])
            if isinstance(a, dict) and a.get("name")
        ]

        return Result(
            category=Category.RESEARCH if is_thesis else Category.ARTICLE,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=as_int(paper.get("year")),
            abstract=abstract,
            venue=venue,
            language=normalise_language(clean_text(paper.get("publicationLanguage"))),
            subjects=subjects,
            identifiers=identifiers,
            access=Access.DOWNLOAD if pdf_url else (Access.LANDING if landing else Access.METADATA),
            downloads=downloads,
            landing_url=landing,
            citations=as_int(paper.get("citationCount")),
            item_type="Thesis" if is_thesis else first_type(pub_types),
            raw=paper,
        )


def first_type(types: list[str]) -> str:
    nice = {
        "journalarticle": "JournalArticle",
        "conference": "Conference",
        "review": "Review",
        "book": "Book",
        "bookchapter": "BookChapter",
        "thesis": "Thesis",
        "dissertation": "Dissertation",
        "dataset": "Dataset",
        "postedcontent": "Preprint",
        "technicalreport": "TechnicalReport",
        "patent": "Patent",
        "study": "Study",
    }
    for value in types:
        if value in nice:
            return nice[value]
    return types[0].title() if types else ""
