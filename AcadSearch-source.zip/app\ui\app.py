"""The main application window.

Responsibilities
----------------
* build the accessible chrome (menu bar with accelerators, labelled search
  bar, three-section results view, status bar, download tray);
* pump the search engine's event queue on the Tk main thread so the UI never
  freezes and the user can cancel at any moment;
* apply the theme, language and font-scale preferences live.
"""

from __future__ import annotations

import logging
import os
import queue
import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

import customtkinter as ctk

from app import i18n
from app.config import APP_VERSION, Config, get_config
from app.core.citation import DEFAULT_STYLE, STYLES, format_citation
from app.core.downloader import (
    DownloadEvent,
    DownloadEventType,
    DownloadManager,
    DownloadState,
    DownloadTask,
)
from app.core.http_client import get_http
from app.core.search_engine import SearchEventType, SearchHandle
from app.core.speech import Speaker
from app.core.text_utils import truncate_words
from app.models import Category, Result, SearchQuery
from app.providers import all_providers
from app.providers.base import providers_for_category
from app.ui.theme import (
    Fonts,
    Metrics,
    apply_theme,
    enable_dpi_awareness,
    fit_window,
)
from app.ui.widgets import (
    ResultCard,
    StatusChip,
    ToolTip,
    bind_tk,
    human_size,
    make_all_focusable,
    open_external,
    set_takefocus,
    suppress_canvas_focus,
)

log = logging.getLogger(__name__)


def _is_descendant(widget: tk.Misc, ancestor: tk.Misc) -> bool:
    """True when ``widget`` is ``ancestor`` or nested somewhere beneath it."""
    path = str(widget)
    parent = str(ancestor)
    return path == parent or path.startswith(parent + ".")

SECTION_ORDER = (Category.BOOK, Category.ARTICLE, Category.RESEARCH)
SECTION_KEYS = ("F2", "F3", "F4")
#: Pylint-free alias used by the status bar.
TAB_LABELS = {
    Category.BOOK: "tab.books",
    Category.ARTICLE: "tab.articles",
    Category.RESEARCH: "tab.research",
}


class AcadSearchApp(ctk.CTk):
    """Top-level window."""

    def __init__(self, config: Config | None = None):
        enable_dpi_awareness()
        self.config = config or get_config()

        # Resolve the palette before the root exists so its background matches.
        self.palette = apply_theme(self.config.theme)
        super().__init__(fg_color=self.palette.bg)

        self.fonts = Fonts(self.config.font_family, self.config.font_scale)
        self.metrics = Metrics.scaled(self.config.font_scale)

        self.title(self._title_text())
        self._apply_window_icon()
        fit_window(self)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        i18n.set_language(self.config.ui_language)

        # --- state ---
        self._engine = None
        self._handle: SearchHandle | None = None
        self._searching = False
        self._response = None
        self._last_download: DownloadTask | None = None
        self._cards: dict[Category, list[ResultCard]] = {c: [] for c in SECTION_ORDER}
        self._chips: dict[str, StatusChip] = {}
        self._focused_card: dict[Category, ResultCard | None] = {c: None for c in SECTION_ORDER}
        self._active_section = Category.BOOK
        self._download_tasks: list[DownloadTask] = []
        self._pane_order: list[tk.Misc] = []
        self._pane_index = 0

        self.http = get_http()
        self.downloads = DownloadManager(self.config)
        # Spoken output starts off: it is opt-in, because it speaks on every
        # arrow key and some users never want audio at all.
        self.speech = Speaker()
        self.speech.set_enabled(False)

        self._build()
        self._bind_shortcuts()
        self._announce(i18n.t("status.idle"))
        self.after(60, self._pump_search_events)
        self.after(60, self._pump_download_events)
        self.after(200, self._poll_system_theme)
        # Runs once the whole tree exists, because a result card is created
        # later on every search and brings its own canvases with it.
        self.after(0, self._fix_focus_order)

    # ==================================================================
    # Construction
    # ==================================================================
    def _build(self) -> None:
        self._grid = ctk.CTkFrame(self, fg_color="transparent")
        self._grid.pack(fill="both", expand=True, padx=self.metrics.lg, pady=self.metrics.md)
        self._grid.grid_columnconfigure(0, weight=1)
        self._grid.grid_rowconfigure(2, weight=1)

        self._build_header()
        self._build_searchbar()
        self._build_sections()
        self._build_statusbar()

    # -- header -----------------------------------------------------------
    def _build_header(self) -> None:
        header = ctk.CTkFrame(self._grid, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", pady=(0, self.metrics.sm))
        header.grid_columnconfigure(0, weight=1)

        titles = ctk.CTkFrame(header, fg_color="transparent")
        titles.grid(row=0, column=0, sticky="w")

        self.title_label = ctk.CTkLabel(
            titles,
            text=i18n.t("app.title"),
            text_color=self.palette.text,
            font=self.fonts.role("display"),
            anchor="w",
        )
        self.title_label.pack(anchor="w")
        self.subtitle_label = ctk.CTkLabel(
            titles,
            text=i18n.t("app.subtitle"),
            text_color=self.palette.text_muted,
            font=self.fonts.role("small"),
            anchor="w",
        )
        self.subtitle_label.pack(anchor="w")

        # Appearance + language switchers on the right.
        controls = ctk.CTkFrame(header, fg_color="transparent")
        controls.grid(row=0, column=1, sticky="e")

        ctk.CTkLabel(
            controls,
            text="◐",
            text_color=self.palette.text_muted,
            font=self.fonts.role("body"),
            width=18,
        ).pack(side="left", padx=(0, 2))

        self.theme_menu_button = ctk.CTkButton(
            controls,
            text=i18n.t("prefs.theme"),
            width=110,
            height=self.metrics.button_h,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.surface_alt,
            hover_color=self.palette.surface_hover,
            border_width=1,
            border_color=self.palette.border,
            text_color=self.palette.text,
            font=self.fonts.role("small"),
            command=self.toggle_theme,
        )
        self.theme_menu_button.pack(side="left", padx=(0, self.metrics.xs))

        self.lang_button = ctk.CTkButton(
            controls,
            text="العربية / EN",
            width=104,
            height=self.metrics.button_h,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.surface_alt,
            hover_color=self.palette.surface_hover,
            border_width=1,
            border_color=self.palette.border,
            text_color=self.palette.text,
            font=self.fonts.role("small"),
            command=self.toggle_language,
        )
        self.lang_button.pack(side="left", padx=(0, self.metrics.xs))

        self.prefs_button = ctk.CTkButton(
            controls,
            text=i18n.t("app.menuprefs"),
            width=100,
            height=self.metrics.button_h,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.surface_alt,
            hover_color=self.palette.surface_hover,
            border_width=1,
            border_color=self.palette.border,
            text_color=self.palette.text,
            font=self.fonts.role("small"),
            command=self.open_preferences,
        )
        self.prefs_button.pack(side="left", padx=(0, self.metrics.xs))

        self.help_button = ctk.CTkButton(
            controls,
            text=f"{i18n.t('help.title')} (F1)",
            width=140,
            height=self.metrics.button_h,
            corner_radius=self.metrics.radius_sm,
            fg_color="transparent",
            hover_color=self.palette.surface_hover,
            text_color=self.palette.text_muted,
            font=self.fonts.role("small"),
            command=self.show_help,
        )
        self.help_button.pack(side="left")

    # -- search bar -------------------------------------------------------
    def _build_searchbar(self) -> None:
        bar = ctk.CTkFrame(
            self._grid,
            fg_color=self.palette.surface,
            corner_radius=self.metrics.radius,
            border_width=1,
            border_color=self.palette.border,
        )
        bar.grid(row=1, column=0, sticky="ew", pady=(0, self.metrics.md))
        bar.grid_columnconfigure(0, weight=1)
        bar.grid_columnconfigure(1, weight=0)

        # --- row 0: query entry (expands) + search/stop button (fixed) ---
        self.query_entry = ctk.CTkEntry(
            bar,
            placeholder_text=i18n.t("search.placeholder"),
            height=42,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.surface_alt,
            border_color=self.palette.border,
            border_width=2,
            text_color=self.palette.text,
            font=self.fonts.role("body"),
        )
        self.query_entry.grid(
            row=0, column=0, sticky="ew",
            padx=(self.metrics.md, self.metrics.sm),
            pady=(self.metrics.md, self.metrics.sm),
        )
        self.query_entry.bind("<Return>", self._on_enter)
        self.query_entry.bind("<KP_Enter>", self._on_enter)

        self.search_button = ctk.CTkButton(
            bar,
            text=i18n.t("search.button"),
            width=120,
            height=42,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.accent,
            hover_color=self.palette.accent_hover,
            text_color=self.palette.text_on_accent,
            font=self.fonts.role("body_bold"),
            command=self.toggle_search,
        )
        self.search_button.grid(
            row=0, column=1, sticky="e",
            padx=(0, self.metrics.md), pady=(self.metrics.md, self.metrics.sm),
        )

        # --- row 1: filters ------------------------------------------------
        filters = ctk.CTkFrame(bar, fg_color="transparent")
        filters.grid(row=1, column=0, columnspan=2, sticky="ew",
                     padx=self.metrics.md, pady=(0, self.metrics.sm))
        filters.grid_columnconfigure(6, weight=1)

        self.language_label = ctk.CTkLabel(
            filters, text=i18n.t("search.language"),
            text_color=self.palette.text_muted, font=self.fonts.role("caption"), width=0,
        )
        self.language_label.grid(row=0, column=0, sticky="w", padx=(0, self.metrics.xs))

        options = i18n.language_options()
        self._language_codes = [code for code, _ in options]
        self.language_var = tk.StringVar(value=options[0][1])
        self.language_menu = ctk.CTkOptionMenu(
            filters,
            values=[label for _, label in options],
            variable=self.language_var,
            width=180,
            height=self.metrics.row_h,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.surface_alt,
            button_color=self.palette.accent,
            button_hover_color=self.palette.accent_hover,
            text_color=self.palette.text,
            font=self.fonts.role("small"),
            dropdown_fg_color=self.palette.surface,
            dropdown_text_color=self.palette.text,
            dropdown_hover_color=self.palette.surface_hover,
            dropdown_font=self.fonts.role("small"),
            command=self._on_language_change,
        )
        self.language_menu.grid(row=0, column=1, sticky="w", padx=(0, self.metrics.md))

        self.count_label = ctk.CTkLabel(
            filters, text=i18n.t("search.results_count"),
            text_color=self.palette.text_muted, font=self.fonts.role("caption"), width=0,
        )
        self.count_label.grid(row=0, column=2, sticky="w", padx=(0, self.metrics.xs))
        self.count_menu = ctk.CTkOptionMenu(
            filters,
            values=["5", "10", "20", "30", "40"],
            width=80,
            height=self.metrics.row_h,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.surface_alt,
            button_color=self.palette.surface_hover,
            button_hover_color=self.palette.border_strong,
            text_color=self.palette.text,
            font=self.fonts.role("small"),
            dropdown_fg_color=self.palette.surface,
            dropdown_text_color=self.palette.text,
            dropdown_hover_color=self.palette.surface_hover,
            dropdown_font=self.fonts.role("small"),
        )
        self.count_menu.set(str(self.config.results_per_source))
        self.count_menu.grid(row=0, column=3, sticky="w", padx=(0, self.metrics.md))

        self.advanced_button = ctk.CTkButton(
            filters,
            text=i18n.t("search.advanced"),
            width=150,
            height=self.metrics.row_h,
            corner_radius=self.metrics.radius_sm,
            fg_color="transparent",
            hover_color=self.palette.surface_hover,
            text_color=self.palette.accent,
            font=self.fonts.role("small"),
            command=self.toggle_advanced,
        )
        self.advanced_button.grid(row=0, column=4, sticky="w")

        ctk.CTkLabel(
            filters,
            text=i18n.t("search.hint"),
            text_color=self.palette.text_faint,
            font=self.fonts.role("caption"),
            anchor="e",
        ).grid(row=0, column=6, sticky="e")

        # --- row 3: citation style picker + copy button -------------------
        # The style is chosen here, once, and the copy button then applies it
        # to whichever result the keyboard focus is sitting on.
        cite = ctk.CTkFrame(bar, fg_color="transparent")
        cite.grid(row=3, column=0, columnspan=2, sticky="ew",
                  padx=self.metrics.md, pady=(0, self.metrics.sm))
        self.citation_bar = cite

        self.citation_style_label = ctk.CTkLabel(
            cite,
            text=i18n.t("citation.format"),
            text_color=self.palette.text_muted,
            font=self.fonts.role("caption"),
            width=0,
        )
        self.citation_style_label.grid(row=0, column=0, sticky="w",
                                       padx=(0, self.metrics.xs))

        # The dropdown shows localised labels; ``_citation_style`` holds the
        # stable key so config.json and the formatters never depend on a label.
        self._citation_styles = list(STYLES)
        self._citation_style = self.config.citation_style
        if self._citation_style not in self._citation_styles:
            self._citation_style = DEFAULT_STYLE
        self._citation_labels = {
            style: i18n.citation_style_label(style) for style in self._citation_styles
        }
        self.citation_style_var = tk.StringVar(
            value=self._citation_labels[self._citation_style]
        )
        self.citation_style_menu = ctk.CTkOptionMenu(
            cite,
            values=[self._citation_labels[s] for s in self._citation_styles],
            variable=self.citation_style_var,
            width=140,
            height=self.metrics.row_h,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.surface_alt,
            button_color=self.palette.accent,
            button_hover_color=self.palette.accent_hover,
            text_color=self.palette.text,
            font=self.fonts.role("small"),
            dropdown_fg_color=self.palette.surface,
            dropdown_text_color=self.palette.text,
            dropdown_hover_color=self.palette.surface_hover,
            dropdown_font=self.fonts.role("small"),
            command=self._on_citation_style_change,
        )
        self.citation_style_menu.grid(row=0, column=1, sticky="w",
                                      padx=(0, self.metrics.sm))

        self.copy_citation_button = ctk.CTkButton(
            cite,
            text=i18n.t("citation.copy"),
            width=170,
            height=self.metrics.row_h,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.accent,
            hover_color=self.palette.accent_hover,
            text_color=self.palette.text_on_accent,
            font=self.fonts.role("body_bold"),
            command=self.copy_focused_citation,
        )
        self.copy_citation_button.grid(row=0, column=2, sticky="w")

        self._focused_citation_label = ctk.CTkLabel(
            cite,
            text="",
            text_color=self.palette.text_faint,
            font=self.fonts.role("caption"),
            anchor="e",
        )
        self._focused_citation_label.grid(row=0, column=3, sticky="e")
        cite.grid_columnconfigure(3, weight=1)

        # --- row 3: advanced options (hidden by default) -------------------
        self.advanced_frame = ctk.CTkFrame(bar, fg_color="transparent")
        self._advanced_visible = False

        self.from_label = ctk.CTkLabel(
            self.advanced_frame, text=i18n.t("search.year_from"),
            text_color=self.palette.text_muted, font=self.fonts.role("caption"), width=0,
        )
        self.from_label.grid(row=0, column=0, sticky="w", padx=(0, self.metrics.xs))
        self.year_from = ctk.CTkEntry(
            self.advanced_frame, width=90, height=self.metrics.row_h,
            corner_radius=self.metrics.radius_sm, fg_color=self.palette.surface_alt,
            border_color=self.palette.border, text_color=self.palette.text,
            font=self.fonts.role("small"), placeholder_text="1990",
        )
        self.year_from.grid(row=0, column=1, sticky="w", padx=(0, self.metrics.md))

        self.to_label = ctk.CTkLabel(
            self.advanced_frame, text=i18n.t("search.year_to"),
            text_color=self.palette.text_muted, font=self.fonts.role("caption"), width=0,
        )
        self.to_label.grid(row=0, column=2, sticky="w", padx=(0, self.metrics.xs))
        self.year_to = ctk.CTkEntry(
            self.advanced_frame, width=90, height=self.metrics.row_h,
            corner_radius=self.metrics.radius_sm, fg_color=self.palette.surface_alt,
            border_color=self.palette.border, text_color=self.palette.text,
            font=self.fonts.role("small"), placeholder_text="2026",
        )
        self.year_to.grid(row=0, column=3, sticky="w", padx=(0, self.metrics.md))

        self.clear_button = ctk.CTkButton(
            self.advanced_frame,
            text=i18n.t("search.clear"),
            width=90,
            height=self.metrics.row_h,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.surface_alt,
            hover_color=self.palette.surface_hover,
            border_width=1,
            border_color=self.palette.border,
            text_color=self.palette.text_muted,
            font=self.fonts.role("small"),
            command=self.clear_search,
        )
        self.clear_button.grid(row=0, column=4, sticky="w")
        # Row 2 is created but kept unmapped; ``toggle_advanced`` reveals it.
        self.advanced_frame.grid(
            row=2, column=0, columnspan=2, sticky="ew",
            padx=self.metrics.md, pady=(0, self.metrics.md),
        )
        self.advanced_frame.grid_forget()
        self.advanced_button.configure(command=self.toggle_advanced)

    def toggle_advanced(self) -> str:
        """Show or hide the year-range and extra filters row."""
        self._advanced_visible = not self._advanced_visible
        if self._advanced_visible:
            self.advanced_frame.grid()
            self.advanced_button.configure(
                text=f"▲ {i18n.t('search.advanced')}",
                text_color=self.palette.accent,
            )
            self.year_from.focus_set()
        else:
            self.advanced_frame.grid_forget()
            self.advanced_button.configure(
                text=i18n.t("search.advanced"), text_color=self.palette.accent
            )
        return "break"

    # -- results sections -------------------------------------------------
    def _build_sections(self) -> None:
        holder = ctk.CTkFrame(self._grid, fg_color="transparent")
        holder.grid(row=2, column=0, sticky="nsew")
        holder.grid_columnconfigure(0, weight=1)
        holder.grid_rowconfigure(1, weight=1)

        # Tab strip: CTkSegmentedButton handles arrow-key traversal for us.
        self.section_button = ctk.CTkSegmentedButton(
            holder,
            values=[i18n.t(TAB_LABELS[c]) for c in SECTION_ORDER],
            command=self._on_section_change,
            height=38,
            corner_radius=self.metrics.radius_sm,
            fg_color=self.palette.surface_alt,
            selected_color=self.palette.accent,
            selected_hover_color=self.palette.accent_hover,
            unselected_color=self.palette.surface_alt,
            unselected_hover_color=self.palette.surface_hover,
            text_color=self.palette.text,
            font=self.fonts.role("body_bold"),
        )
        self.section_button.set(i18n.t(TAB_LABELS[Category.BOOK]))
        self.section_button.grid(row=0, column=0, sticky="ew", pady=(0, self.metrics.sm))
        ToolTip(
            self.section_button,
            "F2 / F3 / F4",
            self.fonts,
            self.palette,
        )

        body = ctk.CTkFrame(holder, fg_color="transparent")
        body.grid(row=1, column=0, sticky="nsew")
        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(0, weight=1)

        self._section_frames: dict[Category, ctk.CTkFrame] = {}
        self._lists: dict[Category, ctk.CTkScrollableFrame] = {}
        self._empty_labels: dict[Category, ctk.CTkLabel] = {}
        self._count_labels: dict[Category, ctk.CTkLabel] = {}

        for index, category in enumerate(SECTION_ORDER):
            frame = ctk.CTkFrame(body, fg_color="transparent")
            frame.grid(row=0, column=0, sticky="nsew")
            body.grid_rowconfigure(0, weight=1)
            # Only the active frame is mapped into view; Tk stacks them in the
            # same cell so switching sections never rebuilds any cards.
            self._section_frames[category] = frame
            frame.grid_forget()

            frame.grid_columnconfigure(0, weight=1)
            frame.grid_rowconfigure(2, weight=1)

            caption = ctk.CTkLabel(
                frame,
                text=i18n.t(f"{TAB_LABELS[category]}.desc"),
                text_color=self.palette.text_faint,
                font=self.fonts.role("caption"),
                anchor="w",
            )
            caption.grid(row=0, column=0, sticky="ew", pady=(0, self.metrics.xs))

            count = ctk.CTkLabel(
                frame,
                text="",
                text_color=self.palette.text_muted,
                font=self.fonts.role("caption"),
                anchor="e",
            )
            count.grid(row=0, column=0, sticky="e")
            self._count_labels[category] = count

            self._lists[category] = ctk.CTkScrollableFrame(
                frame,
                fg_color="transparent",
                corner_radius=self.metrics.radius,
                scrollbar_button_color=self.palette.border_strong,
                scrollbar_button_hover_color=self.palette.accent,
                label_text="",
            )
            self._lists[category].grid(row=2, column=0, sticky="nsew")

            empty = ctk.CTkLabel(
                self._lists[category],
                text=f"{i18n.t('tab.empty')}\n{i18n.t('tab.empty_hint')}",
                text_color=self.palette.text_faint,
                font=self.fonts.role("body"),
                justify="center",
            )
            empty.place(relx=0.5, rely=0.35, anchor="center")
            self._empty_labels[category] = empty

            frame.bind("<FocusIn>", self._on_section_focus, add="+")

        self._activate_section(Category.BOOK)
        self._pane_order = [
            self.query_entry,
            self.language_menu,
            self.count_menu,
            self.advanced_button,
            self.section_button,
        ]

    # -- status bar --------------------------------------------------------
    def _build_statusbar(self) -> None:
        bar = ctk.CTkFrame(
            self._grid,
            fg_color=self.palette.surface,
            corner_radius=self.metrics.radius_sm,
            border_width=1,
            border_color=self.palette.border,
        )
        bar.grid(row=3, column=0, sticky="ew", pady=(self.metrics.md, 0))
        bar.grid_columnconfigure(1, weight=1)

        self.progress = ctk.CTkProgressBar(
            bar,
            width=120,
            height=6,
            corner_radius=3,
            progress_color=self.palette.accent,
            fg_color=self.palette.surface_alt,
            mode="indeterminate",
        )
        self.progress.grid(row=0, column=0, padx=(self.metrics.md, self.metrics.sm),
                           pady=self.metrics.sm, sticky="w")
        self.progress.set(0)
        self.progress.stop()

        # This label doubles as the accessibility live region: it is focusable,
        # so F6 moves the screen reader to the latest status message.
        self.status_label = ctk.CTkLabel(
            bar,
            text=i18n.t("status.idle"),
            text_color=self.palette.text_muted,
            font=self.fonts.role("small"),
            anchor="w",
            justify="left",
        )
        self.status_label.grid(row=0, column=1, sticky="ew",
                               padx=(0, self.metrics.sm), pady=self.metrics.sm)
        # The status bar is a live region: keeping it focusable means a screen-reader
        # user can Tab to it and re-read the latest message on demand.
        set_takefocus(self.status_label, True)

        chips = ctk.CTkFrame(bar, fg_color="transparent")
        chips.grid(row=0, column=2, sticky="e", padx=(0, self.metrics.md),
                   pady=self.metrics.sm)
        self.chip_holder = chips
        self._build_chips()

        self.downloads_button = ctk.CTkButton(
            bar,
            text=i18n.t("download.open_folder"),
            width=150,
            height=26,
            corner_radius=self.metrics.radius_sm,
            fg_color="transparent",
            hover_color=self.palette.surface_hover,
            text_color=self.palette.accent,
            font=self.fonts.role("caption"),
            command=self._downloads_button_command,
        )
        # Spoken-output toggle. CustomTkinter paints onto a canvas, so a screen
        # reader sees empty panes and cannot read the results; this button is
        # the manual way to hear the focused result, and it is also the mute
        # switch once reading is on.
        self.speech_button = ctk.CTkButton(
            bar,
            text=i18n.t("speech.enable"),
            width=150,
            height=26,
            corner_radius=self.metrics.radius_sm,
            fg_color="transparent",
            hover_color=self.palette.surface_hover,
            text_color=self.palette.text_muted,
            font=self.fonts.role("caption"),
            command=self.toggle_speech,
        )
        # On the second row beside the downloads button. Both are 150px wide
        # and the bar is only ~1180px, so a third control on that row would be
        # clipped; the two fit with room to spare.
        self.speech_button.grid(row=1, column=1, sticky="w",
                                padx=(self.metrics.md, 0), pady=(0, self.metrics.sm))

        self.downloads_button.grid(row=1, column=0, sticky="w",
                                   padx=self.metrics.md, pady=(0, self.metrics.sm))

    def _build_chips(self) -> None:
        for child in self.chip_holder.winfo_children():
            child.destroy()
        self._chips.clear()
        for provider in all_providers():
            name = i18n.t(f"provider.{provider.provider_id}")
            enabled = self.config.is_enabled(provider.provider_id)
            chip = StatusChip(
                self.chip_holder,
                self.palette,
                self.fonts,
                name,
                "pending" if enabled else "disabled",
            )
            chip.pack(side="left", padx=(0, self.metrics.xs))
            self._chips[provider.provider_id] = chip
            ToolTip(chip, provider.homepage, self.fonts, self.palette)

    # ==================================================================
    # Keyboard
    # ==================================================================
    def _fix_focus_order(self) -> None:
        """Remove CustomTkinter's decorative canvases from the Tab order.

        A CTk widget is a frame plus an internal canvas used to paint the
        background. That canvas keeps Tk's default ``-takefocus ""``, which on
        Windows means it *is* focusable, so Tab walks into 1000x300-pixel blank
        areas that show no ring and announce nothing -- the "invisible buttons"
        the user reported. Cards are rebuilt on every search, so this is
        re-run whenever results are drawn.
        """
        try:
            suppress_canvas_focus(self)
            make_all_focusable(self, self.palette)
        except tk.TclError:
            return
        # The search entry is the one control that should keep focus, and its
        # placeholder is not an accessible name, so pin a label on it.
        try:
            inner = getattr(self.query_entry, "_entry", None)
            if inner is not None and inner.winfo_exists():
                set_takefocus(inner, True)
                bind_tk(
                    inner,
                    "<FocusIn>",
                    lambda _e=None: self.query_entry.configure(border_width=2),
                )
                bind_tk(
                    inner,
                    "<FocusOut>",
                    lambda _e=None: self.query_entry.configure(border_width=1),
                )
        except (tk.TclError, AttributeError, ValueError):
            pass

    def _move_card_focus(self, step: int) -> str | None:
        """Arrow Up/Down walks the cards of the active pane.

        Returns ``None`` (not ``"break"``) when the user is typing, so the
        caret still moves inside the search box and the arrow keys are not
        stolen from any editable field.
        """
        try:
            focused = self.focus_get()
        except (tk.TclError, KeyError):
            focused = None
        if focused is not None and focused.__class__.__name__ in (
            "Entry",
            "Text",
            "CTkTextbox",
        ):
            return None
        cards = self._cards.get(self._active_section, [])
        if not cards:
            return "break"
        current = self._focused_card.get(self._active_section)
        try:
            index = cards.index(current) if current is not None else -1
        except ValueError:
            index = -1
        index += step
        if index < 0:
            index = 0
        elif index >= len(cards):
            index = len(cards) - 1
        self._set_focus_card(cards[index])
        if self.speech.enabled:
            # Read the new result as the user moves, so the audio follows the
            # keyboard. Throttled inside the engine for held arrow keys.
            self._speak_focused()
        return "break"

    def _bind_shortcuts(self) -> None:
        bindings = {
            "<Control-k>": lambda e: self._focus_entry(),
            "<Control-f>": lambda e: self._focus_entry(),
            "<F1>": lambda e: self.show_help(),
            "<F2>": lambda e: self._jump_to_section(0),
            "<F3>": lambda e: self._jump_to_section(1),
            "<F4>": lambda e: self._jump_to_section(2),
            "<F5>": lambda e: self._rerun_search(),
            "<F6>": lambda e: self._cycle_pane(),
            "<Escape>": self._on_escape,
            "<Up>": lambda e: self._move_card_focus(-1),
            "<Down>": lambda e: self._move_card_focus(1),
            "<Control-d>": lambda e: self.toggle_theme(),
            "<Control-l>": lambda e: self.toggle_language(),
            "<Control-comma>": lambda e: self.open_preferences(),
            "<Control-Shift-O>": lambda e: self.open_downloads_folder(),
            "<Control-Shift-Delete>": lambda e: self.clear_cache(),
            "<Alt-d>": lambda e: self._active_action("download"),
            "<Alt-o>": lambda e: self._active_action("source"),
            "<Alt-c>": lambda e: self.copy_focused_citation(),
            "<Control-Shift-C>": lambda e: self.copy_focused_citation(),
            "<Control-Home>": lambda e: self._jump_to_result(0),
            "<Control-End>": lambda e: self._jump_to_result(-1),
            # Reread the focused result, and toggle spoken output.
            "<Alt-r>": lambda e: self._speak_focused(force=True),
            "<Alt-R>": lambda e: self._speak_focused(force=True),
            "<Alt-s>": lambda e: self.toggle_speech(),
        }
        for sequence, handler in bindings.items():
            self.bind_all(sequence, handler)
        # Ctrl+Tab is the platform convention for "next pane".
        self.bind_all("<Control-Tab>", lambda e: self._cycle_pane(1))
        self.bind_all("<Control-ISO_Left_Tab>", lambda e: self._cycle_pane(-1))

    def _on_enter(self, _event=None) -> str:
        self.start_search()
        return "break"

    def _on_escape(self, _event=None) -> str:
        if self._searching:
            self.stop_search()
        return "break"

    def _focus_entry(self) -> str:
        self.query_entry.focus_set()
        self.query_entry.select_range(0, "end")
        return "break"

    def _cycle_pane(self, direction: int = 1) -> str:
        """F6 moves focus between the main panes of the interface."""
        if not self._pane_order:
            return "break"
        self._pane_index = (self._pane_index + direction) % len(self._pane_order)
        widget = self._pane_order[self._pane_index]
        try:
            widget.focus_set()
        except tk.TclError:
            pass
        return "break"

    def _jump_to_section(self, index: int) -> str:
        if 0 <= index < len(SECTION_ORDER):
            self._activate_section(SECTION_ORDER[index])
        return "break"

    def _jump_to_result(self, index: int) -> str:
        cards = self._cards.get(self._active_section, [])
        if not cards:
            return "break"
        card = cards[index] if index >= 0 else cards[-1]
        self._set_focus_card(card)
        return "break"

    def _on_section_focus(self, category: Category | None = None) -> None:
        """Remember which section currently holds keyboard focus."""
        if category is None:
            try:
                focused = self.focus_get()
            except (tk.TclError, KeyError):
                return
            for candidate, frame in self._section_frames.items():
                if focused is not None and str(frame).startswith(str(focused)):
                    category = candidate
                    break
            else:
                return
        if category in SECTION_ORDER:
            self._active_section = category

    def _on_card_focus(self, card: ResultCard, category: Category) -> None:
        """Track both the active section and the card the citation acts on."""
        self._active_section = category
        self._focused_card[category] = card
        self._refresh_citation_preview()

    def _active_action(self, action: str) -> str:
        card = self._focused_card.get(self._active_section)
        if card is None:
            return "break"
        {
            "download": card._download,
            "source": card._open_source,
            "citation": card._copy,
        }[action]()
        return "break"

    # ==================================================================
    # Search
    # ==================================================================
    def toggle_search(self) -> None:
        if self._searching:
            self.stop_search()
        else:
            self.start_search()

    def build_query(self) -> SearchQuery | None:
        text = self.query_entry.get().strip()
        if not text:
            self._announce(i18n.t("status.empty_field"), error=True)
            self._focus_entry()
            return None
        language = i18n.language_code_for(self.language_var.get())
        try:
            per_source = int(self.count_menu.get())
        except (TypeError, ValueError):
            per_source = self.config.results_per_source
        return SearchQuery(
            text=text,
            language=language,
            per_source=per_source,
            year_from=_parse_year(self.year_from.get()),
            year_to=_parse_year(self.year_to.get()),
            categories=set(SECTION_ORDER),
        )

    def start_search(self) -> None:
        query = self.build_query()
        if query is None:
            return
        if self._engine is None:
            from app.core.search_engine import SearchEngine

            self._engine = SearchEngine()

        self._searching = True
        self.search_button.configure(
            text=i18n.t("search.button.stop"), fg_color=self.palette.danger,
            hover_color=self.palette.danger,
        )
        self.progress.start()
        total_planned = sum(
            len(providers_for_category(c)) for c in SECTION_ORDER
        )
        self._announce(i18n.t("status.searching", count=total_planned))
        for chip in self._chips.values():
            chip.set_state(self.palette, self.fonts, "pending", chip.cget("text"))
        for category in SECTION_ORDER:
            self._count_labels[category].configure(text=i18n.t("tab.loading"))

        self._handle = self._engine.start(query)

    def stop_search(self) -> None:
        if self._engine is not None:
            self._engine.cancel_current()
        self._announce(i18n.t("status.cancelled"))

    def _rerun_search(self) -> str:
        if self.query_entry.get().strip():
            self.start_search()
        return "break"

    def clear_search(self) -> None:
        self.query_entry.delete(0, "end")
        self.year_from.delete(0, "end")
        self.year_to.delete(0, "end")
        self._response = None
        for category in SECTION_ORDER:
            self._populate(category, [])
        self._announce(i18n.t("status.idle"))
        self._focus_entry()

    # -- event pump --------------------------------------------------------
    def _pump_search_events(self) -> None:
        """Drain the engine queue on the Tk thread. Never blocks."""
        handle = self._handle
        if handle is not None:
            try:
                while True:
                    event = handle.events.get_nowait()
                    self._on_search_event(event)
            except queue.Empty:
                pass
            if handle.done and handle.events.empty():
                self._finish_search_ui()
                self._handle = None
        self.after(80, self._pump_search_events)

    def _on_search_event(self, event) -> None:
        if event.type is SearchEventType.PROVIDER_UPDATE and event.report:
            self._update_chip(event.report)
        elif event.type is SearchEventType.PARTIAL_RESULTS and event.response:
            self._merge_partial(event.response)
        elif event.type is SearchEventType.FINISHED and event.response:
            self._response = event.response
        elif event.type is SearchEventType.CANCELLED and event.response:
            self._response = event.response
        elif event.type is SearchEventType.FAILED:
            self._announce(i18n.t("status.error", error=event.message), error=True)

    def _update_chip(self, report) -> None:
        chip = self._chips.get(report.provider_id)
        if chip is None:
            return
        name = i18n.t(f"provider.{report.provider_id}")
        status = report.status.value
        if status == "error":
            message = (
                i18n.t(f"status.{report.message}")
                if report.message in ("rate_limited", "key_missing", "offline")
                else report.message or ""
            )
            chip.set_state(
                self.palette, self.fonts, "error",
                f"{name} ✕ {message}" if message else f"{name} ✕",
            )
        elif status == "empty":
            chip.set_state(self.palette, self.fonts, "empty", f"{name} 0")
        elif status == "running":
            chip.set_state(self.palette, self.fonts, "running", f"{name} …")
        elif status in ("pending", "skipped"):
            chip.set_state(self.palette, self.fonts, status, name)
        else:
            chip.set_state(
                self.palette, self.fonts, "ok", f"{name} {report.count}"
            )

    def _merge_partial(self, response) -> None:
        """Render results as they arrive, without discarding the user's scroll."""
        for category in SECTION_ORDER:
            items = response.by_category(category)
            existing = self._cards.get(category, [])
            if len(items) != len(existing):
                self._populate(category, items)

    def _finish_search_ui(self) -> None:
        self._searching = False
        self.search_button.configure(
            text=i18n.t("search.button"),
            fg_color=self.palette.accent,
            hover_color=self.palette.accent_hover,
        )
        self.progress.stop()
        self.progress.set(0)

        if self._response is None:
            self._announce(i18n.t("status.no_results"))
            return

        for category in SECTION_ORDER:
            self._populate(category, self._response.by_category(category))

        total = self._response.total()
        failed = sum(1 for r in self._response.reports if r.failed)
        if total == 0:
            message = i18n.t("status.no_results")
        elif failed:
            message = i18n.t("status.done_partial", total=total, failed=failed)
        else:
            message = i18n.t(
                "status.done", total=total, seconds=self._response.elapsed
            )
        self._announce(message, error=False)

    # -- rendering ---------------------------------------------------------
    def _populate(self, category: Category, items: list[Result]) -> None:
        container = self._lists[category]
        for child in container.winfo_children():
            if child is not self._empty_labels[category]:
                child.destroy()

        cards: list[ResultCard] = []
        page_limit = self.config.results_per_page
        for index, item in enumerate(items[: page_limit * 3]):
            card = ResultCard(
                container,
                item,
                self.palette,
                self.fonts,
                self.metrics,
                on_download=self.handle_download,
                on_open_source=self.handle_open_source,
                on_copy_citation=self.handle_copy_citation,
                abstract_chars=self.config.abstract_chars,
            )
            card.grid(
                row=index, column=0, sticky="ew",
                padx=(0, self.metrics.sm), pady=(0, self.metrics.sm),
            )
            bind_tk(
                card,
                "<FocusIn>",
                # ``_e=None`` because bind_tk scripts carry no ``%``
                # substitutions, so Tk invokes the handler with no arguments.
                lambda _e=None, cat=category, c=card: self._on_card_focus(c, cat),
            )
            cards.append(card)
        container.grid_columnconfigure(0, weight=1)

        self._cards[category] = cards
        self._focused_card[category] = None
        # The new cards brought fresh decoration canvases with them.
        self.after_idle(self._fix_focus_order)

        if items:
            self._empty_labels[category].place_forget()
        else:
            self._empty_labels[category].place(relx=0.5, rely=0.35, anchor="center")

        total = len(items)
        shown = len(cards)
        self._count_labels[category].configure(
            text=(
                i18n.t("generic.of_total", shown=shown, total=total)
                if shown < total
                else i18n.t("generic.results", count=total)
            )
        )

    def _set_focus_card(self, card: ResultCard) -> None:
        self._focused_card[card.result.category] = card
        self._active_section = card.result.category
        self._refresh_citation_preview()
        if self.speech.enabled:
            # Tab and Enter land on a card without the arrow keys, so mirror
            # the spoken result here too rather than only on Up/Down.
            self.after_idle(self._speak_focused)
        try:
            # The real <FocusIn> binding on the card drives the focus ring, so
            # do not synthesise the event: that would light the ring for a
            # card that never actually received keyboard focus.
            card.focus_set()
        except tk.TclError:
            pass

    def _activate_section(self, category: Category) -> None:
        self._active_section = category
        for other, frame in self._section_frames.items():
            if other is category:
                frame.grid(row=0, column=0, sticky="nsew")
            else:
                frame.grid_forget()
        try:
            self.section_button.set(i18n.t(TAB_LABELS[category]))
        except tk.TclError:
            pass

    def _on_section_change(self, value: str) -> None:
        for category in SECTION_ORDER:
            if i18n.t(TAB_LABELS[category]) == value:
                self._activate_section(category)
                return

    def _on_language_change(self, _value: str = "") -> None:
        # The option menu labels change with the UI language, so re-map them.
        # The *code* is what the query actually needs, so resolve it before the
        # labels are rebuilt and then select the matching entry again.
        code = i18n.language_code_for(self.language_var.get())
        options = i18n.language_options()
        self._language_codes = [c for c, _ in options]
        self.language_menu.configure(values=[label for _, label in options])
        for candidate, label in options:
            if candidate == code:
                self.language_var.set(label)
                break

    # ==================================================================
    # Result actions
    # ==================================================================
    def handle_download(self, result: Result, card: ResultCard) -> None:
        task = self.downloads.enqueue(result)
        if task is None:
            self._announce(
                i18n.t("status.error", error=i18n.t("access.metadata")), error=True
            )
            return
        if task.state is DownloadState.SKIPPED:
            # No open file exists: send the user to the official source page.
            self._announce(i18n.t("access.landing"))
            if self.config.confirm_open_browser:
                self._confirm_open(task.target.url)
            else:
                open_external(task.target.url)
            return
        self._download_tasks.append(task)
        self._refresh_downloads_button()
        self._announce(i18n.t("download.started", name=task.filename))

    def handle_open_source(self, result: Result, card: ResultCard) -> None:
        url = result.landing_url or (result.downloads[0].url if result.downloads else "")
        if not url:
            self._announce(
                i18n.t("status.error", error=i18n.t("access.metadata")), error=True
            )
            return
        if self.config.confirm_open_browser:
            self._confirm_open(url)
        else:
            open_external(url)
            self._announce(i18n.t("action.open_source"))

    def handle_copy_citation(self, result: Result, card: ResultCard) -> None:
        """A card's own citation button: use the style chosen in the toolbar."""
        self._citation_style = self.config.citation_style or self._citation_style
        self.copy_focused_citation()

    def _on_citation_style_change(self, label: str) -> None:
        """Map the chosen dropdown label back to a stable style key."""
        for style, text in self._citation_labels.items():
            if text == label:
                self._citation_style = style
                break
        self.config.citation_style = self._citation_style
        self._refresh_citation_preview()

    def _focused_result(self) -> ResultCard | None:
        """The card the user is standing on, falling back to the last focused.

        The live focus is checked first so Tab / arrow navigation always wins,
        and ``_focused_card`` covers programmatic jumps such as ``Ctrl+Home``.
        """
        try:
            focused = self.focus_get()
        except (tk.TclError, KeyError):
            focused = None

        if focused is not None:
            for cards in self._cards.values():
                for card in cards:
                    if focused is card or _is_descendant(focused, card):
                        return card

        return self._focused_card.get(self._active_section)

    def _refresh_citation_preview(self) -> None:
        """Show the title the copy button will act on, or a hint if none."""
        card = self._focused_result()
        if card is None:
            self._focused_citation_label.configure(
                text=i18n.t("citation.no_selection")
            )
            return
        title = truncate_words(card.result.title, 8)
        if len(title) > 46:
            title = title[:45].rstrip() + "…"
        self._focused_citation_label.configure(
            text=f"{i18n.t('citation.copies')}: {title}"
        )

    def copy_focused_citation(self) -> str:
        """Copy the selected result's citation in the style chosen above."""
        card = self._focused_result()
        if card is None:
            self._announce(i18n.t("citation.no_selection"), error=True)
            return "break"
        text = format_citation(card.result, self._citation_style)
        try:
            self.clipboard_clear()
            self.clipboard_append(text)
            self.update_idletasks()
        except tk.TclError:
            self._announce(
                i18n.t("status.error", error=i18n.t("generic.copy")), error=True
            )
            return "break"
        self._last_citation = text
        self._announce(
            i18n.t("citation.copied_style", style=i18n.citation_style_label(
                self._citation_style))
        )
        return "break"

    def _confirm_open(self, url: str) -> None:
        if messagebox.askyesno(
            i18n.t("generic.confirm_title"),
            i18n.t("download.confirm_open", url=url),
            parent=self,
        ):
            open_external(url)

    # -- downloads ---------------------------------------------------------
    def _pump_download_events(self) -> None:
        try:
            while True:
                event = self.downloads.events.get_nowait()
                self._on_download_event(event)
        except queue.Empty:
            pass
        self.after(120, self._pump_download_events)

    def _on_download_event(self, event: DownloadEvent) -> None:
        task = event.task
        if event.type is DownloadEventType.FINISHED:
            # No modal dialog: the status bar button becomes "open the file"
            # so a batch of downloads never blocks the interface.
            self._refresh_downloads_button()
            self._announce(
                i18n.t("download.finished", name=task.path.name if task.path else task.filename)
            )
        elif event.type is DownloadEventType.PROGRESS:
            total = human_size(task.total) if task.total else "…"
            self._refresh_downloads_button(
                detail=f"{task.received / 1024 / 1024:.1f} / {total} MB"
            )
        elif event.type is DownloadEventType.FAILED:
            self._announce(
                i18n.t("download.failed", name=task.filename, error=task.error),
                error=True,
            )
        elif event.type is DownloadEventType.CANCELLED:
            self._announce(i18n.t("download.cancelled"))

    def _refresh_downloads_button(self, detail: str = "") -> None:
        """The status-bar button doubles as the downloads tray shortcut."""
        done = [t for t in self._download_tasks if t.state is DownloadState.DONE]
        if not self._download_tasks:
            self._last_download = None
            self.downloads_button.configure(text=i18n.t("download.open_folder"))
            return
        if done:
            self._last_download = done[-1]
            label = i18n.t("download.show")
        else:
            self._last_download = None
            label = i18n.t("download.title")
        text = f"{label} ({len(done)}/{len(self._download_tasks)})"
        if detail:
            text = f"{label} {detail}"
        self.downloads_button.configure(text=text)

    def _downloads_button_command(self) -> None:
        """Reveal the most recent finished download, else open the folder."""
        last = getattr(self, "_last_download", None)
        if last is not None and last.path is not None and last.path.exists():
            self._reveal(last.path)
        else:
            self.open_downloads_folder()

    def _reveal(self, path: Path) -> None:
        try:
            if sys.platform.startswith("win"):
                subprocess.Popen(["explorer", "/select,", str(path)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path.parent)])
        except Exception:
            open_external(path.as_uri())

    def open_downloads_folder(self) -> None:
        folder = self.config.download_folder
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(folder))  # noqa: S606 - Windows shell API
            else:
                open_external(folder.as_uri())
        except Exception:
            messagebox.showinfo(
                i18n.t("download.open_folder"), str(folder), parent=self
            )

    # ==================================================================
    # Preferences / help
    # ==================================================================
    def open_preferences(self) -> None:
        from app.ui.preferences import PreferencesDialog

        PreferencesDialog(self, self.config)

    def show_help(self) -> str:
        from app.ui.help_dialog import ShortcutDialog

        ShortcutDialog(self)
        return "break"

    def toggle_theme(self) -> str:
        order = ["system", "dark", "light"]
        try:
            index = order.index(self.config.theme)
        except ValueError:
            index = 0
        self.set_theme(order[(index + 1) % len(order)])
        return "break"

    def set_theme(self, preference: str) -> None:
        self.config.theme = preference
        self.palette = apply_theme(preference)
        self.configure(fg_color=self.palette.bg)
        self._restyle()
        self._announce(i18n.t(f"prefs.theme.{preference}"))

    def toggle_language(self) -> str:
        self.set_language("en" if i18n.get_language() == "ar" else "ar")
        return "break"

    def set_language(self, code: str) -> None:
        i18n.set_language(code)
        self.config.ui_language = code
        self.title(self._title_text())
        self._restyle(retranslate=True)
        self._announce(i18n.t("status.idle"))

    def _restyle(self, retranslate: bool = False) -> None:
        """Re-apply the palette (and optionally every string) to the whole tree."""
        p = self.palette
        self.title_label.configure(
            text=i18n.t("app.title"), text_color=p.text,
            font=self.fonts.role("display"),
        )
        self.subtitle_label.configure(
            text=i18n.t("app.subtitle"), text_color=p.text_muted,
            font=self.fonts.role("small"),
        )
        for widget in (self.theme_menu_button, self.lang_button, self.prefs_button):
            widget.configure(
                fg_color=p.surface_alt, hover_color=p.surface_hover,
                border_color=p.border, text_color=p.text, font=self.fonts.role("small"),
            )
        if retranslate:
            self.help_button.configure(text=f"{i18n.t('help.title')} (F1)")
            self.prefs_button.configure(text=i18n.t("app.menuprefs"))
            self.theme_menu_button.configure(text=i18n.t("prefs.theme"))

        self.query_entry.configure(
            fg_color=p.surface_alt, border_color=p.border, text_color=p.text,
            font=self.fonts.role("body"),
            placeholder_text=i18n.t("search.placeholder"),
        )
        if retranslate:
            self.search_button.configure(
                text=i18n.t("search.button.stop") if self._searching
                else i18n.t("search.button")
            )
            self.language_label.configure(text=i18n.t("search.language"))
            self.count_label.configure(text=i18n.t("search.results_count"))
            self.advanced_button.configure(text=i18n.t("search.advanced"))
            self.from_label.configure(text=i18n.t("search.year_from"))
            self.to_label.configure(text=i18n.t("search.year_to"))
            self.clear_button.configure(text=i18n.t("search.clear"))
            self.downloads_button.configure(text=i18n.t("download.open_folder"))
            self.citation_style_label.configure(text=i18n.t("citation.format"))
            self.copy_citation_button.configure(text=i18n.t("citation.copy"))
            # Style labels are identical in both languages, but rebuilding them
            # keeps the dropdown in sync if a label ever becomes localised.
            self._citation_labels = {
                style: i18n.citation_style_label(style) for style in self._citation_styles
            }
            self.citation_style_menu.configure(
                values=[self._citation_labels[s] for s in self._citation_styles]
            )
            self.citation_style_var.set(self._citation_labels[self._citation_style])
            self._refresh_citation_preview()
            self.section_button.configure(
                values=[i18n.t(TAB_LABELS[c]) for c in SECTION_ORDER]
            )
            self.section_button.set(i18n.t(TAB_LABELS[self._active_section]))
            self._on_language_change(self.language_var.get())
            for category in SECTION_ORDER:
                self._empty_labels[category].configure(
                    text=f"{i18n.t('tab.empty')}\n{i18n.t('tab.empty_hint')}"
                )
        self.status_label.configure(text_color=p.text_muted, font=self.fonts.role("small"))
        self.progress.configure(progress_color=p.accent, fg_color=p.surface_alt)
        self.citation_style_label.configure(text_color=p.text_muted,
                                            font=self.fonts.role("caption"))
        self._focused_citation_label.configure(text_color=p.text_faint,
                                               font=self.fonts.role("caption"))
        self.citation_style_menu.configure(
            fg_color=p.surface_alt,
            button_color=p.accent,
            button_hover_color=p.accent_hover,
            text_color=p.text,
            font=self.fonts.role("small"),
            dropdown_fg_color=p.surface,
            dropdown_text_color=p.text,
            dropdown_hover_color=p.surface_hover,
            dropdown_font=self.fonts.role("small"),
        )
        self.copy_citation_button.configure(
            fg_color=p.accent, hover_color=p.accent_hover,
            text_color=p.text_on_accent, font=self.fonts.role("body_bold"),
        )
        self._build_chips()
        for category in SECTION_ORDER:
            for card in self._cards.get(category, []):
                card.refresh_theme(p, self.fonts)

    def _announce(self, message: str, error: bool = False) -> None:
        """Update the status line (the focusable live region)."""
        try:
            self.status_label.configure(
                text=message,
                text_color=self.palette.danger if error else self.palette.text_muted,
            )
        except tk.TclError:
            pass

    # ==================================================================
    # Spoken output
    # ==================================================================
    def _speak(self, text: str, force: bool = False) -> bool:
        """Speak ``text`` and mirror it into the status line.

        A screen reader cannot see the CustomTkinter canvas, so the status line
        doubles as the visible copy of whatever is being said. Failures are
        non-fatal: a machine with no speech engine keeps working silently.
        """
        if not self.speech.enabled:
            return False
        spoken = self.speech.say(text, force=force)
        if spoken and text:
            self._announce(text)
        return spoken

    def _speak_focused(self, force: bool = False) -> str:
        """Read the result under the cursor aloud, if any."""
        card = self._focused_result()
        if card is None:
            if not force:
                self._announce(i18n.t("speech.no_selection"))
            return "break"
        text = self.speech.describe_result(card.result, i18n.get_language())
        if not text:
            self._announce(i18n.t("speech.no_text"))
            return "break"
        self._speak(text, force=force)
        return "break"

    def toggle_speech(self) -> str:
        """Turn spoken output on, or mute it when it is already on."""
        if not self.speech.enabled:
            self.speech.set_enabled(True)
            if not self.speech.ensure_ready():
                # No engine on this machine: stay quiet rather than pretend.
                self.speech.set_enabled(False)
                self._refresh_speech_button()
                self._announce(i18n.t("speech.unavailable"), error=True)
                return "break"
            self._refresh_speech_button()
            self._speak(i18n.t("speech.on"), force=True)
            return "break"

        muted = self.speech.toggle_mute()
        self._refresh_speech_button()
        if muted:
            self._announce(i18n.t("speech.off"))
        else:
            self._speak(i18n.t("speech.on"), force=True)
        return "break"

    def _refresh_speech_button(self) -> None:
        """Keep the toggle's caption and colour in step with the engine."""
        try:
            if not self.speech.enabled:
                label, colour = i18n.t("speech.enable"), self.palette.text_muted
            elif self.speech.muted:
                label, colour = i18n.t("speech.muted"), self.palette.text_muted
            else:
                label, colour = i18n.t("speech.on"), self.palette.accent
            self.speech_button.configure(text=label, text_color=colour)
        except tk.TclError:
            pass

    def _apply_window_icon(self) -> None:
        """Show the bundled icon in the title bar and task bar.

        Cosmetic only, so every failure is swallowed: a missing asset must
        never stop the window from opening. ``iconbitmap`` is tried first
        because Tk renders it crisply; the PNG is the fallback for builds that
        ship only the raster asset.
        """
        from app.config import resource_dir

        try:
            base = resource_dir() / "assets"
            ico = base / "acadsearch.ico"
            png = base / "acadsearch.png"
            if ico.is_file():
                self.iconbitmap(str(ico))
            elif png.is_file():
                self.iconphoto(True, tk.PhotoImage(file=str(png)))
        except (tk.TclError, OSError):
            pass

    def _title_text(self) -> str:
        from app.config import APP_NAME

        return f"{APP_NAME} — {i18n.t('app.subtitle')} {APP_VERSION}"

    def _poll_system_theme(self) -> None:
        """Follow the Windows appearance setting while set to "system"."""
        if self.config.theme == "system":
            from app.ui.theme import active_mode, resolve_mode

            if resolve_mode("system") != active_mode():
                self.palette = apply_theme("system")
                self.configure(fg_color=self.palette.bg)
                self._restyle()
        self.after(4000, self._poll_system_theme)

    # ==================================================================
    # Menu (screen readers announce menu accelerators)
    # ==================================================================
    def _build_menu(self) -> None:
        menubar = tk.Menu(self, tearoff=0)
        self.configure(menu=menubar)
        self._menus = (menubar,)

        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(
            label=i18n.t("app.menu_open_downloads"),
            accelerator="Ctrl+Shift+O",
            command=self.open_downloads_folder,
        )
        file_menu.add_separator()
        file_menu.add_command(
            label=i18n.t("app.menu_clear_cache"),
            accelerator="Ctrl+Shift+Delete",
            command=self.clear_cache,
        )
        file_menu.add_separator()
        file_menu.add_command(
            label=i18n.t("app.menu_exit"), accelerator="Alt+F4", command=self.on_close
        )
        menubar.add_cascade(label=i18n.t("app.menufile"), menu=file_menu)

        search_menu = tk.Menu(menubar, tearoff=0)
        search_menu.add_command(
            label=i18n.t("app.menu_focus_search"),
            accelerator="Ctrl+K",
            command=self._focus_entry,
        )
        search_menu.add_command(
            label=i18n.t("search.button"),
            accelerator="F5",
            command=self._rerun_search,
        )
        menubar.add_cascade(label=i18n.t("app.menuedit"), menu=search_menu)

        prefs_menu = tk.Menu(menubar, tearoff=0)
        prefs_menu.add_command(
            label=i18n.t("citation.copy"),
            accelerator="Ctrl+Shift+C",
            command=self.copy_focused_citation,
        )
        prefs_menu.add_separator()
        prefs_menu.add_command(
            label=i18n.t("app.menuprefs"),
            accelerator="Ctrl+,",
            command=self.open_preferences,
        )
        prefs_menu.add_command(
            label=i18n.t("app.menu_toggle_theme"),
            accelerator="Ctrl+D",
            command=self.toggle_theme,
        )
        prefs_menu.add_command(
            label=i18n.t("app.menu_language"),
            accelerator="Ctrl+L",
            command=self.toggle_language,
        )
        menubar.add_cascade(label=i18n.t("app.menuprefs"), menu=prefs_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(
            label=i18n.t("help.title"), accelerator="F1", command=self.show_help
        )
        help_menu.add_command(
            label=i18n.t("app.menu_about"), command=self.show_about
        )
        menubar.add_cascade(label=i18n.t("app.menuhelp"), menu=help_menu)
        self.menubar = menubar

    def show_about(self) -> None:
        messagebox.showinfo(i18n.t("app.menu_about"), i18n.t("app.menu_about_text"), parent=self)

    def clear_cache(self) -> None:
        removed = self.http.clear_cache()
        self._announce(f"{i18n.t('app.menu_clear_cache')}: {removed}")

    def on_close(self) -> None:
        if self._engine is not None:
            self._engine.shutdown()
        self.downloads.cancel_all()
        # Stop the speech worker, otherwise a queued result keeps the SAPI
        # thread alive after the window is gone.
        try:
            self.speech.shutdown()
        except Exception:
            log.debug("could not stop speech", exc_info=True)
        try:
            self.config.save()
        except Exception:
            log.debug("could not persist config", exc_info=True)
        self.destroy()


def _parse_year(value: str) -> int | None:
    text = (value or "").strip()
    if not text.isdigit():
        return None
    year = int(text)
    return year if 1000 <= year <= 2200 else None


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )
    app = AcadSearchApp()
    app._build_menu()
    app.mainloop()
    return 0
