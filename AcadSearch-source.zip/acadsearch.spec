# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for the AcadSearch desktop build.

One-file, windowed. Produces ``dist/AcadSearch.exe``.

    python -m PyInstaller acadsearch.spec --noconfirm

Notes
-----
* ``--onefile`` + ``--windowed`` means no console window and a single
  artefact the user can copy to a USB stick. The trade-off is a slower cold
  start, because the archive unpacks into %TEMP% on each launch.
* CustomTkinter is gone: the interface is PySide6. Tk and CustomTkinter are
  excluded so the Tcl/Tk runtime does not ride along in a Qt application.
* ``requests`` pulls in ``certifi`` (CA bundle) and ``urllib3``; without
  ``collect_data_files`` the packaged app fails TLS on every HTTPS call.
* The provider modules are listed by hand because they register themselves
  through a decorator, which PyInstaller's import analysis cannot follow.
"""

import sys
from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files

BLOCK_CIPHER = None

# The interface is PySide6 now, so the CustomTkinter/Tk theme data the previous
# build needed is gone. What must still be collected is the CA bundle: the
# providers all speak HTTPS, and without certifi's cacert.pem every call fails
# TLS inside the frozen build while working fine from source.
datas = []

# Bundled assets (app icon) live in ./assets.
assets = Path(SPECPATH) / "assets"
if assets.is_dir():
    for item in assets.iterdir():
        if item.is_file():
            datas.append((str(item), "assets"))

for package in ("certifi", "urllib3"):
    datas += collect_data_files(package)

# The twenty-nine providers are discovered at import time by ``app.providers.base``,
# which imports them by name in ``_ensure_loaded``, so static analysis does find
# them. They are listed here as well because the cost of a missing line is a
# packaged app that quietly searches fewer databases than the source tree, and
# because a future refactor to a dynamic import would make the difference
# invisible. Verified against the frozen archive with
# ``python -m PyInstaller.utils.cliutils.archive_viewer -l -r -b dist/AcadSearch.exe``.
PROVIDER_MODULES = [
    "app.providers.arxiv",
    "app.providers.base",
    "app.providers.base_search",
    "app.providers.core",
    "app.providers.crossref",
    "app.providers.datacite",
    "app.providers.doaj",
    "app.providers.dumas",
    "app.providers.erudit",
    "app.providers.europe_pmc",
    "app.providers.google_books",
    "app.providers.hal",
    "app.providers.hindawi",
    "app.providers.internet_archive",
    "app.providers.lens",
    "app.providers.mirabel",
    "app.providers.noorbook",
    "app.providers.open_library",
    "app.providers.openaire",
    "app.providers.openalex",
    "app.providers.openedition",
    "app.providers.persee",
    "app.providers.pubmed",
    "app.providers.scilit",
    "app.providers.scinapse",
    "app.providers.semantic_scholar",
    "app.providers.springer",
    "app.providers.sudoc",
    "app.providers.thesesfr",
    "app.providers.zenodo",
]

hiddenimports = [
    "PySide6.QtNetwork",
    "certifi",
    "urllib3",
    # ``main.py`` sets sys.path and imports these by name, and
    # ``main_window`` imports theme/preferences inside a try/except, so neither
    # edge is visible to static analysis.
    "qt_prototype",
    "qt_prototype.main_window",
    "qt_prototype.preferences",
    "qt_prototype.theme",
    # The local-file picker and its extractor are imported through the same
    # try/except edge as the dialogs above, so name them for the freezer too.
    "qt_prototype.local_file_dialog",
    "qt_prototype.help_dialog",
    "qt_prototype.about_dialog",
    "app.core.local_file",
    "app.core.local_lookup",
    "app.core.doc_ai",
    "pypdf",
    "pypdfium2",
    "PIL.Image",
    # Bundled key defaults are read through a runtime import in
    # ``app.config._bundled_keys``; list it so a distributable ships with its
    # distributor's keys even though the early return hides the import edge.
    "app.private_keys",
    *PROVIDER_MODULES,
]

# Unused at runtime; dropping them keeps the binary smaller. tkinter is excluded
# on purpose: the old build needed it for CustomTkinter, and leaving it in adds
# the whole Tcl/Tk runtime to a Qt application.
excludes = [
    "pytest",
    "IPython",
    "notebook",
    "matplotlib",
    "numpy",
    "pandas",
    "scipy",
    "tkinter",
    "customtkinter",
    "test",
    "unittest",
    "PySide6.QtWebEngineCore",
    "PySide6.QtWebEngineWidgets",
    "PySide6.Qt3DCore",
    "PySide6.QtMultimedia",
    "PySide6.QtQuick",
    "PySide6.QtQml",
    "PySide6.QtCharts",
    "PySide6.QtDataVisualization",
]

icon_path = assets / "acadsearch.ico"
icon = str(icon_path) if icon_path.is_file() else None

a = Analysis(
    ["main.py"],
    pathex=[str(Path(SPECPATH))],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=BLOCK_CIPHER,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=BLOCK_CIPHER)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="AcadSearch",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=icon,
    version=str(Path(SPECPATH) / "version_info.txt")
    if (Path(SPECPATH) / "version_info.txt").is_file()
    else None,
)
