"""Check the result card is a quiet, read-only row: no buttons on it at all.

Actions (تنزيل، نسخ التوثيق، نسخ الملخص، فتح للقراءة) live behind the
Application key on the focused row, so the results screen stays free of
buttons. The card still decides whether a download file exists (for Alt+D)
and still shows the abstract preview.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(r"D:\projects\برنامج\بحث علمي")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "qt_prototype"))

from PySide6.QtWidgets import QApplication, QPushButton

import main_window
from app.config import get_config
from app.models import Category, DownloadFormat, DownloadTarget, Result


def make_result(**kw) -> Result:
    defaults = dict(
        category=Category.ARTICLE,
        title="A study about machine learning",
        source="open_library",
        year=2023,
        authors=["Sara Ahmed", "Omar Ali"],
        venue="Journal of Testing",
        landing_url="https://example.org/paper",
    )
    defaults.update(kw)
    return Result(**defaults)


def main() -> int:
    app = QApplication.instance() or QApplication([])
    win = main_window.MainWindow()

    failures: list[str] = []

    def check(label: str, ok: bool, detail: str = "") -> None:
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" -- {detail}" if detail else ""))
        if not ok:
            failures.append(label)

    print("== the card stays quiet: no buttons on it ==")
    multi = make_result(
        downloads=[
            DownloadTarget(url="https://example.org/a.pdf", fmt=DownloadFormat.PDF, open_access=True),
            DownloadTarget(url="https://example.org/b.epub", fmt=DownloadFormat.EPUB, open_access=True),
            DownloadTarget(url="https://example.org/c.html", fmt=DownloadFormat.HTML),
        ]
    )
    card = main_window.ResultCard(multi)
    buttons = card.findChildren(QPushButton)
    labels = [b.text() for b in buttons]
    check("no buttons anywhere on the card",
          not buttons, str(labels))
    check("download target is the open-access PDF",
          card.download_target().url.endswith("a.pdf"),
          str(card.download_target()))

    print("== result with no file at all ==")
    bare = make_result(downloads=[])
    card2 = main_window.ResultCard(bare)
    check("still no buttons on the card",
          not card2.findChildren(QPushButton))
    check("download_target is None", card2.download_target() is None)

    print("== abstract preview on the card ==")
    long_abstract = (
        "An abstract long enough to prove the preview is cut rather than "
        "dumped: it runs well past the two-line budget and should end with an "
        "ellipsis after the nearest word boundary and nothing else."
    )
    with_abs = make_result(abstract=long_abstract)
    card3 = main_window.ResultCard(with_abs)
    check("an abstract means a snippet label", card3.snippet is not None)
    if card3.snippet is not None:
        check("snippet text is non-empty", bool(card3.snippet.text()),
              repr(card3.snippet.text()[:40]))
        check(
            "snippet text stays within the preview budget",
            len(card3.snippet.text()) <= 200,
            f"{len(card3.snippet.text())} chars",
        )
        check(
            "long abstract is cut with an ellipsis",
            card3.snippet.text().rstrip().endswith("…"),
            repr(card3.snippet.text()[-12:]),
        )
        check("snippet is silent for the screen reader",
              card3.snippet.accessibleName() == "",
              repr(card3.snippet.accessibleName()))
    style = card3.snippet.styleSheet() if card3.snippet else ""
    check("snippet has a stylesheet id",
          card3.snippet is not None and card3.snippet.objectName() == "SummarySnippet",
          style[:40])
    card4 = main_window.ResultCard(make_result(abstract=""))
    check("no abstract means no snippet", card4.snippet is None)
    card5 = main_window.ResultCard(make_result(abstract=None))
    check("a missing abstract is the same as an empty one", card5.snippet is None)

    print("== source is readable, not a raw id ==")
    line = main_window.spoken_line(multi)
    check("spoken line names the source in Arabic",
          "أوبن ليبري" in line and "المصدر" not in line
          and "open_library" not in line, line)
    check("spoken line keeps the title", multi.title in line)

    print("== style and source labels (i18n) ==")
    check("APA has a translated label",
          main_window.style_label("apa") != "apa",
          main_window.style_label("apa"))
    check("unknown style falls back to the id",
          main_window.style_label("nope") == "nope")
    known = sorted(get_config().known_providers)
    check(
        "every known provider has a readable label",
        all(main_window.source_label(pid) != pid for pid in known),
        f"{len(known)} providers",
    )

    print()
    if failures:
        print(f"FAILED: {len(failures)} -> {failures}")
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())