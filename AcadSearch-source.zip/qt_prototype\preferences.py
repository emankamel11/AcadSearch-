"""Preferences dialog: interface language, citation style, sound cues, and API keys.

A small number of fields on purpose. Every control carries an accessible name
and an accessible description that says what the setting actually does, because
the only way the user reaches them is Tab and a screen reader.

The dialog writes to Config and, for the two settings that change what is on
screen (language, citation style), asks the caller to rebuild the UI.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QAccessible, QAccessibleEvent
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app import i18n
from app.config import get_config

try:
    from qt_prototype.about_dialog import AboutPanel, UI_LANGUAGES
except ImportError:  # running as a plain script from inside qt_prototype
    from about_dialog import AboutPanel, UI_LANGUAGES  # type: ignore[no-redef]

CITATION_STYLES = (
    "apa",
    "mla",
    "chicago",
    "harvard",
    "ieee",
    "bibtex",
    "ris",
)


def describe_pick(widget: QComboBox, hint: str) -> None:
    """Short name for the screen reader, full hint for the mouse.

    The hint used to be the accessible *description*, which NVDA reads out loud
    on top of the name every single time the combo takes focus. Tooltips are
    seen by the people who can see, and cost a screen-reader user nothing.
    """
    widget.setAccessibleName("")
    widget.setToolTip(hint)


def _announce(widget, text: str) -> None:
    """Say a short status without moving focus, like the main window does."""
    widget.setAccessibleName(text)
    for kind in (QAccessible.Event.NameChanged, QAccessible.Event.Alert):
        try:
            QAccessible.updateAccessibility(QAccessibleEvent(widget, kind))
        except (RuntimeError, TypeError):
            pass


class PreferencesDialog(QDialog):
    """Settings the user asked for: language, citation style, API keys."""

    def __init__(self, parent=None, focus_key: str | None = None):
        super().__init__(parent)
        self.setWindowTitle(i18n.t("app.menuprefs"))
        self.setAccessibleName(i18n.t("app.menuprefs"))
        #: "gemini" when the local-file dialog asked for a key: the field is
        #: focused on open so Ctrl+V lands in it instead of the language combo.
        self._focus_key = focus_key
        self.setMinimumWidth(580)

        root = QVBoxLayout(self)
        root.setSpacing(10)

        # One window, three sections. Preferences used to be a single long
        # column: language, then the sound switch, then eleven key fields, so
        # the settings a reader changes often were buried above a wall of keys.
        self.tabs = QTabWidget()
        self.tabs.setObjectName("PrefsTabs")
        self.tabs.setAccessibleName(i18n.t("prefs.tabs.accessible"))
        self.tabs.setToolTip(i18n.t("prefs.tabs.tooltip"))
        root.addWidget(self.tabs, 1)

        general = QWidget()
        general.setAccessibleName(i18n.t("prefs.tab.general"))
        general_layout = QVBoxLayout(general)
        general_layout.setContentsMargins(12, 12, 12, 12)
        general_layout.setSpacing(10)

        # ---- interface language ----
        self.lang = QComboBox()
        for code, label in UI_LANGUAGES:
            self.lang.addItem(label, code)
        self.lang.setCurrentIndex(
            max(0, [c for c, _ in UI_LANGUAGES].index(get_config().ui_language))
        )
        describe_pick(self.lang, i18n.t("prefs.lang.tooltip"))
        self.lang.setAccessibleName(i18n.t("prefs.lang.accessible"))

        # ---- citation style ----
        self.style = QComboBox()
        for code in CITATION_STYLES:
            self.style.addItem(i18n.citation_style_label(code), code)
        current_style = get_config().citation_style
        if current_style in CITATION_STYLES:
            self.style.setCurrentIndex(CITATION_STYLES.index(current_style))
        describe_pick(self.style, i18n.t("prefs.style.tooltip"))
        self.style.setAccessibleName(i18n.t("prefs.style.accessible"))

        form = QFormLayout()
        form.addRow(i18n.t("prefs.lang.label"), self.lang)
        form.addRow(i18n.t("prefs.style.label"), self.style)
        general_layout.addLayout(form)

        note = QLabel(i18n.t("prefs.restart_note"))
        note.setWordWrap(True)
        note.setAccessibleName("")
        general_layout.addWidget(note)

        # ---- sound cues ----
        self.sounds = QCheckBox(i18n.t("prefs.sounds.label"))
        self.sounds.setChecked(get_config().sound_enabled)
        self.sounds.setAccessibleName(i18n.t("prefs.sounds.accessible"))
        self.sounds.setToolTip(i18n.t("prefs.sounds.tooltip"))
        general_layout.addWidget(self.sounds)
        general_layout.addStretch(1)
        self.tabs.addTab(general, i18n.t("prefs.tab.general"))

        # ---- API keys ----
        keys_page = QWidget()
        keys_page.setAccessibleName(i18n.t("prefs.tab.keys"))
        keys_layout = QVBoxLayout(keys_page)
        keys_layout.setContentsMargins(12, 12, 12, 12)
        keys_layout.setSpacing(10)
        keys_layout.addWidget(QLabel(i18n.t("prefs.api_keys")))
        cfg = get_config()

        self.gb_key = QLineEdit(cfg.google_books_key)
        self.gb_key.setEchoMode(QLineEdit.Password)
        self.gb_key.setAccessibleName(i18n.t("prefs.gb_key.accessible"))
        self.gb_key.setToolTip(i18n.t("prefs.gb_key.tooltip"))

        self.s2_key = QLineEdit(cfg.semantic_scholar_key)
        self.s2_key.setEchoMode(QLineEdit.Password)
        self.s2_key.setAccessibleName(i18n.t("prefs.s2_key.accessible"))
        self.s2_key.setToolTip(i18n.t("prefs.s2_key.tooltip"))

        self.core_key = QLineEdit(cfg.core_key)
        self.core_key.setEchoMode(QLineEdit.Password)
        self.core_key.setAccessibleName(i18n.t("prefs.core_key.accessible"))
        self.core_key.setToolTip(i18n.t("prefs.core_key.tooltip"))

        self.base_key = QLineEdit(cfg.base_key)
        self.base_key.setEchoMode(QLineEdit.Password)
        self.base_key.setAccessibleName(i18n.t("prefs.base_key.accessible"))
        self.base_key.setToolTip(i18n.t("prefs.base_key.tooltip"))

        self.pubmed_key = QLineEdit(cfg.pubmed_key)
        self.pubmed_key.setEchoMode(QLineEdit.Password)
        self.pubmed_key.setAccessibleName(i18n.t("prefs.pubmed_key.accessible"))
        self.pubmed_key.setToolTip(i18n.t("prefs.pubmed_key.tooltip"))

        self.lens_key = QLineEdit(cfg.lens_key)
        self.lens_key.setEchoMode(QLineEdit.Password)
        self.lens_key.setAccessibleName(i18n.t("prefs.lens_key.accessible"))
        self.lens_key.setToolTip(i18n.t("prefs.lens_key.tooltip"))

        self.scilit_key = QLineEdit(cfg.scilit_key)
        self.scilit_key.setEchoMode(QLineEdit.Password)
        self.scilit_key.setAccessibleName(i18n.t("prefs.scilit_key.accessible"))
        self.scilit_key.setToolTip(i18n.t("prefs.scilit_key.tooltip"))

        self.scinapse_key = QLineEdit(cfg.scinapse_key)
        self.scinapse_key.setEchoMode(QLineEdit.Password)
        self.scinapse_key.setAccessibleName(i18n.t("prefs.scinapse_key.accessible"))
        self.scinapse_key.setToolTip(i18n.t("prefs.scinapse_key.tooltip"))

        self.springer_key = QLineEdit(cfg.springer_key)
        self.springer_key.setEchoMode(QLineEdit.Password)
        self.springer_key.setAccessibleName(i18n.t("prefs.springer_key.accessible"))
        self.springer_key.setToolTip(i18n.t("prefs.springer_key.tooltip"))

        self.gemini_key = QLineEdit(cfg.gemini_key)
        self.gemini_key.setEchoMode(QLineEdit.Password)
        self.gemini_key.setAccessibleName(i18n.t("prefs.gemini_key.accessible"))
        self.gemini_key.setToolTip(i18n.t("prefs.gemini_key.tooltip"))
        # The key is long and masked, and pasting it used to fail silently when
        # focus was still on the language combo. A real button works whatever
        # has focus, and its confirmation is spoken.
        self.gemini_paste = QPushButton(i18n.t("prefs.paste"))
        self.gemini_paste.setAccessibleName(i18n.t("prefs.paste.accessible"))
        self.gemini_paste.setToolTip(i18n.t("prefs.paste.tooltip"))
        self.gemini_paste.clicked.connect(self._paste_gemini)
        self.gemini_show = QCheckBox(i18n.t("prefs.show"))
        self.gemini_show.setAccessibleName(i18n.t("prefs.show.accessible"))
        self.gemini_show.setToolTip(i18n.t("prefs.show.tooltip"))
        self.gemini_show.toggled.connect(self._show_gemini)
        # A key copied from a web page can arrive with a trailing newline or a
        # line break in the middle. Gemini rejects that, and the masked field
        # hides the reason, so remove the whitespace as it arrives.
        self.gemini_key.textChanged.connect(self._clean_gemini_text)
        gemini_row = QHBoxLayout()
        gemini_row.setContentsMargins(0, 0, 0, 0)
        gemini_row.addWidget(self.gemini_key, 1)
        gemini_row.addWidget(self.gemini_paste)
        gemini_row.addWidget(self.gemini_show)

        self.oa_email = QLineEdit(cfg.contact_email)
        self.oa_email.setAccessibleName(i18n.t("prefs.oa_email.accessible"))
        self.oa_email.setToolTip(i18n.t("prefs.oa_email.tooltip"))

        keys = QFormLayout()
        # Gemini first: it is the only key the file assistant needs, and it
        # should not sit below ten other fields where a reader has to hunt.
        keys.addRow(i18n.t("prefs.gemini_label"), gemini_row)
        keys.addRow(i18n.t("prefs.gb_label"), self.gb_key)
        keys.addRow(i18n.t("prefs.s2_label"), self.s2_key)
        keys.addRow(i18n.t("prefs.core_label"), self.core_key)
        keys.addRow(i18n.t("prefs.base_label"), self.base_key)
        keys.addRow(i18n.t("prefs.pubmed_label"), self.pubmed_key)
        keys.addRow(i18n.t("prefs.lens_label"), self.lens_key)
        keys.addRow(i18n.t("prefs.scilit_label"), self.scilit_key)
        keys.addRow(i18n.t("prefs.scinapse_label"), self.scinapse_key)
        keys.addRow(i18n.t("prefs.springer_label"), self.springer_key)
        keys.addRow(i18n.t("prefs.oa_label"), self.oa_email)
        keys_layout.addLayout(keys)

        self.key_status = QLabel("")
        self.key_status.setObjectName("StatusLabel")
        self.key_status.setWordWrap(True)
        self.key_status.setAccessibleName("")
        if cfg.gemini_key:
            self.key_status.setText(
                i18n.t("prefs.gemini.present", n=len(cfg.gemini_key))
            )
        keys_layout.addWidget(self.key_status)

        keys_note = QLabel(i18n.t("prefs.keys_note"))
        keys_note.setAccessibleName("")
        keys_note.setWordWrap(True)
        keys_layout.addWidget(keys_note)

        keys_help = QLabel(i18n.t("prefs.api_keys.help"))
        keys_help.setWordWrap(True)
        keys_layout.addWidget(keys_help)
        keys_layout.addStretch(1)
        self.tabs.addTab(keys_page, i18n.t("prefs.tab.keys"))

        # ---- about ----
        # The version, the build date and the contact address used to live in a
        # second window reached by its own header button. Keeping them in the
        # last tab means one dialog for both "change something" and "tell me
        # what this program is", and one less button beside the search box.
        about_page = QWidget()
        about_page.setAccessibleName(i18n.t("prefs.about.title"))
        about_layout = QVBoxLayout(about_page)
        about_layout.setContentsMargins(12, 12, 12, 12)
        about_layout.setSpacing(10)
        self.about_panel = AboutPanel(about_page)
        about_layout.addWidget(self.about_panel)
        self.tabs.addTab(about_page, i18n.t("prefs.about.title"))

        # The contact address and the downloads path are single unbreakable
        # words. At the default font they fit; at a larger system font they
        # are wider than the tab, and the About tab used to answer with a
        # horizontal scrollbar. Let the window widen with them, up to a width
        # that still fits a laptop screen.
        self._fit_about_width()

        buttons = QDialogButtonBox(
            QDialogButtonBox.Save | QDialogButtonBox.Cancel
        )
        # Qt ships the two labels in English, which meant the screen reader read
        # "Save" and "Cancel" to an Arabic user. Label them in the interface
        # language and keep "Enter saves" as the visible shortcut hint.
        self.save_btn = buttons.button(QDialogButtonBox.Save)
        self.cancel_btn = buttons.button(QDialogButtonBox.Cancel)
        self.save_btn.setText(i18n.t("prefs.save"))
        self.cancel_btn.setText(i18n.t("prefs.cancel"))
        self.save_btn.setAccessibleName(i18n.t("prefs.save_btn.accessible"))
        self.save_btn.setToolTip(i18n.t("prefs.save_btn.tooltip"))
        self.cancel_btn.setAccessibleName(i18n.t("prefs.cancel_btn.accessible"))
        self.cancel_btn.setToolTip(i18n.t("prefs.cancel_btn.tooltip"))
        self.save_btn.setDefault(True)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        self.tabs.currentChanged.connect(self._tab_changed)
        self._tab_changed(self.tabs.currentIndex())
        root.addWidget(buttons)

    def _fit_about_width(self) -> None:
        """Widen the window until the About tab needs no horizontal scroll."""
        scroll = self.about_panel.findChild(QScrollArea, "AboutScroll")
        content = scroll.widget() if scroll is not None else None
        if content is None:
            return
        needed = content.minimumSizeHint().width() + 64
        self.setMinimumWidth(max(580, min(needed, 920)))

    def _tab_changed(self, index: int) -> None:
        """The About tab is read-only, so it gets one closing button.

        Leaving Save visible there implies there is something to save on a
        page of labels. Switching the footer to a plain Close keeps the two
        kinds of tab honest, and the action the reader hears matches what the
        button will do.
        """
        on_about = index == self.tabs.count() - 1
        self.save_btn.setVisible(not on_about)
        self.cancel_btn.setText(
            i18n.t("about.close.text") if on_about else i18n.t("prefs.cancel")
        )
        self.cancel_btn.setAccessibleName(
            i18n.t("about.close.accessible") if on_about
            else i18n.t("prefs.cancel_btn.accessible")
        )
        self.cancel_btn.setToolTip(
            i18n.t("about.close.tooltip") if on_about
            else i18n.t("prefs.cancel_btn.tooltip")
        )

    def showEvent(self, event):  # noqa: N802 - Qt naming
        """When the file assistant asked for a key, open with it focused.

        Pasting with Ctrl+V only reaches the focused field. Preferences used
        to open on the language combo, so a paste right after pressing "Add a
        Gemini key" changed nothing at all. Focusing (and selecting) the key
        field makes the action the user came for work immediately.
        """
        super().showEvent(event)
        # The window is about to take its real size; recompute the width with
        # whatever font and stylesheet are in force now (the main window hands
        # its zoomed stylesheet to this dialog before showing it).
        self._fit_about_width()
        if self._focus_key == "gemini":
            self._focus_key = None
            self.tabs.setCurrentIndex(1)
            self.gemini_key.setFocus()
            self.gemini_key.selectAll()
        else:
            # Start on the tab strip so NVDA announces the window and how many
            # sections it has. Dropping straight into the language combo hid
            # the fact that the About page now lives here.
            self.tabs.setFocus()

    def _paste_gemini(self) -> None:
        """Put the clipboard into the Gemini field and say whether it worked."""
        text = "".join((QApplication.clipboard().text() or "").split())
        if not text:
            message = i18n.t("prefs.paste.empty")
            self.key_status.setText(message)
            _announce(self.key_status, message)
            return
        self.gemini_key.setText(text)
        self.gemini_key.setFocus()
        self.gemini_key.setCursorPosition(len(text))
        message = i18n.t("prefs.paste.done", n=len(text))
        self.key_status.setText(message)
        _announce(self.key_status, message)

    def _show_gemini(self, shown: bool) -> None:
        """Reveal the pasted key on request, then put the dots back."""
        self.gemini_key.setEchoMode(
            QLineEdit.Normal if shown else QLineEdit.Password
        )

    def _clean_gemini_text(self, text: str) -> None:
        """Keys never contain whitespace; drop it before it reaches the API."""
        cleaned = "".join(text.split())
        if cleaned != text:
            self.gemini_key.setText(cleaned)
            self.gemini_key.setCursorPosition(len(cleaned))

    def keyPressEvent(self, event):  # noqa: N802 - Qt naming
        """Enter anywhere in the dialog means "save and close".

        Qt gives Return inside a QLineEdit to the line edit itself, so the
        window's default Save button never fired and the user had to Tab to the
        bottom of the dialog to finish. A screen-reader user should not need a
        button hunt, and every other dialog on Windows behaves this way.
        """
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and not event.isAutoRepeat():
            self.accept()
            return
        super().keyPressEvent(event)

    def apply_to_config(self) -> tuple[str, bool]:
        """Write the settings. Returns (old_language, language_changed)."""
        cfg = get_config()
        old = cfg.ui_language
        cfg.ui_language = self.lang.currentData()
        cfg.citation_style = self.style.currentData()
        cfg.google_books_key = self.gb_key.text().strip()
        cfg.semantic_scholar_key = self.s2_key.text().strip()
        cfg.core_key = self.core_key.text().strip()
        cfg.base_key = self.base_key.text().strip()
        cfg.pubmed_key = self.pubmed_key.text().strip()
        cfg.lens_key = self.lens_key.text().strip()
        cfg.scilit_key = self.scilit_key.text().strip()
        cfg.scinapse_key = self.scinapse_key.text().strip()
        cfg.springer_key = self.springer_key.text().strip()
        # A key copied from a web page can carry a line break in the middle;
        # Gemini rejects it and the reader sees only "key not valid".
        cfg.gemini_key = "".join(self.gemini_key.text().split())
        cfg.contact_email = self.oa_email.text().strip()
        cfg.sound_enabled = self.sounds.isChecked()
        cfg.save()
        return old, cfg.ui_language != old