"""Preferences dialog: interface language, citation style, sound cues, and API keys.

A small number of fields on purpose. Every control carries an accessible name
and an accessible description that says what the setting actually does, because
the only way the user reaches them is Tab and a screen reader.

The dialog writes to Config and, for the two settings that change what is on
screen (language, citation style), asks the caller to rebuild the UI.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QVBoxLayout,
)

from app import i18n
from app.config import get_config

#: Interface languages offered. Only Arabic and English are translated, so
#: offering the other 19 search languages here would set an interface nobody
#: can read.
UI_LANGUAGES = (("ar", "العربية"), ("en", "English"))

CITATION_STYLES = (
    "apa",
    "mla",
    "chicago",
    "harvard",
    "ieee",
    "bibtex",
    "ris",
)


def describe_pick(widget: QComboBox, hint: str) -> None:
    """Short name for the screen reader, full hint for the mouse.

    The hint used to be the accessible *description*, which NVDA reads out loud
    on top of the name every single time the combo takes focus. Tooltips are
    seen by the people who can see, and cost a screen-reader user nothing.
    """
    widget.setAccessibleName("")
    widget.setToolTip(hint)


def build_date() -> str:
    """When this build was made, as a plain ``YYYY-MM-DD`` date.

    The shipped exe carries its own timestamp, which is the honest build date.
    A source run has no exe, so the file that defines the app's identity (its
    config module, where the version lives) stands in. Unreadable file: an
    em dash, never a traceback.
    """
    try:
        if getattr(sys, "frozen", False):
            stamp = Path(sys.executable).stat().st_mtime
        else:
            stamp = (Path(__file__).resolve().parent.parent
                     / "app" / "config.py").stat().st_mtime
        return time.strftime("%Y-%m-%d", time.localtime(stamp))
    except OSError:
        return "—"


class PreferencesDialog(QDialog):
    """Settings the user asked for: language, citation style, API keys."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(i18n.t("app.menuprefs"))
        self.setAccessibleName(i18n.t("app.menuprefs"))

        root = QVBoxLayout(self)

        # ---- interface language ----
        self.lang = QComboBox()
        for code, label in UI_LANGUAGES:
            self.lang.addItem(label, code)
        self.lang.setCurrentIndex(
            max(0, [c for c, _ in UI_LANGUAGES].index(get_config().ui_language))
        )
        describe_pick(self.lang, i18n.t("prefs.lang.tooltip"))
        self.lang.setAccessibleName(i18n.t("prefs.lang.accessible"))

        # ---- citation style ----
        self.style = QComboBox()
        for code in CITATION_STYLES:
            self.style.addItem(i18n.citation_style_label(code), code)
        current_style = get_config().citation_style
        if current_style in CITATION_STYLES:
            self.style.setCurrentIndex(CITATION_STYLES.index(current_style))
        describe_pick(self.style, i18n.t("prefs.style.tooltip"))
        self.style.setAccessibleName(i18n.t("prefs.style.accessible"))

        form = QFormLayout()
        form.addRow(i18n.t("prefs.lang.label"), self.lang)
        form.addRow(i18n.t("prefs.style.label"), self.style)
        root.addLayout(form)

        note = QLabel(i18n.t("prefs.restart_note"))
        note.setWordWrap(True)
        note.setAccessibleName("")
        root.addWidget(note)

        # ---- sound cues ----
        self.sounds = QCheckBox(i18n.t("prefs.sounds.label"))
        self.sounds.setChecked(get_config().sound_enabled)
        self.sounds.setAccessibleName(i18n.t("prefs.sounds.accessible"))
        self.sounds.setToolTip(i18n.t("prefs.sounds.tooltip"))
        root.addWidget(self.sounds)

        # ---- API keys ----
        root.addWidget(QLabel(i18n.t("prefs.api_keys")))
        cfg = get_config()

        self.gb_key = QLineEdit(cfg.google_books_key)
        self.gb_key.setEchoMode(QLineEdit.Password)
        self.gb_key.setAccessibleName(i18n.t("prefs.gb_key.accessible"))
        self.gb_key.setToolTip(i18n.t("prefs.gb_key.tooltip"))

        self.s2_key = QLineEdit(cfg.semantic_scholar_key)
        self.s2_key.setEchoMode(QLineEdit.Password)
        self.s2_key.setAccessibleName(i18n.t("prefs.s2_key.accessible"))
        self.s2_key.setToolTip(i18n.t("prefs.s2_key.tooltip"))

        self.core_key = QLineEdit(cfg.core_key)
        self.core_key.setEchoMode(QLineEdit.Password)
        self.core_key.setAccessibleName(i18n.t("prefs.core_key.accessible"))
        self.core_key.setToolTip(i18n.t("prefs.core_key.tooltip"))

        self.base_key = QLineEdit(cfg.base_key)
        self.base_key.setEchoMode(QLineEdit.Password)
        self.base_key.setAccessibleName(i18n.t("prefs.base_key.accessible"))
        self.base_key.setToolTip(i18n.t("prefs.base_key.tooltip"))

        self.pubmed_key = QLineEdit(cfg.pubmed_key)
        self.pubmed_key.setEchoMode(QLineEdit.Password)
        self.pubmed_key.setAccessibleName(i18n.t("prefs.pubmed_key.accessible"))
        self.pubmed_key.setToolTip(i18n.t("prefs.pubmed_key.tooltip"))

        self.lens_key = QLineEdit(cfg.lens_key)
        self.lens_key.setEchoMode(QLineEdit.Password)
        self.lens_key.setAccessibleName(i18n.t("prefs.lens_key.accessible"))
        self.lens_key.setToolTip(i18n.t("prefs.lens_key.tooltip"))

        self.scilit_key = QLineEdit(cfg.scilit_key)
        self.scilit_key.setEchoMode(QLineEdit.Password)
        self.scilit_key.setAccessibleName(i18n.t("prefs.scilit_key.accessible"))
        self.scilit_key.setToolTip(i18n.t("prefs.scilit_key.tooltip"))

        self.scinapse_key = QLineEdit(cfg.scinapse_key)
        self.scinapse_key.setEchoMode(QLineEdit.Password)
        self.scinapse_key.setAccessibleName(i18n.t("prefs.scinapse_key.accessible"))
        self.scinapse_key.setToolTip(i18n.t("prefs.scinapse_key.tooltip"))

        self.springer_key = QLineEdit(cfg.springer_key)
        self.springer_key.setEchoMode(QLineEdit.Password)
        self.springer_key.setAccessibleName(i18n.t("prefs.springer_key.accessible"))
        self.springer_key.setToolTip(i18n.t("prefs.springer_key.tooltip"))

        self.oa_email = QLineEdit(cfg.contact_email)
        self.oa_email.setAccessibleName(i18n.t("prefs.oa_email.accessible"))
        self.oa_email.setToolTip(i18n.t("prefs.oa_email.tooltip"))

        keys = QFormLayout()
        keys.addRow(i18n.t("prefs.gb_label"), self.gb_key)
        keys.addRow(i18n.t("prefs.s2_label"), self.s2_key)
        keys.addRow(i18n.t("prefs.core_label"), self.core_key)
        keys.addRow(i18n.t("prefs.base_label"), self.base_key)
        keys.addRow(i18n.t("prefs.pubmed_label"), self.pubmed_key)
        keys.addRow(i18n.t("prefs.lens_label"), self.lens_key)
        keys.addRow(i18n.t("prefs.scilit_label"), self.scilit_key)
        keys.addRow(i18n.t("prefs.scinapse_label"), self.scinapse_key)
        keys.addRow(i18n.t("prefs.springer_label"), self.springer_key)
        keys.addRow(i18n.t("prefs.oa_label"), self.oa_email)
        root.addLayout(keys)

        keys_note = QLabel(i18n.t("prefs.keys_note"))
        keys_note.setAccessibleName("")
        root.addWidget(keys_note)

        root.addWidget(QLabel(i18n.t("prefs.api_keys.help")))

        buttons = QDialogButtonBox(
            QDialogButtonBox.Save | QDialogButtonBox.Cancel
        )
        # Qt ships the two labels in English, which meant the screen reader read
        # "Save" and "Cancel" to an Arabic user. Label them in the interface
        # language and keep "Enter saves" as the visible shortcut hint.
        save = buttons.button(QDialogButtonBox.Save)
        cancel = buttons.button(QDialogButtonBox.Cancel)
        save.setText(i18n.t("prefs.save"))
        cancel.setText(i18n.t("prefs.cancel"))
        save.setAccessibleName(i18n.t("prefs.save_btn.accessible"))
        save.setToolTip(i18n.t("prefs.save_btn.tooltip"))
        cancel.setAccessibleName(i18n.t("prefs.cancel_btn.accessible"))
        cancel.setToolTip(i18n.t("prefs.cancel_btn.tooltip"))
        save.setDefault(True)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    def keyPressEvent(self, event):  # noqa: N802 - Qt naming
        """Enter anywhere in the dialog means "save and close".

        Qt gives Return inside a QLineEdit to the line edit itself, so the
        window's default Save button never fired and the user had to Tab to the
        bottom of the dialog to finish. A screen-reader user should not need a
        button hunt, and every other dialog on Windows behaves this way.
        """
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and not event.isAutoRepeat():
            self.accept()
            return
        super().keyPressEvent(event)

    def apply_to_config(self) -> tuple[str, bool]:
        """Write the settings. Returns (old_language, language_changed)."""
        cfg = get_config()
        old = cfg.ui_language
        cfg.ui_language = self.lang.currentData()
        cfg.citation_style = self.style.currentData()
        cfg.google_books_key = self.gb_key.text().strip()
        cfg.semantic_scholar_key = self.s2_key.text().strip()
        cfg.core_key = self.core_key.text().strip()
        cfg.base_key = self.base_key.text().strip()
        cfg.pubmed_key = self.pubmed_key.text().strip()
        cfg.lens_key = self.lens_key.text().strip()
        cfg.scilit_key = self.scilit_key.text().strip()
        cfg.scinapse_key = self.scinapse_key.text().strip()
        cfg.springer_key = self.springer_key.text().strip()
        cfg.contact_email = self.oa_email.text().strip()
        cfg.sound_enabled = self.sounds.isChecked()
        cfg.save()
        return old, cfg.ui_language != old