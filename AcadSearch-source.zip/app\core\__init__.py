"""Core services: HTTP, search orchestration, downloads, citation formatting.

Submodules are imported explicitly (e.g. ``from app.core.http_client import
get_http``) rather than re-exported here, because ``app.providers`` depends on
``app.core.http_client`` and re-exports would create an import cycle.
"""

__all__ = [
    "citation",
    "downloader",
    "http_client",
    "search_engine",
    "text_utils",
]
