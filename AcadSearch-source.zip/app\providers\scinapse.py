"""Scinapse — scholarly search API (https://api.scinapse.io).

A free API key from the Scinapse dashboard travels in the ``X-API-KEY`` header,
which the shared HTTP client maps off the ``x-api-key`` parameter. Field names
are read defensively, because the envelope has drifted between API versions.
"""

from __future__ import annotations

import threading

from app.core.text_utils import as_int, clean_text, extract_doi, truncate_words
from app.models import Access, Category, DownloadFormat, Result, SearchQuery
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://api.scinapse.io/papers"

ARTICLE_TYPES = ("journal", "conference", "article", "review")
BOOK_TYPES = ("book", "monograph")
RESEARCH_TYPES = ("thesis", "dissertation", "report", "preprint")


@register
class ScinapseProvider(BaseProvider):
    provider_id = "scinapse"
    display_name = "Scinapse"
    categories = (Category.ARTICLE, Category.RESEARCH, Category.BOOK)
    weight = 45
    requires_key = "scinapse_key"
    homepage = "https://www.scinapse.io"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        if not self.config.scinapse_key:
            return []
        params: dict[str, object] = {
            "query": query.text,
            "limit": min(query.per_source, 50),
            "offset": 0,
            "x-api-key": self.config.scinapse_key,
        }
        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        return [self._to_result(r) for r in (payload.get("data") or [])]

    def _to_result(self, record: dict) -> Result:
        title = clean_text(
            record.get("title") or record.get("name") or record.get("paperTitle")
        )
        authors: list[str] = []
        for author in (record.get("authors") or []):
            name = clean_text(
                author.get("name")
                or author.get("displayName")
                or author.get("authorName")
            )
            if name and name not in authors:
                authors.append(name)
        authors = authors[:12]

        year = first_int(record, "yearPublished", "publishedYear", "year")
        doi = extract_doi(record.get("doi"))
        journal = record.get("journal") or {}
        venue = clean_text(journal.get("name")) or clean_text(record.get("venue"))

        kind = clean_text(
            record.get("publicationType") or record.get("type")
        ).lower()
        if any(k in kind for k in BOOK_TYPES):
            category = Category.BOOK
        elif any(k in kind for k in RESEARCH_TYPES):
            category = Category.RESEARCH
        else:
            category = Category.ARTICLE

        pdf = clean_text(record.get("pdfUrl") or record.get("openAccessPdfUrl"))
        landing = clean_text(record.get("url") or record.get("link"))

        identifiers: dict[str, str] = {}
        if doi:
            identifiers["doi"] = doi
        pid = record.get("id") or record.get("paperId")
        if pid is not None:
            identifiers["scinapse"] = str(pid)

        downloads: list = []
        if pdf:
            downloads.append(target(pdf, DownloadFormat.PDF, label="PDF",
                                    open_access=True))

        return Result(
            category=category,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=year,
            abstract=truncate_words(clean_text(record.get("abstract")), 320),
            venue=venue,
            language=clean_text(record.get("language") or record.get("lang")),
            identifiers=identifiers,
            access=Access.DOWNLOAD if downloads else (
                Access.LANDING if landing else Access.METADATA
            ),
            downloads=downloads,
            landing_url=landing,
            item_type=kind.title() or "Paper",
            raw=record,
        )


def first_int(record: dict, *names: str) -> int | None:
    for name in names:
        value = record.get(name)
        if value is not None:
            return as_int(value)
    return None