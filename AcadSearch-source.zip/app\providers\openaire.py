"""OpenAIRE — the European open scholarly graph: theses, reports, datasets.

Docs: https://graph.openaire.eu/docs/apis/search-api/
Aggregates Zenodo, DBLP, arXiv, university repositories and institutional
archives, which makes it the best free source for *theses and dissertations* —
the one category most academic APIs cover poorly.

No API key required.
"""

from __future__ import annotations

import re
import threading

from app.core.text_utils import (
    clean_text,
    extract_doi,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://api.openaire.eu/search/publications"

#: Type values that indicate a non-journal research output.
RESEARCH_HINTS = frozenset(
    {
        "thesis",
        "theses",
        "dissertation",
        "doctoral",
        "phd",
        "bachelor",
        "master",
        "diploma",
        "preprint",
        "postedcontent",
        "dataset",
        "other",
        "technicalreport",
        "report",
        "monograph",
        "book",
        "bookchapter",
        "bookpublication",
        "workingpaper",
        "conferencepaper",
    }
)

#: Phrases that mark a title as a thesis even when the type fields are vague.
_TITLE_HINTS = (
    "thesis",
    "dissertation",
    "doctoral",
    "ph.d",
    "master's thesis",
    "bachelor's thesis",
    "preprint",
)


def _is_research(result_type: str, instance_types: set[str], title: str) -> bool:
    tokens = set()
    for value in (result_type, *instance_types):
        for token in re.split(r"[^a-z0-9]+", value.lower()):
            if token:
                tokens.add(token)
    if tokens & RESEARCH_HINTS:
        return True
    lowered = title.lower()
    return any(hint in lowered for hint in _TITLE_HINTS)


@register
class OpenAIREProvider(BaseProvider):
    provider_id = "openaire"
    display_name = "OpenAIRE"
    categories = (Category.ARTICLE, Category.RESEARCH)
    weight = 30
    homepage = "https://explore.openaire.eu"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        # No ``language`` parameter: the endpoint answers HTTP 400 for every
        # value tried (ISO-639-1 "fr", ISO-639-2 "fra", and the English name
        # alike). Language is instead taken from each record's own metadata,
        # and ``fetch`` filters on it locally, like Open Library does.
        params: dict[str, object] = {
            "title": query.text,
            "format": "json",
            "size": min(query.per_source, 25),
            "sortBy": "resultdateofacceptance,descending",
        }

        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        results = _dig(payload, "response", "results", "result")
        if isinstance(results, dict):
            results = [results]
        out: list[Result] = []
        for entry in results or []:
            try:
                item = self._to_result(entry)
            except (KeyError, TypeError, IndexError):
                continue  # the OpenAIRE schema is famously irregular
            if item is not None:
                out.append(item)
        return _keep_language(out, query.language)

    # -- mapping ----------------------------------------------------------
    def _to_result(self, entry: dict) -> Result | None:
        result = _dig(entry, "metadata", "oaf:entity", "oaf:result")
        if not isinstance(result, dict):
            return None

        children = _children(result)

        title = clean_text(_scalar(_dig(result, "title")))
        if not title:
            title = clean_text(_scalar(_dig(result, "rels", "title")))
        if not title:
            for child in children:
                title = clean_text(_scalar(_dig(child, "title")))
                if title:
                    break
        if not title:
            return None

        description = truncate_words(clean_text(_scalar(_dig(result, "description"))), 600)

        result_type = clean_text(_scalar(_dig(result, "resulttype", "@classid"))).lower()

        authors = _creators(result) or [a for child in children for a in _creators(child)]

        # Instances carry the actual repository URLs; they live either directly
        # on the result or nested under ``children``.
        instances = _instances(result) + [i for child in children for i in _instances(child)]
        instance_types = {
            clean_text(_scalar(_dig(inst, "instancetype", "@classname"))).lower()
            for inst in instances
        }

        # A thesis/dissertation/report belongs in the research section. Matching is
        # token-based so a title containing "master" does not trigger a false
        # positive on an unrelated journal article.
        is_research = _is_research(result_type, instance_types, title)

        year = _acceptance_year(result, children)
        identifiers = _identifiers(result, children)
        subjects = _subjects(result, children)

        venue = _venue(result, children)
        downloads, landing = _links(instances, identifiers)
        if not landing and identifiers.get("doi"):
            landing = f"https://doi.org/{identifiers['doi']}"

        # OpenAIRE's own graph is an open-access aggregator, so any instance
        # URL it exposes is a legitimate landing page.
        item_type = (
            sorted(instance_types)[0] if instance_types else result_type
        ).title()
        return Result(
            category=Category.RESEARCH if is_research else Category.ARTICLE,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=year,
            abstract=description,
            venue=venue,
            publisher=_publisher(result, children),
            language=normalise_language(_language(result, children)),
            subjects=subjects,
            identifiers=identifiers,
            access=(
                Access.DOWNLOAD
                if any(d.fmt is DownloadFormat.PDF for d in downloads)
                else (Access.LANDING if landing else Access.METADATA)
            ),
            downloads=downloads,
            landing_url=landing,
            item_type=item_type,
            raw=result,
        )


# ---------------------------------------------------------------------------
# OpenAIRE JSON helpers
#
# The schema is irregular by design: every scalar is wrapped in ``{"$": ...}``,
# every repeatable element may be a dict *or* a list, repository URLs are nested
# under ``children``, and unknown dates are encoded as the year 9999.
# ---------------------------------------------------------------------------
#: OpenAIRE writes 9999-… / 0000-… when it does not know the date.
_DATE_SENTINELS = {"9999", "0000"}


def _dig(node: object, *path: str) -> object:
    """Walk a nested dict, returning ``None`` as soon as the path breaks."""
    current = node
    for key in path:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def _children(result: dict) -> list[dict]:
    node = result.get("children")
    if not isinstance(node, dict):
        return _as_dicts(node)
    out: list[dict] = []
    for key in ("result", "instance"):
        out.extend(_as_dicts(node.get(key)))
    return out


def _instances(node: dict) -> list[dict]:
    return _as_dicts(node.get("instance"))


def _as_dicts(node: object) -> list[dict]:
    if node is None:
        return []
    if isinstance(node, dict):
        return [node]
    if isinstance(node, list):
        return [item for item in node if isinstance(item, dict)]
    return []


def _creators(node: dict) -> list[str]:
    names = []
    for creator in _as_list(node.get("creator")):
        name = clean_text(_scalar(creator))
        if name:
            names.append(name)
    return names


def _subjects(result: dict, children: list[dict]) -> list[str]:
    out: list[str] = []
    for node in [result, *children]:
        for subject in _as_list(node.get("subject")):
            text = clean_text(_scalar(subject))
            if text and text not in out:
                out.append(text)
    return out[:6]


def _venue(result: dict, children: list[dict]) -> str:
    journal = clean_text(_scalar(result.get("journal")))
    if journal:
        return journal
    for node in [result, *children]:
        for key in ("publisher", "journal"):
            value = clean_text(_scalar(node.get(key)))
            if value:
                return value
    return ""


def _publisher(result: dict, children: list[dict]) -> str:
    for node in children + [result]:
        value = clean_text(_scalar(node.get("publisher")))
        if value:
            return value
    return ""


def _language(result: dict, children: list[dict]) -> str:
    for node in [result, *children]:
        value = clean_text(_scalar(_dig(node, "language", "@classid")))
        if value:
            return value
    return ""


def _keep_language(
    results: list[Result], wanted: str
) -> list[Result]:
    """Apply the language filter locally, since the API rejects the parameter.

    A record with no language at all is kept: dropping it would hide perfectly
    good records over a missing field, and the user already asked for the term
    itself in ``q``.
    """
    if not wanted or wanted == "any":
        return results
    kept = [r for r in results if not r.language or r.language == wanted]
    return kept or results


def _acceptance_year(result: dict, children: list[dict]) -> int | None:
    for node in [result, *children]:
        for field in ("dateofacceptance", "relevantdate", "dateofacceptance"):
            raw = clean_text(_scalar(_dig(node, field)))
            match = raw[:4]
            if match.isdigit() and match not in _DATE_SENTINELS:
                year = int(match)
                if 1000 <= year <= 2100:
                    return year
    return None


def _identifiers(result: dict, children: list[dict]) -> dict[str, str]:
    out: dict[str, str] = {}
    for node in [result, *children]:
        for pid in _as_list(node.get("pid")):
            if not isinstance(pid, dict):
                text = clean_text(_scalar(pid))
                doi = extract_doi(text)
                if doi:
                    out.setdefault("doi", doi)
                continue
            classid = clean_text(pid.get("@classid")).lower()
            value = clean_text(pid.get("$"))
            if classid == "doi":
                doi = extract_doi(value)
                if doi:
                    out["doi"] = doi
            elif "arxiv" in classid and value:
                out["arxiv"] = value.split("v")[0]
            elif "handle" in classid and value:
                out.setdefault("handle", value)
    return out


def _links(instances: list[dict], identifiers: dict[str, str]):
    """Build download targets plus a landing page from the instance URLs."""
    downloads: list = []
    landing = ""
    seen: set[str] = set()

    for instance in instances:
        webresource = _dig(instance, "webresource")
        if not isinstance(webresource, dict):
            continue
        url = clean_text(_scalar(_dig(webresource, "url")))
        if url and not landing:
            landing = url
        for download in _as_list(_dig(webresource, "downloads")):
            link = clean_text(_scalar(_dig(download, "url")))
            if not link or link in seen:
                continue
            seen.add(link)
            downloads.append(
                target(
                    link,
                    _guess_format(link),
                    label=clean_text(_scalar(_dig(download, "@classname")))
                    or "OpenAIRE",
                    open_access=True,
                )
            )
        if len(downloads) >= 3:
            break

    # arXiv records in OpenAIRE often carry no instance URL; build the PDF.
    arxiv_id = identifiers.get("arxiv")
    if arxiv_id:
        pdf_url = f"https://arxiv.org/pdf/{arxiv_id}"
        if pdf_url not in seen:
            seen.add(pdf_url)
            downloads.insert(
                0, target(pdf_url, DownloadFormat.PDF, label="arXiv PDF", open_access=True)
            )
            landing = landing or f"https://arxiv.org/abs/{arxiv_id}"

    return downloads, landing


def _scalar(node: object) -> str:
    if node is None:
        return ""
    if isinstance(node, dict):
        value = node.get("$")
        if value is None:
            value = node.get("@value")
        if value is None:
            return ""
        return clean_text(value)
    if isinstance(node, list):
        return _scalar(node[0]) if node else ""
    return clean_text(node)


def _as_list(node: object) -> list:
    if node is None:
        return []
    if isinstance(node, list):
        return node
    return [node]


def _guess_format(url: str) -> DownloadFormat:
    lowered = url.lower().split("?")[0]
    for ext, fmt in (
        (".pdf", DownloadFormat.PDF),
        (".epub", DownloadFormat.EPUB),
        (".zip", DownloadFormat.ZIP),
        (".gz", DownloadFormat.ZIP),
    ):
        if lowered.endswith(ext):
            return fmt
    return DownloadFormat.HTML
