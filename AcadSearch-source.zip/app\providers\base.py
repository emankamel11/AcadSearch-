"""Provider base class and registry.

A provider is a small adapter that turns a :class:`~app.models.SearchQuery` into
normalised :class:`~app.models.Result` objects. Adding a new data source means
subclassing :class:`BaseProvider` and decorating it with :func:`register` — the
UI, engine and preferences screen pick it up automatically.
"""

from __future__ import annotations

import logging
import threading

from app.core.http_client import HttpClient, ProviderError, get_http
from app.models import (
    Access,
    Category,
    DownloadFormat,
    DownloadTarget,
    Result,
    SearchQuery,
)

log = logging.getLogger(__name__)


class BaseProvider:
    """Template for every data source."""

    #: Stable identifier used in config, status chips and citation merging.
    provider_id: str = ""
    #: Human readable name; the UI localises the well-known ones via i18n.
    display_name: str = ""
    #: Which result sections this provider feeds.
    categories: tuple[Category, ...] = ()
    #: Rough ordering hint inside a section (lower = ranked first).
    weight: int = 50
    #: Whether an API key is needed to be useful.
    requires_key: str = ""  # "" | "google_books_key" | "semantic_scholar_key"
    #: Optional short note rendered in Preferences.
    homepage: str = ""

    def __init__(self, http: HttpClient | None = None, config=None):
        from app.config import get_config

        self.http = http or get_http()
        self.config = config or get_config()

    # -- API to implement -------------------------------------------------
    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:  # pragma: no cover - abstract
        raise NotImplementedError

    # -- helpers ----------------------------------------------------------
    def available(self) -> bool:
        """Cheap check for whether this provider can run right now."""
        if not self.config.is_enabled(self.provider_id):
            return False
        if self.requires_key and not getattr(self.config, self.requires_key, ""):
            # Not fatal: these APIs still answer without a key, just throttled.
            return True
        return True

    def run(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        """Run the provider, applying shared year filtering and normalisation."""
        if not self.config.is_enabled(self.provider_id):
            raise ProviderError(f"{self.provider_id}: معطّل / disabled", kind="error")

        if not query.text:
            return []

        results = self.fetch(query, cancel) or []

        if cancel is not None and cancel.is_set():
            return []

        out: list[Result] = []
        for item in results:
            if not item.title or not query.matches_year(item.year):
                continue
            item.score = self.weight
            if not item.identifiers.get("source"):
                item.identifiers["source"] = self.provider_id
            out.append(item)

        self._postprocess(out, query)
        return out

    def _postprocess(self, results: list[Result], query: SearchQuery) -> None:
        """Hook for language filtering and access-class assignment."""
        from app.core.text_utils import detect_script_languages, normalise_language

        for item in results:
            item.language = normalise_language(item.language)
            if not item.language:
                item.language = detect_script_languages(item.title, item.abstract)
            if not item.access or item.access is Access.METADATA:
                item.access = infer_access(item)
            item.abstract = item.abstract.strip()
            item.title = item.title.strip()

        if query.language and query.language != "any":
            wanted = query.language
            matching = [r for r in results if r.language == wanted]
            # Never show an empty tab just because the API omitted the field.
            if matching:
                results[:] = matching


def infer_access(item: Result) -> Access:
    """Decide what the "Download" button should do."""
    for target in item.downloads:
        if target.fmt in (DownloadFormat.PDF, DownloadFormat.EPUB, DownloadFormat.ZIP):
            return Access.DOWNLOAD
        if target.open_access:
            return Access.LANDING
    for target in item.downloads:
        if target.fmt is DownloadFormat.HTML:
            return Access.LANDING
    return Access.METADATA


def target(
    url: str,
    fmt: DownloadFormat = DownloadFormat.SOURCE,
    *,
    label: str = "",
    open_access: bool = False,
) -> DownloadTarget:
    """Build a download target, ignoring empty URLs."""
    if not url:
        raise ValueError("download target requires a url")
    return DownloadTarget(
        url=url, fmt=fmt, label=label, open_access=open_access
    )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------
_REGISTRY: dict[str, BaseProvider] = {}
_ORDER: list[str] = []


def register(cls: type[BaseProvider]) -> type[BaseProvider]:
    """Class decorator that adds a provider to the global registry."""
    if not cls.provider_id:
        raise ValueError(f"{cls.__name__} must define provider_id")
    if cls.provider_id in _REGISTRY:
        raise ValueError(f"duplicate provider id: {cls.provider_id}")
    _REGISTRY[cls.provider_id] = cls()  # type: ignore[assignment]
    _ORDER.append(cls.provider_id)
    return cls


def all_providers() -> list[BaseProvider]:
    """Every registered provider, in registration order."""
    _ensure_loaded()
    return [_REGISTRY[pid] for pid in _ORDER]


def get_provider(provider_id: str) -> BaseProvider | None:
    _ensure_loaded()
    return _REGISTRY.get(provider_id)


def providers_for_category(category: Category) -> list[BaseProvider]:
    _ensure_loaded()
    items = [p for p in (_REGISTRY[pid] for pid in _ORDER) if category in p.categories]
    return sorted(items, key=lambda p: p.weight)


_loaded = False


def _ensure_loaded() -> None:
    """Import the bundled provider modules exactly once."""
    global _loaded
    if _loaded:
        return
    _loaded = True
    from app.providers import (  # noqa: F401  (import for side effects)
        arxiv,
        asjp,
        base_search,
        core,
        crossref,
        datacite,
        doaj,
        dumas,
        erudit,
        europe_pmc,
        google_books,
        hal,
        hindawi,
        internet_archive,
        lens,
        mirabel,
        noorbook,
        open_library,
        openaire,
        openalex,
        openedition,
        persee,
        pubmed,
        scilit,
        scinapse,
        semantic_scholar,
        springer,
        sudoc,
        thesesfr,
        wikisource,
        zenodo,
    )
