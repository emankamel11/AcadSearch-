"""Does Tab actually move focus inside Qt, and does Qt report it accessibly?

If focus moves and Qt emits focus events, then a screen reader has everything it
needs and the problem is on the NVDA side. If focus never moves, the widget
tree is visible but not keyboard-reachable.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PySide6.QtCore import QTimer
from PySide6.QtGui import QAccessible
from PySide6.QtWidgets import QApplication

import prototype


def log(msg: str) -> None:
    print(msg, flush=True)


def on_focus_changed(w) -> None:
    if w is None:
        return
    iface = QAccessible.queryAccessibleInterface(w)
    name = ""
    role = ""
    if iface is not None:
        try:
            name = iface.text(QAccessible.Text.Name) or ""
            role = iface.role()
        except Exception as exc:  # pragma: no cover - diagnostic only
            log(f"   (iface error {exc})")
    log(f"FOCUS -> name='{name}'  role={role}  class={type(w).__name__}")


def dump_focused(win) -> None:
    app = QApplication.instance()
    w = app.focusWidget()
    log(f"  focusWidget = {type(w).__name__ if w else None}")
    if w is not None:
        iface = QAccessible.queryAccessibleInterface(w)
        log(f"  accessible name = '{w.accessibleName()}'")
        log(f"  accessible role = {iface.role() if iface else None}")
        log(f"  hasFocus        = {w.hasFocus()}")
        log(f"  isActiveWindow  = {w.window().isActiveWindow()}")
    for named in (win.query, win.search_btn, win.tabs):
        log(f"  {type(named).__name__:14} focusPolicy={named.focusPolicy()} "
            f"tabFocus={named.focusPolicy() != type(named).__mro__[0] and named.focusPolicy()}")


def main() -> int:
    app = QApplication(sys.argv)
    win = prototype.MainWindow()
    win.show()

    def activate():
        win.raise_()
        win.activateWindow()
        win.query.setFocus()

    QTimer.singleShot(800, activate)
    QTimer.singleShot(1500, lambda: log("--- focus now ---"))
    QTimer.singleShot(1600, lambda: dump_focused(win))

    def step():
        app.sendPostedEvents()
        QTimer.singleShot(400, step)

    step()
    QTimer.singleShot(30000, app.quit)
    app.focusChanged.connect(on_focus_changed)
    log("started; press Tab a few times")
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())