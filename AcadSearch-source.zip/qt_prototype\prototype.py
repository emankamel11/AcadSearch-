"""Day 1 prototype: the same AcadSearch flow rebuilt on PySide6.

Purpose is to answer one question with evidence instead of promises: do Qt
widgets become real UIA elements, so NVDA reads the search box, the category
tabs, every result and every download button?

Everything user-facing gets an explicit accessibleName and accessibleDescription,
because Qt does not always derive a useful name from the label alone.

The real backend (app.core.search_engine.SearchEngine) is reused unchanged.
"""

from __future__ import annotations

import queue
import sys
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QAccessible
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QProgressBar,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.search_engine import SearchEngine, SearchEventType
from app.models import Access, Category, Result, SearchQuery

CATEGORIES = [
    (Category.BOOK, "الكتب"),
    (Category.ARTICLE, "المقالات العلمية"),
    (Category.RESEARCH, "الأبحاث والأطروحات"),
]


def accessible(widget, name: str, description: str = "") -> None:
    """Name a widget for screen readers.

    Qt already reports the right control role for standard widgets, so only the
    name and description are set here.
    """
    widget.setAccessibleName(name)
    if description:
        widget.setAccessibleDescription(description)


def year_of(result: Result) -> str:
    return str(result.year) if result.year else "سنة غير محددة"


def speakable(result: Result) -> str:
    """One spoken sentence per result: title, authors, year, availability."""
    parts = [result.title or "بدون عنوان"]
    if result.authors:
        parts.append("، " + "، ".join(result.authors[:3]))
    parts.append(year_of(result))
    if result.venue:
        parts.append(result.venue)
    if result.access == Access.DOWNLOAD and result.downloads:
        kind = "متاح للتنزيل"
    elif result.access == Access.LANDING:
        kind = "متاح للقراءة على الموقع"
    elif result.access == Access.BORROW:
        kind = "متاح للإعارة"
    else:
        kind = "بيانات فقط"
    parts.append(kind)
    return ". ".join(parts)


class SearchThread(QThread):
    finished_ok = Signal()
    failed = Signal(str)

    def __init__(self, engine: SearchEngine, query: SearchQuery, sink, parent=None):
        super().__init__(parent)
        self._engine = engine
        self._query = query
        self._sink = sink

    def run(self) -> None:
        handle = self._engine.start(self._query)
        response = None
        message = ""
        while not handle.done():
            self.msleep(60)
            try:
                while True:
                    event = handle.events.get_nowait()
                    if event.response is not None and event.response.results:
                        response = event.response
                    if event.type in (
                        SearchEventType.FINISHED,
                        SearchEventType.FAILED,
                        SearchEventType.CANCELLED,
                    ):
                        if event.response is not None:
                            response = event.response
                        message = event.message
            except queue.Empty:
                pass
        self._sink(response, message)
        self.finished_ok.emit()


class ResultCard(QFrame):
    def __init__(self, result: Result, parent=None):
        super().__init__(parent)
        self.result = result
        self.setFrameShape(QFrame.StyledPanel)
        grid = QGridLayout(self)
        grid.setContentsMargins(10, 8, 10, 8)

        title = QLabel(result.title or "بدون عنوان")
        title.setWordWrap(True)
        title.setStyleSheet("font-weight: 600;")
        title.setTextInteractionFlags(Qt.TextSelectableByMouse)
        accessible(title, result.title or "بدون عنوان", "عنوان النتيجة")
        grid.addWidget(title, 0, 0, 1, 2)

        meta_bits = []
        if result.authors:
            meta_bits.append("، ".join(result.authors[:4]))
        meta_bits.append(year_of(result))
        if result.venue:
            meta_bits.append(result.venue)
        meta = QLabel(" • ".join(meta_bits))
        meta.setWordWrap(True)
        meta.setStyleSheet("color: #6b7280;")
        accessible(meta, " • ".join(meta_bits), "المؤلفون والسنة")
        grid.addWidget(meta, 1, 0, 1, 2)

        source = QLabel(result.source)
        source.setStyleSheet("color: #9ca3af; font-size: 11px;")
        accessible(source, f"المصدر: {result.source}")
        grid.addWidget(source, 2, 0)

        if result.downloads:
            target = result.downloads[0]
            label = target.label or "تنزيل"
            btn = QPushButton(f"تنزيل {target.fmt.value.upper()}")
            btn.clicked.connect(self._download)
            accessible(
                btn,
                f"زر تنزيل {label}",
                f"ينزّل {result.title} بصيغة {target.fmt.value}",
            )
            grid.addWidget(btn, 2, 1, alignment=Qt.AlignRight)
        else:
            note = QLabel("لا يوجد ملف")
            note.setStyleSheet("color: #9ca3af;")
            accessible(note, "لا يوجد ملف可直接 تنزيله")
            grid.addWidget(note, 2, 1, alignment=Qt.AlignRight)

    def _download(self) -> None:
        self.setAccessibleDescription(
            f"بدأ تنزيل {self.result.title} بصيغة "
            f"{self.result.downloads[0].fmt.value}"
        )


class Tab(QWidget):
    def __init__(self, category: Category, title: str, parent=None):
        super().__init__(parent)
        self.category = category
        self._rows: dict[str, ResultCard] = {}
        lay = QVBoxLayout(self)
        self.count = QLabel("لا توجد نتائج بعد")
        accessible(self.count, "لا توجد نتائج بعد", "عدد النتائج في هذا التصنيف")
        lay.addWidget(self.count)

        scroll = QListWidget()
        scroll.setObjectName(f"results_{category.value}")
        accessible(
            scroll,
            f"نتائج {title}",
            "استخدم السهم للأعلى والأسفل للتنقل بين النتائج، وحرف د أو Enter للتنزيل",
        )
        lay.addWidget(scroll, 1)
        self.list = scroll

    def clear(self) -> None:
        self.list.clear()
        self._rows.clear()

    def add(self, result: Result) -> None:
        card = ResultCard(result)
        item = QListWidgetItem()
        item.setSizeHint(card.sizeHint())
        self.list.addItem(item)
        self.list.setItemWidget(item, card)
        self._rows[result.title + year_of(result)] = card

    def announce_count(self) -> None:
        n = self.list.count()
        text = "لا توجد نتائج" if n == 0 else f"{n} نتيجة"
        self.count.setText(text)
        self.count.setAccessibleName(text)
        self.count.setAccessibleDescription(f"عدد النتائج في تصنيف {self.category.value}")


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("AcadSearch — نموذج الوصولية")
        self.resize(940, 680)
        self._engine = SearchEngine()
        self._thread: SearchThread | None = None

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        # ---- search row ----
        row = QHBoxLayout()
        self.query = QLineEdit()
        self.query.setPlaceholderText("اكتب كلمة البحث")
        self.query.returnPressed.connect(self.start_search)
        accessible(self.query, "مربع البحث", "اكتب كلمة البحث هنا ثم اضغط Enter")
        row.addWidget(self.query, 1)

        self.search_btn = QPushButton("بحث")
        self.search_btn.clicked.connect(self.start_search)
        accessible(self.search_btn, "زر بحث", "ابدأ البحث في تسعة مصادر")
        row.addWidget(self.search_btn)

        clear_btn = QPushButton("مسح")
        clear_btn.clicked.connect(self._clear)
        accessible(clear_btn, "زر مسح الحقل", "امسح نص البحث")
        row.addWidget(clear_btn)
        root.addLayout(row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        accessible(self.progress, "شريط التقدم", "البحث جارٍ")
        root.addWidget(self.progress)

        self.status = QLabel("جاهز")
        accessible(self.status, "الحالة: جاهز")
        root.addWidget(self.status)

        # ---- category tabs ----
        self.tabs = QTabWidget()
        accessible(
            self.tabs,
            "تصنيفات النتائج",
            "استخدم Control+Tab للتنقل بين الكتب والمقالات والأبحاث",
        )
        self.tab_pages: dict[Category, Tab] = {}
        for category, title in CATEGORIES:
            page = Tab(category, title)
            self.tab_pages[category] = page
            self.tabs.addTab(page, title)
        root.addWidget(self.tabs, 1)

        self.query.setFocus()

    def _set_status(self, text: str) -> None:
        self.status.setText(text)
        self.status.setAccessibleName("الحالة: " + text)

    def _clear(self) -> None:
        self.query.clear()
        for page in self.tab_pages.values():
            page.clear()
            page.announce_count()
        self._set_status("جاهز")

    def start_search(self) -> None:
        text = self.query.text().strip()
        if not text:
            self._set_status("اكتب كلمة بحث أولاً")
            self.query.setFocus()
            return
        if self._thread and self._thread.isRunning():
            self._set_status("البحث جارٍ، انتظر")
            return

        self.progress.setVisible(True)
        self._set_status("جارٍ البحث...")
        for page in self.tab_pages.values():
            page.clear()

        query = SearchQuery(
            text=text,
            categories={c for c, _ in CATEGORIES},
            per_source=10,
        )
        self._thread = SearchThread(self._engine, query, self._on_done, self)
        self._thread.finished_ok.connect(self._thread_done)
        self._thread.failed.connect(self._thread_failed)
        self._thread.start()
        # Move focus somewhere useful and announce it.
        self.search_btn.setAccessibleName("زر بحث، البحث جارٍ")
        self._set_status("جارٍ البحث، انتظر النتيجة")

    def _on_done(self, response, message: str) -> None:
        self._pending = response
        self._message = message

    def _thread_done(self) -> None:
        self.progress.setVisible(False)
        response = getattr(self, "_pending", None)
        if response is None:
            self._set_status("لم يتم العثور على نتائج")
            self.query.setFocus()
            return
        total = 0
        if response is not None:
            for result in response.results:
                page = self.tab_pages.get(result.category)
                if page is None:
                    continue
                page.add(result)
                total += 1
        for page in self.tab_pages.values():
            page.announce_count()
        if total:
            self._set_status(f"تم العثور على {total} نتيجة")
            first = self.tabs.currentWidget()
            first.list.setFocus()
            first.list.setCurrentRow(0)
        else:
            self._set_status("لم يتم العثور على نتائج")
            self.query.setFocus()

    def _thread_failed(self, message: str) -> None:
        self.progress.setVisible(False)
        self._set_status(f"فشل البحث: {message}")

    def closeEvent(self, event):
        self._engine.shutdown()
        super().closeEvent(event)


def main() -> int:
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    win.raise_()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())