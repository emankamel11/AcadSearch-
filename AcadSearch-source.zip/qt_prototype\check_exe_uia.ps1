﻿# Check the packaged EXE through UI Automation, the way a screen reader sees it.
#
# Uses the UIAutomationClient assemblies that ship with Windows, so no Python
# package is needed. Checks the frozen build rather than the source tree: a
# packaged app can come up unstyled, missing its providers, or with a button
# that throws, and none of that shows when running from source.

Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

$root = [System.Windows.Automation.AutomationElement]::RootElement
$condition = [System.Windows.Automation.Condition]::TrueCondition
$deadline = (Get-Date).AddSeconds(90)
$window = $null

while ((Get-Date) -lt $deadline -and -not $window) {
    $children = $root.FindAll(
        [System.Windows.Automation.TreeScope]::Children, $condition)
    foreach ($child in $children) {
        try {
            $name = $child.Current.Name
        } catch { continue }
        if ($name -and ($name.Contains("أكاد") -or $name.Contains("AcadSearch"))) {
            $window = $child
            break
        }
    }
    if (-not $window) { Start-Sleep -Seconds 1 }
}

if (-not $window) {
    Write-Output "FAIL: AcadSearch window not found in the UIA tree"
    exit 1
}

Write-Output "window name : $($window.Current.Name)"
Write-Output "class       : $($window.Current.ClassName)"
Write-Output "offscreen   : $($window.Current.IsOffscreen)"
Write-Output ""

$all = $window.FindAll(
    [System.Windows.Automation.TreeScope]::Descendants, $condition)

$named = @()
foreach ($el in $all) {
    try {
        if ($el.Current.Name) {
            $named += [PSCustomObject]@{
                Type  = $el.Current.ControlType.ProgrammaticName -replace 'ControlType\.', ''
                Name  = $el.Current.Name
                Off   = $el.Current.IsOffscreen
            }
        }
    } catch {}
}

Write-Output "== descendants $($all.Count), named $($named.Count) =="
foreach ($n in $named) {
    $flag = if ($n.Off) { "  [offscreen]" } else { "" }
    Write-Output ("  {0,-14} {1}{2}" -f $n.Type, $n.Name, $flag)
}

Write-Output ""
$buttons = @($named | Where-Object { $_.Type -eq 'Button' })
Write-Output "== buttons $($buttons.Count) =="
foreach ($b in $buttons) { Write-Output "   $($b.Name)" }

$edits = @($named | Where-Object { $_.Type -eq 'Edit' })
Write-Output ""
Write-Output "== edit fields $($edits.Count) =="
foreach ($e in $edits) { Write-Output "   $($e.Name)" }

$hasSettings = @($buttons | Where-Object { $_.Name -like "*إعدادات*" }).Count -gt 0
$hasBox      = @($edits   | Where-Object { $_.Name -eq "بحث" }).Count -gt 0
$hasSearch   = @($buttons | Where-Object { $_.Name -eq "بحث" }).Count -gt 0

# The filter row is part of the search path, so a frozen build that silently
# dropped it would look fine here while the feature is simply gone.
$combos  = @($named | Where-Object { $_.Type -eq 'ComboBox' })
$spinners = @($named | Where-Object { $_.Type -in @('Spinner', 'Text') })
$hasLang   = @($combos | Where-Object { $_.Name -eq "اللغة" }).Count -gt 0
$hasYears  = @($named | Where-Object { $_.Type -eq 'Spinner' }).Count -ge 2

Write-Output ""
Write-Output "== combo boxes $($combos.Count) =="
foreach ($c in $combos) { Write-Output "   $($c.Name)" }

Write-Output ""
Write-Output "settings button  : $hasSettings"
Write-Output "search box       : $hasBox"
Write-Output "search button    : $hasSearch"
Write-Output "language filter  : $hasLang"
Write-Output "year filters     : $hasYears"

# How much does the packaged window talk? UIA HelpText is the accessible
# description, and NVDA reads it out loud on top of the name every time an
# element takes focus -- so a build that puts paragraphs there is the build the
# user complained about, and only the frozen binary can be trusted to show it.
$chatty = @()
foreach ($el in $all) {
    try {
        $help = $el.Current.HelpText
        if ($help -and $help.Length -gt 0) {
            $chatty += [PSCustomObject]@{
                Name = $el.Current.Name
                Len  = $help.Length
                Text = $help
            }
        }
    } catch {}
}
$hasChatty = $chatty.Count -gt 0
Write-Output "long descriptions: $hasChatty"
if ($hasChatty) {
    foreach ($c in $chatty) {
        $snippet = $c.Text
        if ($snippet.Length -gt 70) { $snippet = $snippet.Substring(0, 70) + "..." }
        Write-Output "   $($c.Name) [$($c.Len)] $snippet"
    }
}

if ($hasSettings -and $hasBox -and $hasSearch -and $hasLang -and $hasYears -and -not $hasChatty) {
    Write-Output ""
    Write-Output "OK - the packaged window exposes every element NVDA needs, and says only the label"
    exit 0
}
if ($hasChatty) {
    Write-Output ""
    Write-Output "TOO MUCH SPEECH - elements carry descriptions NVDA will read aloud"
    exit 1
}
Write-Output ""
Write-Output "MISSING KEY ELEMENTS"
exit 1