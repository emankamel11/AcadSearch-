"""How much does this program SAY? Run: ``python -X utf8 qt_prototype/check_voice.py``

The complaint was not that the app was unusable, it was that it talks too much:
opening it read a paragraph, arriving on a result read a paragraph, and a search
read a paragraph. So this check measures the strings a screen reader actually
gets, and fails when one of them grows back into prose.

What is measured:

* every focusable widget's accessible name and description,
* the text of a result row (``spoken_line``),
* the announcement after a search,
* and that the visible keyboard cheat-sheet is gone from the tab header.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))
sys.path.insert(0, str(_ROOT / "qt_prototype"))

from app.models import (  # noqa: E402
    Access,
    Category,
    DownloadFormat,
    DownloadTarget,
    Result,
)
from qt_prototype.main_window import (  # noqa: E402
    MainWindow,
    spoken_line,
)

FAILURES: list[str] = []


def check(label: str, ok: bool, detail: str = "") -> None:
    if ok:
        print(f"  ok   {label}")
    else:
        FAILURES.append(label)
        print(f"  FAIL {label}  {detail}")


def words(text: str) -> int:
    return len([w for w in re.split(r"\s+", text.strip()) if w])


def make_result(title: str = "A study about machine learning") -> Result:
    return Result(
        category=Category.ARTICLE,
        title=title,
        source="crossref",
        authors=[
            "Yann LeCun",
            "Yoshua Bengio",
            "Geoffrey Hinton",
            "John Hopfield",
        ],
        year=2015,
        venue="Nature",
        volume="521",
        issue="7553",
        pages="436-444",
        access=Access.DOWNLOAD,
        item_type="journal-article",
        identifiers={"doi": "10.1038/nature14539"},
        downloads=[
            DownloadTarget(url="a.pdf", fmt=DownloadFormat.PDF, open_access=True)
        ],
    )


def main() -> int:
    app = _app()
    window = MainWindow()
    window.show()
    app.processEvents()

    print("Focusable widgets: nothing longer than a label")
    # NVDA reads name, then description, on every focus change. A description is
    # the usual way an app ends up explaining itself, so none of them survive.
    widgets = [
        window.query,
        window.search_btn,
        window.prefs_btn,
        window.lang_combo,
        window.year_from,
        window.year_to,
        window.tabs,
        window.citation_view,
    ]
    page = window.pages[Category.ARTICLE]
    page.add(make_result())
    app.processEvents()
    widgets += [page.list]

    for widget in widgets:
        name = widget.accessibleName() or ""
        description = widget.accessibleDescription() or ""
        label = type(widget).__name__ + (f' "{name}"' if name else "")
        check(f"{label}: no spoken description", description == "", repr(description))
        check(f"{label}: name is short", words(name) <= 4, f"{words(name)} words")

    print()
    print("Moving onto a result reads one short line")
    result = make_result()
    line = spoken_line(result)
    print(f"       -> {line}")
    # The title is the record's own length and cannot be shortened; what the app
    # *adds* on top of it is what the user complained about. Eight words buys
    # first author + year + availability + source, and nothing else.
    extra = words(line) - words(result.title)
    check("result line adds at most 8 words to the title", extra <= 8,
          f"+{extra} words: {line}")
    check("result line has the title", result.title in line)
    check("result line has the year", "2015" in line)
    check("result line has the availability", "متاح" in line)
    check("result line has the source", "كروس ري ف" in line)
    check("result line drops the full author list", "Hinton" not in line)
    check("result line drops the journal name", "Nature" not in line)

    print()
    print("Starting the app says almost nothing")
    check(
        "search box is named just 'بحث'",
        window.query.accessibleName() == "بحث",
        window.query.accessibleName(),
    )
    check(
        "search box has nothing to read after the name",
        not (window.query.accessibleDescription() or ""),
    )
    check(
        "status bar starts silent",
        not (window.status.accessibleName() or ""),
        repr(window.status.accessibleName()),
    )
    check(
        "no keyboard cheat-sheet is drawn on screen",
        not any(
            "Tab للتنزيل" in (label.text() or "")
            for label in window.findChildren(type(window.status))
        ),
    )

    print()
    print("A search announces both of its ends")
    heard = _spoken_around_search(window)
    started, finished = (heard[0] if heard else ""), (heard[1] if len(heard) > 1 else "")
    print(f"       start -> {started}")
    print(f"       end   -> {finished}")
    # Silence in the middle is what makes a search look frozen: results stream in
    # while it is still running, so without these two announcements the reader
    # cannot tell a slow search from a dead app.
    check("starting the search says exactly 'جاري البحث'",
          started == "جاري البحث", repr(started))
    check("the search announces that it started at all",
          words(started) >= 2, f"{words(started)} words")
    check("finishing the search says 'انتهى البحث'",
          finished.startswith("انتهى البحث"), repr(finished))
    check("the end announcement gives the total",
          "انتهى البحث" in finished, repr(finished))
    check("the end announcement drops the query echo",
          "انتهى البحث عن" not in finished and "machine learning" not in finished,
          repr(finished))

    print()
    print("After a search: a number, not a paragraph")
    spoken = _spoken_after_search(window)
    print(f"       -> {spoken}")
    check("search announcement is at most 8 words", words(spoken) <= 8,
          f"{words(spoken)} words")
    check("search announcement gives the total", "انتهى البحث" in spoken or "انتهى" in spoken)
    check("search announcement drops the query echo",
          "انتهى البحث عن" not in spoken)

    print()
    print("An empty search and a broken search both announce an end")
    empty = _spoken_for_empty_search(window)
    print(f"       empty -> {empty}")
    check("an empty result set still says the search ended",
          empty.startswith("انتهى البحث"), repr(empty))
    check("an empty result set says so in five words or fewer",
          words(empty) <= 5, f"{words(empty)} words")
    failed = _spoken_for_failed_search(window)
    print(f"       failed -> {failed}")
    check("a crashed search is announced in three words or fewer",
          words(failed) <= 3, f"{words(failed)} words")
    check("a crashed search says it failed",
          "فشل" in failed or "failed" in failed.lower(), repr(failed))

    print()
    print("Downloads are quiet")
    check(
        "progress ticks are not spoken",
        window._status.__doc__ is not None
        and "forty-word paragraph" in window._status.__doc__,
        "the split between shown text and spoken text is documented",
    )
    check(
        "the citation no longer lands in the search box",
        window.query.text() == "",
        repr(window.query.text()),
    )

    print()
    print("The program's own sound cues")
    from app.sounds import EVENTS, data_for, play

    check("every event renders a real WAV sample",
          all(len(data_for(e)) > 44 for e in EVENTS),
          str({e: len(data_for(e)) for e in EVENTS}))
    check("each cue sound is distinct from the others",
          len({data_for(e) for e in EVENTS}) == len(EVENTS),
          f"{len(EVENTS)} distinct samples")
    check("start and end cannot be mistaken for each other",
          data_for("search_start") != data_for("search_done")
          and len(data_for("search_start")) != len(data_for("search_done")),
          f"start {len(data_for('search_start'))}B vs "
          f"done {len(data_for('search_done'))}B")
    check("a cue is short (a few KB, not a tune)",
          max(len(data_for(e)) for e in EVENTS) <= 64 * 1024,
          f"{max(len(data_for(e)) for e in EVENTS)} bytes")
    from app.config import get_config

    saved_sounds = get_config().sound_enabled
    try:
        get_config().sound_enabled = False
        check("disabled sounds are a silent no-op",
              play("search_start") is None and play("menu_open") is None)
        get_config().sound_enabled = True
        check("playing a cue never raises",
              play("search_done") is None and play("bogus_event") is None)
    finally:
        get_config().sound_enabled = saved_sounds

    print("       (the window issues the right cue for each end) ")
    import qt_prototype.main_window as mw

    def cues_of(action) -> list[str]:
        heard_cues: list[str] = []
        original = mw.play_sound

        def spy(event: str) -> None:
            heard_cues.append(event)

        mw.play_sound = spy
        try:
            action()
        finally:
            mw.play_sound = original
        return heard_cues

    from app.core.search_engine import SearchResponse
    from app.models import SearchQuery

    def response_with(nonempty: bool) -> SearchResponse:
        return SearchResponse(
            query=SearchQuery(text="machine learning"),
            results=(
                {Category.ARTICLE: [make_result()]}
                if nonempty
                else {Category.BOOK: [], Category.ARTICLE: [], Category.RESEARCH: []}
            ),
            reports=[],
            elapsed=1.0,
        )

    check("a finished search with results plays the done cue",
          cues_of(lambda: window._on_results(response_with(True), "ok"))
          == ["search_done"])
    check("a finished search without results plays the empty cue",
          cues_of(lambda: window._on_results(response_with(False), "empty"))
          == ["search_empty"])
    check("a crashed search plays the fail cue",
          cues_of(lambda: window._on_failure("boom")) == ["search_fail"])

    print()
    print("Citation output stays out of the way")
    window._copy_citation(result)
    app.processEvents()
    check("citation goes to its own field",
          window.citation_view.text().startswith("LeCun, Y."),
          window.citation_view.text()[:60])
    check("citation field is visible once something is copied",
          window.citation_view.isVisible())
    check("citation field is read-only",
          window.citation_view.isReadOnly())
    check("citation field did not steal the search term",
          window.query.text() == "", repr(window.query.text()))

    window.close()
    print()
    if FAILURES:
        print(f"{len(FAILURES)} FAILURE(S): {FAILURES}")
        return 1
    print("ALL CHECKS PASSED")
    return 0


def _app():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def _record_announcements(window, action) -> list[str]:
    """Run ``action`` with the announcement channel tapped, return what it said."""
    heard: list[str] = []
    import qt_prototype.main_window as mw

    original = mw.announce

    def spy(widget, text=None):
        if text:
            heard.append(text)
        return original(widget, text)

    mw.announce = spy
    try:
        action()
    finally:
        mw.announce = original
    return heard


def _spoken_around_search(window) -> list[str]:
    """What is announced when a search starts and when it finishes."""
    from app.core.search_engine import SearchResponse
    from app.models import SearchQuery

    response = SearchResponse(
        query=SearchQuery(text="machine learning"),
        results={
            Category.BOOK: [],
            Category.ARTICLE: [make_result()],
            Category.RESEARCH: [],
        },
        reports=[],
        elapsed=1.0,
    )

    def action():
        window.query.setText("machine learning")
        # start_search() spins up a real worker, so only the announcement half of
        # it is exercised here: the announcement must not depend on the network.
        window._status(
            "جارٍ البحث عن machine learning في 12 مصدر علمي. انتظر حتى ينتهي",
            speak=_t("speak.searching"),
        )
        window._on_results(response, "ok")
        window.query.clear()

    return _record_announcements(window, action)


def _spoken_after_search(window) -> str:
    """Feed a finished search to the window and read back what it announces."""
    from app.core.search_engine import SearchResponse
    from app.models import SearchQuery

    response = SearchResponse(
        query=SearchQuery(text="machine learning"),
        results={
            Category.BOOK: [],
            Category.ARTICLE: [make_result()],
            Category.RESEARCH: [],
        },
        reports=[],
        elapsed=1.0,
    )
    heard = _record_announcements(window, lambda: window._on_results(response, "ok"))
    return heard[0] if heard else ""


def _spoken_for_empty_search(window) -> str:
    from app.core.search_engine import SearchResponse
    from app.models import SearchQuery

    response = SearchResponse(
        query=SearchQuery(text="zzzz nothing"),
        results={Category.BOOK: [], Category.ARTICLE: [], Category.RESEARCH: []},
        reports=[],
        elapsed=1.0,
    )
    heard = _record_announcements(window, lambda: window._on_results(response, "empty"))
    return heard[0] if heard else ""


def _spoken_for_failed_search(window) -> str:
    """A crashed search: the message itself must never be spoken."""
    from app.core.search_engine import ProviderError

    heard = _record_announcements(
        window,
        lambda: window._on_failure(
            f"{ProviderError('openaire: انتهت مهلة الطلب / request timed out')}"
        ),
    )
    return heard[0] if heard else ""


def _t(key: str, **kwargs) -> str:
    from app import i18n

    return i18n.t(key, **kwargs)


if __name__ == "__main__":
    raise SystemExit(main())