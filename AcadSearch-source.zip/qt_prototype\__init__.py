"""The Qt interface for AcadSearch.

A package rather than a folder of loose scripts so the modules inside it
(``theme``, ``preferences``, ``main_window``) import the same way from source
and from the PyInstaller build. PyInstaller's import analysis cannot follow a
bare ``import theme`` inside a subfolder, which left the packaged app unstyled
with a broken settings button.
"""