"""Download manager for open-access files (PDF / EPUB / ZIP).

Scope and ethics
----------------
This module downloads **only** from links that a provider has explicitly
marked as openly licensed (``DownloadTarget.open_access``) or that a
repository publishes under an open licence (arXiv, Internet Archive public
domain, Zenodo, institutional repositories).

When no direct file exists the "Download" button opens the official landing
page instead. It deliberately does not attempt to bypass paywalls, logins or
publisher anti-bot measures — an academic tool should not put its users at
risk of ToS violations.
"""

from __future__ import annotations

import logging
import mimetypes
import os
import queue
import re
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import requests

from app.config import Config, get_config
from app.models import Access, Category, DownloadFormat, DownloadTarget, Result

log = logging.getLogger(__name__)

CHUNK = 64 * 1024
#: Never buffer more than this in memory regardless of Content-Length.
MAX_BUFFER = 32 * 1024 * 1024


class DownloadState(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    CANCELLED = "cancelled"
    SKIPPED = "skipped"


@dataclass
class DownloadTask:
    """One file being fetched (or deliberately not fetched)."""

    result: Result
    target: DownloadTarget
    state: DownloadState = DownloadState.QUEUED
    received: int = 0
    total: int | None = None
    path: Path | None = None
    error: str = ""
    started_at: float = field(default_factory=time.monotonic)

    @property
    def filename(self) -> str:
        return self.result.suggested_filename()

    @property
    def percent(self) -> float:
        if self.state is DownloadState.DONE:
            return 100.0
        if not self.total:
            return 0.0
        return min(100.0, self.received * 100.0 / self.total)

    @property
    def speed(self) -> float:
        elapsed = max(0.001, time.monotonic() - self.started_at)
        return self.received / elapsed


class DownloadEventType(str, Enum):
    QUEUED = "queued"
    STARTED = "started"
    PROGRESS = "progress"
    FINISHED = "finished"
    FAILED = "failed"
    CANCELLED = "cancelled"
    SKIPPED = "skipped"


@dataclass
class DownloadEvent:
    type: DownloadEventType
    task: DownloadTask
    message: str = ""


class DownloadManager:
    """Runs up to ``max_concurrent`` downloads, each on its own thread."""

    def __init__(self, config: Config | None = None, max_concurrent: int = 3):
        self.config = config or get_config()
        self.max_concurrent = max_concurrent
        self._events: "queue.Queue[DownloadEvent]" = queue.Queue()
        self._cancels: dict[int, threading.Event] = {}
        self._lock = threading.Lock()
        self._tasks: list[DownloadTask] = []

    # -- public API ------------------------------------------------------
    @property
    def events(self) -> "queue.Queue[DownloadEvent]":
        return self._events

    def enqueue(self, result: Result) -> DownloadTask | None:
        """Start downloading the best available file for ``result``.

        Returns ``None`` when there is nothing to fetch, in which case the
        caller should open the landing page instead.
        """
        target = self.pick_target(result)
        if target is None or target.fmt is DownloadFormat.SOURCE:
            # A book that only carried a landing page during the search may
            # still have an open file (Internet Archive serves the real PDF
            # from a per-item manifest). Resolve it on demand instead of
            # opening the browser: this is what turns "most books" from
            # read-only into real downloads without slowing every search.
            resolved = self._resolve_book_file(result)
            if resolved is not None:
                target = resolved
        if target is None:
            return None

        task = DownloadTask(result=result, target=target)
        if target.fmt is DownloadFormat.SOURCE:
            # Nothing to fetch: tell the caller to open the browser.
            task.state = DownloadState.SKIPPED
            task.error = "landing-page"
            self._events.put(DownloadEvent(DownloadEventType.SKIPPED, task))
            return task

        if not target.open_access:
            # Defensive: we do not fetch non-open targets automatically.
            task.state = DownloadState.SKIPPED
            task.error = "not-open-access"
            self._events.put(DownloadEvent(DownloadEventType.SKIPPED, task))
            return task

        with self._lock:
            self._tasks.append(task)
        self._events.put(DownloadEvent(DownloadEventType.QUEUED, task))
        threading.Thread(
            target=self._run, args=(task,), name=f"acad-dl-{id(task):x}", daemon=True
        ).start()
        return task

    @staticmethod
    def pick_target(result: Result) -> DownloadTarget | None:
        """Choose what the Download button should act on."""
        candidates = [
            t
            for t in result.downloads
            if t.fmt in (DownloadFormat.PDF, DownloadFormat.EPUB, DownloadFormat.ZIP)
        ]
        open_files = [t for t in candidates if t.open_access]
        chosen = open_files or candidates
        if chosen:
            return chosen[0]
        if result.landing_url:
            return DownloadTarget(
                url=result.landing_url, fmt=DownloadFormat.SOURCE, label="landing"
            )
        return result.downloads[0] if result.downloads else None

    @staticmethod
    def _resolve_book_file(result: Result) -> DownloadTarget | None:
        """Open file for an Archive.org book whose search record showed none."""
        if result.category is not Category.BOOK:
            return None
        identifiers = result.identifiers or {}
        ia_id = identifiers.get("ia") or identifiers.get("ocaid")
        if not ia_id:
            return None
        from app.providers.internet_archive import resolve_open_files

        files = resolve_open_files(ia_id, result.title)
        if not files:
            return None
        real = [
            t
            for t in files
            if t.fmt in (DownloadFormat.PDF, DownloadFormat.EPUB, DownloadFormat.ZIP)
            and t.open_access
        ]
        if not real:
            return None
        known = {existing.url for existing in result.downloads}
        for t in real:
            if t.url not in known:
                result.downloads.append(t)
        if result.access in (Access.METADATA, Access.LANDING, None):
            result.access = Access.DOWNLOAD
        return real[0]

    def cancel_all(self) -> None:
        with self._lock:
            for event in self._cancels.values():
                event.set()

    # -- worker ----------------------------------------------------------
    def _run(self, task: DownloadTask) -> None:
        cancel = threading.Event()
        with self._lock:
            self._cancels[id(task)] = cancel

        task.state = DownloadState.RUNNING
        self._events.put(DownloadEvent(DownloadEventType.STARTED, task))

        try:
            path = self._fetch(task, cancel)
        except _HtmlPage:
            # A "PDF" that is really a web page. Handled here rather than in
            # _fetch: that function returns a path, and returning from it would
            # look like a successful download of nothing.
            task.state = DownloadState.SKIPPED
            task.error = "html-page"
            self._events.put(DownloadEvent(DownloadEventType.SKIPPED, task))
            return
        except _Cancelled:
            task.state = DownloadState.CANCELLED
            self._events.put(DownloadEvent(DownloadEventType.CANCELLED, task))
            return
        except Exception as exc:
            task.state = DownloadState.FAILED
            task.error = str(exc)
            log.warning("download failed for %s: %s", task.filename, exc)
            self._events.put(DownloadEvent(DownloadEventType.FAILED, task))
            return
        finally:
            with self._lock:
                self._cancels.pop(id(task), None)

        if cancel.is_set():
            _safe_unlink(path)
            task.state = DownloadState.CANCELLED
            self._events.put(DownloadEvent(DownloadEventType.CANCELLED, task))
            return

        task.path = path
        task.state = DownloadState.DONE
        self._events.put(DownloadEvent(DownloadEventType.FINISHED, task))

    def _fetch(self, task: DownloadTask, cancel: threading.Event) -> Path:
        url = task.target.url
        # Several open-access publishers (Europe PMC, MIT Press, ...) answer 403
        # to a client that introduces itself as a bot, and serve the same file to
        # anything that looks like a browser. Ask like one.
        headers = {
            "User-Agent": self.config.user_agent,
            "Accept": (
                "application/pdf,application/epub+zip,application/zip;q=0.9,"
                "application/octet-stream;q=0.8,*/*;q=0.7"
            ),
            "Accept-Language": "en,fr;q=0.8",
        }
        limit = self.config.max_download_mb * 1024 * 1024

        # Stream to a .part file so an interrupted download is never mistaken
        # for a complete document.
        folder = self.config.download_folder
        destination = folder / _dedupe_name_in_folder(folder, task.filename)
        temporary = destination.with_suffix(destination.suffix + ".part")

        try:
            with requests.get(
                url, headers=headers, stream=True, timeout=(20, 60), allow_redirects=True
            ) as response:
                response.raise_for_status()

                total_header = response.headers.get("Content-Length")
                task.total = (
                    min(int(total_header), limit)
                    if total_header and total_header.isdigit()
                    else None
                )

                actual_ext = _extension_from(response, task.target.fmt)
                if actual_ext in (".html", ".htm"):
                    # The server says it is sending a web page, so there is no
                    # file to fetch. Bail out before writing anything, instead of
                    # saving "Title.pdf.html" and calling it a download.
                    raise _HtmlPage()
                if actual_ext and not destination.name.lower().endswith(actual_ext):
                    destination = destination.with_suffix(destination.suffix + actual_ext)
                    temporary = destination.with_suffix(destination.suffix + ".part")

                written = 0
                first_chunk = True
                with open(temporary, "wb") as handle:
                    for chunk in response.iter_content(CHUNK):
                        if cancel.is_set():
                            raise _Cancelled()
                        if not chunk:
                            continue
                        if first_chunk:
                            first_chunk = False
                            # A "PDF" link that quietly answers with a web page
                            # used to be saved as Book.pdf.html and reported as a
                            # finished download: the user got a file that opens in
                            # a browser and cannot be read. Say what happened.
                            if _looks_like_html(chunk):
                                raise _HtmlPage()
                        written += len(chunk)
                        if written > limit:
                            raise RuntimeError(
                                f"الملف أكبر من الحد المسموح "
                                f"({self.config.max_download_mb} MB)"
                            )
                        handle.write(chunk)
                        task.received = written
                        if written % (CHUNK * 8) == 0 or task.total is None:
                            self._events.put(
                                DownloadEvent(DownloadEventType.PROGRESS, task)
                            )
        except BaseException:
            # Never leave a half-written .part behind.
            _safe_unlink(temporary)
            raise

        if task.total and task.received < task.total * 0.98:
            _safe_unlink(temporary)
            raise RuntimeError("انقطع التنزيل قبل اكتمال الملف / truncated download")

        os.replace(temporary, destination)
        return destination


class _Cancelled(Exception):
    pass


class _HtmlPage(Exception):
    """The server answered with a web page instead of the requested file."""


def _looks_like_html(chunk: bytes) -> bool:
    """Sniff a page out of the first bytes, for servers that mislabel the type.

    The leading whitespace is skipped inside the match, not before it: one real
    response started with 200 blank lines, which is enough to hide any "<html"
    from a check that slices first and strips afterwards.
    """
    head = chunk[:4096]
    match = re.match(rb"\s*(<!doctype\s+html|<html[\s>]|<!--|<script|<meta)",
                     head[:2048], re.I)
    return match is not None


def _extension_from(response: requests.Response, fmt: DownloadFormat) -> str:
    """Trust Content-Disposition/Content-Type over our guess."""
    disposition = response.headers.get("Content-Disposition", "")
    match = re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)", disposition, re.I)
    if match:
        suffix = Path(match.group(1)).suffix.lower()
        if suffix in (".pdf", ".epub", ".zip", ".djvu", ".txt", ".html"):
            return suffix
    ctype = (response.headers.get("Content-Type") or "").split(";")[0].strip()
    guessed = mimetypes.guess_extension(ctype) or ""
    if guessed in (".pdf", ".epub", ".zip", ".html", ".htm"):
        return ".html" if guessed == ".htm" else guessed
    return f".{fmt.value}" if fmt is not DownloadFormat.SOURCE else ""


def _dedupe_name(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|\r\n\t]', "_", name).strip(" .") or "document"


def _dedupe_name_in_folder(folder: Path, name: str) -> str:
    """Append ``(2)``, ``(3)`` … rather than overwriting an existing file."""
    candidate = folder / name
    if not candidate.exists():
        return name
    stem, dot, ext = name.partition(".")
    for index in range(2, 1000):
        probe = f"{stem} ({index}){dot}{ext}"
        if not (folder / probe).exists():
            return probe
    return f"{stem} ({int(time.time())}){dot}{ext}"


def _safe_unlink(path: Path | None) -> None:
    if path is None:
        return
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass
