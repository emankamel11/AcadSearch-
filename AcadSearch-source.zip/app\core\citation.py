﻿"""Citation formatting.

Every result card carries a "ظ†ط³ط® ط§ظ„طھظˆط«ظٹظ‚" button and the toolbar has a style
selector; both write the *same* string so what you preview is what you paste.
Academic rules differ per source type (a book is not a journal article), so
each style branches on the record type rather than emitting one flat template.

Italic segments are wrapped in ``*â€¦*``. Word and Google Docs turn that into
real italics automatically when pasted, which keeps the output usable in a
thesis without the app having to own a rich-text clipboard.
"""

from __future__ import annotations

import re

from app import i18n
from app.models import Result

#: ``(key, label)`` in display order. Keys are stable and used in config.json.
STYLES: tuple[str, ...] = (
    "apa",
    "mla",
    "chicago",
    "harvard",
    "ieee",
    "bibtex",
    "ris",
)

#: Styles that produce a bibliography entry rather than a numbered footnote.
TEXT_STYLES: frozenset[str] = frozenset({"apa", "mla", "chicago", "harvard"})

_SUFFIXES = {"jr", "sr", "ii", "iii", "iv", "phd", "md"}
_PARTICLES = {"al", "bin", "ibn", "de", "da", "van", "von", "der", "den", "di", "del", "la", "le"}


def _year(result: Result) -> str:
    return str(result.year) if result.year else "n.d."


def _year_terminal(result: Result) -> str:
    """``"2019."`` â€” the year already carrying its own period.

    ``_year`` returns ``"n.d."`` for an unknown date, so appending another
    period would print ``n.d..``.
    """
    year = _year(result)
    return year if year.endswith(".") else f"{year}."


def _doi(result: Result) -> str:
    return (result.identifiers.get("doi") or "").strip()


def _inverted(name: str) -> str:
    """``"Ahmed Mohammed"`` -> ``"Mohammed, A."`` (APA name order).

    Handles particles (``van``, ``al``, ``de``) which belong to the family
    name, hyphenated given names, and suffixes (``Jr.``) which stay last.
    """
    name = (name or "").strip().rstrip(",")
    if not name:
        return ""
    # Already inverted (``"Mohammed, A."``) â€” leave it alone.
    if "," in name:
        return name

    parts = [p for p in re.split(r"\s+", name) if p]
    if len(parts) == 1:
        return parts[0]

    suffix = ""
    if parts[-1].rstrip(".").lower() in _SUFFIXES:
        suffix = parts.pop()

    # Particles belong to the family name and sit *before* it, so walk backwards
    # over the particle that precedes the surname: "Carl Ludwig van der Waals"
    # -> family "van der Waals", given "Carl Ludwig".
    end = len(parts)
    while end > 1 and parts[end - 2].lower().strip(",") in _PARTICLES:
        end -= 1
    family = " ".join(parts[end - 1 :])
    given = parts[: end - 1]

    if not given:
        return f"{family}, {suffix}".strip().strip(",")

    initials = " ".join(f"{p[0].upper()}." for p in given if p)
    inverted = f"{family}, {initials}"
    return f"{inverted}, {suffix}" if suffix else inverted


def _apa_authors(result: Result, limit: int = 20) -> str:
    """APA 7 author list."""
    names = [_inverted(a) for a in result.authors if a and a.strip()]
    if not names:
        return ""
    if len(names) > limit:
        return ", ".join(names[: limit - 1]) + ", ... " + names[-1]
    if len(names) == 1:
        return names[0]
    return ", ".join(names[:-1]) + ", & " + names[-1]


def _apa_editors(result: Result, limit: int = 20) -> str:
    """APA 7 editor list for edited books."""
    names = [_inverted(a) for a in result.editors if a and a.strip()]
    if not names:
        return ""
    if len(names) > limit:
        return ", ".join(names[: limit - 1]) + ", ... " + names[-1]
    if len(names) == 1:
        return f"{names[0]} (Ed.)"
    return ", ".join(names[:-1]) + ", & " + names[-1] + " (Eds.)"


def _generic_authors(result: Result) -> str:
    return ", ".join(a for a in result.authors if a)


def _plain_authors(result: Result) -> str:
    return _generic_authors(result) or "Anonymous"


def _kind(result: Result) -> str:
    """Collapse the many provider-specific ``item_type`` values to 5 buckets."""
    raw = (result.item_type or "").lower().replace("-", " ").replace("_", " ")
    if any(word in raw for word in ("thesis", "thèse", "these", "dissertation",
                                    "diploma", "bachelor", "master")):
        return "thesis"
    # "book chapter" must be tested before "book", otherwise every chapter is
    # formatted as a whole book and the page range is dropped.
    if "chapter" in raw:
        return "chapter"
    if "book" in raw:
        return "book"
    if any(word in raw for word in ("preprint", "posted", "working paper", "report", "standard")):
        return "report"
    if any(word in raw for word in ("dataset", "data set", "software")):
        return "dataset"
    return "article"


def _bare(text: str) -> str:
    """Strip trailing sentence punctuation and whitespace."""
    return (text or "").strip().rstrip(".,;:")


def _en_dash(text: str) -> str:
    """``"436-444"`` -> ``"436\u2013444"``.

    APA 7, MLA and Chicago all set a page range with an en dash, and a plain
    hyphen is what a reader copies into a thesis and gets marked down for.
    """
    return re.sub(r"(?<=\d)\s*-\s*(?=\d)", "\u2013", text or "")


def _page_range(result: Result) -> str:
    """The page locator with a proper en dash."""
    return _en_dash(str(result.pages or "").strip())


def _pages(result: Result) -> str:
    """The page locator, prefixed with the volume(issue) when known.

    APA 7 wants ``320(3), 145\u2013162``; the other styles want ``pp. 145\u2013162``
    with the volume carried by the venue instead. Keeping this in one place
    stops the two halves of the locator drifting apart.
    """
    pages = _page_range(result)
    volume_issue = _volume_issue(result)
    if pages and volume_issue:
        return f"{volume_issue}, {pages}"
    return pages or ""


def _volume_issue(result: Result) -> str:
    """``"320(3)"`` from the volume and issue, or an empty string."""
    volume = _bare(result.volume)
    issue = _bare(result.issue)
    if volume and issue:
        return f"{volume}({issue})"
    return volume or issue


def _terminal(text: str) -> str:
    """Guarantee a field ends in exactly one period."""
    text = _bare(text)
    return f"{text}." if text else ""


def _sentence(text: str) -> str:
    """Append a period only if the text does not already end with one."""
    text = text.rstrip()
    if not text:
        return ""
    return text if text.endswith(".") else f"{text}."


def _italic(text: str, terminal: bool = True) -> str:
    """Italic span with the period *outside* it (``*Title*.`` not ``*Title.*``).

    Putting the full stop inside the asterisks makes Word swallow it into the
    italic run, which looks wrong in a reference list.
    """
    text = _bare(text)
    if not text:
        return ""
    return f"*{text}*." if terminal else f"*{text}*"


def _quoted(text: str, mark: str = '"') -> str:
    """Quoted span; the period goes *inside* the quotes per MLA/Chicago."""
    text = _bare(text)
    if not text:
        return ""
    return f'{mark}{text}.{mark}' if mark == '"' else f"{mark}{text}{mark}."


# ---------------------------------------------------------------------------
# APA 7
# ---------------------------------------------------------------------------
def format_apa(result: Result) -> str:
    authors = _apa_authors(result)
    lead = f"{authors} ({_year(result)}). " if authors else f"({_year(result)}). "
    kind = _kind(result)
    doi = _doi(result)
    arxiv = result.identifiers.get("arxiv")

    if kind == "book":
        # APA 7: for edited books, use editors in place of authors.
        if result.editors and not result.authors:
            ed = _apa_editors(result)
            year = _year(result)
            lead = f"{ed} ({year}). " if year else f"{ed}. "
        body = f"{lead}{_italic(result.title)}"
        edn = (result.edition or "").strip()
        if edn and edn.lower() not in ("1", "1st", "first", "1st edition"):
            low = edn.lower()
            if not (" ed." in low or low.endswith(" ed") or " edition" in low):
                body += f" ({edn} ed.)"
            else:
                body += f" ({edn})"
        body += " "
        publisher = _bare(result.publisher or result.venue)
        body += _terminal(publisher) if publisher else ""
    elif kind == "chapter":
        body = f"{lead}{_terminal(result.title)}"
        locator = _page_range(result)
        # In edited book: "In E. Editor (Ed.), Title of book..."
        eds = _apa_editors(result)
        if result.venue:
            if result.editors:
                body += f" In {eds}, {_italic(result.venue, terminal=False)}"
            else:
                body += f" In {_italic(result.venue, terminal=False)}"
        elif result.editors:
            body += f" In {eds}, {_italic(result.title, terminal=False)}"  # fallback
        if locator:
            body += f" (pp. {locator})"
        body = _sentence(body)
    elif kind == "thesis":
        body = f"{lead}{_italic(result.title, terminal=False)}"
        label = i18n_thesis()
        body += f" [{label}، {result.venue}]." if result.venue \
            else f" [{label}]."
    elif kind == "dataset":
        body = f"{lead}{_italic(result.title, terminal=False)}"
        body += f" [{i18n.t('citation.dataset')}{_list_separator()} {result.venue}]." \
            if result.venue else f" [{i18n.t('citation.dataset')}]."
    elif kind == "report":
        body = f"{lead}{_italic(result.title, terminal=False)}"
        if arxiv:
            body += f" [{i18n.t('citation.preprint')}{_list_separator()} arXiv:{arxiv}]."
        elif result.venue:
            body += f" {_italic(result.venue, terminal=False)}."
        else:
            body += "."
    else:  # article / chapter
        body = f"{lead}{_terminal(result.title)}"
        pages_text = _pages(result)
        if result.venue:
            body += f" {_italic(result.venue, terminal=False)}"
            if pages_text:
                body += f", {pages_text}"
        elif pages_text:
            # No journal to hang the locator off; emit it as a plain tail
            # rather than leaving a leading comma after the title.
            body = f"{_terminal(result.title)} {pages_text}"
        body = _sentence(body)

    if doi:
        body = f"{body.rstrip()} https://doi.org/{doi}"
    elif kind != "book" and result.landing_url:
        # APA 7 wants the URL on articles, chapters, preprints, datasets and
        # theses; a plain book reference is already complete without one.
        body = f"{body.rstrip()} {result.landing_url.strip()}"
    return body.strip()


def i18n_thesis() -> str:
    return i18n.t("citation.thesis")


def _list_separator() -> str:
    """Arabic uses a different comma inside ``[â€¦]`` brackets."""
    return "طŒ" if i18n.get_language() == "ar" else ","


# ---------------------------------------------------------------------------
# MLA 9 / Chicago 17 / Harvard / IEEE
# ---------------------------------------------------------------------------
def format_mla(result: Result) -> str:
    authors = _plain_authors(result)
    kind = _kind(result)
    parts = [_terminal(authors) if authors else ""]
    # MLA 9 italics books but quotes articles â€” the reverse of what v8 did.
    parts.append(_italic(result.title) if kind == "book" else _quoted(result.title))
    if result.venue:
        venue = _bare(result.venue)
        vol_iss = _volume_issue(result)
        parts.append(_terminal(f"{venue}, vol. {vol_iss}" if vol_iss else venue))
    pages = _page_range(result)
    if pages and kind != "book":
        parts.append(f"pp. {pages},")
    parts.append(_year_terminal(result))
    doi = _doi(result)
    if doi:
        parts.append(f"https://doi.org/{doi}.")
    elif result.landing_url:
        parts.append(_terminal(result.landing_url))
    return " ".join(p for p in parts if p).strip()


def format_chicago(result: Result) -> str:
    authors = _plain_authors(result)
    kind = _kind(result)
    parts = [_terminal(authors) if authors else ""]
    parts.append(_italic(result.title) if kind == "book" else _quoted(result.title))
    if result.venue:
        venue = _bare(result.venue)
        vol_iss = _volume_issue(result)
        parts.append(_terminal(f"{venue} {vol_iss}" if vol_iss else venue))
    pages = _page_range(result)
    if pages and kind != "book":
        parts.append(f"{pages}.")
    parts.append(_year_terminal(result))
    doi = _doi(result)
    parts.append(f"https://doi.org/{doi}." if doi else _terminal(result.landing_url))
    return " ".join(p for p in parts if p).strip()


def format_harvard(result: Result) -> str:
    authors = _plain_authors(result)
    kind = _kind(result)
    parts = []
    if authors:
        parts.append(f"{authors} ({_year(result)})")
    parts.append(_italic(result.title) if kind == "book" else _quoted(result.title, "'"))
    vol_iss = _volume_issue(result)
    if result.venue:
        venue = _bare(result.venue)
        parts.append(_terminal(f"{venue}, {vol_iss}" if vol_iss else venue))
    elif vol_iss:
        # Keep the locator rather than dropping it with the missing venue.
        parts.append(_terminal(f"vol. {vol_iss}"))
    pages = _page_range(result)
    doi = _doi(result)
    url = f"https://doi.org/{doi}" if doi else result.landing_url
    # The comma hangs off the page range, so it may only be added when
    # something actually follows; otherwise the entry ends in a stray comma.
    if pages and kind != "book":
        parts.append(f"pp. {pages}," if url else f"pp. {pages}.")
    if url:
        parts.append(f"Available at: {url}")
    return " ".join(parts).strip()


def format_ieee(result: Result) -> str:
    """IEEE: initials before the family name, quoted titles.

    The reference number is assigned by the bibliography, so this emits only
    the entry text.
    """
    names = []
    for author in result.authors:
        author = (author or "").strip()
        if not author:
            continue
        if "," in author:
            names.append(author)
            continue
        parts = author.split()
        if len(parts) == 1:
            names.append(parts[0])
            continue
        initials = " ".join(f"{p[0].upper()}." for p in parts[:-1])
        names.append(f"{initials} {parts[-1]}")

    kind = _kind(result)
    if names:
        head = ", ".join(names)
        if len(names) > 6:
            head = ", ".join(names[:6]) + ", et al."
        elif len(names) > 1:
            head = ", ".join(names[:-1]) + ", and " + names[-1]
        # An initial already ends in a period, so appending one blindly would
        # print "A. P. D..".
        head = _terminal(head)
    else:
        head = ""

    # A book title is followed by a comma in IEEE, so it must not carry its own
    # period the way a quoted article title does.
    body = _bare(result.title) if kind == "book" else _quoted(result.title)
    tail = ""
    vol_iss = _volume_issue(result)
    if result.venue:
        venue = _bare(result.venue)
        tail = f", {venue}, vol. {vol_iss}" if vol_iss else f", {venue}"
    elif vol_iss:
        tail = f", vol. {vol_iss}"
    pages = _page_range(result)
    if pages and kind != "book":
        tail += f", pp. {pages}"
    if result.year:
        tail += f", {result.year}"
    tail += "."
    doi = _doi(result)
    if doi:
        tail += f" doi: {doi}."
    elif result.landing_url:
        tail += f" [Online]. Available: {result.landing_url}"

    return f"{head} {body}{tail}".strip()


# ---------------------------------------------------------------------------
# Structured exports
# ---------------------------------------------------------------------------
_BIBTEX_ESCAPE = {"&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_"}


def _bibtex_escape(value: str) -> str:
    out = ""
    for char in value:
        out += _BIBTEX_ESCAPE.get(char, char)
    return out.replace("{", " ").replace("}", " ").strip()


def _bibtex_key(result: Result) -> str:
    """Stable, collision-resistant key: ``mohammed2021deep``.

    Restricted to ASCII: BibTeX/LaTeX treat non-Latin characters in a citation
    key as undefined behaviour, so an all-Arabic record falls back to ``anon``.
    """
    surname = ""
    if result.authors and result.authors[0]:
        raw = result.authors[0].strip()
        surname = raw.split(",")[0] if "," in raw else raw.split()[-1]
    surname = re.sub(r"[^A-Za-z]", "", surname).lower() or "anon"

    words = re.split(r"[^A-Za-z0-9]+", result.title or "")
    topic = next((w.lower() for w in words[1:] if len(w) > 3), "")
    return f"{surname}{result.year or ''}{topic[:4] or 'work'}"


def format_bibtex(result: Result) -> str:
    kind = _kind(result)
    entry = {
        "thesis": "phdthesis",
        "book": "book",
        "report": "misc",
        "dataset": "misc",
        "chapter": "incollection",
    }.get(kind, "article")

    fields = [
        ("author", " and ".join(_inverted(a) for a in result.authors if a)),
        ("title", result.title),
        ("year", str(result.year) if result.year else ""),
    ]
    if entry == "article" and result.venue:
        fields.append(("journal", result.venue))
    elif entry == "incollection" and result.venue:
        fields.append(("booktitle", result.venue))
    elif entry == "book" and result.venue:
        fields.append(("publisher", result.venue))
    elif entry == "phdthesis" and result.venue:
        fields.append(("school", result.venue))

    doi = _doi(result)
    if doi:
        fields.append(("doi", doi))
    if result.identifiers.get("arxiv"):
        fields.append(("eprint", result.identifiers["arxiv"]))
        fields.append(("archiveprefix", "arXiv"))
    if result.volume:
        fields.append(("volume", str(result.volume)))
    if result.issue:
        fields.append(("number", str(result.issue)))
    if result.pages:
        fields.append(("pages", str(result.pages)))
    if result.landing_url:
        fields.append(("url", result.landing_url))

    body = ",\n".join(
        f"  {name} = {{{_bibtex_escape(value)}}}"
        for name, value in fields
        if value
    )
    return f"@{entry}{{{_bibtex_key(result)},\n{body}\n}}"


_RIS_TYPES = {
    "book": "BOOK",
    "thesis": "THES",
    "article": "JOUR",
    "report": "RPRT",
    "dataset": "DATA",
    "chapter": "CHAP",
}


def format_ris(result: Result) -> str:
    kind = _kind(result)
    code = _RIS_TYPES.get(kind, "JOUR")
    lines = [f"TY  - {code}"]
    for author in result.authors:
        if author:
            lines.append(f"AU  - {_inverted(author)}")
    lines.append(f"TI  - {result.title}")
    if result.year:
        lines.append(f"PY  - {result.year}")
    if result.venue:
        key = "T2" if code in ("BOOK", "CHAP") else ("PB" if code == "RPRT" else "JO")
        lines.append(f"{key}  - {result.venue}")
    if result.volume:
        lines.append(f"VL  - {result.volume}")
    if result.issue:
        lines.append(f"IS  - {result.issue}")
    if result.pages:
        lines.append(f"SP  - {result.pages}")
    doi = _doi(result)
    if doi:
        lines.append(f"DO  - {doi}")
    if result.landing_url:
        lines.append(f"UR  - {result.landing_url}")
    lines.append("ER  - ")
    return "\n".join(lines)


FORMATTERS = {
    "apa": format_apa,
    "mla": format_mla,
    "chicago": format_chicago,
    "harvard": format_harvard,
    "ieee": format_ieee,
    "bibtex": format_bibtex,
    "ris": format_ris,
}

DEFAULT_STYLE = "apa"


def format_citation(result: Result, style: str = DEFAULT_STYLE) -> str:
    """Render ``result`` in ``style``, falling back to APA on a bad key."""
    formatter = FORMATTERS.get((style or "").strip().lower(), format_apa)
    return formatter(result)


