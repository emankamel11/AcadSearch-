"""Generate assets/acadsearch.ico.

The icon is a document with a citation mark, plus a magnifier for "search",
drawn on a rounded square. It is generated rather than hand-drawn so every
size stays crisp and the palette can follow the app theme.

    python -X utf8 -m tools.make_icon
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

ACCENT = (37, 99, 235)      # blue-600
ACCENT_DARK = (29, 78, 216)
PAPER = (255, 255, 255)
INK = (30, 41, 59)
GLASS = (147, 197, 253)

SIZES = (16, 20, 24, 32, 40, 48, 64, 128, 256)
OUT = Path(__file__).resolve().parent.parent / "assets" / "acadsearch.ico"


def _rounded(draw: ImageDraw.ImageDraw, box, radius, fill) -> None:
    draw.rounded_rectangle(box, radius=radius, fill=fill)


def render(size: int) -> Image.Image:
    """Draw the icon at ``size`` pixels, supersampled 8x then downscaled."""
    ss = 8
    n = size * ss
    img = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    u = n / 256.0  # design grid is 256x256

    # Background plate.
    _rounded(d, (0, 0, n - 1, n - 1), radius=int(56 * u), fill=ACCENT)
    _rounded(d, (0, 0, n - 1, int(150 * u)), radius=int(56 * u),
             fill=ACCENT_DARK)

    # Document sheet.
    _rounded(d, (int(58 * u), int(52 * u), int(178 * u), int(196 * u)),
             radius=int(10 * u), fill=PAPER)
    # Folded corner.
    d.polygon(
        [
            (int(140 * u), int(52 * u)),
            (int(178 * u), int(90 * u)),
            (int(140 * u), int(90 * u)),
        ],
        fill=(203, 213, 225),
    )

    # Text lines on the sheet.
    for i, width in enumerate((78, 78, 60, 44)):
        y = int((112 + i * 20) * u)
        d.rounded_rectangle(
            (int(76 * u), y, int((76 + width) * u), y + int(9 * u)),
            radius=int(4.5 * u),
            fill=(203, 213, 225),
        )

    # Magnifier over the lower-right of the sheet.
    cx, cy, r = int(178 * u), int(178 * u), int(44 * u)
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=GLASS)
    d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=INK, width=int(9 * u))
    # Handle.
    d.line(
        (cx + int(r * 0.68), cy + int(r * 0.68), int(228 * u), int(228 * u)),
        fill=INK,
        width=int(17 * u),
    )
    d.ellipse((int(206 * u), int(206 * u), int(240 * u), int(240 * u)),
              fill=INK)

    return img.resize((size, size), Image.LANCZOS)


def main() -> int:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    frames = [render(s) for s in SIZES]
    frames[-1].save(
        OUT,
        format="ICO",
        sizes=[(s, s) for s in SIZES],
        append_images=frames[:-1],
    )
    # A PNG next to it is handy for docs and the About dialog.
    render(256).save(OUT.with_suffix(".png"))
    print(f"wrote {OUT} ({OUT.stat().st_size} bytes, sizes={SIZES})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
