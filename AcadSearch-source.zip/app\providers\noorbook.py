"""Noor-Book — Arabic books aggregator.

https://www.noor-book.com

The site dropped its old ``/search`` page; a query now goes to the home page as
``/?search_for=...`` and comes back as server-rendered result cards. Each card
only links to a landing page, but the landing page's own "download" button is a
short three-request handshake that ends in a real PDF URL, so the top few hits
can be offered as files instead of read-only links.
"""

from __future__ import annotations

import json
import random
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote, urljoin

from app.core.text_utils import clean_text, normalise_language, truncate_words
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target


BASE = "https://www.noor-book.com"
SEARCH_URL = f"{BASE}/"
MAX_RESOLVED = 3

#: Every result card starts with this wrapper; splitting on it is sturdier
#: than trying to balance the nested ``div`` elements.
_CARD_SPLIT = re.compile(r'<div\s+class="book-restult"', re.I)
#: ``<a href="/كتاب-....-pdf"><h3 itemprop="name">TITLE</h3></a>``
_TITLE_RE = re.compile(
    r'href="([^"]+)"[^>]*>\s*<h3\s+itemprop=["\']name["\'][^>]*>(.*?)</h3>',
    re.S | re.I,
)
_AUTHOR_BLOCK_RE = re.compile(
    r'<span\s+itemprop=["\']author["\'][^>]*>(.*?)</span>', re.S | re.I
)
_AUTHOR_NAME_RE = re.compile(
    r'<p\s+itemprop=["\']name["\'][^>]*>(.*?)</p>', re.S | re.I
)
_COVER_RE = re.compile(
    r'<img[^>]+itemprop=["\']image["\'][^>]*\bsrc=["\']([^"\']+)["\']', re.I
)
_TAG_RE = re.compile(r"<[^>]+>")
_ARABIC_RE = re.compile(r"[\u0600-\u06FF]")


def _plain(value: str) -> str:
    return clean_text(_TAG_RE.sub(" ", value or ""))


def _js_var(html: str, name: str) -> str:
    match = re.search(rf"{re.escape(name)}\s*=\s*'([^']+)'", html)
    return match.group(1) if match else ""


def _unique_id() -> str:
    """Mirror the site's ``uniqueID()`` cache-buster (four hex chunks + digits)."""
    chunks = "".join(f"{random.randrange(0x10000):04x}" for _ in range(4))
    return chunks + str(int(5828365 * random.random() + 4584))


@register
class NoorBookProvider(BaseProvider):
    provider_id = "noorbook"
    display_name = "Noor-Book (كتب عربية)"
    categories = (Category.BOOK,)
    weight = 16
    homepage = BASE

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        text = (query.text or "").strip()
        if not text:
            return []

        try:
            html = self.http.get_text(
                SEARCH_URL,
                params={"search_for": text},
                provider=self.provider_id,
                cancel=cancel,
            )
        except Exception:
            return []

        results = self._parse_cards(html)
        if cancel is not None and cancel.is_set():
            return results[: query.per_source]

        self._attach_pdfs(results, cancel)
        return results[: query.per_source]

    # -- search page ----------------------------------------------------
    def _parse_cards(self, html: str) -> list[Result]:
        results: list[Result] = []
        seen: set[str] = set()

        for chunk in _CARD_SPLIT.split(html)[1:]:
            title_match = _TITLE_RE.search(chunk)
            if not title_match:
                continue
            href, raw_title = title_match.group(1), title_match.group(2)
            title = _plain(raw_title)
            if not title:
                continue
            # The search page also lists review and quote pages; only the book
            # cards end in "-pdf" and lead to a real landing page.
            path = href.split("?", 1)[0].rstrip("/").lower()
            if not path.endswith("-pdf"):
                continue

            landing = urljoin(BASE + "/", href)
            if landing in seen:
                continue
            seen.add(landing)

            authors: list[str] = []
            for block in _AUTHOR_BLOCK_RE.findall(chunk):
                for name in _AUTHOR_NAME_RE.findall(block):
                    author = _plain(name)
                    if author and author not in authors:
                        authors.append(author)

            cover = ""
            cover_match = _COVER_RE.search(chunk)
            if cover_match:
                cover = urljoin(BASE + "/", cover_match.group(1))

            language = "ar" if _ARABIC_RE.search(title) else "en"
            results.append(
                Result(
                    category=Category.BOOK,
                    title=title,
                    source=self.provider_id,
                    authors=authors[:10],
                    year=None,
                    abstract=truncate_words("", 250),
                    venue="Noor-Book",
                    publisher="Noor-Book",
                    language=normalise_language(language),
                    subjects=[],
                    identifiers={"source": self.provider_id},
                    access=Access.LANDING,
                    downloads=[
                        target(landing, DownloadFormat.HTML, label="Noor-Book", open_access=True)
                    ],
                    landing_url=landing,
                    cover_url=cover or None,
                    item_type="Book",
                    raw={"landing_url": landing},
                )
            )
        return results

    # -- landing page -> real PDF --------------------------------------
    def _attach_pdfs(self, results: list[Result], cancel: threading.Event | None) -> None:
        """Resolve the top hits in parallel; the handshake costs three requests."""
        if not results:
            return
        limit = min(MAX_RESOLVED, len(results))
        candidates = results[:limit]
        with ThreadPoolExecutor(max_workers=limit, thread_name_prefix="noor") as pool:
            futures = {
                pool.submit(self._resolve_pdf, item.landing_url, cancel): item
                for item in candidates
            }
            for future in as_completed(futures):
                item = futures[future]
                try:
                    pdf = future.result()
                except Exception:
                    pdf = None
                if not pdf:
                    continue
                item.downloads = [
                    target(pdf, DownloadFormat.PDF, label="PDF (Noor-Book)", open_access=True),
                    target(
                        item.landing_url,
                        DownloadFormat.HTML,
                        label="Noor-Book",
                        open_access=True,
                    ),
                ]
                item.access = Access.DOWNLOAD

    def _resolve_pdf(self, landing: str, cancel: threading.Event | None) -> str | None:
        if not landing:
            return None
        try:
            html = self.http.get_text(
                landing,
                provider=self.provider_id,
                use_cache=False,
                cancel=cancel,
            )
        except Exception:
            return None

        csrf = _js_var(html, "csrf_token")
        crypto = _js_var(html, "crypto_token")
        book_hash = _js_var(html, "book_hash")
        signed_hash = _js_var(html, "b_h")
        if not (csrf and crypto and book_hash and signed_hash):
            return None

        headers = {
            "X-Requested-With": "XMLHttpRequest",
            # Header values must survive latin-1: the Arabic path has to be
            # percent-encoded or requests refuses to send the request.
            "Referer": quote(landing, safe=":/%"),
        }
        try:
            raw = self.http.post_text(
                f"{BASE}/Verification/check_user?o={_unique_id()}",
                data={"csrf_token": csrf, "book_hash": signed_hash, "_": crypto, "ls": ""},
                headers=headers,
                provider=self.provider_id,
                cancel=cancel,
            )
            info = json.loads(raw) if raw.lstrip().startswith("{") else {}
        except Exception:
            info = {}

        token = str(info.get("osf") or csrf)
        session = str(info.get("ls") or "")
        try:
            links = self.http.post_text(
                f"{BASE}/book/get_download_links?o={_unique_id()}",
                data={"book_hash": book_hash, "csrf_token": token, "_": crypto, "ls": session},
                headers=headers,
                provider=self.provider_id,
                cancel=cancel,
            )
        except Exception:
            return None

        match = re.search(
            r"""href=["'](/book/internal_download/[^"']+)["']""", links
        )
        if not match:
            return None
        return urljoin(BASE + "/", match.group(1))
