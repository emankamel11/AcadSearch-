"""Hindawi — open-access Arabic and English books.

https://www.hindawi.org used to expose a JSON search API; that host now
redirects to https://www.safahat.org, whose search is an HTML form. The book
pages still serve the original Hindawi files, and every book id resolves to a
free PDF/EPUB under ``downloads.hindawi.org``.
"""

from __future__ import annotations

import re
import threading
from urllib.parse import quote

from app.core.text_utils import clean_text, normalise_language
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target


SEARCH_BASE = "https://www.safahat.org/search"
BOOK_BASE = "https://www.safahat.org/books"
DOWNLOADS_BASE = "https://downloads.hindawi.org/books"

#: ``<li><a href='/books/81514680/'>بداية ونهاية</a> &middot; بقلم <a ...>نجيب محفوظ</a></li>``
_CARD_RE = re.compile(
    r"<li>\s*<a\s+href=['\"]/books/(\d+)/['\"][^>]*>(.*?)</a>(.*?)</li>",
    re.S | re.I,
)
_AUTHOR_RE = re.compile(
    r"<a\s+href=['\"]/contributors/[^'\"]*['\"][^>]*>(.*?)</a>",
    re.S | re.I,
)
_TAG_RE = re.compile(r"<[^>]+>")
_ARABIC_RE = re.compile(r"[\u0600-\u06FF]")


def _plain(value: str) -> str:
    return clean_text(_TAG_RE.sub(" ", value or ""))


def _dotted(text: str) -> str:
    """Safahat spells a multi-word query with dots: ``بداية.ونهاية``."""
    return ".".join(part for part in re.split(r"\s+", text.strip()) if part)


@register
class HindawiProvider(BaseProvider):
    provider_id = "hindawi"
    display_name = "Hindawi / صفحات (كتب مفتوحة)"
    categories = (Category.BOOK,)
    weight = 18
    homepage = "https://www.safahat.org"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        text = (query.text or "").strip()
        if not text:
            return []

        wanted = max(1, min(query.per_source, 40))
        results: list[Result] = []
        seen: set[str] = set()

        for mode in self._modes(query.field):
            if len(results) >= wanted:
                break
            if cancel is not None and cancel.is_set():
                break
            url = f"{SEARCH_BASE}/{mode}/{quote(_dotted(text), safe='')}/"
            try:
                html = self.http.get_text(
                    url,
                    provider=self.provider_id,
                    cancel=cancel,
                )
            except Exception:
                continue
            for result in self._parse(html):
                book_id = result.identifiers.get("book_id", "")
                if book_id and book_id in seen:
                    continue
                if book_id:
                    seen.add(book_id)
                results.append(result)
                if len(results) >= wanted:
                    break

        return results

    @staticmethod
    def _modes(field: str) -> tuple[str, ...]:
        if field == "author":
            return ("contributor",)
        if field == "title":
            return ("title",)
        # "any": exact title first, then the author index. The keyword index
        # matches book descriptions, which produces a lot of noise for a
        # novel title and is covered by the other book sources.
        return ("title", "contributor")

    def _parse(self, html: str) -> list[Result]:
        start = html.find("نتائج البحث")
        end = html.find("<!--searchResults-->")
        if start != -1 and end > start:
            html = html[start:end]

        results: list[Result] = []
        for match in _CARD_RE.finditer(html):
            book_id = match.group(1)
            title = _plain(match.group(2))
            if not title:
                continue

            authors: list[str] = []
            for author in _AUTHOR_RE.findall(match.group(3) or ""):
                name = _plain(author)
                if name and name not in authors:
                    authors.append(name)

            landing = f"{BOOK_BASE}/{book_id}/"
            downloads = [
                target(
                    f"{DOWNLOADS_BASE}/{book_id}.pdf",
                    DownloadFormat.PDF,
                    label="PDF (Hindawi)",
                    open_access=True,
                ),
                target(
                    f"{DOWNLOADS_BASE}/{book_id}.epub",
                    DownloadFormat.EPUB,
                    label="EPUB (Hindawi)",
                    open_access=True,
                ),
            ]

            language = "ar" if _ARABIC_RE.search(title) else "en"
            results.append(
                Result(
                    category=Category.BOOK,
                    title=title,
                    source=self.provider_id,
                    authors=authors[:10],
                    year=None,
                    abstract="",
                    venue="Hindawi",
                    publisher="مؤسسة هنداوي",
                    language=normalise_language(language),
                    subjects=[],
                    identifiers={"source": self.provider_id, "book_id": book_id},
                    access=Access.DOWNLOAD,
                    downloads=downloads,
                    landing_url=landing,
                    item_type="Book",
                    raw={"book_id": book_id, "landing_url": landing},
                )
            )
        return results
