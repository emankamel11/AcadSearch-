"""Read bibliographic metadata out of a file that lives on the user's disk.

The file is read locally and never uploaded. Only strings the file already
carries are used -- the PDF Info dictionary / XMP packet, or the OOXML core
properties of a Word document -- because guessing an author or a year from the
body text produces a *wrong* citation, which is worse in a reference list than
an empty field the user can fill in.

Anything that cannot be read reliably is left blank and surfaced as an editable
field in the dialog. ``.doc`` (the pre-2007 binary format) is deliberately not
parsed: without Word or LibreOffice installed there is no dependable way to do
it, so only the file name is used as a starting point.
"""

from __future__ import annotations

import html
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from app.models import Category, Result

#: Extensions the "add a local file" dialog offers by default.
SUPPORTED_EXTENSIONS: tuple[str, ...] = (".pdf", ".docx", ".doc", ".odt")

_DC = "{http://purl.org/dc/elements/1.1/}"
_DCTERMS = "{http://purl.org/dc/terms/}"
_META = "{urn:oasis:names:tc:opendocument:xmlns:meta:1.0}"

#: Document kinds the dialog can produce, in display order.
KINDS: tuple[str, ...] = ("book", "article", "thesis", "chapter", "report", "dataset")

#: ``kind`` -> the loose item_type string the citation formatter buckets on.
_ITEM_TYPES: dict[str, str] = {
    "book": "Book",
    "article": "JournalArticle",
    "thesis": "Thesis",
    "chapter": "BookChapter",
    "report": "Report",
    "dataset": "Dataset",
}

_CATEGORY_FOR: dict[str, Category] = {
    "book": Category.BOOK,
    "article": Category.ARTICLE,
    "thesis": Category.RESEARCH,
    "chapter": Category.BOOK,
    "report": Category.RESEARCH,
    "dataset": Category.RESEARCH,
}


def is_supported(path: str | Path) -> bool:
    return Path(path).suffix.lower() in SUPPORTED_EXTENSIONS


def file_filter() -> str:
    """A Qt file-dialog filter listing the formats we can read."""
    return (
        "Documents (*.pdf *.docx *.doc *.odt);;"
        "PDF (*.pdf);;"
        "Word (*.docx *.doc);;"
        "OpenDocument (*.odt);;"
        "All files (*)"
    )


def extract_result(path: str | Path, kind: str | None = None) -> Result:
    """Build a :class:`Result` from ``path``.

    ``kind`` overrides the guessed document kind. Missing metadata is left
    empty rather than invented.
    """
    p = Path(path)
    suffix = p.suffix.lower()

    title = ""
    authors: list[str] = []
    year: int | None = None
    publisher = ""
    doi = ""

    try:
        if suffix == ".pdf":
            title, authors, year, publisher = _pdf_metadata(p)
        elif suffix == ".docx":
            title, authors, year, publisher = _docx_metadata(p)
        elif suffix == ".odt":
            title, authors, year, publisher = _odt_metadata(p)
    except (OSError, zipfile.BadZipFile, ET.ParseError, ValueError):
        title, authors, year, publisher = "", [], None, ""

    resolved_kind = kind or _guess_kind(p, title)
    metadata_title = _clean(title)
    title = metadata_title or _title_from_filename(p)
    authors = [author for author in authors if not _is_device_author(author)]

    result = build_result(
        p,
        resolved_kind,
        title=title,
        authors=authors,
        year=year,
        venue=publisher,
        doi=doi,
    )
    # The dialog uses this to tell a real title from the file-name fallback, so
    # a later DOI/ISBN lookup may replace the placeholder but never a title the
    # user typed.
    result.raw["title_source"] = "metadata" if metadata_title else "filename"
    return result


def build_result(
    path: str | Path,
    kind: str,
    *,
    title: str,
    authors: list[str],
    year: int | None,
    venue: str,
    doi: str = "",
    editors: list[str] | None = None,
    pages: int | None = None,
    volume: str = "",
    issue: str = "",
) -> Result:
    """Assemble a :class:`Result` from fields the user has confirmed.

    Keeping the kind -> category/item_type mapping here means the dialog and
    the extractor can never disagree about what a "book" is.
    """
    p = Path(path)
    identifiers: dict[str, str] = {"local_path": str(p.resolve())}
    if doi:
        identifiers["doi"] = doi.strip()

    return Result(
        category=_CATEGORY_FOR.get(kind, Category.BOOK),
        title=_clean(title),
        source="local",
        authors=[a for a in (authors or []) if a and a.strip()],
        year=year,
        venue=(venue or "").strip(),
        publisher=(venue or "").strip(),
        editors=[e for e in (editors or []) if e and e.strip()],
        pages=pages,
        volume=volume,
        issue=issue,
        item_type=_ITEM_TYPES.get(kind, "Book"),
        identifiers=identifiers,
        raw={"kind": kind, "local_path": str(p.resolve())},
    )


def guess_kind(path: str | Path) -> str:
    return _guess_kind(Path(path), "")


def _guess_kind(path: Path, title: str) -> str:
    """A cautious first guess; the dialog lets the user correct it."""
    blob = f"{path.stem} {title}".lower()
    if any(w in blob for w in ("thèse", "these", "thesis", "dissertation", "doctorat")):
        return "thesis"
    if any(w in blob for w in ("article", "journal", "review", "paper")):
        return "article"
    if any(w in blob for w in ("chapitre", "chapter")):
        return "chapter"
    return "book"


def _title_from_filename(path: Path) -> str:
    stem = re.sub(r"[_]+", " ", path.stem)
    stem = re.sub(r"\s+", " ", stem).strip()
    return stem or path.name


def _clean(value: str) -> str:
    text = html.unescape(value or "")
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


_DOI_RE = re.compile(r"10\.\d{4,9}/[-._;()/:A-Za-z0-9]+", re.IGNORECASE)
_ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def find_doi(text: str) -> str:
    """The first DOI in a block of text, without trailing punctuation."""
    for match in _DOI_RE.finditer(text or ""):
        doi = match.group(0).rstrip(".,;:'\"")
        while doi.endswith(")") and doi.count(")") > doi.count("("):
            doi = doi[:-1]
        if doi.lower().startswith("10."):
            return doi
    return ""


def find_isbn(text: str) -> str:
    """The first string that passes an ISBN-10/13 checksum, digits only.

    Arabic-Indic digits are folded to ASCII first: an Arabic book's copyright
    page may print the ISBN with them even though the barcode uses ASCII.
    """
    folded = (text or "").translate(_ARABIC_DIGITS)
    for match in re.finditer(r"[0-9][0-9\-\s]{8,16}[0-9Xx]", folded):
        candidate = re.sub(r"[^0-9Xx]", "", match.group(0)).upper()
        if _valid_isbn(candidate):
            return candidate
    return ""


def _valid_isbn(value: str) -> bool:
    if len(value) == 13 and value.isdigit():
        total = sum(
            int(digit) * (1 if index % 2 == 0 else 3)
            for index, digit in enumerate(value)
        )
        return total % 10 == 0
    if len(value) == 10:
        if not value[:9].isdigit() or not (value[9].isdigit() or value[9] == "X"):
            return False
        digits = [int(char) for char in value[:9]]
        digits.append(10 if value[9] == "X" else int(value[9]))
        return sum((10 - index) * digit for index, digit in enumerate(digits)) % 11 == 0
    return False


def text_layer(path: str | Path, max_pages: int = 3, max_chars: int = 40000) -> str:
    """The embedded text layer of the first PDF pages, or "" when there is none.

    A scanned book often still carries the invisible OCR layer a scanner or an
    archive added. Reading it lets us find a DOI or ISBN *without* running OCR;
    an image-only scan returns "" and the dialog stays editable. The page and
    character caps keep a huge file from stalling the window.
    """
    p = Path(path)
    if p.suffix.lower() != ".pdf":
        return ""
    try:
        from pypdf import PdfReader
    except Exception:  # noqa: BLE001 - pypdf is optional at runtime
        return ""
    try:
        reader = PdfReader(str(p))
        if getattr(reader, "is_encrypted", False):
            try:
                if reader.decrypt("") == 0:
                    return ""
            except Exception:  # noqa: BLE001 - a DRM-locked file has no layer
                return ""
        pages = reader.pages
        chunks: list[str] = []
        total = 0
        for index in range(min(max_pages, len(pages))):
            try:
                page_text = pages[index].extract_text() or ""
            except Exception:  # noqa: BLE001 - one bad page must not stop the rest
                page_text = ""
            chunks.append(page_text)
            total += len(page_text)
            if total >= max_chars:
                break
        return "\n".join(chunks)[:max_chars]
    except Exception:  # noqa: BLE001 - a corrupt PDF simply has no text layer
        return ""


def document_text(path: str | Path, max_chars: int = 400_000) -> str:
    """The readable body text of a PDF/DOCX/ODT file, for the assistant.

    Unlike :func:`text_layer`, which stops after a few pages because it is only
    hunting for an identifier, this walks the whole file: a book's summary has
    to see more than its first three pages. The cap keeps a runaway file from
    exhausting memory; it is far above a normal book's length.
    """
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix == ".pdf":
        return text_layer(p, max_pages=10_000, max_chars=max_chars)
    if suffix == ".docx":
        return _docx_text(p, max_chars)
    if suffix == ".odt":
        return _odt_text(p, max_chars)
    return ""


def _docx_text(path: Path, max_chars: int) -> str:
    try:
        import zipfile
        from xml.etree import ElementTree as ET

        with zipfile.ZipFile(path) as archive:
            xml = archive.read("word/document.xml")
        root = ET.fromstring(xml)
    except Exception:  # noqa: BLE001 - a missing/corrupt part means no text
        return ""
    namespace = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    lines: list[str] = []
    total = 0
    for paragraph in root.iter(namespace + "p"):
        text = "".join(node.text or "" for node in paragraph.iter(namespace + "t"))
        if not text.strip():
            continue
        lines.append(text)
        total += len(text) + 1
        if total >= max_chars:
            break
    return "\n".join(lines)[:max_chars]


def _odt_text(path: Path, max_chars: int) -> str:
    try:
        import zipfile
        from xml.etree import ElementTree as ET

        with zipfile.ZipFile(path) as archive:
            xml = archive.read("content.xml")
        root = ET.fromstring(xml)
    except Exception:  # noqa: BLE001 - a missing/corrupt part means no text
        return ""
    namespace = "{urn:oasis:names:tc:opendocument:xmlns:text:1.0}"
    lines: list[str] = []
    total = 0
    for paragraph in root.iter():
        if paragraph.tag not in (namespace + "p", namespace + "h"):
            continue
        text = "".join(paragraph.itertext())
        if not text.strip():
            continue
        lines.append(text)
        total += len(text) + 1
        if total >= max_chars:
            break
    return "\n".join(lines)[:max_chars]


#: Default "/Author" values written by scanners, office software and Windows
#: accounts. They are not authors; citing "TOSHIBA" or "Microsoft Office User"
#: is worse than leaving the field for the reader to fill.
_DEVICE_AUTHORS = {
    "toshiba", "hp", "dell", "lenovo", "samsung", "epson", "ricoh", "xerox",
    "brother", "kyocera", "lexmark", "plustek", "visioneer", "kodak", "nikon",
    "olympus", "fujitsu", "panasonic", "minolta", "konica", "scanner",
    "administrator", "admin", "user", "owner", "pc", "home", "computer",
    "unknown", "default", "windows", "microsoft", "adobe", "acrobat",
    "libreoffice", "openoffice", "writer", "word", "microsoft office user",
    "windows user", "home user", "pc user", "unknown author",
    "microsoft corporation", "adobe acrobat", "adobe systems",
}


def _is_device_author(name: str) -> bool:
    value = re.sub(r"\s+", " ", name or "").strip().lower().strip(" .,")
    return not value or value.isdigit() or value in _DEVICE_AUTHORS


def _split_authors(value: str) -> list[str]:
    """Turn a compound author string into a list.

    Handles the two conventions actually found in PDF/Word metadata:
    ``"Doe, J.; Smith, K."`` and ``"John Doe and Jane Smith"``.
    """
    value = _clean(value)
    if not value:
        return []
    if ";" in value:
        parts = value.split(";")
    elif " and " in value.lower():
        parts = re.split(r"\s+and\s+", value, flags=re.IGNORECASE)
    else:
        parts = [value]
    return [part.strip(" ,;") for part in parts if part.strip(" ,;")]


def _year(value: str) -> int | None:
    match = re.search(r"(1[5-9]\d{2}|20\d{2}|21\d{2})", value or "")
    if not match:
        return None
    year = int(match.group(1))
    return year if 1400 <= year <= 2200 else None


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------
def _pdf_metadata(path: Path) -> tuple[str, list[str], int | None, str]:
    data = path.read_bytes()
    text = data.decode("latin-1", "ignore")

    title = _xmp_text(text, "dc:title") or _pdf_info_string(text, "Title")
    creators = _xmp_list(text, "dc:creator") or _split_authors(
        _pdf_info_string(text, "Author")
    )
    year = _year(_xmp_text(text, "dc:date") or _xmp_text(text, "xmp:CreateDate")
                 or _pdf_info_string(text, "CreationDate"))
    # ``/Producer`` names the software that wrote the PDF (Word, LaTeX, a
    # scanner), not a publisher. Using it fills every reference with
    # "Microsoft Word" or "pypdf", so only an explicit XMP publisher counts.
    publisher = _xmp_text(text, "dc:publisher")
    return title, creators, year, publisher


def _xmp_block(text: str, tag: str) -> str:
    match = re.search(
        rf"<{re.escape(tag)}\b[^>]*>(.*?)</{re.escape(tag)}\s*>", text, re.S | re.I
    )
    return match.group(1) if match else ""


def _xmp_text(text: str, tag: str) -> str:
    block = _xmp_block(text, tag)
    if not block:
        return ""
    li = re.search(r"<rdf:li\b[^>]*>(.*?)</rdf:li\s*>", block, re.S | re.I)
    return _clean(li.group(1) if li else block)


def _xmp_list(text: str, tag: str) -> list[str]:
    block = _xmp_block(text, tag)
    if not block:
        return []
    items = re.findall(r"<rdf:li\b[^>]*>(.*?)</rdf:li\s*>", block, re.S | re.I)
    values = [_clean(item) for item in items]
    return [v for v in values if v]


def _pdf_info_string(text: str, key: str) -> str:
    literal = re.search(
        rf"/{re.escape(key)}\s*\(((?:\\.|[^\\()])*)\)", text, re.S
    )
    if literal:
        return _decode_pdf_string(_unescape_pdf(literal.group(1)))
    hexed = re.search(rf"/{re.escape(key)}\s*<([0-9A-Fa-f\s]+)>", text)
    if hexed:
        raw = re.sub(r"\s+", "", hexed.group(1))
        try:
            return _decode_pdf_string(bytes.fromhex(raw))
        except ValueError:
            return ""
    return ""


def _unescape_pdf(value: str) -> str:
    out: list[str] = []
    i = 0
    length = len(value)
    while i < length:
        char = value[i]
        if char == "\\" and i + 1 < length:
            nxt = value[i + 1]
            if nxt in "()\\":
                out.append(nxt)
                i += 2
                continue
            simple = {"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f"}
            if nxt in simple:
                out.append(simple[nxt])
                i += 2
                continue
            if nxt.isdigit():
                octal = re.match(r"[0-7]{1,3}", value[i + 1 :])
                if octal:
                    out.append(chr(int(octal.group(0), 8)))
                    i += 1 + len(octal.group(0))
                    continue
            out.append(nxt)
            i += 2
            continue
        out.append(char)
        i += 1
    return "".join(out)


def _decode_pdf_string(value: str | bytes) -> str:
    """PDF strings are PDFDocEncoding or UTF-16BE, never UTF-8."""
    if isinstance(value, str):
        try:
            raw = value.encode("latin-1")
        except UnicodeEncodeError:
            return value
    else:
        raw = value
    if raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16", "ignore")
    if raw.startswith(b"\xff\xfe"):
        return raw.decode("utf-16-le", "ignore")
    return raw.decode("latin-1", "ignore")


# ---------------------------------------------------------------------------
# Word (.docx) and OpenDocument (.odt) -- both are zip archives
# ---------------------------------------------------------------------------
def _docx_metadata(path: Path) -> tuple[str, list[str], int | None, str]:
    title = ""
    authors: list[str] = []
    year: int | None = None
    publisher = ""

    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        if "docProps/core.xml" in names:
            root = ET.fromstring(archive.read("docProps/core.xml"))
            title = _element_text(root.find(f"{_DC}title"))
            authors = _split_authors(_element_text(root.find(f"{_DC}creator")))
            year = _year(
                _element_text(root.find(f"{_DCTERMS}created"))
                or _element_text(root.find(f"{_DCTERMS}modified"))
            )
        if "docProps/app.xml" in names:
            app_root = ET.fromstring(archive.read("docProps/app.xml"))
            publisher = _element_text(app_root.find(f"{{*}}Company")) or ""
        if not title and "word/document.xml" in names:
            title = _first_paragraph(archive.read("word/document.xml"))
    return title, authors, year, publisher


def _odt_metadata(path: Path) -> tuple[str, list[str], int | None, str]:
    with zipfile.ZipFile(path) as archive:
        if "meta.xml" not in archive.namelist():
            return "", [], None, ""
        root = ET.fromstring(archive.read("meta.xml"))
    title = _element_text(root.find(f".//{_DC}title"))
    authors = _split_authors(
        _element_text(root.find(f".//{_META}initial-creator"))
        or _element_text(root.find(f".//{_DC}creator"))
    )
    year = _year(_element_text(root.find(f".//{_DC}date")))
    # ``meta:generator`` is the software ("LibreOffice/7.5"), not a publisher.
    publisher = ""
    return title, authors, year, publisher


def _element_text(element) -> str:
    if element is None:
        return ""
    return _clean("".join(element.itertext()))


def _first_paragraph(xml_bytes: bytes) -> str:
    """The first non-empty Word paragraph, used only when no title is stored."""
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError:
        return ""
    namespace = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    for paragraph in root.iter(f"{namespace}p"):
        text = _clean("".join(node.text or "" for node in paragraph.iter(f"{namespace}t")))
        if text:
            return text
    return ""
