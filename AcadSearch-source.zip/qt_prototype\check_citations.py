"""Citation correctness (APA 7) and Enter-key behaviour.

Run: ``python -X utf8 qt_prototype/check_citations.py``

APA was the style that reached the clipboard wrong, so the expected strings are
written out literally instead of being recomputed with the same helpers -- a
test that reuses the formatter cannot catch a bug in the formatter.
"""

from __future__ import annotations

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))
sys.path.insert(0, str(_ROOT / "qt_prototype"))

from app.core.citation import format_citation  # noqa: E402
from app.models import Category, Result  # noqa: E402

FAILURES: list[str] = []


def check(label: str, actual, expected) -> None:
    if actual == expected:
        print(f"  ok   {label}")
    else:
        FAILURES.append(label)
        print(f"  FAIL {label}")
        print(f"    got     : {actual!r}")
        print(f"    expected: {expected!r}")


def apa(**kwargs) -> str:
    return format_citation(Result(category=Category.ARTICLE, **kwargs), "apa")


def n_authors(count: int) -> list[str]:
    """``count`` authors whose family names are LastA, LastB, ..."""
    return [f"Given{chr(65 + i)} Last{chr(65 + i)}" for i in range(count)]


def main() -> int:
    print("APA 7")
    check(
        "book needs its publisher",
        apa(title="Why Machines Learn", source="open_library", authors=[],
            year=2024, publisher="Penguin", item_type="book"),
        "(2024). *Why Machines Learn*. Penguin.",
    )
    check(
        "publisher falls back to the venue",
        apa(title="Cosmos", source="open_library", authors=["Isaac Newton"],
            year=1687, venue="Cambridge University Press", item_type="book"),
        "Newton, I. (1687). *Cosmos*. Cambridge University Press.",
    )
    check(
        "two authors use an ampersand before the last",
        apa(title="Artificial Intelligence: A Modern Approach",
            source="open_library", authors=["Stuart Russell", "Peter Norvig"],
            year=2021, publisher="Pearson", item_type="book"),
        "Russell, S., & Norvig, P. (2021). "
        "*Artificial Intelligence: A Modern Approach*. Pearson.",
    )
    check(
        "journal article: volume(issue), pages, DOI",
        apa(title="Deep learning", source="crossref",
            authors=["Yann LeCun", "Yoshua Bengio", "Geoffrey Hinton"],
            year=2015, venue="Nature", volume="521", issue="7553",
            pages="436-444", identifiers={"doi": "10.1038/nature14539"},
            item_type="journal-article"),
        "LeCun, Y., Bengio, Y., & Hinton, G. (2015). Deep learning. "
        "*Nature*, 521(7553), 436\u2013444. https://doi.org/10.1038/nature14539",
    )
    check(
        "page range uses an en dash",
        "436\u2013444" in apa(title="T", source="crossref", authors=["A B"],
                             year=2020, venue="J", pages="436-444",
                             item_type="journal-article"),
        True,
    )
    check(
        "eight authors are all written out (APA 7 allows twenty)",
        apa(title="Eight authors", source="crossref", authors=n_authors(8),
            year=2020, venue="Journal", item_type="journal-article"),
        "LastA, G., LastB, G., LastC, G., LastD, G., LastE, G., LastF, G., "
        "LastG, G., & LastH, G. (2020). Eight authors. *Journal*.",
    )
    check(
        "twelve authors do not collapse to et al.",
        ", et al." in apa(title="T", source="crossref",
                          authors=n_authors(12), year=2020, venue="Journal",
                          item_type="journal-article"),
        False,
    )
    check(
        "twenty-one authors become first nineteen, ellipsis, last author",
        apa(title="T", source="crossref", authors=n_authors(21), year=2020,
            venue="Journal", item_type="journal-article").split(". (2020)")[0],
        ", ".join(f"Last{chr(65 + i)}, G." for i in range(19))
        + ", ... LastU, G",
    )
    check(
        "surname particles stay in the surname",
        apa(title="Cosmos", source="open_library",
            authors=["Carl Ludwig van der Waals"], year=1920,
            publisher="Elsevier", item_type="book"),
        "van der Waals, C. L. (1920). *Cosmos*. Elsevier.",
    )
    check(
        "a book chapter is not formatted as a whole book",
        apa(title="A book chapter", source="openaire", authors=["Nora Editor"],
            year=2018, venue="Big Handbook", pages="45-60",
            item_type="book-chapter"),
        "Editor, N. (2018). A book chapter. In *Big Handbook* (pp. 45\u201360).",
    )
    check(
        "thesis names the degree and the university",
        apa(title="Apprentissage automatique", source="sudoc",
            authors=["Marie Dupont"], year=2022,
            venue="Universit\u00e9 de Paris", item_type="th\u00e8se"),
        "Dupont, M. (2022). *Apprentissage automatique* "
        "[\u0631\u0633\u0627\u0644\u0629 \u0645\u0627\u062c\u0633\u062a\u064a\u0631 \u0623\u0648 "
        "\u062f\u0643\u062a\u0648\u0631\u0627\u0647\u060c Universit\u00e9 de Paris].",
    )
    check(
        "unknown year prints n.d. and never n.d..",
        apa(title="An undated paper", source="crossref", authors=["Ali Hassan"],
            year=None, venue="Some Journal", item_type="journal-article"),
        "Hassan, A. (n.d.). An undated paper. *Some Journal*.",
    )
    check(
        "an article without a DOI keeps its URL",
        apa(title="Open paper", source="openaire", authors=["A B"], year=2022,
            venue="Journal", landing_url="https://example.org/paper",
            item_type="journal-article"),
        "B, A. (2022). Open paper. *Journal*. https://example.org/paper",
    )
    check(
        "a book reference does not end in a bare URL",
        apa(title="A book", source="open_library", authors=["A B"], year=2020,
            publisher="Pub", landing_url="https://example.org/book",
            item_type="book"),
        "B, A. (2020). *A book*. Pub.",
    )
    check(
        "an already inverted name is left alone",
        apa(title="T", source="crossref", authors=["van der Waals, C. L."],
            year=2020, venue="J", item_type="journal-article"),
        "van der Waals, C. L. (2020). T. *J*.",
    )

    print("Enter key")
    try:
        from PySide6.QtCore import Qt
        from PySide6.QtTest import QTest
        from PySide6.QtWidgets import QApplication, QDialogButtonBox

        from app.config import get_config
        from app.models import Access, DownloadFormat, DownloadTarget
        from qt_prototype import main_window
        from qt_prototype.preferences import PreferencesDialog

        app = QApplication.instance() or QApplication([])
        window = main_window.MainWindow()
        window.show()
        app.processEvents()

        fired: list[str] = []

        def probe(button, tag: str) -> None:
            """Replace the real slot: this test is about the key, not the network.

            A live download or citation would leave worker threads and HTTP
            requests running at interpreter exit, which is how the first version
            of this check hung instead of failing.
            """
            try:
                button.clicked.disconnect()
            except (RuntimeError, TypeError):
                pass
            # ``clicked`` passes ``checked`` as its first argument, so the tag
            # is captured in a closure rather than as a lambda default.
            button.clicked.connect(lambda _checked=False, t=tag: fired.append(t))

        probe(window.prefs_btn, "prefs")
        probe(window.search_btn, "search")

        page = window.pages[Category.BOOK]
        page.add(Result(
            category=Category.BOOK, title="book", source="open_library",
            authors=[], year=2020, access=Access.DOWNLOAD, item_type="book",
            downloads=[DownloadTarget(url="a.pdf", fmt=DownloadFormat.PDF,
                                      open_access=True)],
        ))
        app.processEvents()

        def press(widget, key) -> list[str]:
            fired.clear()
            widget.setFocus()
            app.processEvents()
            QTest.keyClick(widget, key)
            app.processEvents()
            return list(fired)

        check("Enter opens settings (the reported problem)",
              press(window.prefs_btn, Qt.Key_Return), ["prefs"])
        check("Space still opens settings",
              press(window.prefs_btn, Qt.Key_Space), ["prefs"])
        check("Enter searches exactly once",
              press(window.search_btn, Qt.Key_Return), ["search"])
        window.close()

        dialog = PreferencesDialog()
        dialog.show()
        app.processEvents()
        box = dialog.findChild(QDialogButtonBox)
        arabic = get_config().ui_language == "ar"
        check(
            "save and cancel carry the interface language",
            sorted(b.text() for b in box.buttons()),
            sorted(["\u062d\u0641\u0638", "\u0625\u0644\u063a\u0627\u0621"] if arabic
                   else ["Save", "Cancel"]),
        )
        check(
            "every key field has an accessible name",
            all(field.accessibleName() for field in
                (dialog.gb_key, dialog.s2_key, dialog.oa_email)),
            True,
        )
        dialog.gb_key.setFocus()
        app.processEvents()
        QTest.keyClick(dialog.gb_key, Qt.Key_Return)
        app.processEvents()
        check("Enter inside a key field saves and closes", dialog.result(), 1)
    except Exception as exc:  # pragma: no cover - environment problem
        FAILURES.append("GUI section")
        print(f"  FAIL GUI section raised {exc!r}")

    print()
    if FAILURES:
        print(f"{len(FAILURES)} FAILURE(S): {FAILURES}")
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())