"""OpenAlex — open catalogue of scholarly works with open-access locations.

Docs: https://docs.openalex.org
Free, no key required; adding ``mailto`` (Preferences → Network) joins the
polite pool and raises the rate limit roughly tenfold.
"""

from __future__ import annotations

import threading

from app.core.text_utils import (
    as_int,
    clean_text,
    extract_doi,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://api.openalex.org/works"

SELECT = (
    "id,doi,title,display_name,publication_year,language,type,cited_by_count,"
    "authorships,primary_location,best_oa_location,open_access,abstract_inverted_index,"
    "concepts,topics,primary_topic,ids,locations_count"
)

#: OpenAlex ``type`` values routed to the research/thesis tab.
RESEARCH_TYPES = {"dissertation", "dataset", "preprint", "report", "paratext", "other"}

#: OpenAlex monographs are books, not research outputs; they belong in the
#: Books tab and enrich it with peer-reviewed scholarly titles.
BOOK_TYPES = {"book", "book-chapter"}


@register
class OpenAlexProvider(BaseProvider):
    provider_id = "openalex"
    display_name = "OpenAlex"
    categories = (Category.BOOK, Category.ARTICLE, Category.RESEARCH)
    weight = 20
    requires_key = "openalex_key"
    homepage = "https://openalex.org"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        # A contact e-mail or a key puts the request in OpenAlex's polite pool,
        # which is both less throttled and allowed a bigger page. Nothing is
        # gained by asking for a large page anonymously: it gets cut back to 25.
        polite = bool(self.config.openalex_key or self.config.contact_email)
        params: dict[str, object] = {
            "search": query.text,
            "per-page": min(query.per_source, 100 if polite else 25),
            "select": SELECT,
        }
        # Polite pool: a contact e-mail (or key) is all that is required.
        if self.config.openalex_key:
            params["api_key"] = self.config.openalex_key
        if self.config.contact_email:
            params["mailto"] = self.config.contact_email
        if query.language and query.language != "any":
            params["filter"] = f"language:{query.language}"
        if query.year_from or query.year_to:
            low = query.year_from or 1000
            high = query.year_to or 3000
            existing = params.get("filter", "")
            year_part = f"from_publication_date:{low}-01-01,to_publication_date:{high}-12-31"
            params["filter"] = f"{existing},{year_part}" if existing else year_part

        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        works = payload.get("results") or []
        return [self._to_result(w) for w in works]

    # -- mapping ----------------------------------------------------------
    def _to_result(self, work: dict) -> Result:
        title = clean_text(work.get("display_name") or work.get("title"))
        work_type = clean_text(work.get("type")).lower()

        abstract = self._abstract(work.get("abstract_inverted_index"))
        authors = [
            clean_text((a.get("author") or {}).get("display_name"))
            for a in (work.get("authorships") or [])
            if a.get("author")
        ]
        authors = [a for a in authors if a]

        identifiers: dict[str, str] = {}
        doi = extract_doi(work.get("doi"))
        if doi:
            identifiers["doi"] = doi
        oa_id = clean_text(work.get("id"))
        if oa_id:
            identifiers["openalex"] = oa_id.rsplit("/", 1)[-1]
        for name, key in (("pmid", "pmid"), ("pmcid", "pmcid")):
            value = clean_text((work.get("ids") or {}).get(key))
            if value:
                identifiers[name] = value.rsplit("/", 1)[-1]

        location = work.get("primary_location") or {}
        # A bare URL is not a venue name; leave it empty rather than showing a link.
        venue = clean_text((location.get("source") or {}).get("display_name"))

        downloads = self._downloads(work)
        landing = clean_text(location.get("landing_page_url")) or (
            f"https://doi.org/{doi}" if doi else oa_id
        )

        topics = [
            clean_text(t.get("display_name"))
            for t in (work.get("topics") or [])[:5]
            if t.get("display_name")
        ] or [
            clean_text(c.get("display_name"))
            for c in (work.get("concepts") or [])[:5]
            if c.get("display_name")
        ]

        is_research = work_type in RESEARCH_TYPES
        if work_type in BOOK_TYPES:
            category = Category.BOOK
        elif is_research:
            category = Category.RESEARCH
        else:
            category = Category.ARTICLE

        (work.get("open_access") or {}).get("is_oa")
        return Result(
            category=category,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=as_int(work.get("publication_year")),
            abstract=abstract,
            venue=venue,
            language=normalise_language(clean_text(work.get("language"))),
            subjects=topics,
            identifiers=identifiers,
            access=Access.DOWNLOAD if downloads else (
                Access.LANDING if landing else Access.METADATA
            ),
            downloads=downloads,
            landing_url=landing,
            citations=as_int(work.get("cited_by_count")),
            item_type=work_type.replace("-", " ").title(),
            raw=work,
            # OA status is surfaced through the access chip, not the score.
        )

    @staticmethod
    def _downloads(work: dict) -> list:
        """Collect every open-access location, preferring PDF."""
        out: list = []
        seen: set[str] = set()
        candidates = []
        best = work.get("best_oa_location")
        if isinstance(best, dict):
            candidates.append(best)
        primary = work.get("primary_location")
        if isinstance(primary, dict):
            candidates.append(primary)
        for extra in (work.get("locations") or []):
            if isinstance(extra, dict):
                candidates.append(extra)

        for place in candidates:
            pdf_url = clean_text(place.get("pdf_url"))
            if pdf_url and pdf_url not in seen:
                seen.add(pdf_url)
                out.append(
                    target(
                        pdf_url,
                        DownloadFormat.PDF,
                        label=clean_text(place.get("version")) or "Open access PDF",
                        open_access=True,
                    )
                )
            landing = clean_text(place.get("landing_page_url"))
            if landing and landing not in seen and not pdf_url:
                seen.add(landing)
                out.append(
                    target(
                        landing,
                        DownloadFormat.HTML,
                        label=clean_text(place.get("version")) or "Source page",
                        open_access=True,
                    )
                )
            if len(out) >= 3:
                break
        return out

    @staticmethod
    def _abstract(inverted: dict | None) -> str:
        """OpenAlex ships abstracts as ``{word: [positions]}``; rebuild the text."""
        if not isinstance(inverted, dict) or not inverted:
            return ""
        positions: list[tuple[int, str]] = []
        for word, spots in inverted.items():
            if not isinstance(spots, list):
                continue
            for spot in spots:
                if isinstance(spot, int):
                    positions.append((spot, word))
        if not positions:
            return ""
        positions.sort(key=lambda pair: pair[0])
        return truncate_words(" ".join(word for _, word in positions), 600)
