"""Visual design for AcadSearch: colours, fonts and icons.

Two audiences share this one interface:

* a screen-reader user, who never sees any of it, and
* a sighted user, who needs it to look like a real program rather than a list
  of grey lines.

So nothing here may remove information. Colour is always decoration on top of
text that already says the same thing: the download badge says "متاح للتنزيل"
as well as being green, and the tab says "الكتب" as well as being brown. That
way the colours help a sighted user and cost a screen-reader user nothing.

Icons are painted here instead of taken from ``QStyle``, because the Windows
standard set is a different shape on every machine and looks borrowed. These are
drawn from paths, so they stay crisp at any DPI and identical everywhere.
"""

from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QIcon,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QPolygonF,
)

# --------------------------------------------------------------------------
# palette
# --------------------------------------------------------------------------

BG = "#eef1f5"
SURFACE = "#ffffff"
SURFACE_ALT = "#f7f9fb"
BORDER = "#c9d2dd"
BORDER_STRONG = "#9aa8b8"

INK = "#14181d"
INK_SOFT = "#4a5563"
INK_FAINT = "#6b7785"

PRIMARY = "#1a5fb4"
PRIMARY_DARK = "#14488a"
PRIMARY_SOFT = "#dbe8f9"

DANGER = "#b3261e"
DANGER_SOFT = "#fbe4e2"
SUCCESS = "#1c6b3c"
SUCCESS_SOFT = "#dff2e6"
WARNING = "#8a5a00"
WARNING_SOFT = "#fdf0d5"

FOCUS = "#0b57d0"

#: One accent per category, used for the tab, the card edge and the badge.
CATEGORY_COLORS: dict[str, tuple[str, str]] = {
    # category id: (strong, soft)
    "BOOK": ("#9a5b13", "#fbeedd"),
    "ARTICLE": ("#12657f", "#e0f2f8"),
    "RESEARCH": ("#5a3a9e", "#ece5fa"),
}

CATEGORY_ORDER = ("BOOK", "ARTICLE", "RESEARCH")


def category_colors(key: str) -> tuple[str, str]:
    return CATEGORY_COLORS.get(key, (PRIMARY, PRIMARY_SOFT))


def qcolor(value: str, alpha: int | None = None) -> QColor:
    col = QColor(value)
    if alpha is not None:
        col.setAlpha(alpha)
    return col


# --------------------------------------------------------------------------
# fonts
# --------------------------------------------------------------------------

UI_FAMILY = "Segoe UI"


def ui_font(size: int = 10, bold: bool = False) -> QFont:
    font = QFont(UI_FAMILY, size)
    font.setBold(bold)
    return font


def mono_font(size: int = 9) -> QFont:
    font = QFont("Consolas", size)
    font.setStyleHint(QFont.StyleHint.Monospace)
    return font


# --------------------------------------------------------------------------
# icon painting
# --------------------------------------------------------------------------

def _canvas(size: int) -> tuple[QPixmap, QPainter]:
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pm)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    return pm, painter


def _stroke(painter: QPainter, color: str, width: float, size: int) -> None:
    pen = QPen(qcolor(color))
    pen.setWidthF(width)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.BrushStyle.NoBrush)


def _draw_search(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.09, s)
    r = s * 0.27
    cx, cy = s * 0.44, s * 0.44
    painter.drawEllipse(QPointF(cx, cy), r, r)
    painter.drawLine(
        QPointF(cx + r * 0.72, cy + r * 0.72), QPointF(s * 0.86, s * 0.86)
    )


def _draw_clear(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.1, s)
    m = s * 0.28
    painter.drawLine(QPointF(m, m), QPointF(s - m, s - m))
    painter.drawLine(QPointF(s - m, m), QPointF(m, s - m))


def _draw_settings(painter: QPainter, s: int, c: str) -> None:
    """A gear: outer teeth plus a hub."""
    _stroke(painter, c, s * 0.08, s)
    import math

    cx = cy = s / 2
    outer = s * 0.36
    inner = s * 0.27
    path = QPainterPath()
    teeth = 8
    for i in range(teeth * 2):
        angle = math.pi * i / teeth
        radius = outer if i % 2 == 0 else inner
        point = QPointF(cx + radius * math.cos(angle), cy + radius * math.sin(angle))
        if i == 0:
            path.moveTo(point)
        else:
            path.lineTo(point)
    path.closeSubpath()
    painter.drawPath(path)
    painter.drawEllipse(QPointF(cx, cy), s * 0.13, s * 0.13)


def _draw_download(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.09, s)
    cx = s / 2
    # Arrow pointing down into a tray.
    painter.drawLine(QPointF(cx, s * 0.18), QPointF(cx, s * 0.56))
    painter.drawLine(QPointF(cx - s * 0.15, s * 0.41), QPointF(cx, s * 0.58))
    painter.drawLine(QPointF(cx + s * 0.15, s * 0.41), QPointF(cx, s * 0.58))
    tray = QPainterPath()
    tray.moveTo(s * 0.22, s * 0.62)
    tray.lineTo(s * 0.22, s * 0.8)
    tray.lineTo(s * 0.78, s * 0.8)
    tray.lineTo(s * 0.78, s * 0.62)
    painter.drawPath(tray)


def _draw_folder(painter: QPainter, s: int, c: str) -> None:
    """A closed folder, for the button that opens the downloads folder."""
    _stroke(painter, c, s * 0.09, s)
    path = QPainterPath()
    path.moveTo(s * 0.18, s * 0.76)
    path.lineTo(s * 0.18, s * 0.28)
    path.lineTo(s * 0.42, s * 0.28)
    path.lineTo(s * 0.50, s * 0.40)
    path.lineTo(s * 0.82, s * 0.40)
    path.lineTo(s * 0.82, s * 0.76)
    path.closeSubpath()
    painter.drawPath(path)


def _draw_citation(painter: QPainter, s: int, c: str) -> None:
    """Two quote marks, the universal citation glyph."""
    _stroke(painter, c, s * 0.085, s)
    for offset in (s * 0.30, s * 0.62):
        path = QPainterPath()
        path.moveTo(offset, s * 0.72)
        path.lineTo(offset, s * 0.44)
        path.cubicTo(offset, s * 0.24, offset + s * 0.13, s * 0.22, offset + s * 0.16, s * 0.30)
        path.cubicTo(offset + s * 0.10, s * 0.34, offset + s * 0.06, s * 0.40, offset + s * 0.06, s * 0.44)
        path.closeSubpath()
        painter.drawPath(path)
        painter.drawLine(
            QPointF(offset + s * 0.06, s * 0.44), QPointF(offset + s * 0.06, s * 0.72)
        )


def _draw_book(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.08, s)
    path = QPainterPath()
    path.moveTo(s * 0.5, s * 0.28)
    path.cubicTo(s * 0.42, s * 0.20, s * 0.24, s * 0.20, s * 0.18, s * 0.24)
    path.lineTo(s * 0.18, s * 0.76)
    path.cubicTo(s * 0.24, s * 0.72, s * 0.42, s * 0.72, s * 0.5, s * 0.80)
    path.cubicTo(s * 0.58, s * 0.72, s * 0.76, s * 0.72, s * 0.82, s * 0.76)
    path.lineTo(s * 0.82, s * 0.24)
    path.cubicTo(s * 0.76, s * 0.20, s * 0.58, s * 0.20, s * 0.5, s * 0.28)
    painter.drawPath(path)
    painter.drawLine(QPointF(s * 0.5, s * 0.28), QPointF(s * 0.5, s * 0.80))


def _draw_article(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.08, s)
    painter.drawRoundedRect(QRectF(s * 0.24, s * 0.18, s * 0.52, s * 0.64), s * 0.06, s * 0.06)
    for i, y in enumerate((0.34, 0.46, 0.58)):
        painter.drawLine(
            QPointF(s * 0.33, s * y), QPointF(s * (0.67 if i < 2 else 0.58), s * y)
        )


def _draw_research(painter: QPainter, s: int, c: str) -> None:
    """A flask: the research mark."""
    _stroke(painter, c, s * 0.08, s)
    path = QPainterPath()
    path.moveTo(s * 0.42, s * 0.16)
    path.lineTo(s * 0.42, s * 0.44)
    path.lineTo(s * 0.24, s * 0.78)
    path.cubicTo(s * 0.20, s * 0.85, s * 0.26, s * 0.86, s * 0.32, s * 0.86)
    path.lineTo(s * 0.68, s * 0.86)
    path.cubicTo(s * 0.74, s * 0.86, s * 0.80, s * 0.85, s * 0.76, s * 0.78)
    path.lineTo(s * 0.58, s * 0.44)
    path.lineTo(s * 0.58, s * 0.16)
    painter.drawPath(path)
    painter.drawLine(QPointF(s * 0.36, s * 0.16), QPointF(s * 0.64, s * 0.16))
    painter.drawLine(QPointF(s * 0.30, s * 0.66), QPointF(s * 0.70, s * 0.66))


def _draw_open(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.08, s)
    path = QPainterPath()
    path.moveTo(s * 0.50, s * 0.22)
    path.lineTo(s * 0.84, s * 0.22)
    path.lineTo(s * 0.84, s * 0.78)
    path.lineTo(s * 0.16, s * 0.78)
    path.lineTo(s * 0.16, s * 0.30)
    path.closeSubpath()
    painter.drawPath(path)
    painter.drawLine(
        QPointF(s * 0.34, s * 0.58), QPointF(s * 0.46, s * 0.46)
    )
    painter.drawLine(
        QPointF(s * 0.34, s * 0.46), QPointF(s * 0.46, s * 0.58)
    )


def _draw_borrow(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.08, s)
    painter.drawEllipse(QPointF(s / 2, s * 0.42), s * 0.22, s * 0.22)
    arc = QPainterPath()
    arc.moveTo(s * 0.18, s * 0.84)
    arc.cubicTo(s * 0.24, s * 0.62, s * 0.76, s * 0.62, s * 0.82, s * 0.84)
    painter.drawPath(arc)


def _draw_pin(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.08, s)
    painter.drawEllipse(QPointF(s / 2, s * 0.42), s * 0.18, s * 0.18)
    painter.drawLine(QPointF(s / 2, s * 0.60), QPointF(s / 2, s * 0.84))


def _draw_clock(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.08, s)
    painter.drawEllipse(QPointF(s / 2, s / 2), s * 0.34, s * 0.34)
    painter.drawLine(QPointF(s / 2, s * 0.30), QPointF(s / 2, s / 2))
    painter.drawLine(QPointF(s / 2, s / 2), QPointF(s * 0.66, s * 0.58))


def _draw_info(painter: QPainter, s: int, c: str) -> None:
    _stroke(painter, c, s * 0.08, s)
    painter.drawEllipse(QPointF(s / 2, s / 2), s * 0.34, s * 0.34)
    painter.setBrush(QBrush(qcolor(c)))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.drawEllipse(QPointF(s / 2, s * 0.28), s * 0.05, s * 0.05)
    painter.drawLine(QPointF(s / 2, s * 0.42), QPointF(s / 2, s * 0.72))


_PAINTERS = {
    "search": _draw_search,
    "clear": _draw_clear,
    "settings": _draw_settings,
    "download": _draw_download,
    "folder": _draw_folder,
    "citation": _draw_citation,
    "book": _draw_book,
    "article": _draw_article,
    "research": _draw_research,
    "open": _draw_open,
    "borrow": _draw_borrow,
    "pin": _draw_pin,
    "clock": _draw_clock,
    "info": _draw_info,
}


def icon(name: str, color: str = INK_SOFT, size: int = 20) -> QIcon:
    """A painted icon. Unknown names give a blank icon rather than raising."""
    painter_for = _PAINTERS.get(name)
    result = QIcon()
    if painter_for is None:
        return result
    # Two sizes: one for the 1x display, one so HiDPI screens stay sharp.
    for scale in (1, 2):
        px = size * scale
        pm, painter = _canvas(px)
        painter_for(painter, px, color)
        painter.end()
        result.addPixmap(
            pm,
            QIcon.Mode.Normal,
            QIcon.State.Off,
        )
    return result


def placeholder_icon(category_key: str, size: int = 56) -> QIcon:
    """The coloured stand-in shown while a cover loads, or when there is none."""
    strong, soft = category_colors(category_key)
    name = {"BOOK": "book", "ARTICLE": "article", "RESEARCH": "research"}.get(
        category_key, "article"
    )
    result = QIcon()
    for scale in (1, 2):
        px = size * scale
        pm, painter = _canvas(px)
        painter.setBrush(QBrush(qcolor(soft)))
        painter.setPen(QPen(qcolor(BORDER)))
        radius = px * 0.10
        painter.drawRoundedRect(QRectF(1, 1, px - 2, px - 2), radius, radius)
        _PAINTERS[name](painter, px, strong)
        painter.end()
        result.addPixmap(pm, QIcon.Mode.Normal, QIcon.State.Off)
    return result


# --------------------------------------------------------------------------
# stylesheet
# --------------------------------------------------------------------------

def stylesheet(font_size: int = 10) -> str:
    """The whole-app look.

    Kept in one place so Preferences can rebuild it when the user changes the
    font size, instead of each widget setting its own font and drifting.
    """
    pad = font_size + 4
    return f"""
    QMainWindow, QWidget {{
        background: {BG};
        color: {INK};
        font-family: "{UI_FAMILY}";
        font-size: {font_size}pt;
    }}

    /* ---- header ---- */
    #Header {{
        background: {PRIMARY};
        border: none;
    }}
    #HeaderTitle {{
        color: #ffffff;
        font-size: {font_size + 5}pt;
        font-weight: 700;
        background: transparent;
    }}
    #HeaderSubtitle {{
        color: #d3e3f7;
        font-size: {font_size}pt;
        background: transparent;
    }}

    /* ---- search row ---- */
    #SearchBox {{
        background: {SURFACE};
        border: 2px solid {BORDER_STRONG};
        border-radius: 8px;
        padding: {pad}px {pad + 4}px;
        font-size: {font_size + 2}pt;
        selection-background-color: {PRIMARY};
        selection-color: #ffffff;
    }}
    #SearchBox:focus {{
        border: 3px solid {FOCUS};
        padding: {pad - 1}px {pad + 3}px;
    }}
    #SearchBox::placeholder {{ color: {INK_FAINT}; }}

    QPushButton {{
        background: {SURFACE};
        color: {INK};
        border: 2px solid {BORDER_STRONG};
        border-radius: 8px;
        padding: {pad}px {pad + 6}px;
        font-size: {font_size + 1}pt;
        font-weight: 600;
        min-height: {font_size + 12}px;
    }}
    QPushButton:hover {{ background: {PRIMARY_SOFT}; border-color: {PRIMARY}; }}
    QPushButton:pressed {{ background: #c5daf5; }}
    QPushButton:disabled {{ color: {INK_FAINT}; border-color: {BORDER}; background: {SURFACE_ALT}; }}

    #PrimaryButton {{
        background: {PRIMARY};
        color: #ffffff;
        border: 2px solid {PRIMARY_DARK};
    }}
    #PrimaryButton:hover {{ background: #1f6fc9; border-color: {PRIMARY_DARK}; }}
    #PrimaryButton:pressed {{ background: {PRIMARY_DARK}; }}

    #DownloadButton {{
        background: {SUCCESS_SOFT};
        color: #10492a;
        border: 2px solid {SUCCESS};
    }}
    #DownloadButton:hover {{ background: #cfeada; }}

    #CitationButton {{
        background: {PRIMARY_SOFT};
        color: #123a6b;
        border: 2px solid {PRIMARY};
    }}
    #CitationButton:hover {{ background: #cfe0f7; }}

    /* A visible focus ring is the only way a keyboard user knows where they
       are. It is deliberately thick, because a thin ring is invisible to
       people with low vision. */
    QPushButton:focus, QLineEdit:focus, QListWidget:focus, QTabBar:focus,
    QTabWidget:focus, QComboBox:focus, QDialogButtonBox:focus {{
        outline: none;
        border: 3px solid {FOCUS};
    }}
    QPushButton:focus-visible, QTabBar::tab:focus {{
        border: 3px solid {FOCUS};
    }}

    /* ---- status ---- */
    #StatusLabel {{
        background: {SURFACE};
        border: 1px solid {BORDER};
        border-left: 6px solid {PRIMARY};
        border-radius: 6px;
        padding: {pad}px {pad + 2}px;
        color: {INK};
        font-size: {font_size + 1}pt;
    }}
    #CountLabel {{
        color: {INK_SOFT};
        font-size: {font_size}pt;
        font-weight: 600;
        padding: 2px 4px;
        background: transparent;
    }}

    /* ---- tabs ---- */
    QTabWidget::pane {{
        border: 1px solid {BORDER};
        border-radius: 8px;
        background: {SURFACE};
        top: -1px;
    }}
    QTabBar::tab {{
        background: {SURFACE_ALT};
        color: {INK_SOFT};
        border: 1px solid {BORDER};
        border-bottom: none;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        padding: {pad}px {pad + 8}px;
        margin: 2px;
        font-size: {font_size + 1}pt;
        font-weight: 600;
        min-width: 110px;
    }}
    QTabBar::tab:hover {{ background: {PRIMARY_SOFT}; color: {INK}; }}
    QTabBar::tab:selected {{
        background: {SURFACE};
        color: {INK};
        border: 2px solid {PRIMARY};
        border-bottom: 2px solid {SURFACE};
        font-weight: 700;
    }}

    /* ---- result list ---- */
    QListWidget {{
        background: {SURFACE};
        border: 1px solid {BORDER};
        border-radius: 8px;
        outline: none;
        padding: 4px;
    }}
    QListWidget::item {{
        border: none;
        border-radius: 8px;
        margin: 2px 4px;
        padding: 0px;
        color: {INK};
    }}
    QListWidget::item:selected {{
        background: {PRIMARY_SOFT};
        border: 2px solid {PRIMARY};
        margin: 1px 3px;
    }}
    QListWidget::item:hover {{ background: {SURFACE_ALT}; }}

    /* ---- result context menu ---- */
    QMenu {{
        background: {SURFACE};
        border: 1px solid {BORDER};
        border-radius: 8px;
        padding: 6px;
        color: {INK};
    }}
    QMenu::item {{
        background: transparent;
        padding: 8px 24px;
        border-radius: 6px;
        color: {INK};
    }}
    QMenu::item:selected {{
        background: {PRIMARY_SOFT};
        color: {INK};
    }}
    QMenu::item:disabled {{
        color: {INK_SOFT};
    }}
    QMenu::separator {{
        height: 1px;
        background: {BORDER};
        margin: 4px 8px;
    }}

    /* ---- result card ---- */
    #ResultCard {{
        background: {SURFACE};
        border: 1px solid {BORDER};
        border-radius: 8px;
    }}
    #ResultTitle {{
        font-size: {font_size + 2}pt;
        font-weight: 700;
        color: {INK};
        background: transparent;
    }}
    #ResultMeta {{
        color: {INK_SOFT};
        font-size: {font_size}pt;
        background: transparent;
    }}
    #SourceBadge {{
        color: #ffffff;
        border-radius: 10px;
        padding: 3px 10px;
        font-size: {font_size - 1}pt;
        font-weight: 700;
    }}
    #AvailabilityBadge {{
        border-radius: 10px;
        padding: 3px 10px;
        font-size: {font_size - 1}pt;
        font-weight: 700;
        background: {SURFACE_ALT};
        color: {INK_SOFT};
    }}

    /* ---- the copied-citation field ---- */
    # Styled like the search box but quieter: it is an output, not something
    # you type a query into.
    #CitationView {{
        background: {SURFACE_ALT};
        border: 1px solid {BORDER};
        border-radius: 6px;
        padding: {pad - 4}px {pad}px;
        color: {INK_SOFT};
        font-size: {font_size}pt;
    }}
    #CitationView:focus {{ border: 3px solid {FOCUS}; }}

    /* ---- the abstract preview on a card, and the full summary field ---- */
    /* Quieter than the title on purpose: it is context, not the result. */
    #SummarySnippet {{
        color: {INK_SOFT};
        font-size: {font_size - 1}pt;
        background: transparent;
    }}
    /* The same quiet output treatment as the citation field: an abstract
       is read, never typed into. */
    #SummaryView {{
        background: {SURFACE_ALT};
        border: 1px solid {BORDER};
        border-radius: 6px;
        padding: {pad - 4}px {pad}px;
        color: {INK};
        font-size: {font_size}pt;
    }}
    #SummaryView:focus {{ border: 3px solid {FOCUS}; }}

    /* ---- progress ---- */
    QProgressBar {{
        background: {SURFACE_ALT};
        border: 1px solid {BORDER};
        border-radius: 7px;
        height: 16px;
        text-align: center;
        color: {INK};
        font-weight: 600;
    }}
    QProgressBar::chunk {{
        background: {PRIMARY};
        border-radius: 6px;
    }}

    QScrollBar:vertical {{
        background: {SURFACE_ALT};
        width: 14px;
        margin: 2px;
        border-radius: 7px;
    }}
    QScrollBar::handle:vertical {{
        background: {BORDER_STRONG};
        border-radius: 6px;
        min-height: 30px;
    }}
    QScrollBar::handle:vertical:hover {{ background: {INK_FAINT}; }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
    QScrollBar:horizontal {{
        background: {SURFACE_ALT};
        height: 14px;
        border-radius: 7px;
    }}
    QScrollBar::handle:horizontal {{
        background: {BORDER_STRONG};
        border-radius: 6px;
        min-width: 30px;
    }}
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}

    /* ---- menus / combo boxes in dialogs ---- */
    QComboBox {{
        background: {SURFACE};
        border: 2px solid {BORDER_STRONG};
        border-radius: 6px;
        padding: {pad - 2}px {pad}px;
        min-height: {font_size + 8}px;
    }}
    QComboBox:focus {{ border: 3px solid {FOCUS}; }}
    QComboBox QAbstractItemView {{
        background: {SURFACE};
        border: 1px solid {BORDER_STRONG};
        selection-background-color: {PRIMARY_SOFT};
        selection-color: {INK};
        outline: none;
    }}
    QListView::item:selected {{ background: {PRIMARY_SOFT}; }}

    /* ---- search filter row: language + year ---- */
    /* Softer than the search box on purpose. The filters narrow an existing
       search, so they should not compete with the box the user types in. */
    #FilterCombo {{
        background: {SURFACE};
        border: 1px solid {BORDER};
        border-radius: 6px;
        padding: {pad - 4}px {pad - 2}px;
        min-height: {font_size + 4}px;
        color: {INK};
    }}
    #FilterCombo:focus {{ border: 3px solid {FOCUS}; }}
    #FilterCombo:hover {{ border-color: {BORDER_STRONG}; }}

    QDialog {{ background: {BG}; }}
    #HelpTitle {{
        font-size: {font_size + 4}pt;
        font-weight: 700;
        color: {INK};
        background: transparent;
    }}
    #HelpGroup {{
        font-size: {font_size + 2}pt;
        font-weight: 700;
        color: {PRIMARY_DARK};
        background: transparent;
        padding-top: 8px;
    }}
    #HelpKey {{
        font-weight: 700;
        color: {INK};
        background: transparent;
        font-size: {font_size + 1}pt;
    }}
    #HelpText {{
        color: {INK_SOFT};
        background: transparent;
        font-size: {font_size}pt;
    }}
    QGroupBox {{
        border: 1px solid {BORDER};
        border-radius: 8px;
        margin-top: 14px;
        padding-top: 10px;
        font-weight: 700;
        background: {SURFACE};
    }}
    QGroupBox::title {{
        subcontrol-origin: margin;
        right: 12px;
        padding: 0 6px;
        color: {PRIMARY_DARK};
        background: transparent;
    }}
    QCheckBox {{ padding: 4px; }}
    QCheckBox:focus {{ color: {FOCUS}; }}

    QToolTip {{
        background: #1c1c1c;
        color: #ffffff;
        border: 1px solid {BORDER_STRONG};
        padding: 4px 6px;
    }}

    QMessageBox {{ background: {BG}; }}
    """