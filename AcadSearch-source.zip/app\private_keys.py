"""Keys baked into a distributable build.

The repository copy stays EMPTY and secret-free. A distributor who wants the
keyed sources (CORE, BASE, Lens.org, Scilit, Scinapse, Springer) to work on
every machine that runs the app fills in the values below and then runs
``build_exe.bat`` — the resulting exe ships these defaults.

Accepted field names (the same ones Preferences uses, see app.config.Config):

    google_books_key   OpenAlex   semantic_scholar_key   pubmed_key
    core_key           base_key   lens_key               scilit_key
    scinapse_key       springer_key

Never commit a filled-in file. Precedence at runtime stays:
environment variable > user config file > the values here.
"""

BUNDLED_KEYS: dict[str, str] = {}