import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from app.providers.internet_archive import InternetArchiveProvider as P

CASES = [
    ("Machine Learning", ["Tom Mitchell"]),
    ("Machine_Learning", ["Some One"]),
    ("understanding-machine-learning-theory-algorithms", ["x"]),
    ("Introduction To Machine Learning With Python ( PDFDrive. ", ["a"]),
    ("Coursera - Mathematics for Machine Learning and Data", ["a"]),
    ("Giga Course. Com Udemy Complete Machine Learning", ["a"]),
    ("pdfcoffee.com_the-hundred-page-machine-learning-book", ["a"]),
    ("Predicting Interest Level based on EEG Scan Data using", ["a"]),
    ("Making music through real-time voice timbre analysis", ["Dan Stowell"]),
    (
        "Hands-on machine learning with Scikit-Learn and TensorFlow",
        ["Gron"],
    ),
    (
        "Data analysis, machine learning and applications : proceedings",
        ["a", "b"],
    ),
    ("Gaussian Processes for Machine Learning", ["Rasmussen, Williams"]),
    ("nasa_techdoc_19960011791", []),
    ("machine learning, deep learning , ai , maths", ["x"]),
    ("Machine learning", ["Marcelo C. Pontes"]),
    (
        "Understanding Machine Learning: From Theory to Algorithms",
        ["Shalev-Shwartz"],
    ),
    ("Complete Machine Learning And Data Science Zero To Mastery", ["x"]),
    ("Handson Machine Learning with Scikit Learn and Tensorflow", ["Gron"]),
    ("DTIC AD1048366: Machine-Learning Techniques for the Detection", ["x"]),
    ("ERIC ED607806: A Quantitative Machine Learning Approach", ["x"]),
    (
        "NASA Technical Reports Server (NTRS) 20170001402: Applications",
        ["x"],
    ),
    (
        "FORECASTING ARMY RESERVE OFFICER TRAINING CORPS COMMISSIONING",
        ["US Army"],
    ),
    ("Wave Dynamics in Cold Plasma: A FDTD and Machine Learning Model", ["x"]),
    (
        "NADI PARIKSHA: A NOVEL MACHINE LEARNING BASED WRIST PULSE",
        ["x"],
    ),
    (
        "Data analysis, machine learning and applications : proceedings",
        ["Brassard"],
    ),
    ("Machine Learning Tom Mitchell", ["Tom M. Mitchell"]),
]

print("=== quality gate ===")
kept = 0
for title, creator in CASES:
    junk = P._is_scrape(title, creator)
    verdict = "REJECT" if junk else "keep"
    if not junk:
        kept += 1
    print(f"  {verdict:7} {title[:62]}")
print(f"\n  kept {kept}/{len(CASES)}")