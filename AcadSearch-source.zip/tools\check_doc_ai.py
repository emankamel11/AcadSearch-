"""Check the Gemini file assistant without touching the network.

Run:  python -X utf8 tools/check_doc_ai.py
"""

from __future__ import annotations

import sys
import tempfile
import types
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config import get_config  # noqa: E402
from app.core import doc_ai  # noqa: E402
from app.core.local_file import document_text  # noqa: E402

failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  ok   {name}")
    else:
        failures.append(name)
        print(f"  FAIL {name}  {detail}")


class FakeResponse:
    def __init__(self, payload, status: int = 200):
        self._payload = payload
        self.status_code = status
        self.headers: dict = {}

    def json(self):
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


def fake_requests(response: FakeResponse):
    module = types.ModuleType("requests")

    class Timeout(Exception):
        pass

    class RequestException(Exception):
        pass

    module.exceptions = types.SimpleNamespace(
        Timeout=Timeout, RequestException=RequestException
    )
    module.post = lambda *args, **kwargs: response
    return module


def gemini_body(text: str) -> dict:
    return {"candidates": [{"content": {"parts": [{"text": text}]}}]}


def make_docx(path: Path, paragraphs: list[str]) -> None:
    namespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    body = "".join(
        f"<w:p><w:r><w:t>{text}</w:t></w:r></w:p>" for text in paragraphs
    )
    xml = (
        f'<?xml version="1.0" encoding="UTF-8"?>'
        f'<w:document xmlns:w="{namespace}"><w:body>{body}</w:body></w:document>'
    )
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("word/document.xml", xml)


def make_odt(path: Path, paragraphs: list[str]) -> None:
    namespace = "urn:oasis:names:tc:opendocument:xmlns:text:1.0"
    body = "".join(f"<text:p>{text}</text:p>" for text in paragraphs)
    xml = (
        f'<?xml version="1.0" encoding="UTF-8"?>'
        f'<office:document-content xmlns:office="urn:oasis:names:tc:'
        f'opendocument:xmlns:office:1.0" xmlns:text="{namespace}">'
        f"<office:body><office:text>{body}</office:text></office:body>"
        f"</office:document-content>"
    )
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("content.xml", xml)


def main() -> int:
    config = get_config()
    old_key = config.gemini_key
    old_model = config.gemini_model
    real_post = doc_ai._post

    print("== key handling ==")
    config.gemini_key = ""
    check("no key means unavailable", not doc_ai.available())
    try:
        doc_ai.summarize("unused.pdf")
        check("summarise without a key fails", False)
    except doc_ai.DocAIError as exc:
        check("summarise without a key fails", exc.key == "ai.error.no_key", exc.key)
    config.gemini_key = "test-key"
    config.gemini_model = doc_ai.DEFAULT_MODEL
    check("a key makes it available", doc_ai.available())

    print("== a PDF with a text layer goes as text ==")
    calls: list[tuple[dict, str, str]] = []

    def fake_post(payload, model, key, timeout):
        calls.append((payload, model, key))
        return "ملخص تجريبي"

    doc_ai._post = fake_post
    doc_ai.text_layer = lambda *args, **kwargs: "نص الكتاب " * 40
    answer = doc_ai.summarize("book.pdf")
    check("answer text returned", answer.text == "ملخص تجريبي", answer.text)
    check("no images used", answer.images == 0, str(answer.images))
    check("chars recorded", answer.chars > 300, str(answer.chars))
    payload, model, key = calls[-1]
    parts = payload["contents"][0]["parts"]
    check("text part sent", parts[1]["text"].startswith("نص الكتاب"), parts[1]["text"][:40])
    check("key sent as the header value", key == "test-key", key)
    check("default model used", model == doc_ai.DEFAULT_MODEL, model)
    check("system instruction sent", "system_instruction" in payload)
    check("summary instruction asks for the main idea",
          "الفكرة الرئيسة" in parts[0]["text"])

    print("== an image-only PDF goes as page images ==")
    doc_ai.text_layer = lambda *args, **kwargs: ""
    doc_ai._render_pdf = lambda *args, **kwargs: [
        ("image/jpeg", "AAAA"), ("image/jpeg", "BBBB")
    ]
    answer = doc_ai.summarize("scan.pdf")
    check("images counted", answer.images == 2, str(answer.images))
    parts = calls[-1][0]["contents"][0]["parts"]
    inline = [p for p in parts if "inline_data" in p]
    check("two inline images sent", len(inline) == 2, str(len(inline)))
    check("first page is labelled", parts[1]["text"] == "[page 1]", parts[1]["text"])
    check("mime is jpeg", inline[0]["inline_data"]["mime_type"] == "image/jpeg")

    print("== questions carry the question ==")
    doc_ai.text_layer = lambda *args, **kwargs: "نص " * 100
    doc_ai.ask("book.pdf", "ما منهج الباحث؟")
    parts = calls[-1][0]["contents"][0]["parts"]
    check("question in the instruction", "ما منهج الباحث؟" in parts[0]["text"],
          parts[0]["text"][:80])
    try:
        doc_ai.ask("book.pdf", "   ")
        check("empty question refused", False)
    except doc_ai.DocAIError as exc:
        check("empty question refused", exc.key == "ai.error.no_question", exc.key)

    print("== missing text is a readable failure ==")
    doc_ai.text_layer = lambda *args, **kwargs: ""
    doc_ai._render_pdf = lambda *args, **kwargs: []
    try:
        doc_ai.summarize("empty.pdf")
        check("no text and no images fails", False)
    except doc_ai.DocAIError as exc:
        check("no text and no images fails", exc.key == "ai.error.no_text", exc.key)

    print("== Word and ODT bodies are read ==")
    with tempfile.TemporaryDirectory() as tmp:
        docx = Path(tmp) / "book.docx"
        make_docx(docx, ["الفصل الأول", "مقدمة في المنهج"])
        text = document_text(docx)
        check("docx paragraphs", text.splitlines() == ["الفصل الأول", "مقدمة في المنهج"],
              repr(text))
        odt = Path(tmp) / "book.odt"
        make_odt(odt, ["مقدمة", "النتائج"])
        text = document_text(odt)
        check("odt paragraphs", text.splitlines() == ["مقدمة", "النتائج"], repr(text))

    print("== HTTP failures map to spoken keys ==")
    doc_ai._post = real_post

    def post_with(response, monkeypatch=True):
        previous = sys.modules.get("requests")
        sys.modules["requests"] = fake_requests(response)
        try:
            return doc_ai._post({}, doc_ai.DEFAULT_MODEL, "k", 5)
        finally:
            if previous is None:
                sys.modules.pop("requests", None)
            else:
                sys.modules["requests"] = previous

    cases = [
        ("bad key", FakeResponse({"error": {"message": "API key not valid"}}, 400),
         "ai.error.bad_key"),
        ("forbidden", FakeResponse({"error": {"message": "denied"}}, 403),
         "ai.error.bad_key"),
        ("quota", FakeResponse({}, 429), "ai.error.quota"),
        ("server", FakeResponse({}, 503), "ai.error.server"),
        ("no model", FakeResponse({}, 404), "ai.error.model"),
        ("blocked", FakeResponse({"promptFeedback": {"blockReason": "SAFETY"}}, 200),
         "ai.error.blocked"),
        ("empty", FakeResponse({"candidates": []}, 200), "ai.error.empty"),
        ("no body", FakeResponse(ValueError("bad json"), 200), "ai.error.empty"),
    ]
    for label, response, expected in cases:
        try:
            post_with(response)
            check(f"{label} raises", False)
        except doc_ai.DocAIError as exc:
            check(f"{label} -> {expected}", exc.key == expected, exc.key)

    print("== a throttle states how long to wait ==")
    retry_info = FakeResponse(
        {
            "error": {
                "message": "Resource exhausted",
                "details": [
                    {
                        "@type": "type.googleapis.com/google.rpc.RetryInfo",
                        "retryDelay": "17s",
                    }
                ],
            }
        },
        429,
    )
    try:
        post_with(retry_info)
        check("a 429 with a delay raises", False)
    except doc_ai.DocAIError as exc:
        check("the delay is read from RetryInfo", exc.retry_after == 17.0,
              str(exc.retry_after))
    check("a short delay is worth waiting out",
          doc_ai._worth_waiting(doc_ai.DocAIError("ai.error.quota", retry_after=5.0)))
    check("a long delay is not waited out",
          not doc_ai._worth_waiting(
              doc_ai.DocAIError("ai.error.quota", retry_after=600.0)
          ))

    print("== a retired model falls back ==")
    models: list[str] = []
    config.gemini_model = "retired-model"

    def fallback_post(payload, model, key, timeout):
        models.append(model)
        if model == config.gemini_model:
            raise doc_ai.DocAIError("ai.error.model")
        return "ok"

    doc_ai._post = fallback_post
    doc_ai.text_layer = lambda *args, **kwargs: "نص " * 100
    check("fallback answer", doc_ai.summarize("book.pdf").text == "ok")
    check("fallback model called",
          models == [config.gemini_model, doc_ai.FALLBACK_MODELS[0]],
          repr(models))

    print("== an overloaded model falls back too ==")
    models.clear()

    def busy_post(payload, model, key, timeout):
        models.append(model)
        if model == config.gemini_model:
            raise doc_ai.DocAIError("ai.error.server")
        return "ok"

    doc_ai._post = busy_post
    check("busy model answer", doc_ai.summarize("book.pdf").text == "ok")
    check("busy model moves on",
          models == [config.gemini_model, doc_ai.FALLBACK_MODELS[0]],
          repr(models))

    print("== a book too big for one upload is sent in parts ==")
    config.gemini_key = "test-key"
    config.gemini_model = doc_ai.DEFAULT_MODEL
    real_cap = doc_ai.MAX_REQUEST_BYTES
    # Force the split path without writing a megabyte-sized fixture.
    doc_ai.MAX_REQUEST_BYTES = 150_000
    paragraph = "فقرة طويلة من كتاب عربي تتكرر لقياس حجم الطلب. " * 10
    doc_ai.text_layer = lambda *args, **kwargs: "\n\n".join([paragraph] * 900)
    bodies: list[int] = []

    def limited_post(payload, model, key, timeout):
        import json as _json

        size = len(_json.dumps(payload, ensure_ascii=False).encode("utf-8"))
        bodies.append(size)
        if size > doc_ai.MAX_REQUEST_BYTES + 4_000:
            # The real network cut a 1.35 MB body off mid-upload with exactly
            # the error the reader saw as "check your internet".
            raise doc_ai.DocAIError("ai.error.network")
        return f"ملخص {len(bodies)}"

    doc_ai._post = limited_post
    stages: list[str] = []
    answer = doc_ai.summarize(
        "big.pdf", progress=lambda key, params: stages.append(key)
    )
    check("a big book still returns an answer", bool(answer.text), answer.text[:40])
    # A reader waiting minutes with an empty answer box reads it as broken, so
    # the parts must be announced while they happen, not only at the end.
    check("the wait is announced before reading",
          stages[:1] == ["ai.progress.reading"], repr(stages[:2]))
    check("every part is announced",
          sum(1 for key in stages if key == "ai.progress.part") == len(bodies) - 1,
          repr(stages))
    check("the merge is announced last",
          stages[-1:] == ["ai.progress.merge"], repr(stages[-2:]))
    check("no request crosses the body cap",
          all(size <= doc_ai.MAX_REQUEST_BYTES + 4_000 for size in bodies),
          str(bodies))
    check("the book was sent in more than one request", len(bodies) > 1,
          str(len(bodies)))
    check("the final call merges the parts",
          answer.text == f"ملخص {len(bodies)}", answer.text)

    bodies.clear()
    doc_ai.text_layer = lambda *args, **kwargs: "نص قصير عن الموضوع. " * 6
    doc_ai.summarize("small.pdf")
    check("a small document is still one request", len(bodies) == 1,
          str(bodies))
    doc_ai.MAX_REQUEST_BYTES = real_cap

    config.gemini_key = old_key
    config.gemini_model = old_model

    print()
    if failures:
        print(f"FAILED: {len(failures)} check(s): {failures}")
        return 1
    print("ALL DOC-AI CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
