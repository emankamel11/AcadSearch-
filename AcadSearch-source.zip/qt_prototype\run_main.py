"""Launch the Qt interface with sample results loaded, for checking the tabs.

This is NOT the normal launcher: it fills every tab with fixed examples at
startup, which reads as though the program had already searched. The real
launcher is ``run_app.py``, which starts empty. Use this one only to inspect
the tab layout without waiting on eleven live providers.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from app.models import Access, Category, DownloadFormat, DownloadTarget, Result

import main_window

FAKE = {
    Category.BOOK: [
        dict(title="مقدمة في التعلم الآلي", authors=["أنيل ك. جين", "نيتين غوبتا"],
             year=2021, venue="MIT Press", source="open_library", access=Access.DOWNLOAD,
             downloads=[DownloadTarget(url="https://example.org/a.epub",
                                       fmt=DownloadFormat.EPUB, label="EPUB")]),
        dict(title="دليل التعلم العميق", authors=["يان لكون"], year=2019,
             venue="Springer", source="google_books", access=Access.BORROW, downloads=[]),
    ],
    Category.ARTICLE: [
        dict(title="تصميم عناصر واجهة مقروءة لقارئات الشاشة",
             authors=["سارة أحمد", "محمد خان"], year=2023, venue="مجلة تفاعل الإنسان والحاسوب",
             source="crossref", access=Access.DOWNLOAD,
             downloads=[DownloadTarget(url="https://example.org/b.pdf",
                                       fmt=DownloadFormat.PDF, label="PDF")]),
        dict(title="تحليل إمكانية الوصول في تطبيقات سطح المكتب",
             authors=["ليلى حسن"], year=2022, venue="Springer", source="openalex",
             access=Access.LANDING, downloads=[]),
    ],
    Category.RESEARCH: [
        dict(title="رسالة ماجستير: توليد الكلام العربي", authors=["نور حسن"], year=2024,
             venue="جامعة القاهرة", source="sudoc", access=Access.METADATA, downloads=[]),
    ],
}


def seed(win) -> None:
    total = 0
    for category, rows in FAKE.items():
        page = win.pages[category]
        for row in rows:
            page.add(Result(category=category, **row))
            total += 1
        page.update_count()
    win._status(f"تم العثور على {total} نتيجة (بيانات تجريبية)")
    page = win.pages[Category.BOOK]
    win.tabs.setCurrentIndex(0)
    page.focus_first()


def main() -> int:
    app = QApplication(sys.argv)
    win = main_window.MainWindow()
    win.show()
    win.raise_()
    win.activateWindow()
    QTimer.singleShot(1000, lambda: seed(win))
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())