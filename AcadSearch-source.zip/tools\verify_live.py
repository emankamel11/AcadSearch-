"""End-to-end verification: real live search + real PDF download.

Run from the project root:  python -X utf8 verify_live.py
"""

from __future__ import annotations

import queue
import time

from app.config import Config
from app.core.citation import STYLES, format_citation
from app.core.downloader import DownloadManager, DownloadState
from app.core.search_engine import SearchEventType, get_engine
from app.models import Category, DownloadFormat, SearchQuery

failures: list[str] = []


def report(label: str, ok: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" - {detail}" if detail else ""))
    if not ok:
        failures.append(label)


def main() -> int:
    cfg = Config()
    query = SearchQuery(
        text="machine learning",
        categories={Category.BOOK, Category.ARTICLE, Category.RESEARCH},
        per_source=4,
    )

    print("=" * 72)
    print("1. LIVE SEARCH - real network, every provider")
    print("=" * 72)

    engine = get_engine()
    handle = engine.start(query)
    partials = []
    while not handle.done and time.monotonic() - handle.started_at < 120:
        try:
            ev = handle.events.get_nowait()
            if ev.type is SearchEventType.PARTIAL_RESULTS and ev.response:
                partials.append(ev.response)
        except queue.Empty:
            time.sleep(0.05)

    final = None
    while True:
        try:
            ev = handle.events.get_nowait()
        except queue.Empty:
            break
        if ev.type is SearchEventType.FINISHED and ev.response:
            final = ev.response

    response = final or (partials[-1] if partials else None)
    if response is None:
        report("search produced a response", False)
        return 1

    results = [r for group in response.results.values() for r in group]
    report("search returned results", bool(results), f"{len(results)} results")
    report("elapsed under 120s", response.elapsed < 120, f"{response.elapsed:.1f}s")

    print("\n  per-provider outcome:")
    for rep in sorted(response.reports, key=lambda r: r.provider_id):
        print(
            f"    {rep.provider_id:18} {rep.status.value:12} "
            f"count={rep.count:<3} {rep.seconds:5.2f}s  {rep.message[:40]}"
        )

    print("\n  per-category counts:")
    for cat, group in response.results.items():
        print(f"    {cat.value:10} {len(group)}")

    if response.errors:
        print(f"\n  errors: {response.errors}")

    print()
    print("=" * 72)
    print("2. CITATION FORMATTING on real provider data")
    print("=" * 72)
    if not results:
        report("have a result to cite", False)
        return 1
    sample = results[0]
    print(f"  source: {sample.source}  type: {sample.category.value}")
    print(f"  title : {sample.title[:64]!r}\n")
    for style in STYLES:
        try:
            text = format_citation(sample, style)
            report(f"{style:8} formats without error", bool(text.strip()),
                   text[:70].replace("\n", " "))
        except Exception as exc:  # noqa: BLE001
            report(f"{style:8} formats without error", False,
                   f"{type(exc).__name__}: {exc}")

    print()
    print("=" * 72)
    print("3. REAL DOWNLOAD - open-access PDF over the network")
    print("=" * 72)
    oa = [r for r in results if any(d.fmt is DownloadFormat.PDF for d in r.downloads)]
    if not oa:
        print("  (no open-access PDF among the results - skipping download check)")
        print()
        print("=" * 72)
        if failures:
            print(f"{len(failures)} FAILURE(S): {failures}")
            return 1
        print("All live checks passed.")
        return 0

    target = oa[0]
    print(f"  picking: {target.title[:58]!r} ({target.source})")
    mgr = DownloadManager(cfg)
    task = mgr.enqueue(target)
    if task is None:
        report("enqueue accepted the task", False)
        return 1
    report("enqueue accepted the task", True, task.filename)

    while task.state not in (DownloadState.DONE, DownloadState.FAILED,
                            DownloadState.CANCELLED):
        try:
            mgr.events.get_nowait()
        except queue.Empty:
            time.sleep(0.05)
        if time.monotonic() - handle.started_at > 240:
            break

    path = task.path
    size = path.stat().st_size if path and path.exists() else -1
    magic = path.open("rb").read(5) if size > 0 else b""
    report("download reached DONE", task.state is DownloadState.DONE,
           f"{task.state.name} {task.error or ''}")
    report("file exists and is non-empty", size > 0,
           f"{size} bytes at {path}")
    report("file is a real PDF (magic %PDF-)", magic == b"%PDF-", repr(magic))

    print()
    print("=" * 72)
    if failures:
        print(f"{len(failures)} FAILURE(S): {failures}")
        return 1
    print("All live checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
