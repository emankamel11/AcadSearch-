"""Ad-hoc end-to-end check of the search engine against the live APIs.

Usage:  python -m tools.probe "machine learning"
Not imported by the application.
"""

from __future__ import annotations

import logging
import sys
import time

from app.core.search_engine import SearchEngine, SearchEventType
from app.models import Category, SearchQuery

logging.basicConfig(level=logging.WARNING)


def main() -> int:
    text = sys.argv[1] if len(sys.argv) > 1 else "machine learning"
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else 5

    engine = SearchEngine()
    query = SearchQuery(text=text, per_source=limit)
    handle = engine.start(query)
    started = time.monotonic()

    response = None
    while True:
        try:
            event = handle.events.get(timeout=40)
        except Exception:
            break
        if event.type is SearchEventType.PROVIDER_UPDATE and event.report:
            r = event.report
            print(
                f"  [{r.status.value:8}] {r.provider_id:18} "
                f"n={r.count:<3} {r.seconds:5.2f}s {r.message}"
            )
        elif event.type is SearchEventType.FINISHED:
            response = event.response
        elif event.type is SearchEventType.FAILED:
            print("FAILED:", event.message)
        if handle.done and handle.events.empty():
            break

    if response is None:
        print("no final response")
        return 1

    print(f"\nQuery: {text!r}  elapsed={time.monotonic()-started:.2f}s")
    labels = {
        Category.BOOK: "BOOKS",
        Category.ARTICLE: "ARTICLES",
        Category.RESEARCH: "RESEARCH/THESES",
    }
    for category in (Category.BOOK, Category.ARTICLE, Category.RESEARCH):
        items = response.by_category(category)
        print(f"\n=== {labels[category]}: {len(items)} ===")
        for item in items[:4]:
            primary = item.primary_download
            link = primary.url[:70] if primary else "-"
            print(f"  - {item.title[:70]!r}")
            print(
                f"    src={item.source} year={item.year} lang={item.language!r} "
                f"cit={item.citations} acc={item.access.value}"
            )
            print(f"    venue={item.venue[:50]!r} subj={item.subjects[:3]}")
            print(f"    abs={item.abstract[:110]!r}")
            print(f"    ids={ {k: v[:32] for k, v in item.identifiers.items()} }")
            print(f"    dl =[{link}] fmt={primary.fmt.value if primary else '-'} oa={primary.open_access if primary else '-'}")
            print(f"    cite: {item.citation_string()[:130]}")

    print(f"\nTOTAL={response.total()} errors={response.errors}")
    engine.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
