"""arXiv — open-access preprint server (physics, CS, maths, quant biology, ...).

Docs: https://info.arxiv.org/help/api/index.html
Every record exposes a direct, free PDF. arXiv asks for a descriptive
User-Agent (set in :class:`~app.core.http_client.HttpClient`) and rate-limits to
roughly one request every three seconds.
"""

from __future__ import annotations

import threading
import xml.etree.ElementTree as ET

from app.core.text_utils import (
    as_int,
    clean_text,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://export.arxiv.org/api/query"
ATOM = "{http://www.w3.org/2005/Atom}"
ARXIV = "{http://arxiv.org/schemas/atom}"


@register
class ArxivProvider(BaseProvider):
    provider_id = "arxiv"
    display_name = "arXiv"
    categories = (Category.RESEARCH,)
    weight = 10
    homepage = "https://arxiv.org"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        params = {
            "search_query": self._build_query(query),
            "start": 0,
            "max_results": min(query.per_source, 30),
            "sortBy": "relevance",
            "sortOrder": "descending",
        }
        text = self.http.get_text(
            ENDPOINT, params, provider=self.provider_id, use_cache=True, cancel=cancel
        )
        return self._parse(text)

    @staticmethod
    def _build_query(query: SearchQuery) -> str:
        """arXiv field syntax; quote phrases and escape reserved characters."""
        terms = []
        for word in query.text.split():
            cleaned = word.strip('"')
            if not cleaned:
                continue
            if any(ch in cleaned for ch in ':()+-'):
                cleaned = f'"{cleaned}"'
            terms.append(f"all:{cleaned}")
        expression = " AND ".join(terms) or "all:*"

        if query.year_from or query.year_to:
            low = query.year_from or 1991
            high = query.year_to or 2100
            expression = f"({expression}) AND submittedDate:[{low}01010000 TO {high}12312359]"
        return expression

    def _parse(self, xml_text: str) -> list[Result]:
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError as exc:
            raise RuntimeError(f"arXiv: استجابة XML غير صالحة ({exc})") from exc

        out: list[Result] = []
        for entry in root.findall(f"{ATOM}entry"):
            item = self._to_result(entry)
            if item is not None:
                out.append(item)
        return out

    def _to_result(self, entry: ET.Element) -> Result | None:
        title = clean_text(_text(entry, f"{ATOM}title"))
        if not title:
            return None

        entry_id = clean_text(_text(entry, f"{ATOM}id"))
        summary = truncate_words(clean_text(_text(entry, f"{ATOM}summary")), 600)

        authors = [
            clean_text(a.findtext(f"{ATOM}name"))
            for a in entry.findall(f"{ATOM}author")
        ]
        authors = [a for a in authors if a]

        published = clean_text(_text(entry, f"{ATOM}published"))
        year = as_int(published[:4]) if published else None

        # Primary category doubles as the subject classification.
        primary_node = entry.find(f"{ARXIV}primary_category")
        subjects: list[str] = []
        if primary_node is not None:
            term = clean_text(primary_node.get("term"))
            if term:
                subjects.append(term)
        for node in entry.findall(f"{ATOM}category"):
            term = clean_text(node.get("term"))
            if term and term not in subjects:
                subjects.append(term)

        from app.core.text_utils import ARXIV_ARCHIVES, arxiv_id

        archive = primary_node.get("term") if primary_node is not None else ""
        if archive:
            label = ARXIV_ARCHIVES.get(archive)
            if not label and "." in archive:
                label = ARXIV_ARCHIVES.get(archive.split(".")[0])
            if label and label not in subjects:
                subjects.insert(0, label)

        identifier = arxiv_id(entry_id)
        landing = f"https://arxiv.org/abs/{identifier}" if identifier else entry_id
        pdf_url = clean_text(_text(entry, f"{ARXIV}pdf")) or (
            f"https://arxiv.org/pdf/{identifier}" if identifier else ""
        )
        doi = clean_text(_text(entry, f"{ARXIV}doi"))

        downloads = []
        if pdf_url:
            downloads.append(
                target(pdf_url, DownloadFormat.PDF, label="arXiv PDF (open access)", open_access=True)
            )
        if entry_id:
            downloads.append(
                target(
                    entry_id.replace("http://", "https://"),
                    DownloadFormat.HTML,
                    label="arXiv abstract",
                    open_access=True,
                )
            )

        identifiers = {"arxiv": identifier} if identifier else {}
        if doi:
            identifiers["doi"] = doi
        journal_ref = clean_text(_text(entry, f"{ARXIV}journal_ref"))
        if journal_ref:
            identifiers["journal_ref"] = journal_ref

        return Result(
            category=Category.RESEARCH,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=year,
            abstract=summary,
            venue=clean_text(journal_ref) or clean_text(archive or ""),
            subjects=subjects[:6],
            identifiers=identifiers,
            access=Access.DOWNLOAD if pdf_url else Access.METADATA,
            downloads=downloads,
            landing_url=landing,
            item_type="Preprint",
            raw={},
        )


def _text(node: ET.Element, path: str) -> str:
    return node.findtext(path) or ""
