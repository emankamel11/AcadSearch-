"""Érudit — Canadian French journals in humanities and social sciences.

Érudit (erudit.org) provides open access and subscription content
from Quebec and Canadian journals.
"""

from __future__ import annotations

import re
import threading
from urllib.parse import urljoin

from app.core.text_utils import clean_text, truncate_words
from app.models import (
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

SEARCH_URL = "https://www.erudit.org/fr/recherche/"

_TAG_RE = re.compile(r"<[^>]+>")
_A_RE = re.compile(r'<a[^>]+href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)</a>', re.I | re.S)
_PDF_RE = re.compile(r'href=[\'"]([^\'"]+\.pdf[^\'"]*)[\'"]', re.I)


@register
class EruditProvider(BaseProvider):
    provider_id = "erudit"
    display_name = "Érudit (دوريات كندية/فرنسية)"
    categories = (Category.ARTICLE, Category.RESEARCH)
    weight = 34
    homepage = "https://www.erudit.org/"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = query.text.strip()
        if not text:
            return []

        if cancel is not None and cancel.is_set():
            return []

        wanted = max(10, min(query.per_source, 40))

        params = {"search": text}

        try:
            html = self.http.get_text(
                SEARCH_URL,
                params=params,
                provider=self.provider_id,
                cancel=cancel,
            )
        except ProviderError:
            raise
        except Exception as exc:
            raise ProviderError(f"erudit: {type(exc).__name__}", kind="error") from exc

        if cancel is not None and cancel.is_set():
            return []

        out: list[Result] = []
        seen = set()

        for m in _A_RE.finditer(html):
            href = m.group(1)
            if not href.startswith("http") and href.startswith("/"):
                pass
            if '/revue/' not in href and '/document/' not in href and '/article/' not in href:
                continue
            title = clean_text(_strip_html(m.group(2)))
            if not title or len(title) < 10 or title.lower() in ('erudit', 'recherche'):
                continue
            url = urljoin(SEARCH_URL, href)
            if url in seen:
                continue
            seen.add(url)

            start = max(0, m.start() - 150)
            end = min(len(html), m.end() + 300)
            block = html[start:end]

            authors = []
            for am in re.finditer(r'class=["\'][^"\']*(?:author|auteur)[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S):
                a = clean_text(_strip_html(am.group(1)))
                if a and len(a) < 80 and a not in authors:
                    authors.append(a)

            year = None
            ym = re.search(r'\b(1[0-9]{3}|20[0-9]{2})\b', block)
            if ym:
                year = int(ym.group(1))

            journal = ""
            for jm in re.finditer(r'class=["\'][^"\']*(?:revue|titre.*revue)[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S):
                journal = clean_text(_strip_html(jm.group(1)))
                if journal and len(journal) < 100:
                    break

            pdf_url = ""
            pm = _PDF_RE.search(block)
            if pm:
                pdf_url = urljoin(SEARCH_URL, pm.group(1))

            downloads = []
            if pdf_url:
                downloads.append(target(pdf_url, DownloadFormat.PDF, label="PDF", open_access=True))
            downloads.append(target(url, DownloadFormat.HTML, label="Érudit", open_access=True))

            out.append(
                Result(
                    category=Category.ARTICLE,
                    title=title,
                    source=self.provider_id,
                    authors=authors[:12],
                    year=year,
                    abstract="",
                    venue=journal or "Érudit",
                    language="fr",
                    identifiers={"source": self.provider_id},
                    downloads=downloads,
                    landing_url=url,
                )
            )
            if len(out) >= wanted:
                break

        return out


def _strip_html(value: str) -> str:
    if "<" not in value:
        return value
    text = _TAG_RE.sub(" ", value)
    return clean_text(text.replace("&nbsp;", " "))
