"""Check local-file metadata extraction (PDF / DOCX / ODT) without the GUI.

Run:  python -X utf8 tools/check_local_file.py
"""

from __future__ import annotations

import sys
import tempfile
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.citation import format_citation  # noqa: E402
from app.core.local_file import build_result, extract_result, is_supported  # noqa: E402
from app.models import Category  # noqa: E402

failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  ok   {name}")
    else:
        failures.append(name)
        print(f"  FAIL {name}  {detail}")


def make_pdf(folder: Path) -> Path:
    path = folder / "these.pdf"
    body = (
        b"%PDF-1.4\n"
        b"1 0 obj\n"
        b"<< /Title (Le Retour du Roi Jibril) "
        b"/Author (Rams\\351s Kefi; Rachid La\\357reche) "
        b"/CreationDate (D:20250101000000) >>\n"
        b"endobj\n"
        b"trailer\n<< /Root 1 0 R >>\n%%EOF\n"
    )
    path.write_bytes(body)
    return path


def make_xmp_pdf(folder: Path) -> Path:
    path = folder / "xmp.pdf"
    xmp = (
        '<?xpacket begin=""?>'
        '<x:xmpmeta xmlns:x="adobe:ns:meta/">'
        '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
        '<rdf:Description xmlns:dc="http://purl.org/dc/elements/1.1/">'
        "<dc:title><rdf:Alt><rdf:li xml:lang=\"x-default\">Probl&egrave;mes de linguistique</rdf:li></rdf:Alt></dc:title>"
        "<dc:creator><rdf:Seq><rdf:li>Benveniste, &#201;.</rdf:li></rdf:Seq></dc:creator>"
        "<dc:date><rdf:Seq><rdf:li>1974-01-01</rdf:li></rdf:Seq></dc:date>"
        "</rdf:Description></rdf:RDF></x:xmpmeta>"
    ).encode("utf-8")
    path.write_bytes(b"%PDF-1.4\n" + xmp + b"\n%%EOF\n")
    return path


def make_arabic_pdf(folder: Path) -> Path:
    """A PDF whose Info strings are UTF-16BE, as Arabic-producing tools write."""
    path = folder / "arabic.pdf"

    def hexed(text: str) -> str:
        return "FEFF" + text.encode("utf-16-be").hex().upper()

    body = (
        "%PDF-1.4\n"
        "1 0 obj\n"
        f"<< /Title <{hexed('فن البحث العلمي')}> "
        f"/Author <{hexed('أحمد محمد علي')}> "
        "/Producer (Microsoft Word) "
        "/CreationDate (D:20190315120000) >>\n"
        "endobj\n"
        "%%EOF\n"
    ).encode("latin-1")
    path.write_bytes(body)
    return path


def make_scanner_pdf(folder: Path) -> Path:
    """A scan whose /Author is the device, as scanners actually write it."""
    path = folder / "scan.pdf"
    path.write_bytes(
        b"%PDF-1.4\n"
        b"1 0 obj\n"
        b"<< /Title (Lecture notes) /Author (TOSHIBA) "
        b"/CreationDate (D:20200101000000) >>\n"
        b"endobj\n%%EOF\n"
    )
    return path


def make_docx(folder: Path) -> Path:
    path = folder / "book.docx"
    core = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<cp:coreProperties '
        'xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        "<dc:title>L&#8217;&#233;nonciation</dc:title>"
        "<dc:creator>Kerbrat-Orecchioni, C.</dc:creator>"
        '<dcterms:created xsi:type="dcterms:W3CDTF">2001-05-01T00:00:00Z</dcterms:created>'
        "</cp:coreProperties>"
    ).encode("utf-8")
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("docProps/core.xml", core)
        archive.writestr(
            "word/document.xml",
            b'<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Body</w:t></w:r></w:p></w:body></w:document>',
        )
    return path


def make_odt(folder: Path) -> Path:
    path = folder / "note.odt"
    meta = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<office:document-meta '
        'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0">'
        "<office:meta>"
        "<dc:title>L&#8217;oral comme fiction</dc:title>"
        "<meta:initial-creator>Dargnat, M.</meta:initial-creator>"
        "<dc:date>2006-01-01</dc:date>"
        "<meta:generator>LibreOffice/7.5</meta:generator>"
        "</office:meta></office:document-meta>"
    ).encode("utf-8")
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("mimetype", "application/vnd.oasis.opendocument.text")
        archive.writestr("meta.xml", meta)
    return path


def main() -> int:
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp)

        print("== extensions ==")
        check(".pdf supported", is_supported("x.pdf"))
        check(".docx supported", is_supported("x.docx"))
        check(".odt supported", is_supported("x.odt"))
        check(".txt not supported", not is_supported("x.txt"))

        print("== PDF Info dictionary ==")
        result = extract_result(make_pdf(folder))
        check("title read", result.title == "Le Retour du Roi Jibril", result.title)
        check(
            "resume-style split",
            result.authors == ["Ramsés Kefi", "Rachid Laïreche"],
            repr(result.authors),
        )
        check("year read", result.year == 2025, str(result.year))
        apa = format_citation(result, "apa")
        check("APA mentions the title", "Le Retour du Roi Jibril" in apa, apa)
        check("APA mentions the year", "(2025)" in apa, apa)

        print("== PDF XMP ==")
        xmp = extract_result(make_xmp_pdf(folder))
        check("xmp title", xmp.title == "Problèmes de linguistique", xmp.title)
        check("xmp author", xmp.authors == ["Benveniste, É."], repr(xmp.authors))
        check("xmp year", xmp.year == 1974, str(xmp.year))

        print("== Word .docx core properties ==")
        docx = extract_result(make_docx(folder), kind="book")
        check("docx title", docx.title == "L’énonciation", docx.title)
        check("docx author", docx.authors == ["Kerbrat-Orecchioni, C."], repr(docx.authors))
        check("docx year", docx.year == 2001, str(docx.year))

        print("== ODT meta ==")
        odt = extract_result(make_odt(folder))
        check("odt title", odt.title == "L’oral comme fiction", odt.title)
        check("odt author", odt.authors == ["Dargnat, M."], repr(odt.authors))
        check("odt year", odt.year == 2006, str(odt.year))
        check("odt generator is not the publisher", odt.venue == "", repr(odt.venue))

        print("== Arabic PDF (UTF-16BE Info) ==")
        arabic = extract_result(make_arabic_pdf(folder))
        check("arabic title", arabic.title == "فن البحث العلمي", arabic.title)
        check("arabic author", arabic.authors == ["أحمد محمد علي"], repr(arabic.authors))
        check("arabic year", arabic.year == 2019, str(arabic.year))
        check(
            "pdf producer is not the publisher",
            arabic.venue == "",
            repr(arabic.venue),
        )
        arabic_apa = format_citation(arabic, "apa")
        check("arabic name is not inverted", "أحمد محمد علي" in arabic_apa, arabic_apa)
        check("arabic title in APA", "فن البحث العلمي" in arabic_apa, arabic_apa)
        check("software name never reaches APA", "Word" not in arabic_apa, arabic_apa)

        print("== French hyphenated given name ==")
        french = format_citation(
            build_result(
                folder / "livre.pdf",
                "book",
                title="Introduction à la recherche",
                authors=["Jean-Pierre Dupont"],
                year=2019,
                venue="Presses Universitaires",
            ),
            "apa",
        )
        check("hyphenated initials stay joined", "Dupont, J.-P." in french, french)
        check("accented letters survive", "Introduction à la recherche" in french, french)

        print("== scanner / device author is dropped ==")
        scan = extract_result(make_scanner_pdf(folder))
        check("device name is not an author", scan.authors == [], repr(scan.authors))
        check("title still read", scan.title == "Lecture notes", scan.title)

        print("== fallback: unknown file uses the name ==")
        plain = folder / "my_reading_notes.txt"
        plain.write_text("hello", encoding="utf-8")
        fallback = extract_result(plain)
        check(
            "filename used as title",
            fallback.title == "my reading notes",
            fallback.title,
        )

    print()
    if failures:
        print(f"FAILED: {len(failures)} check(s): {failures}")
        return 1
    print("ALL LOCAL-FILE CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
