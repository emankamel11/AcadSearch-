﻿"""Check the visual layout is real, not just present in the object tree.

The earlier card bug was invisible to the accessibility tests: the buttons had
correct names, took focus and answered Enter, but had a height of zero, so they
could not be seen or clicked with a mouse. This asserts the geometry a person
actually sees: real sizes, on screen, inside the window, and not overlapping.
"""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from PySide6.QtCore import QPoint, Qt
from PySide6.QtWidgets import QApplication, QLabel, QPushButton

from app.models import (
    Access,
    Category,
    DownloadFormat,
    DownloadTarget,
    Result,
)

import main_window
import theme

FAILED: list[str] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if condition else 'FAIL'}] {label}" + (f" -- {detail}" if detail else ""))
    if not condition:
        FAILED.append(label)


def make_result(title: str, source: str, year: int | None = 2020,
                abstract: str = "") -> Result:
    return Result(
        category=Category.BOOK,
        title=title,
        source=source,
        authors=["Sara Ahmed", "Omar Ali"],
        year=year,
        venue="Journal of Testing",
        access=Access.DOWNLOAD,
        abstract=abstract,
        downloads=[
            DownloadTarget(
                url="https://example.org/a.pdf",
                fmt=DownloadFormat.PDF,
                open_access=True,
            )
        ],
    )


app = QApplication([])
win = main_window.MainWindow()
win.resize(1100, 800)
win.show()
app.processEvents()

print("== window and stylesheet ==")
check("stylesheet is applied", len(win.styleSheet()) > 2000, f"{len(win.styleSheet())} chars")
check("window has a real size", win.width() >= 900 and win.height() >= 600,
      f"{win.width()}x{win.height()}")
check("layout has margins", win.layout() is not None)

print()
print("== header and search row ==")
labels = [w for w in win.findChildren(QLabel) if w.objectName() == "Header"]
check("header exists", len(labels) == 1, f"{len(labels)} found")
if labels:
    check("header has height", labels[0].height() >= 40, f"h={labels[0].height()}")
    check("header is not read by the screen reader",
          labels[0].accessibleName() == "", repr(labels[0].accessibleName()))

check("search box styled", win.query.objectName() == "SearchBox")
check("search button is primary", win.search_btn.objectName() == "PrimaryButton")
check("search button has an icon", not win.search_btn.icon().isNull())
check("settings button has an icon", not win.prefs_btn.icon().isNull())
check("clear button has an icon", not win.prefs_btn.icon().isNull())

print()
print("== filter row is visible and reachable ==")
check("language combo exists", win.lang_combo.objectName() == "FilterCombo")
check("language combo has a visible size",
      win.lang_combo.height() >= 20 and win.lang_combo.width() >= 60,
      f"{win.lang_combo.width()}x{win.lang_combo.height()}")
check("language combo is announced", "لغة" in win.lang_combo.accessibleName(),
      win.lang_combo.accessibleName())
check("language combo offers all + the three main languages",
      win.lang_combo.count() == 4, str(win.lang_combo.count()))
check("year boxes exist and are announced",
      "من" in win.year_from.accessibleName()
      and "إلى" in win.year_to.accessibleName(),
      f"{win.year_from.accessibleName()} / {win.year_to.accessibleName()}")
check("year box defaults to no bound", win.year_from.value() == 0)
check("year box says what zero means", win.year_from.specialValueText() != "",
      win.year_from.specialValueText())
check("filter row does not steal the whole window",
      win.tabs.height() > 300, f"tabs h={win.tabs.height()}")
check("filters are above the results, not inside them",
      win.lang_combo.mapToGlobal(QPoint(0, 0)).y()
      < win.tabs.mapToGlobal(QPoint(0, 0)).y())

print()
print("== a filled card is actually visible ==")
page = win.pages[Category.BOOK]
LONG_ABSTRACT = (
    "هذا ملخص طويل كتب لنتيجة تجريبية، يشرح فكرة البحث وأهم النتائج "
    "والمنهجية المتبعة والحدود والمقترحات المستقبلية بهدف فحص كيفية قص النص "
    "عند حد معين من المحارف دون إسقاط منتصف الكلمات العربية أو الإنكليزية."
)
page.add(make_result("A study with a long abstract to preview", "crossref", 2021, LONG_ABSTRACT))
for i in range(3):
    page.add(make_result(f"A study about machine learning number {i}", "open_library"))
page.add(make_result("Plain result without abstract", "open_library"))
app.processEvents()
page.update_count()
win.tabs.setCurrentWidget(page)
# A fresh search leaves row 0 selected (focus_first), which scrolls the list
# back to the top after items were added with scrollToItem. Replicate that so
# the first card is on screen; without it the taller rows push row 0 off.
page.focus_first()
app.processEvents()

check("list has rows", page.list.count() == 5, str(page.list.count()))
card = page._cards[0]
check("card has real height", card.height() >= 110, f"h={card.height()}")
check("card is visible", card.isVisible())
check("card is inside the window",
      win.rect().contains(win.mapFromGlobal(card.mapToGlobal(QPoint(0, 0)))))

buttons = card.findChildren(QPushButton)
check("the card holds no action buttons: the screen stays quiet",
      not buttons, str([b.text() for b in buttons]))

# The bug that mattered: rows were 18px so the card's buttons had no height.
rows = [page.list.sizeHintForRow(i) for i in range(5)]
check("every row is tall enough for its card",
      all(r >= 110 for r in rows), str(rows))

print()
print("== badges carry colour AND text ==")
source_badges = [w for w in card.findChildren(QLabel) if w.objectName() == "SourceBadge"]
check("source badge exists", len(source_badges) == 1)
if source_badges:
    b = source_badges[0]
    check("source badge has text", bool(b.text().strip()), b.text())
    check("source badge has a background colour",
          "background" in b.styleSheet(), b.styleSheet()[:60])
    # The badge is read from its visible text in browse mode; an accessible name
    # would repeat it on top of the row the caret is already on.
    check("source badge is not spoken twice", b.accessibleName() == "",
          repr(b.accessibleName()))
state_badges = [w for w in card.findChildren(QLabel) if w.objectName() == "AvailabilityBadge"]
check("availability badge exists", len(state_badges) == 1)
if state_badges:
    check("availability badge says the state in words",
          bool(state_badges[0].text().strip()), state_badges[0].text())

print()
print("== cover ==")
check("cover has a real size", card.cover.width() > 40 and card.cover.height() > 40,
      f"{card.cover.width()}x{card.cover.height()}")
check("cover shows the placeholder", not card.cover.pixmap().isNull(),
      f"pixmap null={card.cover.pixmap().isNull()}")
check("cover is not announced", card.cover.accessibleName() == "")

print()
print("== abstract preview on cards ==")
card = page._cards[0]
plain = page._cards[4]
check("a result with an abstract gets the snippet", card.snippet is not None)
if card.snippet is not None:
    s = card.snippet
    check("snippet has visible text", bool(s.text().strip()), repr(s.text()[:40]))
    check("snippet stays within two lines of text", len(s.text()) <= 200,
          f"{len(s.text())} chars")
    check("snippet is not read twice on the row", s.accessibleName() == "",
          repr(s.accessibleName()))
    check("snippet is on screen",
          win.rect().contains(win.mapFromGlobal(s.mapToGlobal(QPoint(0, 0)))))
    check("long abstract is cut with a visible ellipsis", s.text().rstrip().endswith("…"),
          repr(s.text()[-12:]))
check("a result without an abstract has no snippet", plain.snippet is None)

print()
print("== Alt+M opens the read-only summary field ==")
win.show_summary()
app.processEvents()
sv = win.summary_view
check("summary view exists", sv is not None)
check("summary view is read-only", sv.isReadOnly())
check("summary view becomes visible", sv.isVisible())
check("summary view holds the abstract text", bool(sv.toPlainText().strip()),
      f"{len(sv.toPlainText())} chars")
check("summary text includes the title",
      card.result.title in sv.toPlainText())
page.list.setCurrentRow(4)
app.processEvents()
win.show_summary()
app.processEvents()
check("a result without an abstract hides the field", not sv.isVisible())
page.list.setCurrentRow(-1)
app.processEvents()
win.show_summary()
check("no selection says so instead of crashing",
      "لا توجد نتيجة" in win.status.text(), win.status.text()[:50])
page.focus_first()
app.processEvents()

print()
print("== tabs are told apart visually ==")
icons = [not win.tabs.tabIcon(i).isNull() for i in range(win.tabs.count())]
check("all three tabs have an icon", all(icons) and len(icons) == 3, str(icons))

print()
print("== font zoom ==")
base = win.query.font().pointSize()
before = len(win.styleSheet())
win.apply_font_size(14)
app.processEvents()
check("stylesheet rebuilt at a bigger size", len(win.styleSheet()) != before,
      f"{before} -> {len(win.styleSheet())}")
check("search box grew taller", win.query.height() >= 30, f"h={win.query.height()}")
win.apply_font_size(10)
app.processEvents()

print()
print("== status bar tints by meaning ==")
win._status("انتهى البحث عن كتاب", speak=False)
ok_style = "border-left" in win.status.styleSheet()
win._status("ما فيش نتائج", speak=False)
warn_style = win.status.styleSheet()
check("success status is styled", ok_style)
check("warning status changes the tint",
      warn_style != "border-left: 6px solid #1c6b3c;" and "border-left" in warn_style,
      warn_style[:70])
check("status still has its text", bool(win.status.text()))

print()
if FAILED:
    print(f"FAILED: {len(FAILED)} -> {FAILED}")
    raise SystemExit(1)
print("ALL VISUAL CHECKS PASSED")
