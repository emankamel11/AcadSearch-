@echo off
REM ---------------------------------------------------------------------------
REM AcadSearch - build the standalone Windows executable.
REM
REM     build_exe.bat            build  -> dist\AcadSearch.exe
REM     build_exe.bat clean      remove build\, dist\ and __pycache__ first
REM     build_exe.bat installer  build dist\AcadSearch-Setup-<version>.exe
REM     build_exe.bat verify     check the built exe through UI Automation
REM
REM The build is a one-file windowed app: no console, single .exe.
REM ---------------------------------------------------------------------------
setlocal EnableDelayedExpansion
cd /d "%~dp0"

set "EXE=dist\AcadSearch.exe"

if /i "%~1"=="clean" goto :clean
if /i "%~1"=="verify" goto :verify
if /i "%~1"=="installer" goto :installer

echo.
echo [1/6] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not on PATH. Install Python 3.10+ and retry.
    exit /b 1
)

echo [2/6] Installing dependencies...
python -m pip install --disable-pip-version-check -q -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install requirements.
    exit /b 1
)
python -m pip install --disable-pip-version-check -q "pyinstaller>=6.3.0"
if errorlevel 1 (
    echo [ERROR] Failed to install PyInstaller.
    exit /b 1
)

echo [3/6] Compiling sources (syntax check)...
python -m compileall -q app main.py tools qt_prototype
if errorlevel 1 (
    echo [ERROR] Syntax check failed - see messages above.
    exit /b 1
)

echo [4/6] Running GUI smoke test on the source tree...
python -X utf8 -m tools.smoke_ui
if errorlevel 1 (
    echo [ERROR] Smoke test failed - not building a broken .exe.
    exit /b 1
)

echo [5/6] Checking the interface tests...
python -X utf8 qt_prototype\check_card.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Result-card test failed.
    exit /b 1
)
python -X utf8 qt_prototype\check_visual.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Visual-layout test failed - the layout could be broken.
    exit /b 1
)
python -X utf8 qt_prototype\check_tab_order.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Tab-order test failed - the keyboard route is broken.
    exit /b 1
)
python -X utf8 qt_prototype\check_filters.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Filter test failed - language or year filters are not working.
    exit /b 1
)
python -X utf8 qt_prototype\check_citations.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Citation or Enter-key test failed - check_citations.py has the details.
    exit /b 1
)
python -X utf8 qt_prototype\check_voice.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Too much speech - check_voice.py has the details.
    exit /b 1
)
python -X utf8 tools\check_search_deadline.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Search deadline or straggler-thread test failed - tools\check_search_deadline.py has the details.
    exit /b 1
)
python -X utf8 qt_prototype\check_prefs.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Preferences test failed - the settings dialog or the API key fields are wrong.
    exit /b 1
)
python -X utf8 qt_prototype\check_context_menu.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Result context-menu test failed - the Application key must open the row menu with the arrows working.
    exit /b 1
)
python -X utf8 tools\check_book_dl.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Book download-enrichment test failed - tools\check_book_dl.py has the details.
    exit /b 1
)
python -X utf8 tools\check_abstracts.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Abstract-on-demand test failed - tools\check_abstracts.py has the details.
    exit /b 1
)

echo [6/6] Building the executable with PyInstaller...
if exist build rmdir /s /q build
if exist "%EXE%" del /q "%EXE%"
python -m PyInstaller acadsearch.spec --noconfirm --clean
if errorlevel 1 (
    echo [ERROR] PyInstaller build failed. See the log above.
    exit /b 1
)

if not exist "%EXE%" (
    echo [ERROR] Build reported success but %EXE% is missing.
    exit /b 1
)

for %%F in ("%EXE%") do set "SIZE=%%~zF"
set /a MB=!SIZE! / 1048576

REM After the build, not before: only the finished binary can prove that the
REM version the app reports is the version the user downloads.
python -X utf8 tools\check_version.py >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Version mismatch - the app, the exe and the installer disagree.
    echo         Run: python -X utf8 tools\check_version.py
    exit /b 1
)

echo.
echo ============================================================
echo  BUILD OK   dist\AcadSearch.exe  (~!MB! MB)
echo ============================================================
echo Run it:      "%CD%\dist\AcadSearch.exe"
echo Installer:   build_exe.bat installer
echo.
goto :eof

:installer
if not exist "%EXE%" (
    echo [ERROR] %EXE% not found. Run build_exe.bat first.
    exit /b 1
)
REM Inno Setup is not on PATH by default; the per-user install is the usual
REM location. Fall back to whatever is on PATH so this works either way.
set "ISCC="
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC for %%I in (ISCC.exe) do if not "%%~$PATH:I"=="" set "ISCC=%%~$PATH:I"
if not defined ISCC (
    echo [ERROR] Inno Setup 6 not found. Install it, then run this again.
    exit /b 1
)
echo Building the installer with "%ISCC%"...
"%ISCC%" installer\Acadsearch.iss
if errorlevel 1 (
    echo [ERROR] Installer build failed.
    exit /b 1
)
echo [OK] Installer written to dist\AcadSearch-Setup-*.exe
goto :eof

:clean
echo Cleaning build artefacts...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist __pycache__ rmdir /s /q __pycache__
for /d /r "%CD%\app" %%D in (__pycache__) do rmdir /s /q "%%D" 2>nul
for /d /r "%CD%\tools" %%D in (__pycache__) do rmdir /s /q "%%D" 2>nul
echo Done.
goto :eof

:verify
if not exist "%EXE%" (
    echo [ERROR] %EXE% not found. Run build_exe.bat first.
    exit /b 1
)
REM A frozen build can differ from the source tree: modules PyInstaller could
REM not see are missing at runtime, so the packaged window is inspected through
REM UI Automation. That is the same tree NVDA reads, so this catches an
REM unlabelled or missing control before a user ever opens it.
if exist qt_prototype\check_exe_uia.ps1 (
    echo Launching the packaged window...
    start "" "%EXE%"
    echo Waiting for it to appear, then reading it with UI Automation...
    powershell -NoProfile -ExecutionPolicy Bypass -File qt_prototype\check_exe_uia.ps1
    if errorlevel 1 (
        echo [ERROR] The packaged window did not expose the expected controls.
        echo         Close it, fix the problem, rebuild.
        exit /b 1
    )
    echo [OK] Frozen build exposes every control a screen reader needs.
) else (
    echo [SKIP] qt_prototype\check_exe_uia.ps1 is missing; skipping the UIA check.
)
echo.
echo Press any key to close the window and finish.
pause >nul
goto :eof
