"""Check the search filters: language, publication years, and font persistence.

These are the settings a reader changes once and expects to still be there
next time. They are also easy to break silently, because a combo box that looks
right but never reaches the query object produces a window that filters nothing
and reports no error.
"""

from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from PySide6.QtWidgets import QApplication

import app.config as config_module
from app.config import Config, get_config
from app.models import LANGUAGES

import main_window

FAILED: list[str] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if condition else 'FAIL'}] {label}" + (f" -- {detail}" if detail else ""))
    if not condition:
        FAILED.append(label)


def fresh(file_data: dict | None = None) -> Config:
    """Build a config as if ``config.json`` held exactly ``file_data``.

    The real reader is swapped out so the checks do not depend on whatever the
    developer last saved on this machine -- otherwise "the default is all
    languages" fails for anyone who has ever used the filter.
    """
    original = config_module._read_config_file
    payload = {} if file_data is None else file_data
    config_module._read_config_file = lambda: dict(payload)
    try:
        return Config()
    finally:
        config_module._read_config_file = original


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()
    app.processEvents()

    config = get_config()
    pristine = fresh()
    config.search_language = pristine.search_language
    config.year_from = pristine.year_from
    config.year_to = pristine.year_to
    config.save()

    print("== defaults on a clean install ==")
    check("language filter starts at all languages",
          pristine.search_language == "any", pristine.search_language)
    check("no year bounds by default",
          (pristine.year_from, pristine.year_to) == (None, None),
          f"{pristine.year_from}..{pristine.year_to}")

    print()
    print("== language filter ==")
    check("four choices: all + Arabic + French + English",
          win.lang_combo.count() == 4,
          str([win.lang_combo.itemText(i) for i in range(win.lang_combo.count())]))
    check("'any' is selected, so a search is never silently empty",
          win.lang_combo.currentData() == "any", str(win.lang_combo.currentData()))
    check("every choice is a code the query understands",
          all(win.lang_combo.itemData(i) in {c for c, _, _ in LANGUAGES}
              for i in range(win.lang_combo.count())))

    index = next(i for i in range(win.lang_combo.count())
                 if win.lang_combo.itemData(i) == "fr")
    win.lang_combo.setCurrentIndex(index)
    app.processEvents()
    check("choosing French is remembered in the config",
          config.search_language == "fr", config.search_language)

    print()
    print("== publication year filter ==")
    check("no bound by default", win.year_from.value() == 0)
    win.year_from.setValue(2015)
    win.year_to.setValue(2020)
    app.processEvents()
    check("lower bound is remembered", config.year_from == 2015, str(config.year_from))
    check("upper bound is remembered", config.year_to == 2020, str(config.year_to))

    print()
    print("== the filters reach the query that is actually run ==")
    captured: dict = {}

    class _Signal:
        def connect(self, *_args, **_kwargs):
            pass

    class _FakeWorker:
        """Captures the query instead of hitting the network."""

        def __init__(self, engine, query, parent=None):
            captured["query"] = query
            self.done_ok = _Signal()
            self.done_fail = _Signal()

        def start(self):
            pass

        def isRunning(self):
            return False

        def wait(self, _ms=0):
            return True

    original_worker = main_window.SearchWorker
    main_window.SearchWorker = _FakeWorker
    try:
        win.query.setText("intelligence artificielle")
        win.start_search()
    finally:
        main_window.SearchWorker = original_worker

    query = captured.get("query")
    check("a query was built", query is not None)
    if query is not None:
        check("the query carries the chosen language",
              query.language == "fr", query.language)
        check("the query carries the year window",
              (query.year_from, query.year_to) == (2015, 2020),
              f"{query.year_from}..{query.year_to}")
        check("the query still covers all three categories",
              len(query.categories) == 3, str(len(query.categories)))

    print()
    print("== filters survive a restart ==")
    config.save()
    reloaded = Config()
    check("French is still selected after re-reading config.json",
          reloaded.search_language == "fr", reloaded.search_language)
    check("the year window is still there",
          (reloaded.year_from, reloaded.year_to) == (2015, 2020),
          f"{reloaded.year_from}..{reloaded.year_to}")

    print()
    print("== a silly config cannot break the filter ==")
    broken = fresh(
        {
            "searchLanguage": "not-a-language",
            "yearFrom": 99999,
            "yearTo": None,
        }
    )
    check("an unknown language falls back to all",
          broken.search_language == "any", broken.search_language)
    check("an impossible year is dropped", broken.year_from is None,
          str(broken.year_from))

    swapped = fresh({"yearFrom": 2024, "yearTo": 2010})
    check("reversed years are swapped rather than emptying the search",
          (swapped.year_from, swapped.year_to) == (2010, 2024),
          f"{swapped.year_from}..{swapped.year_to}")

    print()
    print("== font size is remembered ==")
    win.apply_font_size(14)
    check("zoom stores the size", abs(get_config().font_scale - 1.4) < 0.01,
          str(get_config().font_scale))
    win.apply_font_size(10)

    print()
    print("== put the settings back ==")
    config.search_language = "any"
    config.year_from = None
    config.year_to = None
    config.font_scale = 1.0
    config.save()
    win.lang_combo.setCurrentIndex(0)
    win.year_from.setValue(0)
    win.year_to.setValue(0)
    print("  config restored to defaults")

    print()
    if FAILED:
        print(f"FAILED: {len(FAILED)} -> {FAILED}")
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())