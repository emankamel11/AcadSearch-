"""Check the search filters: language, publication years, and font persistence.

These are the settings a reader changes once and expects to still be there
next time. They are also easy to break silently, because a combo box that looks
right but never reaches the query object produces a window that filters nothing
and reports no error.
"""

from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from PySide6.QtWidgets import QApplication

import app.config as config_module
from app import i18n
from app.config import Config, get_config
from app.models import (
    LANGUAGES,
    Category,
    DownloadFormat,
    DownloadTarget,
    Result,
    SearchQuery,
    SearchResponse,
)

import main_window

FAILED: list[str] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if condition else 'FAIL'}] {label}" + (f" -- {detail}" if detail else ""))
    if not condition:
        FAILED.append(label)


def fresh(file_data: dict | None = None) -> Config:
    """Build a config as if ``config.json`` held exactly ``file_data``.

    The real reader is swapped out so the checks do not depend on whatever the
    developer last saved on this machine -- otherwise "the default is all
    languages" fails for anyone who has ever used the filter.
    """
    original = config_module._read_config_file
    payload = {} if file_data is None else file_data
    config_module._read_config_file = lambda: dict(payload)
    try:
        return Config()
    finally:
        config_module._read_config_file = original


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()
    app.processEvents()

    config = get_config()
    pristine = fresh()
    config.search_language = pristine.search_language
    config.year_from = pristine.year_from
    config.year_to = pristine.year_to
    config.save()

    print("== defaults on a clean install ==")
    check("language filter starts at all languages",
          pristine.search_language == "any", pristine.search_language)
    check("no year bounds by default",
          (pristine.year_from, pristine.year_to) == (None, None),
          f"{pristine.year_from}..{pristine.year_to}")

    print()
    print("== language filter ==")
    check("four choices: all + Arabic + French + English",
          win.lang_combo.count() == 4,
          str([win.lang_combo.itemText(i) for i in range(win.lang_combo.count())]))
    check("'any' is selected, so a search is never silently empty",
          win.lang_combo.currentData() == "any", str(win.lang_combo.currentData()))
    check("every choice is a code the query understands",
          all(win.lang_combo.itemData(i) in {c for c, _, _ in LANGUAGES}
              for i in range(win.lang_combo.count())))

    index = next(i for i in range(win.lang_combo.count())
                 if win.lang_combo.itemData(i) == "fr")
    win.lang_combo.setCurrentIndex(index)
    app.processEvents()
    check("choosing French is remembered in the config",
          config.search_language == "fr", config.search_language)

    print()
    print("== publication year filter ==")
    check("no bound by default", win.year_from.value() == 0)
    win.year_from.setValue(2015)
    win.year_to.setValue(2020)
    app.processEvents()
    check("lower bound is remembered", config.year_from == 2015, str(config.year_from))
    check("upper bound is remembered", config.year_to == 2020, str(config.year_to))

    print()
    print("== the filters reach the query that is actually run ==")
    captured: dict = {}

    class _Signal:
        def connect(self, *_args, **_kwargs):
            pass

    class _FakeWorker:
        """Captures the query instead of hitting the network."""

        def __init__(self, engine, query, parent=None):
            captured["query"] = query
            self.done_ok = _Signal()
            self.done_fail = _Signal()

        def start(self):
            pass

        def isRunning(self):
            return False

        def wait(self, _ms=0):
            return True

    original_worker = main_window.SearchWorker
    main_window.SearchWorker = _FakeWorker
    try:
        title_index = next(
            i for i in range(win.search_field.count())
            if win.search_field.itemData(i) == "title"
        )
        win.search_field.setCurrentIndex(title_index)
        win.query.setText("intelligence artificielle")
        win.start_search()
    finally:
        main_window.SearchWorker = original_worker

    check("the search-field menu offers Any + title + author + ISBN",
          [win.search_field.itemData(i) for i in range(win.search_field.count())]
          == ["any", "title", "author", "isbn"],
          str([win.search_field.itemData(i)
               for i in range(win.search_field.count())]))
    check("the search-field menu has an accessible name",
          bool(win.search_field.accessibleName()),
          win.search_field.accessibleName())

    query = captured.get("query")
    check("a query was built", query is not None)
    if query is not None:
        check("the query carries the chosen language",
              query.language == "fr", query.language)
        check("the query carries the year window",
              (query.year_from, query.year_to) == (2015, 2020),
              f"{query.year_from}..{query.year_to}")
        check("the query still covers all three categories",
              len(query.categories) == 3, str(len(query.categories)))
        check("the query carries the chosen search field",
              query.field == "title", query.field)

    print()
    print("== filters survive a restart ==")
    config.save()
    reloaded = Config()
    check("French is still selected after re-reading config.json",
          reloaded.search_language == "fr", reloaded.search_language)
    check("the year window is still there",
          (reloaded.year_from, reloaded.year_to) == (2015, 2020),
          f"{reloaded.year_from}..{reloaded.year_to}")

    print()
    print("== availability filter ==")
    page = win.pages[Category.BOOK]
    page.clear()
    page.add(Result(
        category=Category.BOOK,
        title="Downloadable book",
        source="open_library",
        downloads=[DownloadTarget("https://example.org/a.pdf", DownloadFormat.PDF)],
        landing_url="https://example.org/a",
    ))
    page.add(Result(
        category=Category.BOOK,
        title="Read on site book",
        source="open_library",
        landing_url="https://example.org/b",
    ))
    page.add(Result(
        category=Category.BOOK,
        title="Metadata only book",
        source="open_library",
    ))
    win._apply_availability_filter("any")
    check("all three rows are visible before filtering",
          page.visible_count() == 3, str(page.visible_count()))

    def avail_index(code: str) -> int:
        return next(i for i in range(win.avail_combo.count())
                    if win.avail_combo.itemData(i) == code)

    # Park the caret on a row that the next filter will hide, then prove the
    # filter moves it instead of leaving Enter/Alt+D aimed at an invisible row.
    page.list.setCurrentRow(1)
    win.avail_combo.setCurrentIndex(avail_index("download"))
    app.processEvents()
    check("downloadable-only keeps the one file row",
          page.visible_count() == 1, str(page.visible_count()))
    check("the tab label counts only visible rows",
          win.tabs.tabText(main_window.CATEGORY_TAB_INDEX[Category.BOOK]).endswith("(1)"),
          win.tabs.tabText(main_window.CATEGORY_TAB_INDEX[Category.BOOK]))
    check("the caret moved off the hidden row",
          page.list.currentRow() == 0 and not page._row_hidden(0),
          str(page.list.currentRow()))

    win.avail_combo.setCurrentIndex(avail_index("read"))
    app.processEvents()
    check("read-on-site keeps only the landing-page row",
          page.visible_count() == 1, str(page.visible_count()))

    win.avail_combo.setCurrentIndex(avail_index("download_or_read"))
    app.processEvents()
    check("download-or-read keeps both reachable rows",
          page.visible_count() == 2, str(page.visible_count()))

    win.avail_combo.setCurrentIndex(avail_index("any"))
    app.processEvents()
    check("All brings every row back", page.visible_count() == 3,
          str(page.visible_count()))
    page.clear()
    page.update_count()

    print()
    print("== empty result screens say which filter was responsible ==")
    for tab in win.pages.values():
        tab.clear()
        tab.update_count()
    title_miss = SearchResponse(
        query=SearchQuery(text="quantum gravity", field="title"),
        field_empty=True,
    )
    win._on_results(title_miss, "")
    check("a field-only miss suggests Any field",
          i18n.t("win.none.field", term="quantum gravity") in win.status.text(),
          win.status.text())

    for tab in win.pages.values():
        tab.clear()
        tab.update_count()
    win.avail_combo.setCurrentIndex(avail_index("download"))
    metadata_only = SearchResponse(
        query=SearchQuery(text="metadata book"),
        results={Category.BOOK: [Result(
            category=Category.BOOK,
            title="Metadata only book",
            source="open_library",
        )]},
    )
    win._on_results(metadata_only, "")
    expected = i18n.t(
        "win.none.availability",
        term="metadata book",
        filter=win.avail_combo.currentText(),
    )
    check("an availability filter that hid everything is named",
          expected in win.status.text(), win.status.text())
    check("its tab reports zero visible results",
          win.tabs.tabText(main_window.CATEGORY_TAB_INDEX[Category.BOOK]).endswith("(0)"),
          win.tabs.tabText(main_window.CATEGORY_TAB_INDEX[Category.BOOK]))
    win.avail_combo.setCurrentIndex(avail_index("any"))
    for tab in win.pages.values():
        tab.clear()
        tab.update_count()

    print()
    print("== a silly config cannot break the filter ==")
    broken = fresh(
        {
            "searchLanguage": "not-a-language",
            "yearFrom": 99999,
            "yearTo": None,
        }
    )
    check("an unknown language falls back to all",
          broken.search_language == "any", broken.search_language)
    check("an impossible year is dropped", broken.year_from is None,
          str(broken.year_from))

    swapped = fresh({"yearFrom": 2024, "yearTo": 2010})
    check("reversed years are swapped rather than emptying the search",
          (swapped.year_from, swapped.year_to) == (2010, 2024),
          f"{swapped.year_from}..{swapped.year_to}")

    print()
    print("== font size is remembered ==")
    win.apply_font_size(14)
    check("zoom stores the size", abs(get_config().font_scale - 1.4) < 0.01,
          str(get_config().font_scale))
    win.apply_font_size(10)

    print()
    print("== put the settings back ==")
    config.search_language = "any"
    config.year_from = None
    config.year_to = None
    config.font_scale = 1.0
    config.availability_filter = "any"
    config.save()
    win.lang_combo.setCurrentIndex(0)
    win.year_from.setValue(0)
    win.year_to.setValue(0)
    win.avail_combo.setCurrentIndex(0)
    win.search_field.setCurrentIndex(0)
    print("  config restored to defaults")

    print()
    if FAILED:
        print(f"FAILED: {len(FAILED)} -> {FAILED}")
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())