"""Open Library — free reference books, subjects and Archive.org links.

Docs: https://openlibrary.org/dev/docs/api/search
No API key required. Very generous rate limits.
"""

from __future__ import annotations

import threading

from app.core.text_utils import (
    as_float,
    as_int,
    clean_text,
    first,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://openlibrary.org/search.json"
COVER = "https://covers.openlibrary.org/b/id/{cover_i}-L.jpg"

FIELDS = (
    "key,title,subtitle,author_name,first_publish_year,subject,number_of_pages_median,"
    "edition_key,ia,ocaid,cover_i,ratings_average,ratings_count,language,publisher,"
    "isbn,edition_count,first_sentence"
)

#: ISO-639-1 -> the ISO-639-3 codes Open Library expects in ``language=``.
LANG1_TO_LANG3: dict[str, list[str]] = {
    "ar": ["ara", "per", "fas", "urd"],
    "en": ["eng"],
    "fr": ["fre", "fra"],
    "de": ["ger", "deu"],
    "es": ["spa"],
    "it": ["ita"],
    "pt": ["por"],
    "ru": ["rus"],
    "zh": ["chi", "zho"],
    "ja": ["jpn"],
    "ko": ["kor"],
    "tr": ["tur"],
    "fa": ["per", "fas"],
    "ur": ["urd"],
    "he": ["heb"],
    "hi": ["hin"],
    "nl": ["dut", "nld"],
    "pl": ["pol"],
    "sv": ["swe"],
    "id": ["ind"],
}


@register
class OpenLibraryProvider(BaseProvider):
    provider_id = "open_library"
    display_name = "Open Library"
    categories = (Category.BOOK,)
    weight = 10
    homepage = "https://openlibrary.org"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        params: dict[str, object] = {
            "q": query.text,
            "limit": query.per_source,
            "fields": FIELDS,
        }
        if query.language and query.language != "any":
            # Exactly one code: Open Library ANDs the values in a comma list
            # rather than OR-ing them, so "fre,fra" matches nothing while "fre"
            # matches. The first entry is the bibliographic (B) code.
            codes = LANG1_TO_LANG3.get(query.language)
            if codes:
                params["language"] = codes[0]
        if query.year_from or query.year_to:
            # Open Library only supports an upper bound; lower bounds are filtered locally.
            if query.year_from and not query.year_to:
                params["q"] = f"{query.text} first_publish_year:[{query.year_from} TO 3000]"

        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        docs = payload.get("docs") or []
        return [self._to_result(doc) for doc in docs]

    # -- mapping ----------------------------------------------------------
    def _to_result(self, doc: dict) -> Result:
        title = clean_text(doc.get("title"))
        subtitle = clean_text(doc.get("subtitle"))
        if subtitle and subtitle.lower() not in title.lower():
            title = f"{title}: {subtitle}"

        authors = [clean_text(a) for a in (doc.get("author_name") or []) if a]
        subjects = [clean_text(s) for s in (doc.get("subject") or [])[:8] if s]

        key = clean_text(doc.get("key"))
        olid = key.rsplit("/", 1)[-1] if key else ""
        landing = f"https://openlibrary.org{key}" if key else ""

        downloads = []
        # Internet Archive: legitimately hosted full text (free or borrowable).
        for ia_id in (doc.get("ia") or [])[:1]:
            ia_id = clean_text(ia_id)
            if ia_id:
                downloads.append(
                    target(
                        f"https://archive.org/details/{ia_id}",
                        DownloadFormat.HTML,
                        label="Internet Archive",
                        open_access=True,
                    )
                )
        # Open Content Alliance = public-domain, free to read. The identifier
        # only guarantees a *landing page*: Archive.org serves the actual PDF
        # from a per-item file whose name is not derivable here, so this stays
        # HTML rather than claiming a PDF the downloader would mis-save.
        for ocaid in (doc.get("ocaid") or [])[:1]:
            ocaid = clean_text(ocaid)
            if ocaid:
                downloads.append(
                    target(
                        f"https://archive.org/details/{ocaid}",
                        DownloadFormat.HTML,
                        label="Archive.org (free full text)",
                        open_access=True,
                    )
                )
        if landing:
            downloads.append(
                target(landing, DownloadFormat.HTML, label="Open Library", open_access=True)
            )

        identifiers = {}
        if olid:
            identifiers["olid"] = olid
        # A book Open Library links to Archive.org can be resolved to a real
        # file later, so the downloader keeps the identifier even when the
        # search response itself only carried a landing page.
        for src in ("ia", "ocaid"):
            for candidate in (doc.get(src) or [])[:1]:
                candidate = clean_text(candidate)
                if candidate:
                    identifiers.setdefault("ia", candidate)
                    break
        # The API returns partial/truncated ISBNs too; keep only well-formed ones.
        isbn_list = [
            clean_text(i).replace("-", "").upper()
            for i in (doc.get("isbn") or [])[:12]
            if _valid_isbn(clean_text(i))
        ]
        if isbn_list:
            identifiers["isbn"] = ", ".join(dict.fromkeys(isbn_list))

        cover_id = as_int(doc.get("cover_i"))
        return Result(
            category=Category.BOOK,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=as_int(doc.get("first_publish_year")),
            abstract=self._summary(doc, subjects),
            venue=first(doc.get("publisher")),
            publisher=first(doc.get("publisher")),
            language=normalise_language(first(doc.get("language"))),
            subjects=subjects,
            identifiers=identifiers,
            access=_access(doc),
            downloads=downloads,
            landing_url=landing,
            cover_url=COVER.format(cover_i=cover_id) if cover_id else None,
            rating=as_float(doc.get("ratings_average")),
            pages=as_int(doc.get("number_of_pages_median")),
            item_type="Book",
            raw=doc,
        )

    @staticmethod
    def _summary(doc: dict, subjects: list[str]) -> str:
        """Open Library has no abstracts; build a short, honest description."""
        parts: list[str] = []
        sentence = clean_text(doc.get("first_sentence"))
        if sentence:
            parts.append(sentence)
        publisher = first(doc.get("publisher"))
        year = as_int(doc.get("first_publish_year"))
        editions = as_int(doc.get("edition_count"))
        meta: list[str] = []
        if editions:
            meta.append(f"{editions} edition{'s' if editions != 1 else ''}")
        if publisher:
            meta.append(publisher)
        if year:
            meta.append(str(year))
        if meta:
            parts.append(" — ".join(meta))
        if subjects:
            parts.append(" · " + ", ".join(subjects[:6]))
        return truncate_words(" ".join(parts), 320)


def _access(doc: dict) -> Access:
    """Public-domain (OCAID) beats borrowable: it needs no login or loan."""
    if doc.get("ocaid"):
        return Access.DOWNLOAD
    if doc.get("ia"):
        return Access.BORROW
    return Access.LANDING


def _valid_isbn(value: str) -> bool:
    """ISBN-10 or ISBN-13, digits (plus ``X``) only."""
    compact = value.replace("-", "").replace(" ", "").upper()
    if len(compact) == 10:
        return compact[:9].isdigit() and (compact[9].isdigit() or compact[9] == "X")
    if len(compact) == 13:
        return compact.isdigit()
    return False
