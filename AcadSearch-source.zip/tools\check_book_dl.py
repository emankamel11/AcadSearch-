"""Book download enrichment check (offline).

A book that only carried a landing page during the search must still resolve
to a real file when the user acts on it, as long as the record names an
Archive.org identifier. This check fakes the Archive.org resolver so it needs
no network, and proves:

  * a BOOK with an ``ia`` identifier is enriched to a real PDF target;
  * the enriched files are kept on the result (menu now says ‎تنزيل‎);
  * an ARTICLE with the same identifier is left alone;
  * a BOOK without an identifier keeps the landing-page behaviour.

Run:  python -X utf8 tools/check_book_dl.py
"""

from __future__ import annotations

import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core.downloader import DownloadManager  # noqa: E402
from app.models import (  # noqa: E402
    Access,
    Category,
    DownloadFormat,
    DownloadTarget,
    Result,
)

passed = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global passed
    marker = "PASS" if condition else "FAIL"
    if condition:
        passed += 1
    print(f"  [{marker}] {name}" + (f" -- {detail}" if detail else ""))


def book(ia_id: str | None, category: Category = Category.BOOK) -> Result:
    identifiers = {}
    if ia_id:
        identifiers["ia"] = ia_id
    return Result(
        category=category,
        title="The Art of War",
        source="open_library",
        authors=["Sun Tzu"],
        year=1910,
        access=Access.LANDING,
        identifiers=identifiers,
        downloads=[
            DownloadTarget(
                url="https://archive.org/details/artofwar",
                fmt=DownloadFormat.HTML,
                label="Internet Archive",
                open_access=True,
            )
        ],
        landing_url="https://archive.org/details/artofwar",
    )


FAKE_PDF = DownloadTarget(
    url="https://archive.org/download/artofwar/artofwar.pdf",
    fmt=DownloadFormat.PDF,
    label="PDF (1.2 MB)",
    open_access=True,
)

# Replace the Archive.org resolver with a deterministic fake.
import app.providers.internet_archive as _ia  # noqa: E402

_ia.resolve_open_files = lambda _ident, _title="", _http=None: [FAKE_PDF]

print("== a resolvable book becomes a real download ==")
record = book("artofwar")
target = DownloadManager._resolve_book_file(record)
check("a PDF target is chosen", target is not None and target.fmt is DownloadFormat.PDF,
      str(target))
check("the file is recorded on the result", any(
    t.fmt is DownloadFormat.PDF for t in record.downloads))
check("the card now reads downloadable", record.access is Access.DOWNLOAD)

print("== enqueue routes the action to the file, not the browser ==")
manager = DownloadManager(max_concurrent=1)
record = book("artofwar")
task = manager.enqueue(record)
check("a task came back", task is not None)
check("the task downloads the PDF", task is not None
      and task.target.fmt is DownloadFormat.PDF, str(task.target if task else None))
if task is not None:
    manager.cancel_all()
    time.sleep(0.5)

print("== a book without an identifier keeps the landing page ==")
record = book(None)
target = DownloadManager._resolve_book_file(record)
check("nothing is resolved", target is None)
manager = DownloadManager(max_concurrent=1)
task = manager.enqueue(record)
check("the browser fallback is offered",
      task is not None and task.target.fmt is DownloadFormat.SOURCE,
      str(task.target if task else None))
if task is not None:
    manager.cancel_all()
    time.sleep(0.5)

print("== a non-book result is never enriched ==")
record = book("artofwar", category=Category.ARTICLE)
target = DownloadManager._resolve_book_file(record)
check("the article is untouched", target is None and len(record.downloads) == 1)

print()
if passed == 8:
    print("CHECK PASSED (8/8)")
    sys.exit(0)
print(f"CHECK FAILED ({passed}/8)")
sys.exit(1)