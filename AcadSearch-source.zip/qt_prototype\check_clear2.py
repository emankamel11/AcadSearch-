"""Reproduce clear the way the real launcher does it.

The report is that clicking مسح leaves the text in the box. The tests call
_clear() directly, which always worked, so the difference must be in how the
button is reached: a real click through the window, or the keyboard.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QKeyEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QPushButton

import main_window


def clear_btn(win):
    for b in win.findChildren(QPushButton):
        if "مسح" in (b.accessibleName() or ""):
            return b
    return None


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()
    win.raise_()
    win.activateWindow()

    def scenario_1_real_click():
        print("=== 1. real mouse click on the button ===")
        btn = clear_btn(win)
        win.query.setText("machine learning")
        win.query.setFocus()
        print("   before:", repr(win.query.text()))
        QTest.mouseClick(btn, Qt.LeftButton, pos=btn.rect().center())
        app.processEvents()
        print("   after :", repr(win.query.text()))
        print()

    def scenario_2_tab_to_button():
        print("=== 2. Tab from the entry until the button has focus, then Space ===")
        win.query.setText("machine learning")
        btn = clear_btn(win)
        btn.setFocus()
        app.processEvents()
        print("   button hasFocus:", btn.hasFocus())
        log = []
        original = win._clear
        win._clear = lambda: (log.append("called"), original())
        QTest.keyClick(btn, Qt.Key_Space)
        app.processEvents()
        print("   _clear called  :", bool(log))
        print("   after          :", repr(win.query.text()))
        win._clear = original
        print()

    def scenario_3_is_the_button_really_the_clear_one():
        print("=== 3. which buttons exist, and what is each wired to ===")
        for b in win.findChildren(QPushButton):
            print(f"   text={b.text()!r:12} name={b.accessibleName()!r}")
        print()

    def scenario_4_focus_stays_in_the_box():
        print("=== 4. type text, then click clear while the caret is in the box ===")
        win.query.setText("machine learning")
        win.query.setCursorPosition(0)
        app.processEvents()
        btn = clear_btn(win)
        QTest.mouseClick(btn, Qt.LeftButton)
        app.processEvents()
        print("   after :", repr(win.query.text()))
        print("   value():", repr(win.query.text()))
        print()

    steps = [scenario_1_real_click, scenario_2_tab_to_button,
             scenario_3_is_the_button_really_the_clear_one,
             scenario_4_focus_stays_in_the_box]

    state = {"i": 0}

    def run_next():
        if state["i"] >= len(steps):
            app.quit()
            return
        steps[state["i"]]()
        state["i"] += 1
        QTimer.singleShot(300, run_next)

    QTimer.singleShot(600, run_next)
    QTimer.singleShot(15000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())