"""Entry point for the packaged AcadSearch build.

PyInstaller needs one top-level script. The interface lives in
``qt_prototype`` rather than beside ``app`` because it is still being built
piece by piece, so this module fixes the import paths and then hands over.

Kept deliberately thin: anything clever here ends up in a frozen build where it
cannot be debugged from source.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _prepare_paths() -> None:
    """Make ``app`` and ``qt_prototype`` importable, frozen or not.

    In a one-file build the code lives under ``sys._MEIPASS``; from source it
    is the parent of this file. Both need to be on the path before anything is
    imported, so this runs before the interface import below.
    """
    if getattr(sys, "frozen", False):
        root = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    else:
        root = Path(__file__).resolve().parent

    for candidate in (root, root / "qt_prototype"):
        text = str(candidate)
        if candidate.is_dir() and text not in sys.path:
            sys.path.insert(0, text)


def _configure_high_dpi() -> None:
    """Let Qt scale the interface on a high-resolution screen.

    Without this the window is drawn at 96dpi and looks tiny and blurry on a
    4K laptop, which for a low-vision user means unreadable rather than merely
    small. Runs before the QApplication exists.
    """
    os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
    os.environ.setdefault("QT_SCALE_FACTOR_ROUNDING_POLICY", "PassThrough")


def _diagnose_ai() -> int:
    """Write why the packaged app cannot reach Gemini to a file.

    The frozen build has no console, so a network failure there is otherwise
    only visible as a spoken sentence in the interface. This reports the TLS
    stack, the CA bundle, DNS, and the real exception chain, then exits before
    any window is created.
    """
    import json
    import socket
    import ssl
    import tempfile
    import traceback

    lines: list[str] = []

    def say(text: str) -> None:
        lines.append(text)

    say(f"frozen={getattr(sys, 'frozen', False)}")
    say(f"meipass={getattr(sys, '_MEIPASS', '')}")
    say(f"python={sys.version.split()[0]}")
    say(f"openssl={ssl.OPENSSL_VERSION}")

    try:
        import certifi

        where = certifi.where()
        size = os.path.getsize(where) if os.path.exists(where) else -1
        say(f"certifi={where} exists={os.path.exists(where)} size={size}")
    except Exception as exc:  # noqa: BLE001 - the point is to report it
        say(f"certifi FAILED {type(exc).__name__}: {exc}")

    for name in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
                 "REQUESTS_CA_BUNDLE", "SSL_CERT_FILE"):
        say(f"env {name}={os.environ.get(name, '')!r}")

    host = "generativelanguage.googleapis.com"
    try:
        infos = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        say(f"dns={sorted({i[4][0] for i in infos})}")
    except Exception as exc:  # noqa: BLE001
        say(f"dns FAILED {type(exc).__name__}: {exc}")

    for label, verify in (("default", None), ("certifi", True), ("none", False)):
        try:
            ctx = ssl.create_default_context()
            if verify is True:
                import certifi as _certifi

                ctx.load_verify_locations(_certifi.where())
            if verify is False:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            with socket.create_connection((host, 443), timeout=15) as raw:
                with ctx.wrap_socket(raw, server_hostname=host) as tls:
                    cert = tls.getpeercert()
                    issuer = dict(x[0] for x in cert.get("issuer", ())) if cert else {}
                    say(f"tls {label}=ok {tls.version()} issuer={issuer.get('organizationName', '?')}")
        except Exception as exc:  # noqa: BLE001
            say(f"tls {label}=FAILED {type(exc).__name__}: {exc}")

    try:
        from app.config import get_config
        from app.core import doc_ai

        key = get_config().gemini_key.strip()
        say(f"key length={len(key)} model={doc_ai.DEFAULT_MODEL}")

        import certifi
        import requests

        attempts = [("plain", {})]
        try:
            attempts.append(("certifi", {"verify": certifi.where()}))
        except Exception:  # noqa: BLE001
            pass
        attempts.append(("noverify", {"verify": False}))

        for label, kwargs in attempts:
            try:
                response = requests.get(
                    f"{doc_ai.API_ROOT}/{doc_ai.DEFAULT_MODEL}",
                    headers={"x-goog-api-key": key},
                    timeout=(10, 30),
                    **kwargs,
                )
                say(f"get {label}={response.status_code}")
            except Exception as exc:  # noqa: BLE001
                say(f"get {label}=FAILED {type(exc).__name__}: {str(exc)[:300]}")

        try:
            text = doc_ai._post(
                {"contents": [{"parts": [{"text": "Reply with: OK"}]}]},
                doc_ai.DEFAULT_MODEL,
                key,
                45,
            )
            say(f"generate=ok {text.strip()[:40]!r}")
        except Exception as exc:  # noqa: BLE001
            say(f"generate=FAILED {type(exc).__name__}: {str(exc)[:300]}")
            cause = exc.__cause__
            while cause is not None:
                say(f"  caused by {type(cause).__name__}: {str(cause)[:300]}")
                cause = cause.__cause__
            say(traceback.format_exc()[-1500:])

        # A real book is not a 20-byte prompt: a text file is uploaded as up to
        # 400k characters, and a scanned one as twelve page images. Both are
        # tested here because a connection reset on a large body is exactly the
        # kind of failure the small call cannot show.
        work = Path(tempfile.gettempdir()) / "acad-ai-diag"
        work.mkdir(exist_ok=True)

        try:
            odt = work / "big.odt"
            paragraph = ("هذه فقرة اختبار طويلة تتكرر لقياس حجم الطلب. " * 12)
            body = "".join(f"<text:p>{paragraph}</text:p>" for _ in range(600))
            xml = (
                '<?xml version="1.0" encoding="UTF-8"?>'
                '<office:document-content '
                'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
                'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0">'
                f"<office:body><office:text>{body}</office:text></office:body>"
                "</office:document-content>"
            )
            import zipfile

            with zipfile.ZipFile(odt, "w") as archive:
                archive.writestr("content.xml", xml)
            answer = doc_ai.summarize(odt, timeout=120)
            say(f"big-text=ok chars={answer.chars} reply={answer.text.strip()[:60]!r}")
        except Exception as exc:  # noqa: BLE001
            say(f"big-text=FAILED {type(exc).__name__}: {str(exc)[:300]}")
            say(traceback.format_exc()[-900:])

        try:
            from PIL import Image, ImageDraw

            pdf = work / "scan.pdf"
            pages = []
            for number in range(3):
                image = Image.new("RGB", (1240, 1754), "white")
                draw = ImageDraw.Draw(image)
                for line in range(24):
                    y = 80 + line * 60
                    draw.text((90, y), f"page {number + 1} line {line + 1} " * 4,
                              fill="black")
                pages.append(image)
            pages[0].save(pdf, save_all=True, append_images=pages[1:])
            answer = doc_ai.summarize(pdf, timeout=120)
            say(f"scan-pdf=ok images={answer.images} reply={answer.text.strip()[:60]!r}")
        except Exception as exc:  # noqa: BLE001
            say(f"scan-pdf=FAILED {type(exc).__name__}: {str(exc)[:300]}")
            say(traceback.format_exc()[-900:])
    except Exception:  # noqa: BLE001
        say("diagnostic body failed:\n" + traceback.format_exc())

    target = Path(tempfile.gettempdir()) / "acad_ai_diag.txt"
    try:
        target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except Exception:
        target = Path(sys.executable).with_name("acad_ai_diag.txt")
        target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 0


def _diagnose_books() -> int:
    """Search real novels through the real engine and write what came back.

    The frozen build has no console, so "the novel I searched is not there" is
    otherwise only visible as an empty tab. This runs the same engine and the
    same availability rule the window uses, per provider, then writes the card
    list to ``%TEMP%\\acad_books_diag.txt``. It also prints the stored
    ``availability_filter``, because that one setting can hide every card the
    providers did return.
    """
    import queue
    import tempfile
    import time
    import traceback

    from app.config import get_config
    from app.core.search_engine import SearchEngine
    from app.models import Category, SearchQuery

    titles = [
        "الحرافيش",
        "ذاكرة الجسد",
        "مئة عام من العزلة",
        "ساق البامبو",
        "باب الخروج",
        "الأسود يليق بك",
    ]

    def has_file(item) -> bool:
        # Must mirror qt_prototype.main_window.has_download.
        return any(t.fmt.value in ("pdf", "epub", "zip") for t in item.downloads)

    def visible(item, mode: str) -> bool:
        # Must mirror MainWindow._matches_availability.
        if mode == "any":
            return True
        has_dl = has_file(item)
        has_read = bool(item.landing_url) and not has_dl
        if mode == "download":
            return has_dl
        if mode == "read":
            return has_read
        if mode == "download_or_read":
            return has_dl or has_read or bool(item.landing_url)
        return True

    lines: list[str] = []

    def say(text: str) -> None:
        lines.append(text)

    config = get_config()
    mode = config.availability_filter
    say(f"frozen={getattr(sys, 'frozen', False)}")
    say(f"availability_filter={mode!r} search_language={config.search_language!r}")
    say(f"results_per_source={config.results_per_source} "
        f"max_results_per_tab={config.max_results_per_tab}")
    say("")

    try:
        for field in ("any", "title"):
            for title in titles:
                started = time.monotonic()
                query = SearchQuery(
                    text=title,
                    language=config.search_language or "any",
                    per_source=config.results_per_source,
                    categories={Category.BOOK},
                    field=field,
                )
                engine = SearchEngine()
                handle = engine.start(query)
                final = None
                try:
                    while time.monotonic() - started < 120:
                        try:
                            event = handle.events.get(timeout=1.0)
                        except queue.Empty:
                            continue
                        if event.type.value == "finished":
                            final = event.response
                            break
                        if event.type.value in ("failed", "cancelled"):
                            say(f"FIELD={field} TITLE={title} EVENT={event.type.value} "
                                f"{event.message}")
                            break
                finally:
                    engine.shutdown()

                if final is None:
                    say(f"FIELD={field} TITLE={title} NO FINAL RESPONSE")
                    say("")
                    continue

                books = final.results.get(Category.BOOK, [])
                files = [item for item in books if has_file(item)]
                shown = [item for item in books if visible(item, mode)]
                say(f"FIELD={field} TITLE={title}")
                say(f"  elapsed={final.elapsed:.1f}s cards={len(books)} "
                    f"downloadable={len(files)} visible_after_filter={len(shown)} "
                    f"field_empty={final.field_empty} truncated={final.truncated}")
                for report in final.reports:
                    say(f"  provider {report.provider_id:18s} "
                        f"{report.status.value:8s} count={report.count:3d} "
                        f"{report.seconds:5.1f}s {report.message}")
                for index, item in enumerate(books[:15], 1):
                    real = [t.fmt.value for t in item.downloads
                            if t.fmt.value in ("pdf", "epub", "zip")]
                    say(f"  {index:2d}. [{item.access.value:8s}] "
                        f"files={','.join(real) or '-':9s} "
                        f"src={item.source:15s} {item.title[:60]!r} "
                        f"authors={item.authors[:1]} year={item.year}")
                say("")
    except Exception:  # noqa: BLE001 - the report must explain the failure
        say("diagnostic body failed:\n" + traceback.format_exc())

    target = Path(tempfile.gettempdir()) / "acad_books_diag.txt"
    try:
        target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except Exception:
        target = Path(sys.executable).with_name("acad_books_diag.txt")
        target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 0


def main() -> int:
    _prepare_paths()
    _configure_high_dpi()

    if "--diagnose-ai" in sys.argv:
        return _diagnose_ai()

    if "--diagnose-books" in sys.argv:
        return _diagnose_books()

    from PySide6.QtWidgets import QApplication

    from app import i18n
    from app.config import get_config, migrate_legacy_downloads

    app = QApplication(sys.argv)
    app.setApplicationName("AcadSearch")
    app.setOrganizationName("AcadSearch")

    # A screen reader has to be told the interface language before any widget is
    # built, otherwise NVDA reads Arabic labels with an English voice.
    config = get_config()
    try:
        i18n.set_language(config.ui_language)
    except Exception:  # noqa: BLE001 - a bad config must not stop the app
        pass

    # A config written by an older build does not list the sources added since.
    # ``Config`` already enables them for this session; write the migrated file
    # back once so the settings dialog and config.json agree with the search,
    # instead of re-migrating on every launch.
    if getattr(config, "_migrated_providers", False):
        try:
            config.save()
        except Exception:  # noqa: BLE001 - a read-only config must not block startup
            pass

    from qt_prototype.main_window import MainWindow

    # Files from the old builds sit in a hidden %LOCALAPPDATA% folder. Move them
    # once, into the Downloads folder the app now uses, so nothing a user
    # already downloaded is left behind in a place they cannot see.
    try:
        moved = migrate_legacy_downloads(config)
    except Exception:  # noqa: BLE001 - never block startup on this
        moved = 0

    window = MainWindow()
    window.show()
    window.raise_()
    window.activateWindow()

    # The config already carries a ``font_scale`` from the CustomTkinter build;
    # reuse it so a user who had enlarged the text before keeps that size, and
    # map it onto the Qt point size (scale 1.0 == the 10pt base).
    scale = getattr(config, "font_scale", 1.0) or 1.0
    if scale and scale != 1.0:
        window.apply_font_size(int(round(10 * float(scale))))

    if moved:
        window._status(
            f"نقلنا {moved} ملف قديم لمجلد التنزيلات الجديد: "
            f"{config.download_folder}"
        )
    else:
        window._status(
            "أهلاً. اكتبي كلمة البحث في المربع ثم اضغطي Enter. "
            f"البحث بيجمع من {len(config.enabled_providers)} مصدر علمي"
        )
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())