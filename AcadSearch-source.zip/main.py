"""Entry point for the packaged AcadSearch build.

PyInstaller needs one top-level script. The interface lives in
``qt_prototype`` rather than beside ``app`` because it is still being built
piece by piece, so this module fixes the import paths and then hands over.

Kept deliberately thin: anything clever here ends up in a frozen build where it
cannot be debugged from source.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _prepare_paths() -> None:
    """Make ``app`` and ``qt_prototype`` importable, frozen or not.

    In a one-file build the code lives under ``sys._MEIPASS``; from source it
    is the parent of this file. Both need to be on the path before anything is
    imported, so this runs before the interface import below.
    """
    if getattr(sys, "frozen", False):
        root = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
    else:
        root = Path(__file__).resolve().parent

    for candidate in (root, root / "qt_prototype"):
        text = str(candidate)
        if candidate.is_dir() and text not in sys.path:
            sys.path.insert(0, text)


def _configure_high_dpi() -> None:
    """Let Qt scale the interface on a high-resolution screen.

    Without this the window is drawn at 96dpi and looks tiny and blurry on a
    4K laptop, which for a low-vision user means unreadable rather than merely
    small. Runs before the QApplication exists.
    """
    os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
    os.environ.setdefault("QT_SCALE_FACTOR_ROUNDING_POLICY", "PassThrough")


def main() -> int:
    _prepare_paths()
    _configure_high_dpi()

    from PySide6.QtWidgets import QApplication

    from app import i18n
    from app.config import get_config, migrate_legacy_downloads

    app = QApplication(sys.argv)
    app.setApplicationName("AcadSearch")
    app.setOrganizationName("AcadSearch")

    # A screen reader has to be told the interface language before any widget is
    # built, otherwise NVDA reads Arabic labels with an English voice.
    config = get_config()
    try:
        i18n.set_language(config.ui_language)
    except Exception:  # noqa: BLE001 - a bad config must not stop the app
        pass

    from qt_prototype.main_window import MainWindow

    # Files from the old builds sit in a hidden %LOCALAPPDATA% folder. Move them
    # once, into the Downloads folder the app now uses, so nothing a user
    # already downloaded is left behind in a place they cannot see.
    try:
        moved = migrate_legacy_downloads(config)
    except Exception:  # noqa: BLE001 - never block startup on this
        moved = 0

    window = MainWindow()
    window.show()
    window.raise_()
    window.activateWindow()

    # The config already carries a ``font_scale`` from the CustomTkinter build;
    # reuse it so a user who had enlarged the text before keeps that size, and
    # map it onto the Qt point size (scale 1.0 == the 10pt base).
    scale = getattr(config, "font_scale", 1.0) or 1.0
    if scale and scale != 1.0:
        window.apply_font_size(int(round(10 * float(scale))))

    if moved:
        window._status(
            f"نقلنا {moved} ملف قديم لمجلد التنزيلات الجديد: "
            f"{config.download_folder}"
        )
    else:
        window._status(
            "أهلاً. اكتبي كلمة البحث في المربع ثم اضغطي Enter. "
            f"البحث بيجمع من {len(config.enabled_providers)} مصدر علمي"
        )
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())