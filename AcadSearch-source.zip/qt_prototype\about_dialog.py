"""About window: the facts every "which program is this?" question starts with.

A standalone dialog opened from the About button in the main window, not
buried in Settings. Everything is read from the running program itself and
is selectable so a reader can copy the version or the downloads path.

Every label is focusable and keyboard-selectable: NVDA cannot read a plain
QLabel, so each one gets StrongFocus and TextSelectableByKeyboard, and focus
lands on the title when the dialog opens.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from app import i18n
from app.config import APP_NAME, APP_VERSION, get_config
from qt_prototype.preferences import UI_LANGUAGES, build_date


def _readable(label: QLabel) -> QLabel:
    """Make a label reachable and readable by NVDA.

    A plain QLabel has no focus policy, so Tab skips it and NVDA has nothing
    to land on. StrongFocus + keyboard text selection is what lets a screen
    reader enter the label and read its text.
    """
    label.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
    label.setTextInteractionFlags(
        Qt.TextInteractionFlag.TextSelectableByKeyboard
        | Qt.TextInteractionFlag.TextSelectableByMouse
    )
    return label


class AboutDialog(QDialog):
    """Read-only facts about the running program."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(i18n.t("about.window.title"))
        self.setAccessibleName(i18n.t("about.window.accessible"))
        self.setLayoutDirection(
            Qt.RightToLeft if i18n.is_rtl() else Qt.LeftToRight
        )
        self.setMinimumWidth(480)

        cfg = get_config()
        root = QVBoxLayout(self)

        title = _readable(QLabel(f"{APP_NAME} — {i18n.t('app.subtitle')}"))
        title.setObjectName("HelpTitle")
        title.setWordWrap(True)
        root.addWidget(title)

        about_text = _readable(QLabel(i18n.t("app.menu_about_text")))
        about_text.setObjectName("HelpText")
        about_text.setWordWrap(True)
        root.addWidget(about_text)

        frame = QFrame()
        frame.setFrameShape(QFrame.Shape.StyledPanel)
        form = QFormLayout(frame)

        fields = (
            (i18n.t("prefs.about.version"), APP_VERSION),
            (i18n.t("prefs.about.built"), build_date()),
            (i18n.t("prefs.about.sources"), str(len(cfg.enabled_providers))),
            (i18n.t("prefs.ui_language"),
             dict(UI_LANGUAGES).get(cfg.ui_language, cfg.ui_language)),
            (i18n.t("prefs.download_dir"), str(cfg.download_folder)),
        )
        for label_text, value_text in fields:
            label = _readable(QLabel(label_text))
            value = _readable(QLabel(value_text))
            value.setWordWrap(True)
            value.setAccessibleName(f"{label_text}: {value_text}")
            form.addRow(label, value)

        root.addWidget(frame)
        root.addStretch(1)

        footer = QHBoxLayout()
        footer.addStretch(1)
        close = QPushButton(i18n.t("about.close.text"))
        close.setObjectName("PrimaryButton")
        close.setAccessibleName(i18n.t("about.close.accessible"))
        close.setToolTip(i18n.t("about.close.tooltip"))
        close.setDefault(True)
        close.clicked.connect(self.accept)
        footer.addWidget(close)
        root.addLayout(footer)

        self._title = title

    def showEvent(self, event):  # noqa: N802 - Qt naming
        """Focus the title after the window is visible.

        setFocus() inside __init__ is ignored: the widget has no window yet,
        so Qt drops the request and NVDA lands on nothing. showEvent runs
        once the dialog is on screen, which is when focus actually sticks.
        """
        super().showEvent(event)
        self._title.setFocus()

    def keyPressEvent(self, event):  # noqa: N802 - Qt naming
        """Escape closes, like every other dialog on Windows."""
        if event.key() == Qt.Key_Escape and not event.isAutoRepeat():
            self.accept()
            return
        super().keyPressEvent(event)
