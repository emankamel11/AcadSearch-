"""About panel: what the program is, and the facts behind "which version?".

Shown as a read-only tab inside Preferences, not a separate window: settings
and program information live in one place now, so the header keeps only the
controls a search needs.

The tab answers a first-time reader's real questions in order -- what is this,
what does it do, where does it search, and which version am I running -- then
offers the contact address. Everything sits in a scroll area so a large font,
or the Ctrl+plus zoom, can never push the version and the address off the page
(which is how the tab once appeared to hold nothing but the email).

Every label is focusable and keyboard-selectable: NVDA cannot read a plain
QLabel, so each one gets StrongFocus and TextSelectableByKeyboard.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QAccessible, QAccessibleEvent
from PySide6.QtWidgets import (
    QApplication,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from app import i18n
from app.config import APP_NAME, APP_VERSION, get_config

#: Interface languages offered. Kept here so the About tab can show the
#: language by its readable name without importing the settings dialog.
UI_LANGUAGES = (("ar", "العربية"), ("en", "English"))


def _readable(label: QLabel) -> QLabel:
    """Make a label reachable and readable by NVDA.

    A plain QLabel has no focus policy, so Tab skips it and NVDA has nothing
    to land on. StrongFocus plus keyboard text selection means the reader can
    stop on the version or the address and copy it.
    """
    label.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
    label.setTextInteractionFlags(
        Qt.TextInteractionFlag.TextSelectableByKeyboard
        | Qt.TextInteractionFlag.TextSelectableByMouse
    )
    return label


def _announce(widget, text: str) -> None:
    """Say a short confirmation without moving focus."""
    widget.setAccessibleName(text)
    for kind in (QAccessible.Event.NameChanged, QAccessible.Event.Alert):
        try:
            QAccessible.updateAccessibility(QAccessibleEvent(widget, kind))
        except (RuntimeError, TypeError):
            pass


def build_date() -> str:
    """When this build was made, as a plain ``YYYY-MM-DD`` date.

    The shipped exe carries its own timestamp, which is the honest build date.
    A source run has no exe, so the file that defines the app's identity (its
    config module, where the version lives) stands in. Unreadable file: an
    em dash, never a traceback.
    """
    try:
        if getattr(sys, "frozen", False):
            stamp = Path(sys.executable).stat().st_mtime
        else:
            stamp = (Path(__file__).resolve().parent.parent
                     / "app" / "config.py").stat().st_mtime
        return time.strftime("%Y-%m-%d", time.localtime(stamp))
    except OSError:
        return "—"


def _paragraph(text: str) -> QLabel:
    """A wrapped, readable body of text."""
    label = _readable(QLabel(text))
    label.setObjectName("HelpText")
    label.setWordWrap(True)
    label.setAccessibleName(text)
    return label


def _bullet(text: str) -> QLabel:
    """One item in the feature list, marked by a leading bullet."""
    label = _paragraph(f"•  {text}")
    label.setContentsMargins(6, 0, 0, 0)
    return label


def _section(title: str) -> tuple[QGroupBox, QVBoxLayout]:
    """A titled box, so the tab reads as short labelled blocks."""
    box = QGroupBox(title)
    box.setAccessibleName(title)
    layout = QVBoxLayout(box)
    layout.setContentsMargins(12, 14, 12, 12)
    layout.setSpacing(8)
    return box, layout


class AboutPanel(QWidget):
    """Read-only facts about the running program, for the About tab."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AboutPanel")
        self.setAccessibleName(i18n.t("prefs.about.title"))

        cfg = get_config()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # A scroll area, not a bare column: with a large system font the old
        # layout clipped at the fold and the tab looked like it held only the
        # contact address. Scrolling keeps every section reachable at any zoom.
        scroll = QScrollArea()
        scroll.setObjectName("AboutScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        scroll.setAccessibleName(i18n.t("prefs.about.title"))
        outer.addWidget(scroll, 1)

        content = QWidget()
        content.setObjectName("AboutContent")
        root = QVBoxLayout(content)
        root.setContentsMargins(0, 0, 8, 0)
        root.setSpacing(12)

        title = _readable(
            QLabel(f"{APP_NAME} — {i18n.t('app.subtitle')}")
        )
        title.setObjectName("HelpTitle")
        title.setWordWrap(True)
        title.setAccessibleName(
            i18n.t("about.title.accessible", name=APP_NAME,
                   subtitle=i18n.t("app.subtitle"))
        )
        root.addWidget(title)

        # ---- what the program is ----
        what_box, what_layout = _section(i18n.t("about.what_title"))
        what_layout.addWidget(_paragraph(i18n.t("about.what_text")))
        root.addWidget(what_box)

        # ---- what it does for the reader ----
        features_box, features_layout = _section(
            i18n.t("about.features_title")
        )
        for key in (
            "about.feature.search",
            "about.feature.tabs",
            "about.feature.abstract",
            "about.feature.cite",
            "about.feature.download",
            "about.feature.local",
            "about.feature.a11y",
        ):
            features_layout.addWidget(_bullet(i18n.t(key)))
        root.addWidget(features_box)

        # ---- where it searches ----
        sources_box, sources_layout = _section(
            i18n.t("about.sources_title")
        )
        for key in (
            "about.sources.books",
            "about.sources.articles",
            "about.sources.papers",
        ):
            sources_layout.addWidget(_paragraph(i18n.t(key)))
        root.addWidget(sources_box)

        # ---- release facts ----
        facts_box, facts_layout = _section(i18n.t("about.facts_title"))
        form = QFormLayout()
        form.setContentsMargins(0, 0, 0, 0)
        form.setSpacing(8)

        enabled = list(cfg.enabled_providers)
        source_names = ", ".join(i18n.t(f"provider.{p}") for p in enabled)

        fields = (
            (i18n.t("prefs.about.version"), APP_VERSION),
            (i18n.t("prefs.about.built"), build_date()),
            (i18n.t("prefs.about.sources"), str(len(enabled))),
            (i18n.t("prefs.ui_language"),
             dict(UI_LANGUAGES).get(cfg.ui_language, cfg.ui_language)),
            (i18n.t("prefs.download_dir"), str(cfg.download_folder)),
        )
        for label_text, value_text in fields:
            label = _readable(QLabel(label_text))
            value = _readable(QLabel(value_text))
            value.setWordWrap(True)
            value.setAccessibleName(f"{label_text}: {value_text}")
            if label_text == i18n.t("prefs.about.sources"):
                # Sighted users can hover the count and see what it counts;
                # the reader already has the number and the sources themselves
                # stay discoverable through Preferences.
                value.setToolTip(source_names)
            form.addRow(label, value)
        facts_layout.addLayout(form)
        root.addWidget(facts_box)

        # ---- contact ----
        contact_box, contact_layout = _section(i18n.t("prefs.about.contact"))
        self.email = i18n.t("about.contact.email")
        contact_value = _readable(QLabel(self.email))
        contact_value.setObjectName("ContactEmail")
        contact_value.setWordWrap(True)
        contact_value.setAccessibleName(
            f"{i18n.t('prefs.about.contact')}: {self.email}"
        )
        contact_value.setToolTip(i18n.t("about.copy_email.tooltip"))

        # Selecting a label with the keyboard works, but it is not obvious.
        # One button copies the address and speaks the result, which is what a
        # reader asks for after hearing "للتواصل".
        self.copy_email_btn = QPushButton(i18n.t("about.copy_email.text"))
        self.copy_email_btn.setAccessibleName(
            i18n.t("about.copy_email.accessible")
        )
        self.copy_email_btn.setToolTip(i18n.t("about.copy_email.tooltip"))
        self.copy_email_btn.clicked.connect(self._copy_email)

        contact_row = QHBoxLayout()
        contact_row.setContentsMargins(0, 0, 0, 0)
        contact_row.setSpacing(8)
        contact_row.addWidget(contact_value, 1)
        contact_layout.addLayout(contact_row)
        # The button sits on its own line: beside a long address the two
        # together are the widest thing in the tab, and at a larger font they
        # alone were enough to force a horizontal scrollbar.
        contact_layout.addWidget(self.copy_email_btn)
        contact_layout.addWidget(_paragraph(i18n.t("about.license")))
        root.addWidget(contact_box)

        self.status = QLabel("")
        self.status.setObjectName("StatusLabel")
        self.status.setWordWrap(True)
        self.status.setAccessibleName("")
        root.addWidget(self.status)

        root.addStretch(1)
        scroll.setWidget(content)

    def _copy_email(self) -> None:
        QApplication.clipboard().setText(self.email)
        message = i18n.t("about.email_copied", email=self.email)
        self.status.setText(message)
        _announce(self.status, message)
