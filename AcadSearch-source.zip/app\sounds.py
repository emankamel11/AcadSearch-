"""Sound cues the program generates for itself, as its own musical signature.

These are deliberately not Windows event sounds and do not want to sound like
them. The OS scheme is a user's own personal setting, it blends in with every
other app, and it may be muted -- so the program instead synthesises short
*musical* phrases, each a little melody with a bell-like, plucked timbre
(two detuned voices and a decaying tail, like a struck glockenspiel bar).

The three moments the reader depends on are told apart by *direction*:

* ``search_start`` -- a bright run climbing two octaves, "off we go";
* ``search_done``   -- a deep calm gong boom that settles lower, "closed", the
                       opposite of a Windows chime;
* ``search_empty``  -- two low notes easing down, "nothing wrong, just nothing";
* ``search_fail``   -- a dull downward stumble, "that went wrong";
* ``menu_open``     -- two identical pops (not a melody), "a menu is drawn".

A search is spoken, not rumoured: the start cue rises, the end cue falls, so
even with the volume down to nothing the ear never mistakes one for the other.

Two details are load-bearing and worth the three lines of documentation:

1. Playback is *file based*. ``winsound`` with SND_MEMORY + SND_ASYNC keeps only
   a pointer to the buffer; if the bytes are collected while the cue is still
   playing, the app plays freed memory -- a glitch, or worse, the system's
   default sound. Writing each cue to a tiny cache file in the temp folder and
   playing it with SND_FILENAME makes the audio always faithful, no pointers.
   The one-file executable stays one file: the sounds live in temp, not in the
   package.
2. Every call is wrapped, so a cue can never take the app -- or a running
   search -- down.
"""

from __future__ import annotations

import io
import math
import struct
import tempfile
import wave
from pathlib import Path

_RATE = 22050          # 22.05 kHz is plenty for a short plucked phrase.
_AMP = 0.30            # Clear, but quieter than the speech engine.
_GAP = 0.03            # Small silence between the notes of a phrase.

#: name -> list of (kind, freq_or_chord, seconds). ``"note"`` plays one tone,
#: ``"chord"`` rings several frequencies at once, ``"gong"`` is a deep boom.
#: Start climbs; the end is a settled gong, so start and end can never be
#: confused with each other.
_PHRASES: dict[str, list[tuple[str, object, float]]] = {
    # E5-A5-C6-E6, climbing two octaves in a bright run: the search goes up.
    "search_start": [
        ("note", 659.25, 0.08),
        ("note", 880.00, 0.08),
        ("note", 1046.50, 0.10),
        ("note", 1318.51, 0.30),
    ],
    # A single deep, calm gong boom (C3, 130 Hz): a slow gentle rise, a long
    # resonance that settles a touch lower by the tail. The opposite of a
    # Windows beep -- big, warm, unmistakably "the search is closed".
    "search_done": [
        ("gong", 130.81, 1.35),
    ],
    # Two low notes easing down: present, but nothing came back.
    "search_empty": [
        ("note", 293.66, 0.18),
        ("note", 220.00, 0.42),
    ],
    # B4-G4-E4, a dull downward stumble: it went wrong.
    "search_fail": [
        ("note", 493.88, 0.15),
        ("note", 392.00, 0.10),
        ("note", 329.63, 0.35),
    ],
    # Two identical pops, not a melody: a menu has been drawn.
    "menu_open": [
        ("note", 740.00, 0.09),
        ("note", 740.00, 0.09),
    ],
}

EVENTS = tuple(_PHRASES)

# The rendered bytes stay here for the whole process; data_for()/tests read
# them, and each cue is written once from here to a temp .wav for playback.
_CACHE: dict[str, bytes] = {}

#: Where the one-file build keeps its five tiny .wav files at runtime.
_PLAY_DIR: Path | None = None


def data_for(event: str) -> bytes:
    """The rendered 16-bit mono WAV bytes for one event, kept alive forever."""
    cached = _CACHE.get(event)
    if cached is not None:
        return cached
    body = bytearray()
    for i, (kind, freq, seconds) in enumerate(_PHRASES[event]):
        if i:
            body += _silence(_GAP)
        if kind == "chord":
            body += _chord(freq, seconds)
        elif kind == "gong":
            body += _gong(float(freq), seconds)
        else:
            body += _pluck(float(freq), seconds)
    wav = _wav(bytes(body))
    _CACHE[event] = wav
    return wav


def play(event: str) -> None:
    """Play one cue asynchronously. Silent no-op when sounds are off."""
    try:
        from app.config import get_config

        if not get_config().sound_enabled:
            return
        if event not in _PHRASES:
            return
        import winsound

        winsound.PlaySound(
            _wav_path(event),
            winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT,
        )
    except Exception:
        # No audio device, a right-freezing build step, anything: the search
        # itself must never die because a cue could not play.
        pass


def _wav_path(event: str) -> str:
    """Lazily cache each cue as a temp .wav; return the path to play it from."""
    global _PLAY_DIR
    if _PLAY_DIR is None:
        _PLAY_DIR = Path(tempfile.gettempdir()) / "AcadSearchSounds"
        try:
            _PLAY_DIR.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
    target = _PLAY_DIR / f"{event}.wav"
    try:
        if not target.exists() or target.stat().st_size == 0:
            target.write_bytes(data_for(event))
    except OSError:
        pass
    return str(target)


def _pluck(freq: float, seconds: float, rate: int = _RATE,
           amp: float = _AMP, decay: float = 7.0) -> bytes:
    """One note: bell-like timbre, two detuned voices, exponential tail.

    A bare sine is the flat beep of a system dialog; the detuned double voice
    and the harmonic tail are what give the note a struck-metal character that
    belongs to the program, not to Windows.
    """
    n = int(rate * seconds)
    attack = int(rate * 0.004)  # 4 ms rise so the note never clicks.
    out = bytearray()
    two = 2.0 * math.pi
    detune = freq * 0.006
    for i in range(n):
        t = i / rate
        env = math.exp(-decay * t)
        if i < attack:
            env *= i / attack
        ph = two * freq * t
        ph2 = two * (freq + detune) * t
        s = (
            math.sin(ph)
            + 0.28 * math.sin(ph2)          # detuned twin (chorus/beating)
            + 0.42 * math.sin(two * 2.0 * freq * t)
            + 0.16 * math.sin(two * 3.0 * freq * t)
        )
        sample = amp * env * s
        if sample > 1.0:
            sample = 1.0
        elif sample < -1.0:
            sample = -1.0
        out += struct.pack("<h", int(sample * 32767))
    return bytes(out)


def _gong(freq: float, seconds: float, rate: int = _RATE) -> bytes:
    """One deep, calm boom: a struck metal plate, not a beep or chime.

    Opposite of the bell pluck in every way anyone hears: a slow rise instead
    of a click, a long tail instead of a note, and a pitch that settles a
    little lower by the end -- a gong closing a question rather than an alert
    asking for attention. The low fundamental (130 Hz power taps) rides on
    its own octave and two inharmonic plate partials so small speakers still
    catch the warmth.
    """
    n = int(rate * seconds)
    attack = int(rate * 0.032)  # 32 ms rise: the boom begins gently, never knocks.
    out = bytearray()
    two = 2.0 * math.pi
    glide = 0.015                # the whole boom settles ~1.5% lower by the tail.
    for i in range(n):
        t = i / rate
        glide_f = freq * (1.0 - glide * t / seconds)
        env = math.exp(-3.3 * t)
        if i < attack:
            env *= i / attack
        s = (
            math.sin(two * glide_f * t)
            + 0.15 * math.sin(two * (freq + 1.2) * t)      # slow beating partner
            + 0.58 * math.sin(two * 2.0 * glide_f * t)      # octave = the "body"
            + 0.30 * math.sin(two * 2.95 * glide_f * t)     # inharmonic plate partial
            + 0.14 * math.sin(two * 4.0 * glide_f * t)
            + 0.16 * math.sin(two * 2530.0 * t) * math.exp(-110.0 * t)  # strike
        )
        sample = 0.42 * env * s
        if sample > 1.0:
            sample = 1.0
        elif sample < -1.0:
            sample = -1.0
        out += struct.pack("<h", int((sample * 32767)))
    return bytes(out)


def _chord(freqs: tuple[float, ...], seconds: float, rate: int = _RATE,
           amp: float = _AMP) -> bytes:
    """Ring several notes at once (a chord), each voice sharing the volume."""
    n = int(rate * seconds)
    attack = int(rate * 0.004)
    out = bytearray()
    two = 2.0 * math.pi
    per = amp / len(freqs)
    for i in range(n):
        t = i / rate
        env = math.exp(-6.0 * t)
        if i < attack:
            env *= i / attack
        s = 0.0
        for f in freqs:
            s += math.sin(two * f * t) + 0.35 * math.sin(two * 2.0 * f * t)
        sample = per * env * s
        if sample > 1.0:
            sample = 1.0
        elif sample < -1.0:
            sample = -1.0
        out += struct.pack("<h", int(sample * 32767))
    return bytes(out)


def _silence(seconds: float, rate: int = _RATE) -> bytes:
    return bytes(int(rate * seconds) * 2)


def _wav(pcm: bytes, rate: int = _RATE) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)
    return buf.getvalue()