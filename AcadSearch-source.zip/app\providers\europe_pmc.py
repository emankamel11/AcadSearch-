"""Europe PMC — open-access biomedical literature (no API key).

Europe PMC indexes PubMed, PMC and preprints, so it covers medicine, biology,
chemistry and agriculture. It is the widest key-free source for these fields:
645k+ hits for "machine learning" at the time of writing.

Endpoint: https://www.ebi.ac.uk/europepmc/webservices/rest/search
Auth:     none.

Two things make it worth having next to Europe-wide sources:

* ``resultType=core`` returns the fields we actually display (authors, year,
  journal, abstract, open-access flag) instead of just citations.
* ``fullTextUrlList`` carries a real PDF link for open-access items, which
  means many results are downloadable rather than link-only.
"""

from __future__ import annotations

import threading
import urllib.parse

from app.core.text_utils import as_int, clean_text, truncate_words
from app.models import (
    Access,
    Category,
    DownloadFormat,
    DownloadTarget,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

ENDPOINT = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"

#: Europe PMC indexes abstracts and full text, so it covers all three sections.
CATEGORIES = (Category.ARTICLE, Category.RESEARCH)


@register
class EuropePmcProvider(BaseProvider):
    provider_id = "europe_pmc"
    display_name = "Europe PMC"
    categories = CATEGORIES
    weight = 45
    homepage = "https://europepmc.org"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = query.text.strip()
        if not text:
            return []

        # Two very different situations, and they need different queries.
        #
        # Latin query ("machine learning"): an AND over the whole record means
        # full-text search, which matches any paper that mentions the phrase
        # once in the body -- 645k hits, mostly noise. Scoping to the title
        # drops that to 94k and every hit is about the topic.
        #
        # Arabic query ("الذكاء الاصطناعي"): Europe PMC has almost no Arabic
        # titles, but it *translates* the query and returns the English
        # equivalents ("artificial intelligence"). Title scoping would return
        # almost nothing, so the loose AND is what actually helps here. These
        # results are correct even though their titles do not contain the
        # Arabic words, which is why the relevance gate in the search engine
        # treats them as a separate case.
        latin = text.isascii() and text.isalpha()
        if latin:
            expression = f'TITLE:"{text}"'
        else:
            terms = [t for t in text.split() if t]
            expression = " AND ".join(f'"{t}"' for t in terms) if terms else text

        params = {
            "query": expression,
            "format": "json",
            "resultType": "core",
            "pageSize": str(max(10, min(query.per_source * 2, 50))),
        }
        url = f"{ENDPOINT}?{urllib.parse.urlencode(params)}"

        try:
            payload = self.http.get_json(
                url, provider=self.provider_id, cancel=cancel
            )
        except ProviderError:
            raise
        except Exception as exc:  # pragma: no cover - network
            raise ProviderError(
                f"europe_pmc: {type(exc).__name__}", kind="error"
            ) from exc

        if cancel is not None and cancel.is_set():
            return []

        results: list[Result] = []
        for item in (payload or {}).get("resultList", {}).get("result", []):
            built = self._to_result(item)
            if built is not None:
                results.append(built)
        return results

    # -- mapping -----------------------------------------------------------
    def _to_result(self, item: dict) -> Result | None:
        title = clean_text(item.get("title") or "")
        if not title:
            return None

        authors: list[str] = []
        for entry in item.get("authorList", {}).get("author", []) or []:
            name = clean_text(
                entry.get("fullName") or entry.get("lastName") or ""
            )
            if not name:
                first = clean_text(entry.get("firstName") or "")
                last = clean_text(entry.get("lastName") or "")
                name = f"{first} {last}".strip()
            if name:
                authors.append(name)
        if not authors:
            blob = clean_text(item.get("authorString") or "")
            authors = [a.strip() for a in blob.split(",") if a.strip()]

        journal = ""
        info = item.get("journalInfo") or {}
        inner = info.get("journal") or {}
        if isinstance(inner, dict):
            journal = clean_text(inner.get("title") or "")

        year = as_int(item.get("pubYear"))
        doi = clean_text(item.get("doi") or "")

        identifiers: dict[str, str] = {"source": self.provider_id}
        if doi:
            identifiers["doi"] = doi
        pmid = clean_text(str(item.get("pmid") or ""))
        if pmid:
            identifiers["pmid"] = pmid
        pmcid = clean_text(str(item.get("pmcid") or ""))
        if pmcid:
            identifiers["pmcid"] = pmcid

        downloads: list[DownloadTarget] = []
        open_access = str(item.get("isOpenAccess") or "").upper() == "Y"
        for link in item.get("fullTextUrlList", {}).get("fullTextUrl", []) or []:
            link_url = clean_text(link.get("url") or "")
            if not link_url:
                continue
            style = (link.get("documentStyle") or "").lower()
            availability = (link.get("availability") or "").lower()
            if availability and availability not in ("free", "open access", "open"):
                continue
            fmt = (
                DownloadFormat.PDF
                if "pdf" in style
                else DownloadFormat.HTML
            )
            downloads.append(
                target(
                    link_url,
                    fmt,
                    label=link.get("documentStyle") or fmt.value.upper(),
                    open_access=open_access,
                )
            )
            if len(downloads) >= 2:
                break

        # PPR/AGR/PMP are the preprint, agriculture and patent sources, which
        # belong under research; everything else is a published article.
        source_id = clean_text(str(item.get("source") or ""))
        category = (
            Category.RESEARCH
            if source_id in {"PPR", "AGR", "PMP"}
            else Category.ARTICLE
        )

        abstract = clean_text(item.get("abstractText") or "")
        keywords = item.get("keywordList", {}) or {}
        subjects: list[str] = []
        for entry in keywords.get("keyword", []) or []:
            # Europe PMC returns either a bare string or a dict depending on the
            # record, so both shapes have to be accepted.
            if isinstance(entry, dict):
                value = clean_text(entry.get("subject") or entry.get("keyword") or "")
            else:
                value = clean_text(str(entry or ""))
            if value:
                subjects.append(value)

        result = Result(
            category=category,
            title=title,
            source=self.provider_id,
            authors=authors[:12],
            year=year,
            abstract=truncate_words(abstract, 90),
            venue=journal,
            language=clean_text(item.get("language") or ""),
            subjects=[s for s in subjects if s][:8],
            identifiers=identifiers,
            downloads=downloads,
        )
        result.access = (
            Access.DOWNLOAD
            if downloads
            else (Access.LANDING if pmid or pmcid else Access.METADATA)
        )
        if pmid:
            result.landing_url = f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"
        elif pmcid:
            result.landing_url = f"https://europepmc.org/article/PMC/{pmcid}"
        elif doi:
            result.landing_url = f"https://doi.org/{doi}"
        return result