"""Reproduce the two problems the user reported, and verify the fix.

1. The clear button did not empty the search box.
2. The finishing message is wrong.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import Qt, QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QPushButton

import main_window


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()

    def test_clear() -> None:
        print("=== 1. clear button ===")
        win.query.setText("machine learning")
        win.query.setFocus()
        QTest.keyClicks(win.query, "abc")
        print("  text before  :", repr(win.query.text()))

        clear_btn = None
        for b in win.findChildren(QPushButton):
            if "مسح" in (b.accessibleName() or ""):
                clear_btn = b
                break
        print("  clear button found:", clear_btn is not None,
              "->", clear_btn.accessibleName() if clear_btn else None)

        if clear_btn is not None:
            QTest.mouseClick(clear_btn, Qt.LeftButton)
            app.processEvents()
            print("  text after   :", repr(win.query.text()))
            print("  EMPTY?       :", win.query.text() == "")
            print("  status       :", win.status.accessibleName())
        print()

        print("=== 2. messages ===")
        win.query.setText("machine learning")
        win.start_search()
        print("  while running:", win.status.accessibleName())

    def test_after() -> None:
        print("  after finish :", win.status.accessibleName())
        print("  rows per tab :", {c.value: p.list.count() for c, p in win.pages.items()})

        # The finishing text must carry the real number and the real time.
        text = win.status.accessibleName()
        digits = [ch for ch in text if ch.isdigit()]
        print("  contains digits:", "".join(digits)[:6])
        app.quit()

    QTimer.singleShot(500, test_clear)
    QTimer.singleShot(38000, test_after)
    QTimer.singleShot(60000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())