"""Arabic Wikisource — public-domain Arabic books as real EPUB files.

https://ar.wikisource.org

Wikisource is the only large Arabic collection that is both free and legally
unambiguous: its texts are public domain or openly licensed, and every page can
be exported as EPUB by the Wikimedia ``ws-export`` service. The MediaWiki search
API returns main-namespace pages; subpages (chapters such as
``كليلة ودمنة/باب الفحص عن أمر دمنة``) are filtered out because each of them
would otherwise become a separate "book".

Metadata comes from Wikidata: a batched ``pageprops`` lookup gives the item id,
then one ``wbgetentities`` call supplies the author (P50), publication year
(P577) and page count (P1104). Nothing is mandatory -- a page without a
Wikidata item is still a valid result, it just has fewer details.
"""

from __future__ import annotations

import re
import threading
from urllib.parse import quote

from app.core.text_utils import clean_text, truncate_words
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target


API = "https://ar.wikisource.org/w/api.php"
WIKIDATA_API = "https://www.wikidata.org/w/api.php"
EXPORT_URL = "https://ws-export.wmcloud.org/"
PAGE_BASE = "https://ar.wikisource.org/wiki/"

#: MediaWiki caps ``titles`` and ``ids`` at 50 per request.
BATCH = 50

_YEAR_RE = re.compile(r"[+-]?(\d{4,})")


def _page_url(title: str) -> str:
    return PAGE_BASE + quote(title.replace(" ", "_"), safe="")


def _epub_url(title: str) -> str:
    return f"{EXPORT_URL}?lang=ar&format=epub&page={quote(title, safe='')}"


def _claim_values(entity: dict, prop: str) -> list[dict]:
    values: list[dict] = []
    for claim in (entity.get("claims", {}) or {}).get(prop, []) or []:
        try:
            values.append(claim["mainsnak"]["datavalue"]["value"])
        except (KeyError, TypeError):
            continue
    return values


def _claim_ids(entity: dict, prop: str) -> list[str]:
    ids: list[str] = []
    for value in _claim_values(entity, prop):
        if isinstance(value, dict):
            qid = value.get("id")
            if qid and qid not in ids:
                ids.append(qid)
    return ids


def _claim_year(entity: dict, prop: str) -> int | None:
    for value in _claim_values(entity, prop):
        if not isinstance(value, dict):
            continue
        match = _YEAR_RE.search(str(value.get("time") or ""))
        if match:
            try:
                return int(match.group(1))
            except ValueError:
                continue
    return None


def _claim_number(entity: dict, prop: str) -> int | None:
    for value in _claim_values(entity, prop):
        if not isinstance(value, dict):
            continue
        try:
            return int(float(str(value.get("amount") or "")))
        except ValueError:
            continue
    return None


def _label(entity: dict) -> str:
    labels = entity.get("labels", {}) or {}
    for code in ("ar", "en"):
        value = (labels.get(code) or {}).get("value")
        if value:
            return clean_text(value)
    return ""


@register
class WikisourceProvider(BaseProvider):
    provider_id = "wikisource"
    display_name = "ويكي مصدر (كتب عامة الملكية)"
    categories = (Category.BOOK,)
    weight = 24
    homepage = "https://ar.wikisource.org"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = (query.text or "").strip()
        if not text:
            return []

        limit = max(10, min(50, query.per_source * 2))
        try:
            payload = self.http.get_json(
                API,
                params={
                    "action": "query",
                    "list": "search",
                    "srsearch": text,
                    "srnamespace": 0,
                    "srlimit": limit,
                    "format": "json",
                    "formatversion": 2,
                },
                provider=self.provider_id,
                cancel=cancel,
            )
        except Exception:
            return []

        hits = (payload.get("query", {}) or {}).get("search", []) or []
        candidates: list[tuple[str, str, int | None]] = []
        seen: set[str] = set()
        for hit in hits:
            title = clean_text(hit.get("title"))
            if not title or title in seen:
                continue
            # Chapters live under the book as subpages; magazines use the same
            # slash syntax. Neither is a standalone book.
            if "/" in title or title.startswith("مجلة "):
                continue
            seen.add(title)
            snippet = truncate_words(clean_text(hit.get("snippet")), 500)
            size = hit.get("size")
            candidates.append((title, snippet, size if isinstance(size, int) else None))

        if not candidates:
            return []

        if cancel is not None and cancel.is_set():
            return []

        titles = [title for title, _, _ in candidates]
        qids, extracts = self._page_metadata(titles, cancel)
        works, authors = self._wikidata(qids, cancel)

        results: list[Result] = []
        for title, snippet, size in candidates:
            qid = qids.get(title, "")
            work = works.get(qid, {}) if qid else {}
            author_names = [
                authors[author_id]
                for author_id in _claim_ids(work, "P50")
                if authors.get(author_id)
            ]

            identifiers = {"source": self.provider_id}
            if qid:
                identifiers["wikidata"] = qid
            if title:
                identifiers["wikisource"] = title

            results.append(
                Result(
                    category=Category.BOOK,
                    title=title,
                    source=self.provider_id,
                    authors=author_names[:10],
                    year=_claim_year(work, "P577") if work else None,
                    abstract=extracts.get(title) or snippet,
                    venue="ويكي مصدر",
                    publisher="ويكي مصدر",
                    language="ar",
                    subjects=[],
                    identifiers=identifiers,
                    access=Access.DOWNLOAD,
                    downloads=[
                        target(
                            _epub_url(title),
                            DownloadFormat.EPUB,
                            label="EPUB (Wikisource)",
                            open_access=True,
                        ),
                        target(
                            _page_url(title),
                            DownloadFormat.HTML,
                            label="Wikisource",
                            open_access=True,
                        ),
                    ],
                    landing_url=_page_url(title),
                    pages=_claim_number(work, "P1104") if work else None,
                    item_type="Book",
                    raw={"wikidata": qid, "size": size},
                )
            )
        return results[: query.per_source]

    # -- metadata -------------------------------------------------------
    def _page_metadata(
        self, titles: list[str], cancel: threading.Event | None
    ) -> tuple[dict[str, str], dict[str, str]]:
        """Map page titles to Wikidata ids and a clean lead extract."""
        qids: dict[str, str] = {}
        extracts: dict[str, str] = {}
        for start in range(0, len(titles), BATCH):
            batch = titles[start : start + BATCH]
            if cancel is not None and cancel.is_set():
                break
            try:
                payload = self.http.get_json(
                    API,
                    params={
                        "action": "query",
                        "prop": "pageprops|extracts",
                        "exintro": 1,
                        "explaintext": 1,
                        "titles": "|".join(batch),
                        "format": "json",
                        "formatversion": 2,
                    },
                    provider=self.provider_id,
                    cancel=cancel,
                )
            except Exception:
                continue
            query = payload.get("query", {}) or {}
            normalized = {
                clean_text(item.get("from")): clean_text(item.get("to"))
                for item in (query.get("normalized", []) or [])
            }
            by_title: dict[str, tuple[str, str]] = {}
            for page in query.get("pages", []) or []:
                title = clean_text(page.get("title"))
                if not title:
                    continue
                qid = (page.get("pageprops") or {}).get("wikibase_item", "")
                extract = truncate_words(clean_text(page.get("extract")), 500)
                by_title[title] = (qid, extract)
            for title in batch:
                key = title if title in by_title else normalized.get(title, "")
                if key:
                    qid, extract = by_title.get(key, ("", ""))
                    if qid:
                        qids[title] = qid
                    if extract:
                        extracts[title] = extract
        return qids, extracts

    def _wikidata(
        self, qids: dict[str, str], cancel: threading.Event | None
    ) -> tuple[dict[str, dict], dict[str, str]]:
        """Fetch work claims and the labels of the authors they point at."""
        unique = list(dict.fromkeys(qids.values()))[:BATCH]
        works: dict[str, dict] = {}
        if not unique:
            return works, {}

        try:
            payload = self.http.get_json(
                WIKIDATA_API,
                params={
                    "action": "wbgetentities",
                    "ids": "|".join(unique),
                    "props": "claims|labels",
                    "languages": "ar|en",
                    "format": "json",
                },
                provider=self.provider_id,
                cancel=cancel,
            )
        except Exception:
            return works, {}
        works = payload.get("entities", {}) or {}

        author_ids: list[str] = []
        for work in works.values():
            for author_id in _claim_ids(work, "P50"):
                if author_id not in author_ids:
                    author_ids.append(author_id)
        authors = self._labels(author_ids[:BATCH], cancel)
        return works, authors

    def _labels(
        self, ids: list[str], cancel: threading.Event | None
    ) -> dict[str, str]:
        if not ids:
            return {}
        try:
            payload = self.http.get_json(
                WIKIDATA_API,
                params={
                    "action": "wbgetentities",
                    "ids": "|".join(ids),
                    "props": "labels",
                    "languages": "ar|en",
                    "format": "json",
                },
                provider=self.provider_id,
                cancel=cancel,
            )
        except Exception:
            return {}
        labels: dict[str, str] = {}
        for qid, entity in (payload.get("entities", {}) or {}).items():
            name = _label(entity)
            if name:
                labels[qid] = name
        return labels
