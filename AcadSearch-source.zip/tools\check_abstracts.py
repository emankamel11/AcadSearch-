"""Abstract-on-demand check (offline).

The summary actions promise a real summary: when a metadata-only record has no
abstract, the app asks the DOI sources for one instead of copying a title line
and claiming success. This check fakes the HTTP layer and proves:

  * an OpenAlex record's inverted index becomes a readable abstract;
  * a Crossref JATS blob is stripped to plain text;
  * a record with no DOI at all is never queried;
  * a failed lookup is remembered, so the network is not re-hit on every press.

Run:  python -X utf8 tools/check_abstracts.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core import abstracts  # noqa: E402
from app.models import Category, Result  # noqa: E402

passed = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global passed
    if condition:
        passed += 1
    print(f"  [{'PASS' if condition else 'FAIL'}] {name}"
          + (f" -- {detail}" if detail else ""))


def record(doi: str | None) -> Result:
    identifiers = {"doi": doi} if doi else {}
    return Result(
        category=Category.ARTICLE,
        title="A Study of Widgets",
        source="crossref",
        identifiers=identifiers,
        raw={},
    )


class FakeHttp:
    """Answers each endpoint once and remembers how often it was asked."""

    def __init__(self, openalex: dict | None, crossref: dict | None,
                 semanticscholar: dict | None = None):
        self.openalex = openalex
        self.crossref = crossref
        self.semanticscholar = semanticscholar
        self.calls: list[str] = []

    def get_json(self, url: str, **_kwargs) -> dict | None:
        self.calls.append(url)
        if "openalex" in url:
            return self.openalex
        if "crossref" in url:
            return self.crossref
        if "semanticscholar" in url:
            return self.semanticscholar
        return None


print("== OpenAlex inverted index is rebuilt into an abstract ==")
fake = FakeHttp(
    openalex={"abstract_inverted_index": {"widgets": [0], "matter": [1]}},
    crossref=None,
)
abstracts.get_http = lambda: fake
result = record("10.1234/demo")
text = abstracts.fetch_abstract(result)
check("the abstract came back", text == "widgets matter", repr(text))
check("it was stored on the result", result.abstract == "widgets matter")

print("== Crossref JATS is stripped when OpenAlex has nothing ==")
fake = FakeHttp(
    openalex={},
    crossref={"message": {"abstract": "<jats:p>We study widgets.</jats:p>"}},
)
abstracts.get_http = lambda: fake
result = record("10.1234/only-crossref")
text = abstracts.fetch_abstract(result)
check("tags were removed", text == "We study widgets.", repr(text))

print("== a short OpenAlex stub loses to a real Crossref abstract ==")
fake = FakeHttp(
    openalex={"abstract_inverted_index": {"international": [0]}},
    crossref={"message": {"abstract": "<jats:p>A proper long abstract about "
                                      "widgets that says something real.</jats:p>"}},
)
abstracts.get_http = lambda: fake
result = record("10.1234/stub-vs-full")
text = abstracts.fetch_abstract(result)
check("the stub was replaced", text.startswith("A proper long abstract"),
      repr(text[:60]))

print("== a stub alone is still better than nothing ==")
fake = FakeHttp(
    openalex={"abstract_inverted_index": {"international": [0]}},
    crossref={"message": {}},
)
abstracts.get_http = lambda: fake
result = record("10.1234/stub-only")
text = abstracts.fetch_abstract(result)
check("the stub is kept", text == "international", repr(text))

print("== Semantic Scholar rescues a paper the other two missed ==")
fake = FakeHttp(
    openalex={},
    crossref={"message": {}},
    semanticscholar={"abstract": "From Semantic Scholar."},
)
abstracts.get_http = lambda: fake
result = record("10.1234/s2-only")
text = abstracts.fetch_abstract(result)
check("the S2 abstract came back", text == "From Semantic Scholar.", repr(text))

print("== the longest of Crossref and S2 wins ==")
fake = FakeHttp(
    openalex={},
    crossref={"message": {"abstract": "<jats:p>Short.</jats:p>"}},
    semanticscholar={"abstract": "A much longer abstract from Semantic Scholar "
                                "that says something real about widgets."},
)
abstracts.get_http = lambda: fake
result = record("10.1234/s2-longer")
text = abstracts.fetch_abstract(result)
check("the longer abstract won", text.startswith("A much longer"), repr(text[:50]))

print("== a record without a DOI is never queried ==")
fake = FakeHttp(openalex=None, crossref=None)
abstracts.get_http = lambda: fake
text = abstracts.fetch_abstract(record(None))
check("nothing returned", text == "")
check("no request was made", fake.calls == [], str(fake.calls))

print("== a miss is remembered instead of re-queried ==")
fake = FakeHttp(openalex={}, crossref={"message": {}})
abstracts.get_http = lambda: fake
result = record("10.1234/empty")
first = abstracts.fetch_abstract(result)
second = abstracts.fetch_abstract(result)
check("both attempts returned nothing", first == "" and second == "")
check("the lookup is marked as a miss",
      result.raw.get("_abstract_lookup") == "miss")
check("the network was touched only once", len(fake.calls) == 3,
      str(len(fake.calls)))

print()
if passed == 12:
    print("CHECK PASSED (12/12)")
    sys.exit(0)
print(f"CHECK FAILED ({passed}/12)")
sys.exit(1)
