// AcadSearch - Windows installer (Inno Setup 6).
//
// Produces a Start-menu and desktop shortcut, an Add/Remove Programs entry,
// and an uninstaller. The .exe is unsigned, so SmartScreen may warn on first
// run: tell the user to pick "More info" -> "Run anyway", or install from a
// folder rather than launching the download.
//
// Build:  iscc installer\Acadsearch.iss
// The compiled .exe must already exist in dist\ (build_exe.bat).

#define AppName "AcadSearch"
#define AppNameAr "أكاد سِرتش"
#define AppVersion "2.0.0"
#define AppPublisher "AcadSearch"
#define AppExeName "AcadSearch.exe"

[Setup]
AppId={{7C4B9E12-9A3D-4F6B-8E21-5D0C7A1B4F93}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\AcadSearch
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir=..\dist
OutputBaseFilename=AcadSearch-Setup-{#AppVersion}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
; A per-user install needs no admin rights, which is friendlier for a
; portable academic tool; admins can still choose "all users" in the wizard.
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#AppExeName}
SetupIconFile=..\assets\acadsearch.ico

[Languages]
Name: "en"; MessagesFile: "compiler:Default.isl"
Name: "ar"; MessagesFile: "compiler:Languages\Arabic.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
; One-file build: the .exe carries Python, PySide6 and the eleven providers
; inside it, so this is the only file that has to be installed.
Source: "..\dist\{#AppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\README.md"; DestDir: "{app}"; Flags: ignoreversion isreadme

[Dirs]
; Downloaded PDFs and EPUBs land here; creating it now means the first download
; does not have to make the folder.
Name: "{app}\downloads"

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExeName}"
Name: "{group}\{cm:UninstallProgram,{#AppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(AppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Settings and cached responses are the user's own data, but a stale config
; pointing at the removed 1.0 CustomTkinter build would confuse the new Qt
; build, so it goes with the uninstall. The downloads folder is kept: those are
; the user's books.
Type: filesandordirs; Name: "{app}\config.json"
Type: filesandordirs; Name: "{app}\cache"
Type: filesandordirs; Name: "{app}\__pycache__"

[Code]
// The Arabic UI name is only a label; Inno needs a fixed AppId above, so the
// directory name stays ASCII to avoid mixed-script paths on some systems.
function InitializeSetup(): Boolean;
begin
  Result := True;
end;
