"""Does a searched Arabic novel reach the Books tab, and does the noise leave?

Two live checks, against the real providers:

1. ``بداية ونهاية`` -- the scanned novel must be among the first Books-tab
   records and must carry a real downloadable file. Before the fix, archive.org
   ranked forty fiqh commentaries above it.
2. ``رواية بداية ونهاية نجيب محفوظ`` -- the Zenodo monograph "لغز الخلود", which
   only mentions the author in its abstract, must not survive the Books gate.

    python -X utf8 -m tools.verify_novels
"""

from __future__ import annotations

import queue
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config import get_config
from app.core.search_engine import SearchEventType, get_engine
from app.core.text_utils import fold
from app.models import Category, SearchQuery, Result

#: Run against fresh provider answers: a cache entry written before the ranking
#: and gate changed would hide a regression.
get_config().use_cache = False

FAILED: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if condition else 'FAIL'}] {name}"
          + (f" -- {detail}" if detail else ""))
    if not condition:
        FAILED.append(name)


def has_file(item: Result) -> bool:
    return any(t.fmt.value in ("pdf", "epub", "zip") for t in item.downloads)


def run(text: str, timeout: float = 90.0) -> tuple[list[Result], object]:
    query = SearchQuery(
        text=text,
        categories={Category.BOOK},
        per_source=10,
    )
    engine = get_engine()
    handle = engine.start(query)
    while not handle.done and time.monotonic() - handle.started_at < timeout:
        try:
            handle.events.get_nowait()
        except queue.Empty:
            time.sleep(0.05)
    final = None
    while True:
        try:
            event = handle.events.get_nowait()
        except queue.Empty:
            break
        if event.type is SearchEventType.FINISHED and event.response:
            final = event.response
    if final is None:
        return [], None
    return list(final.results.get(Category.BOOK, [])), final


def contains_title(book: Result, *words: str) -> bool:
    title = fold(book.title or "")
    return all(fold(word) in title for word in words)


def show(books: list[Result], limit: int = 8) -> None:
    for index, item in enumerate(books[:limit], 1):
        authors = ", ".join(item.authors[:2]) or "-"
        file_flag = "download" if has_file(item) else item.access.value
        print(f"    {index}. {item.title[:52]!r} | {authors[:26]} | "
              f"{item.source} | {file_flag}")


def main() -> int:
    print("Live Books-tab check: a searched novel must appear, its noise must go")
    print("=" * 74)

    print("\n[1] بداية ونهاية")
    books, response = run("بداية ونهاية")
    if response is None:
        check("the search finished", False, "no response")
    else:
        print(f"    {len(books)} book(s) in {response.elapsed:.1f}s")
        show(books)
        novel = next(
            (item for item in books if contains_title(item, "بداية", "نهاية")),
            None,
        )
        check("a copy of the novel is in the Books tab", novel is not None)
        if novel is not None:
            rank = books.index(novel) + 1
            check("it is near the top, not buried", rank <= 8, f"rank={rank}")
            check("it can actually be downloaded", has_file(novel),
                  novel.access.value)

    print("\n[2] رواية بداية ونهاية نجيب محفوظ")
    books, response = run("رواية بداية ونهاية نجيب محفوظ")
    if response is None:
        check("the search finished", False, "no response")
    else:
        print(f"    {len(books)} book(s) in {response.elapsed:.1f}s")
        show(books)
        check("the novel is still found",
              any(contains_title(item, "بداية", "نهاية") for item in books))
        noise = [item for item in books if "لغز الخلود" in (item.title or "")]
        check("the unrelated Zenodo monograph is gone", not noise,
              str([item.title for item in noise]))

    print()
    if FAILED:
        print(f"FAILED: {len(FAILED)} check(s): {FAILED}")
        return 1
    print("LIVE NOVEL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
