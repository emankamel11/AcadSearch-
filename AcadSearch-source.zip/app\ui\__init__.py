"""Presentation layer: theme, widgets and windows."""

__all__ = ["app", "help_dialog", "preferences", "theme", "widgets"]
