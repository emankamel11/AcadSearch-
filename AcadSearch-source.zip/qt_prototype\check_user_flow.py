"""The exact sequence the user described.

Type something, press clear while old results are on screen, then type a title
and search. Old results must not survive, and the title must be on top.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QPushButton

import main_window


def clear_btn(win):
    for b in win.findChildren(QPushButton):
        if "مسح" in (b.accessibleName() or ""):
            return b
    return None


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()
    btn = clear_btn(win)

    def top_row(win, n=3):
        page = next(p for p in win.pages.values() if p.list.count())
        return [page.list.item(r).text()[:70] for r in range(min(n, page.list.count()))]

    def step1():
        print("STEP 1: search 'machine learning'")
        win.query.setText("machine learning")
        win.start_search()

    def step2():
        print("   rows:", {c.value: p.list.count() for c, p in win.pages.items()})
        print("   top :", top_row(win, 2))
        print()
        print("STEP 2: press CLEAR while results are on screen")
        btn.click()
        app.processEvents()
        print("   box  :", repr(win.query.text()))
        print("   rows :", {c.value: p.list.count() for c, p in win.pages.items()})
        print("   status:", win.status.accessibleName()[:80])
        print()

    def step3():
        print("STEP 3: wait 6s - nothing may come back")
        print("   box  :", repr(win.query.text()))
        print("   rows :", {c.value: p.list.count() for c, p in win.pages.items()})
        print()

        print("STEP 4: search a title")
        win.query.setText("introduction to machine learning")
        win.start_search()

    def step4():
        print()
        print("STEP 5: results")
        print("   rows:", {c.value: p.list.count() for c, p in win.pages.items()})
        print("   top :")
        for t in top_row(win, 4):
            print("     ", t)
        print("   status:", win.status.accessibleName())
        app.quit()

    QTimer.singleShot(400, step1)
    QTimer.singleShot(28000, step2)
    QTimer.singleShot(34000, step3)
    QTimer.singleShot(62000, step4)
    QTimer.singleShot(80000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())