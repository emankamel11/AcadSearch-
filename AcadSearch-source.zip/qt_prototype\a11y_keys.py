"""Keyboard behaviour a screen-reader user expects but Qt does not give.

Qt only activates a focused push button on **Space**. Enter is reserved for the
window's *default* button, which is the search button in this app -- so a user
who Tabs to "إعدادات" (or to a result's download button) and presses Enter, the
key every other program answers with, got nothing at all. There is no way to
reach a setting with Enter/Space alone.

The filter below makes Enter click whatever button has the focus, and only
that: if the focus sits in a text field, a spin box or a combo box, Enter keeps
its normal meaning (search, spin step, open the list) and is left untouched.
"""

from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, Qt
from PySide6.QtWidgets import QAbstractButton, QApplication

#: Enter must keep its own job inside these; they are not buttons anyway, but the
#: tuple documents the intent and guards against a future QAbstractSpinBox that
#: inherits from a button class.
_KEEP_ENTER = ()


class EnterActivatesFocusedButton(QObject):
    """Application-wide filter: Enter on a focused button == pressing it."""

    def __init__(self, app: QApplication) -> None:
        super().__init__(app)
        self._app = app
        app.installEventFilter(self)

    def eventFilter(self, obj, event) -> bool:  # noqa: N802 - Qt naming
        if (
            event.type() == QEvent.Type.KeyPress
            and event.key() in (Qt.Key_Return, Qt.Key_Enter)
            # A held-down key must not fire the button over and over.
            and not event.isAutoRepeat()
        ):
            focus = self._app.focusWidget()
            if (
                isinstance(focus, QAbstractButton)
                and not isinstance(focus, _KEEP_ENTER)
                and focus.isEnabled()
                and focus.isVisible()
            ):
                focus.click()
                # Swallow the key so the window's default button (search) does
                # not also react and run a second search.
                return True
        return super().eventFilter(obj, event)


_installed: EnterActivatesFocusedButton | None = None


def install(app: QApplication | None = None) -> EnterActivatesFocusedButton:
    """Install once per process; repeated calls return the same filter."""
    global _installed
    if _installed is None:
        _installed = EnterActivatesFocusedButton(app or QApplication.instance())
    return _installed