"""Step 1 only: the search box and the search button.

Kept deliberately tiny so that a screen reader can be tested on it before
anything else is added. If NVDA speaks this, every later screen will too.

Nothing else is here on purpose.
"""

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QAccessible, QAccessibleEvent
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class SearchWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("AcadSearch — 1: مربع البحث")
        self.resize(720, 260)

        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        label = QLabel("اكتب كلمة البحث")
        label.setAccessibleName("عنوان مربع البحث")
        root.addWidget(label)

        row = QHBoxLayout()

        self.query = QLineEdit()
        self.query.setPlaceholderText("مثال: التعلم الآلي")
        self.query.setAccessibleName("مربع البحث")
        self.query.setAccessibleDescription(
            "اكتب كلمة البحث هنا، ثم اضغط زر البحث أو Enter"
        )
        self.query.textChanged.connect(self._echo)
        row.addWidget(self.query, 1)

        self.search_btn = QPushButton("بحث")
        self.search_btn.setAccessibleName("زر البحث")
        self.search_btn.setAccessibleDescription("ابدأ البحث في تسعة مصادر علمية")
        self.search_btn.clicked.connect(self._searched)
        row.addWidget(self.search_btn)

        self.clear_btn = QPushButton("مسح")
        self.clear_btn.setAccessibleName("زر مسح مربع البحث")
        self.clear_btn.clicked.connect(self._cleared)
        row.addWidget(self.clear_btn)

        root.addLayout(row)

        self.result = QLabel("لم يبدأ البحث بعد")
        self.result.setAccessibleName("الحالة: لم يبدأ البحث بعد")
        root.addWidget(self.result)

        self.query.setFocus()

    def _announce(self, widget) -> None:
        """Fire a real accessibility event so a screen reader is notified."""
        iface = QAccessible.queryAccessibleInterface(widget)
        if iface is not None:
            iface.setText(QAccessible.Text.Name, widget.accessibleName())
        QAccessible.updateAccessibility(
            QAccessibleEvent(widget, QAccessibleEvent.Focus)
        )

    def _echo(self) -> None:
        text = self.query.text()
        self.result.setText(f"كتبتِ: {text}" if text else "لم يبدأ البحث بعد")
        self.result.setAccessibleName(
            f"الحالة: كتبتِ {text}" if text else "الحالة: لم يبدأ البحث بعد"
        )
        self._announce(self.result)

    def _searched(self) -> None:
        text = self.query.text().strip()
        if not text:
            message = "مربع البحث فاضي، اكتب كلمة أولًا"
        else:
            message = f"هبدأ البحث عن: {text}"
        self.result.setText(message)
        self.result.setAccessibleName("الحالة: " + message)
        self._announce(self.result)
        # go back to the field, so Tab/Shift+Tab can be tested in a loop
        self.query.setFocus()

    def _cleared(self) -> None:
        self.query.clear()
        self._searched()


def main() -> int:
    app = QApplication(sys.argv)
    win = SearchWindow()
    win.show()
    win.raise_()
    win.activateWindow()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())