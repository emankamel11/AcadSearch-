"""Make the clear action unmistakable, then verify it once more.

The user cannot tell whether clearing worked, so the window now says so out
loud, and the button label itself changes for a moment.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QPushButton

import main_window


def clear_btn(win):
    for b in win.findChildren(QPushButton):
        if "مسح" in (b.accessibleName() or ""):
            return b
    return None


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()

    def run() -> None:
        btn = clear_btn(win)
        win.query.setText("machine learning")
        win.query.setFocus()
        print("before  :", repr(win.query.text()))
        print("button  :", repr(btn.text()), "|", btn.accessibleName())
        btn.click()
        app.processEvents()
        print("after   :", repr(win.query.text()))
        print("status  :", win.status.accessibleName())
        print("status text on screen:", repr(win.status.text()))
        print("rows    :", [p.list.count() for p in win.pages.values()])
        print("focus   :", type(app.focusWidget()).__name__)
        app.quit()

    QTimer.singleShot(600, run)
    QTimer.singleShot(10000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())