"""Find why a search that starts after a clear finishes with zero rows."""

from __future__ import annotations

import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

import main_window


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()

    original = win._on_results

    def traced(response, message):
        print("--- _on_results called ---")
        print("   response is None?", response is None)
        if response is not None:
            print("   results keys :", list(response.results.keys()))
            print("   total        :", response.total())
            print("   errors       :", response.errors[:4])
            print("   reports      :",
                  [(r.provider_id, r.status.value, r.count) for r in response.reports][:9])
        try:
            original(response, message)
        except Exception:
            traceback.print_exc()

    win._on_results = traced

    def step1() -> None:
        win.query.setText("machine learning")
        print("STEP 1: search")
        win.start_search()

    def step2() -> None:
        print()
        print("STEP 2: results:", {c.value: p.list.count() for c, p in win.pages.items()})
        print("   status:", win.status.accessibleName())
        print()
        print("STEP 3: press clear")
        win._clear()
        print("   after clear, text =", repr(win.query.text()))

    def step3() -> None:
        print("STEP 4: search again")
        win.query.setText("machine learning")
        win.start_search()

    def step4() -> None:
        print()
        print("STEP 5: results:", {c.value: p.list.count() for c, p in win.pages.items()})
        print("   status:", win.status.accessibleName())
        app.quit()

    QTimer.singleShot(500, step1)
    QTimer.singleShot(30000, step2)
    QTimer.singleShot(31000, step3)
    QTimer.singleShot(60000, step4)
    QTimer.singleShot(80000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())