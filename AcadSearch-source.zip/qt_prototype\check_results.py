"""Headless check that a real search fills the tabs.

Runs the same code path as the window, but exits by itself and prints the counts,
so the result does not depend on a session staying alive.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

import main_window


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()

    def go() -> None:
        win.query.setText("machine learning")
        win.start_search()

    def report() -> None:
        print()
        print("=== results per tab after a REAL search ===")
        total = 0
        for category, page in win.pages.items():
            n = page.list.count()
            total += n
            print(f"  {category.value:10} {n}")
        print(f"  {'TOTAL':10} {total}")
        print()
        print("status  :", win.status.accessibleName())
        print("tab open:", win.tabs.tabText(win.tabs.currentIndex()))
        first = win.pages.get(list(win.pages)[0])
        if first is not None and first.list.count():
            print("first row:", first.list.item(0).text()[:90])
        app.quit()

    QTimer.singleShot(500, go)
    QTimer.singleShot(42000, report)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())