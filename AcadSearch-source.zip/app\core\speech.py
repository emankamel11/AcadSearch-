"""Spoken feedback for keyboard and screen-reader users.

CustomTkinter paints every button and label onto an internal ``TkCanvas``.
Windows exposes those canvases to UI Automation as empty ``Pane`` elements, so
a screen reader (NVDA, Narrator) sees one opaque window and announces nothing
past the title. Full accessibility would mean moving to a widget toolkit with
a real UIA provider, which is a rewrite rather than a patch.

What this module provides instead: the same information spoken aloud through
the Windows SAPI engine, on demand and while arrowing through results. The
audio comes out of the same device the screen reader uses, so it works with
NVDA already running.

Every method is defensive. A machine with no speech engine, no voices, or no
COM registration must still get a working search UI, so failures are logged
once and then swallowed.
"""

from __future__ import annotations

import logging
import re
import threading
import time
from typing import Any, Iterable

log = logging.getLogger(__name__)

#: Voice-description fragments that mark a voice as Arabic. Matched case
#: insensitively against the SAPI description string.
_ARABIC_HINTS = ("arabic", "ar-sa", "ar-eg", "ar-ae", "arab")

#: Preferred Arabic voices, best first. Matching is done on a normalised form
#: of the description so that registry paths and version suffixes do not matter.
_VOICE_PREFERENCE = ("salma", "leila", "nizar", "mehdi")

#: Guards against a runaway ``say()`` loop when the user holds an arrow key.
_MIN_INTERVAL = 0.15

#: Symbols SAPI reads as noise or mispronounces in academic text.
_SYMBOL_WORDS = {
    "&": " و ",
    "%": " بالمئة ",
    "+": " زائد ",
    "=": " يساوي ",
    "@": " آت ",
    "#": " هاش ",
    "/": " ",
    "\\": " ",
    "|": " ",
    "_": " ",
    "~": " ",
    "^": " ",
    "<": " أصغر من ",
    ">": " أكبر من ",
    "[": " ",
    "]": " ",
    "(": " ",
    ")": " ",
    "{": " ",
    "}": " ",
}

_WHITESPACE = re.compile(r"\s+")
_ROMAN = re.compile(r"^(?=[MDCLXVI])M*(?:CM|CD|D?C{0,3})"
                    r"(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3})$")

#: A URL, optionally wrapped in the punctuation a citation style adds around
#: it. Stripped before the individual symbol rules run, otherwise the ``/`` in
#: the scheme would already have been turned into a space and the pattern would
#: no longer match.
_URL = re.compile(
    r"(?:https?://|www\.|doi\.org/|DOI:?\s*)\S+", re.IGNORECASE
)


def normalise(text: str) -> str:
    """Make a string safe and pleasant for a speech engine to read."""
    if not text:
        return ""
    out = _URL.sub(" ", text)
    for symbol, replacement in _SYMBOL_WORDS.items():
        out = out.replace(symbol, replacement)
    # Keep hyphens and slashes out of words, but a hyphen between digits
    # should be read as "to" (page ranges) rather than silently dropped.
    out = re.sub(r"(?<=\d)\s*[-‐-―]\s*(?=\d)", " إلى ", out)
    out = re.sub(r"[-‐-―_/\\|]+", " ", out)
    out = out.replace("\u00a0", " ")
    out = _WHITESPACE.sub(" ", out)
    return out.strip(" .,;:·•-")


def roman_to_int(value: str) -> int | None:
    """Convert a roman numeral (journal volume) to an int, else ``None``.

    SAPI mispronounces "XIV" as letters, so volumes are spoken as numbers.
    The token must be roman throughout: a single stray letter such as the "I"
    in "MIX" means it is an acronym, not a numeral.
    """
    text = (value or "").strip().upper()
    if len(text) > 8 or not text or not _ROMAN.match(text):
        return None
    table = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
    total = 0
    previous = 0
    for char in reversed(text):
        value_i = table[char]
        if value_i < previous:
            total -= value_i
        else:
            total += value_i
            previous = value_i
    return total or None


class Speaker:
    """Thread-safe wrapper around the Windows SAPI speech engine.

    One instance is shared by the whole application. SAPI is a COM object and
    is not safe to call from several threads at once, so every call is funnelled
    through a single worker thread with a one-slot queue: a new request
    replaces an unread one rather than queueing up a backlog.
    """

    def __init__(self) -> None:
        self._tts: Any = None
        self._voice: Any = None
        self._available = False
        self._enabled = True
        self._muted = False
        self._warned = False
        self._last_spoken = 0.0
        self._lock = threading.Lock()
        self._pending: str | None = None
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # -- lifecycle ------------------------------------------------------
    def start(self) -> bool:
        """Start the worker thread. Safe to call more than once."""
        with self._lock:
            if self._thread is not None:
                return self._available
            self._thread = threading.Thread(
                target=self._run, name="acadsearch-speech", daemon=True
            )
            self._thread.start()
        return True

    def shutdown(self) -> None:
        """Stop speaking and end the worker thread."""
        self.stop()
        with self._lock:
            thread = self._thread
            self._thread = None
        if thread is not None:
            self._stop.set()
            self._wake.set()
            thread.join(timeout=1.5)

    def _run(self) -> None:
        while not self._stop.is_set():
            self._wake.wait(timeout=0.4)
            self._wake.clear()
            if self._stop.is_set():
                break
            with self._lock:
                text, self._pending = self._pending, None
            if text:
                self._speak_now(text)

    # -- engine ---------------------------------------------------------
    def _engine(self) -> Any:
        """Create the SAPI object once, off the Tk thread."""
        if self._tts is not None:
            return self._tts
        try:
            import win32com.client  # type: ignore

            tts = win32com.client.Dispatch("SAPI.SpVoice")
        except Exception as exc:  # pragma: no cover - depends on the host
            self._warn(f"speech engine unavailable ({exc.__class__.__name__})")
            return None
        self._tts = tts
        self._select_voice(tts)
        self._available = True
        return tts

    def _select_voice(self, tts: Any) -> None:
        """Prefer a known Arabic voice; fall back to the default."""
        try:
            voices = list(tts.GetVoices())
        except Exception:
            return
        by_name: dict[str, Any] = {}
        for token in voices:
            try:
                description = str(token.GetDescription())
            except Exception:
                continue
            by_name[description.lower()] = token

        # 1. The ranked list, in order.
        for wanted in _VOICE_PREFERENCE:
            for description, token in by_name.items():
                if wanted in description:
                    self._voice = token
                    return
        # 2. Any voice that advertises Arabic.
        for description, token in by_name.items():
            if any(hint in description for hint in _ARABIC_HINTS):
                self._voice = token
                return
        # 3. Keep the engine default; English text still reads fine.

    def _warn(self, message: str) -> None:
        if not self._warned:
            self._warned = True
            log.info("speech disabled: %s", message)

    # -- public API -----------------------------------------------------
    @property
    def available(self) -> bool:
        """True once the engine has been created successfully."""
        return self._available

    @property
    def enabled(self) -> bool:
        """True when the user has turned spoken output on at all.

        Kept separate from :attr:`muted` so that muting is a pause, not a
        reset: the next toggle unmutes instead of rebuilding the engine.
        """
        return self._enabled

    @property
    def muted(self) -> bool:
        return self._muted

    def ensure_ready(self) -> bool:
        """Create the engine if needed. Safe to call from the UI thread."""
        if not self._enabled:
            return False
        self.start()
        return self._engine() is not None

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = bool(enabled)
        if not enabled:
            self.reset()

    def toggle_mute(self) -> bool:
        self._muted = not self._muted
        if self._muted:
            self.stop()
        return self._muted

    def describe_result(self, result: Any, lang: str = "ar") -> str:
        """Build the spoken description of one search result.

        Deliberately uses the data already shown on the card, so what is heard
        matches what is on screen. Handles are duck-typed to keep this usable
        with any object exposing the same fields.
        """
        parts: list[str] = []

        title = normalise(getattr(result, "title", "") or "")
        if not title:
            return ""

        parts.append(title)

        # Authors. ``author_line`` is the app's own formatting.
        authors = normalise(self._author_line(result))
        if authors:
            parts.append(authors)

        year = getattr(result, "year", None)
        if year:
            parts.append(str(year))

        # Publication: venue, volume, issue, pages.
        publication = self._publication_line(result)
        if publication:
            parts.append(publication)

        # Access type, which decides what the Download button will do.
        access = self._access_label(result, lang)
        if access:
            parts.append(access)

        kind = normalise(getattr(result, "item_type", "") or "")
        if kind:
            parts.append(kind)

        text = ". ".join(part for part in parts if part)
        return text

    def _author_line(self, result: Any) -> str:
        author_line = getattr(result, "author_line", None)
        if callable(author_line):
            try:
                return str(author_line() or "")
            except Exception:
                pass
        authors = getattr(result, "authors", None) or []
        try:
            return ", ".join(str(a) for a in authors[:3])
        except TypeError:
            return ""

    def _publication_line(self, result: Any) -> str:
        bits: list[str] = []
        venue = normalise(getattr(result, "venue", "") or "")
        if venue:
            bits.append(venue)

        volume = normalise(str(getattr(result, "volume", "") or ""))
        if volume:
            # SAPI reads "XIV" out as letters, so roman volumes are announced
            # as the number they stand for. Arabic digits are already fine.
            spoken = roman_to_int(volume)
            if spoken is not None:
                bits.append(f"المجلد {spoken}")
            else:
                bits.append(volume)

        issue = normalise(str(getattr(result, "issue", "") or ""))
        if issue and issue.isdigit():
            bits.append(f"العدد {issue}")

        pages = normalise(str(getattr(result, "pages", "") or ""))
        if pages:
            bits.append(f"الصفحات {pages}")

        return normalise("، ".join(bits))

    def _access_label(self, result: Any, lang: str) -> str:
        from app import i18n

        value = getattr(getattr(result, "access", None), "value", None)
        if not value:
            return ""
        try:
            return i18n.t(f"access.{value}")
        except Exception:
            return ""

    # -- speaking -------------------------------------------------------
    def say(self, text: str, force: bool = False) -> bool:
        """Queue ``text`` to be spoken, replacing anything not yet started.

        Returns ``True`` when the text was accepted. A held arrow key is
        throttled by :data:`_MIN_INTERVAL` unless ``force`` is set.
        """
        if not self.enabled:
            return False
        cleaned = normalise(text)
        if not cleaned:
            return False
        if not self.ensure_ready():
            return False

        stamp = time.monotonic()
        with self._lock:
            if not force and stamp - self._last_spoken < _MIN_INTERVAL:
                return False
            self._last_spoken = stamp
            self._pending = cleaned
        self._wake.set()
        return True

    def say_lines(self, lines: Iterable[str], force: bool = True) -> bool:
        """Speak several parts in order, e.g. title then author then year."""
        parts = [normalise(line) for line in lines]
        return self.say(". ".join(part for part in parts if part), force=force)

    def stop(self) -> None:
        """Flush anything queued and silence the engine immediately."""
        with self._lock:
            self._pending = None
        tts = self._tts
        if tts is None:
            return
        try:
            tts.Speak("", 3)  # 3 == SVSFPurgeBuffer
        except Exception:
            log.debug("could not purge the speech buffer", exc_info=True)

    def reset(self) -> None:
        """Return to the off state, dropping the mute pause and the engine."""
        self.stop()
        self._muted = False
        self._available = False
        self._tts = None
        self._voice = None
        self._warned = False

    def _speak_now(self, text: str) -> None:
        tts = self._engine()
        if tts is None:
            return
        try:
            if self._voice is not None:
                tts.Voice = self._voice
            tts.Speak(text, 0)  # 0 == SVSFlagsAsync, do not block the worker
        except Exception as exc:
            # A failed utterance must not retire the engine: SAPI raises
            # sporadically (audio device busy, voice token gone) and the very
            # next request can succeed. Only log it.
            self._warn(f"utterance failed ({exc.__class__.__name__})")
            log.debug("speech utterance failed", exc_info=True)


#: Shared instance. The UI creates it once and wires it to the arrow keys.
speaker = Speaker()
