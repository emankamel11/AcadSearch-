"""Read a local document with Gemini: a summary, or an answer to a question.

The promise that matters is "even a picture-only book". Two paths keep it:

* a PDF with an OCR text layer, or a Word/ODT file, is sent as plain text;
* an image-only PDF is rendered to JPEG pages and sent as images, because a
  vision model reads them directly and nothing has to be installed.

Nothing leaves the machine until the reader presses "لخّص" or "اسأل", and even
then only the extracted text or page images go to Google -- never the file
itself. The key lives in ``config.json`` and in no document.
"""

from __future__ import annotations

import base64
import io
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from app import i18n
from app.config import get_config
from app.core.local_file import document_text, text_layer

API_ROOT = "https://generativelanguage.googleapis.com/v1beta/models"
#: Verified against a real AI Studio key on 2026-10-27. The previous default,
#: gemini-2.5-flash, now answers 404 for new accounts ("no longer available to
#: new users"), so a fresh install could not summarise anything even with a
#: valid key.
DEFAULT_MODEL = "gemini-3.5-flash"
#: Tried in order when the configured model is retired or Google reports it as
#: overloaded. All three answered successfully with the same key; 3.8-flash was
#: temporarily 503 at the time of the check, which is exactly why a fallback
#: exists instead of one hard-coded name.
FALLBACK_MODELS = ("gemini-3.8-flash", "gemini-flash-lite-latest")

#: Enough for a whole book's text (a 400-page book is roughly 600k characters,
#: so most fit); Gemini Flash accepts far more than this in one request, but the
#: reader's uplink may not. A long document is therefore sent as several
#: requests and the answers are merged (see ``_generate``).
MAX_TEXT_CHARS = 400_000
#: Page images are heavy. Twelve pages is a large enough sample to summarise a
#: scanned book and to answer questions about its beginning.
MAX_IMAGES = 12
#: An image page is downscaled to this longest side before JPEG encoding.
MAX_IMAGE_SIDE = 1600
#: A request body larger than about 1.2 MB was cut off in testing ("The write
#: operation timed out") because the 10-second connect timeout was also the
#: socket timeout, so it governed the upload. With a 60-second allowance the
#: same 1.35 MB body uploaded in 40 s and answered 200. Bodies are still capped
#: below that: a cap of 900 KB keeps a whole book's text in one request on a
#: normal uplink, while a scanned book becomes a few requests instead of a
#: dozen, which matters because the free Gemini tier limits requests per minute.
MAX_REQUEST_BYTES = 900_000
#: A 429 usually carries the exact delay Google wants (``RetryInfo``). Waiting
#: that long is invisible next to reading a scanned book, and it saves a job
#: that is already several minutes in. A longer delay is not waited out: the
#: reader gets the quota message instead of a silent quarter-hour.
QUOTA_WAIT_SECONDS = 20.0



class DocAIError(Exception):
    """A failure the dialog can speak: a translation key plus its parameters.

    ``retry_after`` is set only when Google itself said how long to wait (a
    429 carries ``RetryInfo``); it is not a guess, so a caller may sleep exactly
    that long before retrying instead of failing a three-minute job.
    """

    def __init__(
        self,
        key: str,
        retry_after: float | None = None,
        **params: object,
    ):
        self.key = key
        self.params = params
        self.retry_after = retry_after
        super().__init__(key)


#: Called as ``progress(key, params)`` on the worker thread while a document is
#: being read and sent. It exists because a scanned book takes minutes, and a
#: silent answer box is indistinguishable from a broken one.
Progress = Callable[[str, dict], None]


def _report(progress: Progress | None, key: str, **params: object) -> None:
    """Tell the interface what is happening; a listener error is never fatal."""
    if progress is None:
        return
    try:
        progress(key, params)
    except Exception:  # noqa: BLE001 - a progress label must not stop an answer
        pass


@dataclass
class Answer:
    """The model's text plus what it actually had to read."""

    text: str
    images: int = 0
    chars: int = 0
    truncated: bool = False


SYSTEM_PROMPT = {
    "ar": (
        "أنت مساعد بحثي دقيق يتحدث العربية الفصحى. اعتمد حصرًا على النص أو "
        "الصور المرفقة. إن لم يكن الجواب فيها فقل «لا يذكر المستند ذلك» "
        "صراحةً. لا تخترع مراجع أو أرقام صفحات. اكتب نقاطًا قصيرة مفهومة "
        "لقارئ الشاشة."
    ),
    "en": (
        "You are a precise research assistant. Use only the attached text or "
        "images. If the answer is not there, say plainly \"The document does "
        "not mention that\". Never invent references or page numbers. Write "
        "short bullet points that a screen-reader user can follow."
    ),
}

SUMMARY_PROMPT = {
    "ar": (
        "لخّص هذا المستند تلخيصًا وافيًا: الفكرة الرئيسة أولًا، ثم أهم النقاط "
        "والنتائج، ثم خلاصة في سطرين. اذكر رقم الصفحة بين قوسين حين يتيحه "
        "النص أو الصور."
    ),
    "en": (
        "Summarise this document thoroughly: the main idea first, then its most "
        "important points and findings, then a two-line conclusion. Give the "
        "page number in brackets when the text or the images allow it."
    ),
}

QUESTION_PROMPT = {
    "ar": (
        "سؤال القارئ عن هذا المستند:\n{question}\n\n"
        "أجب مباشرة اعتمادًا على المستند وحده، واذكر الصفحة إن أمكن."
    ),
    "en": (
        "The reader's question about this document:\n{question}\n\n"
        "Answer directly from the document alone, citing the page if possible."
    ),
}

#: Told to the model when a document had to be sent in pieces, so it does not
#: answer as if the piece were the whole book.
PART_NOTE = {
    "ar": (
        "هذا الجزء {index} من {total} من المستند؛ اعتمد على هذا الجزء وحده "
        "في هذا الرد."
    ),
    "en": (
        "This is part {index} of {total} of the document; use only this part "
        "for this reply."
    ),
}

#: The last call: the per-part replies are all the model sees, so a summary of
#: a long book stays one answer instead of four unrelated ones.
MERGE_PROMPT = {
    "ar": (
        "هذه ملخصات أو إجابات لأجزاء متتالية من مستند واحد، بالترتيب. "
        "ادمجها في رد واحد متماسك بالعربية الفصحى، بلا تكرار، واذكر أن "
        "التلخيص شمل المستند كله. لا تضف معلومة غير موجودة في هذه الأجزاء."
    ),
    "en": (
        "These are summaries or answers for consecutive parts of one document, "
        "in order. Merge them into one coherent reply in English, without "
        "repetition, and make clear that the whole document was covered. Do "
        "not add anything that is not present in these parts."
    ),
}


def _ui_lang() -> str:
    return "en" if i18n.get_language() == "en" else "ar"


def api_key() -> str:
    return (get_config().gemini_key or "").strip()


def available() -> bool:
    return bool(api_key())


def _model() -> str:
    return (get_config().gemini_model or DEFAULT_MODEL).strip() or DEFAULT_MODEL


def document_parts(
    path: str | Path, should_stop=None
) -> tuple[list[dict], Answer]:
    """Gemini ``parts`` for one file, plus the shape of what was read."""
    p = Path(path)
    meta = Answer(text="")
    if p.suffix.lower() == ".pdf":
        text = text_layer(p, max_pages=10_000, max_chars=MAX_TEXT_CHARS)
        if len(text.strip()) >= 80:
            meta.chars = len(text)
            meta.truncated = len(text) >= MAX_TEXT_CHARS
            return [{"text": text}], meta
        images = _render_pdf(p, MAX_IMAGES, should_stop)
        if not images:
            raise DocAIError("ai.error.no_text")
        parts: list[dict] = []
        for index, (mime, data) in enumerate(images, 1):
            parts.append({"text": f"[page {index}]"})
            parts.append({"inline_data": {"mime_type": mime, "data": data}})
        meta.images = len(images)
        return parts, meta

    text = document_text(p, max_chars=MAX_TEXT_CHARS)
    if not text.strip():
        raise DocAIError("ai.error.no_text")
    meta.chars = len(text)
    meta.truncated = len(text) >= MAX_TEXT_CHARS
    return [{"text": text}], meta


def _render_pdf(path: Path, limit: int, should_stop=None) -> list[tuple[str, str]]:
    """JPEG-encoded page images, or [] when the file cannot be rendered."""
    try:
        import pypdfium2 as pdfium
    except Exception as exc:  # noqa: BLE001 - optional at runtime
        raise DocAIError("ai.error.renderer") from exc
    try:
        document = pdfium.PdfDocument(str(path))
    except Exception as exc:  # noqa: BLE001 - locked or corrupt
        raise DocAIError("ai.error.reading") from exc
    pages: list[tuple[str, str]] = []
    try:
        for index in range(min(limit, len(document))):
            if should_stop is not None and should_stop():
                break
            try:
                page = document[index]
                width, height = page.get_size()
                scale = max(1.0, min(2.0, MAX_IMAGE_SIDE / max(width, height, 1)))
                image = page.render(scale=scale).to_pil().convert("RGB")
                buffer = io.BytesIO()
                image.save(buffer, "JPEG", quality=82, optimize=True)
                pages.append((
                    "image/jpeg",
                    base64.b64encode(buffer.getvalue()).decode("ascii"),
                ))
            except Exception:  # noqa: BLE001 - one bad page must not stop the rest
                continue
    finally:
        document.close()
    return pages


def summarize(
    path: str | Path,
    timeout: float = 120.0,
    should_stop=None,
    progress: Progress | None = None,
) -> Answer:
    key = api_key()
    if not key:
        raise DocAIError("ai.error.no_key")
    _report(progress, "ai.progress.reading")
    parts, meta = document_parts(path, should_stop=should_stop)
    lang = _ui_lang()
    meta.text = _generate(
        parts, SUMMARY_PROMPT[lang], SYSTEM_PROMPT[lang], key, timeout,
        should_stop, progress,
    )
    return meta


def ask(
    path: str | Path,
    question: str,
    timeout: float = 120.0,
    should_stop=None,
    progress: Progress | None = None,
) -> Answer:
    key = api_key()
    if not key:
        raise DocAIError("ai.error.no_key")
    question = (question or "").strip()
    if not question:
        raise DocAIError("ai.error.no_question")
    _report(progress, "ai.progress.reading")
    parts, meta = document_parts(path, should_stop=should_stop)
    lang = _ui_lang()
    instruction = QUESTION_PROMPT[lang].format(question=question[:2000])
    meta.text = _generate(
        parts, instruction, SYSTEM_PROMPT[lang], key, timeout,
        should_stop, progress,
    )
    return meta


def _generate(
    parts: list[dict],
    instruction: str,
    system: str,
    key: str,
    timeout: float,
    should_stop=None,
    progress: Progress | None = None,
) -> str:
    """Answer one prompt, splitting the document if the body would be too big.

    The network path to Google dropped a 1.35 MB body in testing while a 675 KB
    one passed, so a whole book or a set of scanned pages cannot go in a single
    request. Each piece is answered with the same instruction, then a final call
    merges the pieces into one reply.
    """
    lang = _ui_lang()
    budget = MAX_REQUEST_BYTES - _size({"text": instruction}) - 4_000
    batches = _split_parts(parts, max(60_000, budget))
    if len(batches) <= 1:
        _report(progress, "ai.progress.one")
        return _generate_single(
            batches[0] if batches else [], instruction, system, key, timeout,
            should_stop, progress,
        )

    partials: list[str] = []
    for index, batch in enumerate(batches, 1):
        if should_stop is not None and should_stop():
            raise DocAIError("ai.error.cancelled")
        _report(progress, "ai.progress.part", index=index, total=len(batches))
        note = PART_NOTE[lang].format(index=index, total=len(batches))
        partials.append(
            _generate_single(
                batch, f"{instruction}\n\n{note}", system, key, timeout,
                should_stop, progress,
            )
        )

    _report(progress, "ai.progress.merge", total=len(batches))
    joined = "\n\n---\n\n".join(partials)
    return _generate_single(
        [{"text": joined}], MERGE_PROMPT[lang], system, key, timeout,
        should_stop, progress,
    )


def _size(value: dict) -> int:
    """Bytes this fragment adds to the JSON request body."""
    import json

    return len(json.dumps(value, ensure_ascii=False).encode("utf-8"))


def _split_text(text: str, budget: int) -> list[str]:
    """Paragraph-preserving split that keeps every piece inside ``budget``."""
    if _size({"text": text}) <= budget:
        return [text]
    pieces: list[str] = []
    current: list[str] = []
    size = 0
    for paragraph in text.split("\n\n"):
        cost = _size({"text": paragraph}) + 2
        if cost > budget:
            if current:
                pieces.append("\n\n".join(current))
                current, size = [], 0
            pieces.extend(_hard_split(paragraph, budget))
            continue
        if current and size + cost > budget:
            pieces.append("\n\n".join(current))
            current, size = [paragraph], cost
        else:
            current.append(paragraph)
            size += cost
    if current:
        pieces.append("\n\n".join(current))
    return pieces


def _hard_split(text: str, budget: int) -> list[str]:
    """A single paragraph longer than the budget is cut by characters."""
    pieces: list[str] = []
    current: list[str] = []
    size = 0
    for character in text:
        cost = len(character.encode("utf-8"))
        if current and size + cost > budget:
            pieces.append("".join(current))
            current, size = [], 0
        current.append(character)
        size += cost
    if current:
        pieces.append("".join(current))
    return pieces


def _split_parts(parts: list[dict], budget: int) -> list[list[dict]]:
    """Group parts into requests that each fit the body cap.

    Text is split where needed; an image keeps its ``[page N]`` label because a
    page without its number is worse than one more request.
    """
    batches: list[list[dict]] = []
    current: list[dict] = []
    size = 0
    for part in parts:
        variants = [part]
        if "text" in part and _size(part) > budget:
            variants = [
                {"text": piece} for piece in _split_text(part["text"], budget)
            ]
        for item in variants:
            cost = _size(item)
            if current and size + cost > budget:
                batches.append(current)
                current, size = [], 0
            current.append(item)
            size += cost
    if current:
        batches.append(current)
    return batches


def _generate_single(
    parts: list[dict],
    instruction: str,
    system: str,
    key: str,
    timeout: float,
    should_stop=None,
    progress: Progress | None = None,
) -> str:
    payload = {
        "system_instruction": {"parts": [{"text": system}]},
        "contents": [
            {"role": "user", "parts": [{"text": instruction}] + parts}
        ],
        "generation_config": {
            "temperature": 0.2,
            "max_output_tokens": 4096,
        },
    }
    model = _model()
    if should_stop is not None and should_stop():
        raise DocAIError("ai.error.cancelled")
    # A retired name (404) or a model Google says is overloaded (503) is not
    # the reader's fault and not a reason to give up: try the next known model.
    # Auth, quota and content failures are final -- except that Google's quota
    # is per model, so a 429 also earns the next model a try, and a 429 that
    # states its own retry delay is waited out once, because losing a
    # three-minute scanned book to a ten-second per-minute limit is worse than
    # a short, announced wait.
    last: DocAIError | None = None
    for candidate in (model, *(m for m in FALLBACK_MODELS if m != model)):
        try:
            return _post(payload, candidate, key, timeout)
        except DocAIError as exc:
            if exc.key == "ai.error.quota" and _worth_waiting(exc, should_stop):
                _report(
                    progress, "ai.progress.quota",
                    seconds=max(1, int(exc.retry_after or 0) + 1),
                )
                time.sleep((exc.retry_after or 0) + 1)
                try:
                    return _post(payload, candidate, key, timeout)
                except DocAIError as again:
                    last = again
                    if again.key not in (
                        "ai.error.quota", "ai.error.model", "ai.error.server",
                    ):
                        raise
                    continue
            if exc.key not in (
                "ai.error.model", "ai.error.server", "ai.error.quota",
            ):
                raise
            last = exc
    if last is not None:
        raise last
    raise DocAIError("ai.error.model")


def _worth_waiting(exc: DocAIError, should_stop=None) -> bool:
    """Whether Google named a delay short enough to sit out on the worker."""
    delay = exc.retry_after
    if delay is None or not (0 < delay <= QUOTA_WAIT_SECONDS):
        return False
    return not (should_stop is not None and should_stop())


def _log_failure(model: str, exc: BaseException, attempt: int) -> None:
    """Keep the real transport error where it can be read later.

    The interface can only say "check your connection"; that sentence hid a
    request body being cut off mid-upload. The log holds the exception type and
    message (never the key or the document), so a recurrence is diagnosable.
    """
    chain = []
    cause: BaseException | None = exc
    while cause is not None and len(chain) < 5:
        chain.append(f"{type(cause).__name__}: {cause}")
        cause = cause.__cause__
    _log_line(f"model={model} attempt={attempt} " + " | ".join(chain))


def _log_http(model: str, status: int, detail: str) -> None:
    """Record why Google refused a request: status and its own message.

    A 429 and a 400 read the same in the interface ("Gemini refused"); the log
    keeps the difference, and it is the only trace a frozen build can leave.
    """
    _log_line(f"model={model} http={status} {detail[:300]}")


def _log_line(text: str) -> None:
    import tempfile
    from datetime import datetime
    from pathlib import Path

    line = f"{datetime.now().isoformat(timespec='seconds')} {text}\n"
    try:
        path = Path(tempfile.gettempdir()) / "acad_ai_error.log"
        with path.open("a", encoding="utf-8") as handle:
            handle.write(line)
    except Exception:  # noqa: BLE001 - logging must never break a request
        pass


def _error_detail(response) -> str:
    """Google's own error sentence, never more than a line of it."""
    try:
        return str(response.json().get("error", {}).get("message", ""))
    except Exception:  # noqa: BLE001 - a non-JSON error page is fine
        return ""


def _retry_after(response) -> float | None:
    """The wait Google asked for on a 429, in seconds, when it said one.

    ``RetryInfo.retryDelay`` looks like ``"17s"`` or ``"1.5s"``; a
    ``Retry-After`` header is the plain-seconds fallback.
    """
    try:
        details = response.json().get("error", {}).get("details") or []
    except Exception:  # noqa: BLE001
        details = []
    for item in details:
        if not isinstance(item, dict):
            continue
        if str(item.get("@type", "")).endswith("RetryInfo"):
            raw = str(item.get("retryDelay") or "").strip().lower()
            if raw.endswith("s"):
                raw = raw[:-1]
            try:
                return float(raw)
            except ValueError:
                return None
    try:
        header = response.headers.get("Retry-After")
    except Exception:  # noqa: BLE001
        header = None
    try:
        return float(header) if header is not None else None
    except (TypeError, ValueError):
        return None


def _post(payload: dict, model: str, key: str, timeout: float) -> str:
    """One generateContent call. Split out so tests can replace the network."""
    import requests

    url = f"{API_ROOT}/{model}:generateContent"
    response = None
    for attempt in (1, 2):
        try:
            response = requests.post(
                url,
                headers={"x-goog-api-key": key, "Content-Type": "application/json"},
                json=payload,
                # The first number is not only the connect timeout: with
                # requests/urllib3 it remains the socket timeout, so a 10-second
                # value also cut off the upload itself. On a slow uplink a
                # 1.35 MB book body died at 11 s with "The write operation
                # timed out", which the interface could only report as "check
                # your internet". At 120 s the same body uploaded in 40 s and
                # answered 200. Uploads are also capped (MAX_REQUEST_BYTES), so
                # this is a generous ceiling rather than a wait a healthy
                # connection ever reaches.
                timeout=(60, timeout),
            )
            break
        except requests.exceptions.Timeout as exc:
            _log_failure(model, exc, attempt)
            raise DocAIError("ai.error.timeout") from exc
        except requests.exceptions.RequestException as exc:
            _log_failure(model, exc, attempt)
            # A dropped connection is often a one-off; one quiet retry turns a
            # transient failure into an answer instead of "check your internet".
            if attempt == 1:
                time.sleep(1.5)
                continue
            raise DocAIError("ai.error.network") from exc
    if response is None:  # pragma: no cover - the loop either breaks or raises
        raise DocAIError("ai.error.network")

    status = response.status_code
    if status != 200:
        _log_http(model, status, _error_detail(response))
    if status == 404:
        raise DocAIError("ai.error.model")
    if status in (400, 401, 403):
        detail = _error_detail(response)
        if status in (401, 403) or "API key" in detail or "api key" in detail.lower():
            raise DocAIError("ai.error.bad_key")
        raise DocAIError("ai.error.request", detail=detail[:200])
    if status == 429:
        raise DocAIError("ai.error.quota", retry_after=_retry_after(response))
    if status >= 500:
        raise DocAIError("ai.error.server")
    if status != 200:
        raise DocAIError("ai.error.request", detail=f"HTTP {status}")

    try:
        data = response.json()
    except Exception as exc:  # noqa: BLE001 - an empty body is a failure too
        raise DocAIError("ai.error.empty") from exc

    feedback = data.get("promptFeedback") or {}
    if feedback.get("blockReason"):
        raise DocAIError("ai.error.blocked")
    candidates = data.get("candidates") or []
    if not candidates:
        raise DocAIError("ai.error.empty")
    candidate = candidates[0]
    content = candidate.get("content") or {}
    chunks = [
        str(part.get("text") or "")
        for part in (content.get("parts") or [])
    ]
    text = "".join(chunks).strip()
    if not text:
        if candidate.get("finishReason") in ("SAFETY", "RECITATION"):
            raise DocAIError("ai.error.blocked")
        raise DocAIError("ai.error.empty")
    return text
