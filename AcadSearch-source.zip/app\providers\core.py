"""CORE — the world's largest aggregator of open-access research.

Docs: https://api.core.ac.uk/docs/v3
A free API key (Preferences → API keys → CORE) is required: unlike the
anonymous-friendly sources, CORE answers 401 without a token, so the provider
stays quiet until a key is configured. It searches the full text of journal
articles, theses and datasets from thousands of institutional repositories and
publisher platforms, and returns direct file links when the record is open.
"""

from __future__ import annotations

import threading

from app.core.text_utils import (
    as_int,
    clean_text,
    extract_doi,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://api.core.ac.uk/v3/search/works"

#: CORE ``type`` labels routed to the research (thesis/dataset) tab.
RESEARCH_TYPES = ("thesis", "dissertation", "dataset", "preprint", "report")
BOOK_TYPES = ("book", "monograph", "chapter")


@register
class CoreProvider(BaseProvider):
    provider_id = "core"
    display_name = "CORE"
    categories = (Category.ARTICLE, Category.RESEARCH, Category.BOOK)
    weight = 30
    requires_key = "core_key"
    homepage = "https://core.ac.uk"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        token = self.config.core_key
        if not token:
            return []
        # ``authorization`` is never sent to the server as a query parameter;
        # the HTTP client turns it into an ``Authorization: Bearer`` header.
        params: dict[str, object] = {
            "q": query.text,
            "limit": min(query.per_source, 20),
            "authorization": token,
        }
        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        return [self._to_result(work) for work in (payload.get("results") or [])]

    # -- mapping ----------------------------------------------------------
    def _to_result(self, work: dict) -> Result:
        title = clean_text(work.get("title"))
        work_type = clean_text(work.get("type")).lower()

        authors = [
            clean_text((a or {}).get("name"))
            for a in (work.get("authors") or [])
            if (a or {}).get("name")
        ]
        authors = [a for a in authors if a]

        identifiers: dict[str, str] = {}
        doi = extract_doi(work.get("doi"))
        if doi:
            identifiers["doi"] = doi
        core_id = clean_text(work.get("id"))
        if core_id:
            identifiers["core"] = str(core_id).rsplit("/", 1)[-1]

        venue = clean_text(work.get("journalName")) or clean_text(
            work.get("sourceFullName")
        )
        publisher = clean_text(work.get("publisher"))
        language = normalise_language((work.get("language") or {}).get("code"))
        subjects = [
            clean_text(s) for s in (work.get("subjects") or []) if clean_text(s)
        ][:6]

        downloads = self._downloads(work, doi)
        landing = (
            f"https://doi.org/{doi}"
            if doi
            else clean_text(work.get("landingPageUrl") or work.get("link"))
        )

        if work_type in BOOK_TYPES:
            category = Category.BOOK
        elif work_type in RESEARCH_TYPES:
            category = Category.RESEARCH
        else:
            category = Category.ARTICLE

        return Result(
            category=category,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=as_int(work.get("yearPublished")),
            abstract=truncate_words(clean_text(work.get("abstract")), 320),
            venue=venue or publisher,
            publisher=publisher,
            language=language,
            subjects=subjects,
            identifiers=identifiers,
            access=Access.DOWNLOAD if downloads else (
                Access.LANDING if landing else Access.METADATA
            ),
            downloads=downloads,
            landing_url=landing,
            item_type=work_type.replace("_", " ").title(),
            raw=work,
        )

    @staticmethod
    def _downloads(work: dict, doi: str) -> list:
        """The best open file first, then any other full texts."""
        out: list = []
        seen: set[str] = set()
        candidates: list[str] = []
        if clean_text(work.get("downloadUrl")):
            candidates.append(clean_text(work["downloadUrl"]))
        for url in (work.get("fullTextUrls") or []):
            value = clean_text(url)
            if value:
                candidates.append(value)

        for url in candidates:
            if url in seen or not url.startswith(("http://", "https://")):
                continue
            seen.add(url)
            if url.lower().endswith(".pdf"):
                out.append(
                    target(url, DownloadFormat.PDF, label="CORE open PDF", open_access=True)
                )
            else:
                out.append(
                    target(url, DownloadFormat.HTML, label="CORE full text", open_access=True)
                )
            if len(out) >= 2:
                break
        return out