"""BASE — Bielefeld Academic Search Engine, the world's largest open index.

Docs: https://www.base-search.net/about/en/about_suggest_dc.php
A free API key is passed as the ``X-API-Key`` HTTP header; without one BASE
returns nothing, so the provider stays quiet until a key is configured (the
HTTP client turns the ``x-api-key`` query parameter into that header and
keeps it out of the URL). BASE indexes deep institutional repositories, so a
query that journals skim past still lands on a thesis or an archive PDF.
"""

from __future__ import annotations

import json
import threading

from app.core.text_utils import as_int, clean_text, extract_doi, truncate_words
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

ENDPOINT = "https://api.base-search.net/cgi-bin/BaseHttpSearchInterface.fcgi"

#: BASE ``doctype`` labels routed to the research tab.
RESEARCH_TYPES = ("thesis", "dissertation", "dataset", "report", "preprint")
BOOK_TYPES = ("book", "monograph")


@register
class BaseSearchProvider(BaseProvider):
    provider_id = "base"
    display_name = "BASE"
    categories = (Category.ARTICLE, Category.RESEARCH, Category.BOOK)
    weight = 30
    requires_key = "base_key"
    homepage = "https://www.base-search.net"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        token = self.config.base_key
        if not token:
            return []
        params: dict[str, object] = {
            "func": "PerformSearch",
            "query": query.text,
            "format": "json",
            "hitsperpage": min(query.per_source, 20),
            "x-api-key": token,
        }
        text = self.http.get_text(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        return self._parse(text)

    # -- parsing ----------------------------------------------------------
    def _parse(self, text: str) -> list[Result]:
        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ProviderError(
                f"BASE: استجابة JSON غير صالحة / malformed response", kind="error"
            ) from exc
        response = data.get("response") or {}
        docs = response.get("docs") or []
        return [self._to_result(doc) for doc in docs]

    def _to_result(self, doc: dict) -> Result:
        title = clean_text(_first(doc, ("title", "dctitle")))
        creators = [clean_text(a) for a in _as_list(doc, "authors") if clean_text(a)]
        year = as_int(_first(doc, "year"))
        doctype = clean_text(_first(doc, "doctype")).lower()
        if any(t in doctype for t in BOOK_TYPES):
            category = Category.BOOK
        elif any(t in doctype for t in RESEARCH_TYPES):
            category = Category.RESEARCH
        else:
            category = Category.ARTICLE

        identifiers: dict[str, str] = {}
        doi = extract_doi(_first(doc, "doi"))
        if doi:
            identifiers["doi"] = doi
        base_id = clean_text(_first(doc, "id"))
        if base_id:
            identifiers["base"] = base_id

        subjects = [clean_text(s) for s in _as_list(doc, "subject") if clean_text(s)][:6]
        venue = clean_text(_first(doc, "collname")) or clean_text(
            _first(doc, "publisher")
        )
        language_raw = clean_text(_first(doc, "lang")) or ""
        language = language_raw[:2].lower() if language_raw else ""

        landing = (
            clean_text(_first(doc, "oa_link"))
            or clean_text(_first(doc, "link"))
            or clean_text(_first(doc, "xml_retrieval"))
            or (f"https://doi.org/{doi}" if doi else "")
        )
        downloads = self._downloads(doc)

        return Result(
            category=category,
            title=title,
            source=self.provider_id,
            authors=creators,
            year=year,
            abstract=truncate_words(clean_text(_first(doc, "abstract")), 320),
            venue=venue,
            language=language,
            subjects=subjects,
            identifiers=identifiers,
            access=Access.DOWNLOAD if downloads else (
                Access.LANDING if landing else Access.METADATA
            ),
            downloads=downloads,
            landing_url=landing,
            item_type=doctype.replace("_", " ").title(),
            raw=doc,
        )

    @staticmethod
    def _downloads(doc: dict) -> list:
        """BASE flags openfulltext records; surface the file when it is one."""
        if _first(doc, "allowfulltextaccess") != "1":
            return []
        url = clean_text(_first(doc, "oa_link"))
        if not url or not url.startswith(("http://", "https://")):
            return []
        if url.lower().endswith(".pdf"):
            return [target(url, DownloadFormat.PDF, label="BASE open PDF", open_access=True)]
        return [target(url, DownloadFormat.HTML, label="BASE full text", open_access=True)]


def _first(doc: dict, key: str) -> str:
    """First element of a *field that may be a scalar or a list*."""
    value = doc.get(key) or ""
    if isinstance(value, list):
        return value[0] if value else ""
    return value if isinstance(value, str) else str(value) if value else ""


def _as_list(doc: dict, key: str) -> list[str]:
    value = doc.get(key) or []
    if not isinstance(value, list):
        return [value] if value else []
    return [v for v in value if v]