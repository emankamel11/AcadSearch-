"""Check DOI/ISBN detection and metadata lookup without touching the network.

Run:  python -X utf8 tools/check_local_lookup.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core import local_lookup  # noqa: E402
from app.core.local_file import find_doi, find_isbn  # noqa: E402

failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    if condition:
        print(f"  ok   {name}")
    else:
        failures.append(name)
        print(f"  FAIL {name}  {detail}")


class FakeResponse:
    def __init__(self, payload: dict, status: int = 200):
        self._payload = payload
        self.status_code = status

    def json(self) -> dict:
        return self._payload


CROSSREF = {
    "message": {
        "title": ["Deep learning"],
        "author": [
            {"given": "Yann", "family": "LeCun"},
            {"given": "Yoshua", "family": "Bengio"},
            {"name": "Geoffrey Hinton"},
        ],
        "issued": {"date-parts": [[2015, 5, 27]]},
        "container-title": ["Nature"],
        "publisher": "Springer",
        "DOI": "10.1038/nature14539",
    }
}

GOOGLE = {
    "items": [
        {
            "volumeInfo": {
                "title": "فن البحث العلمي",
                "subtitle": "دليل عملي",
                "authors": ["أحمد محمد علي", "Sami Hassan"],
                "publishedDate": "2019-03-15",
                "publisher": "دار المعرفة",
            }
        }
    ]
}

OPEN_LIBRARY = {
    "docs": [
        {
            "title": "Introduction à la recherche",
            "author_name": ["Élodie Martin"],
            "first_publish_year": 2004,
            "publisher": ["Presses Universitaires"],
        }
    ]
}

ROUTES = {
    "api.crossref.org": CROSSREF,
    "googleapis.com": GOOGLE,
    "openlibrary.org/search": OPEN_LIBRARY,
}


def install_fake_http(status_override: int | None = None):
    calls: list[str] = []

    def fake_get(url, params=None, timeout=None, headers=None):
        calls.append(url)
        for needle, payload in ROUTES.items():
            if needle in url:
                status = status_override if status_override is not None else 200
                return FakeResponse(payload, status)
        return FakeResponse({}, 404)

    local_lookup.requests.get = fake_get
    return calls


def main() -> int:
    print("== DOI in text ==")
    check(
        "finds a DOI and drops the full stop",
        find_doi("see https://doi.org/10.1038/nature14539.") == "10.1038/nature14539",
        find_doi("see https://doi.org/10.1038/nature14539."),
    )
    check(
        "balances a trailing parenthesis",
        find_doi("(doi:10.1002/(SICI)1097-4628(199705)12:3)")
        == "10.1002/(SICI)1097-4628(199705)12:3",
        find_doi("(doi:10.1002/(SICI)1097-4628(199705)12:3)"),
    )
    check("no DOI returns empty", find_doi("nothing here") == "")

    print("== ISBN detection ==")
    check(
        "ISBN-13 with hyphens",
        find_isbn("ISBN 978-0-13-468599-1") == "9780134685991",
        find_isbn("ISBN 978-0-13-468599-1"),
    )
    check(
        "ISBN-10 ending in X",
        find_isbn("ISBN 0-8044-2957-X") == "080442957X",
        find_isbn("ISBN 0-8044-2957-X"),
    )
    check(
        "Arabic-Indic digits are folded",
        find_isbn("ردمك ٩٧٨٠١٣٤٦٨٥٩٩١") == "9780134685991",
        find_isbn("ردمك ٩٧٨٠١٣٤٦٨٥٩٩١"),
    )
    check("bad check digit is rejected", find_isbn("ISBN 978-0-13-468599-2") == "")
    check("random number is rejected", find_isbn("call 1234567890 now") == "")

    print("== Crossref mapping ==")
    install_fake_http()
    doi_fields = local_lookup.lookup_doi("10.1038/nature14539")
    check("title", (doi_fields or {}).get("title") == "Deep learning", repr(doi_fields))
    check(
        "authors keep given + family",
        (doi_fields or {}).get("authors") == ["Yann LeCun", "Yoshua Bengio", "Geoffrey Hinton"],
        repr((doi_fields or {}).get("authors")),
    )
    check("year", (doi_fields or {}).get("year") == 2015, repr((doi_fields or {}).get("year")))
    check("venue prefers the journal", (doi_fields or {}).get("venue") == "Nature",
          repr((doi_fields or {}).get("venue")))
    check("source is doi", (doi_fields or {}).get("source") == "doi")

    print("== Google Books mapping ==")
    install_fake_http()
    isbn_fields = local_lookup.lookup_isbn("9780134685991")
    check("arabic title", (isbn_fields or {}).get("title") == "فن البحث العلمي: دليل عملي",
          repr(isbn_fields))
    check("authors are a list", (isbn_fields or {}).get("authors")
          == ["أحمد محمد علي", "Sami Hassan"], repr(isbn_fields))
    check("year from publishedDate", (isbn_fields or {}).get("year") == 2019,
          repr(isbn_fields))
    check("publisher as venue", (isbn_fields or {}).get("venue") == "دار المعرفة",
          repr(isbn_fields))
    check("source is isbn", (isbn_fields or {}).get("source") == "isbn")

    print("== Open Library fallback ==")
    local_lookup.requests.get_original = local_lookup.requests.get

    def google_down(url, params=None, timeout=None, headers=None):
        if "googleapis.com" in url:
            return FakeResponse({}, 503)
        for needle, payload in ROUTES.items():
            if needle in url:
                return FakeResponse(payload)
        return FakeResponse({}, 404)

    local_lookup.requests.get = google_down
    fallback = local_lookup.lookup_isbn("080442957X")
    check("title from Open Library", (fallback or {}).get("title")
          == "Introduction à la recherche", repr(fallback))
    check("author name resolved", (fallback or {}).get("authors") == ["Élodie Martin"],
          repr((fallback or {}).get("authors")))
    check("year", (fallback or {}).get("year") == 2004, repr((fallback or {}).get("year")))

    print("== failures stay quiet ==")
    install_fake_http(status_override=500)
    check("a 500 returns None", local_lookup.lookup_doi("10.1/x") is None)
    check("a bad ISBN returns None", local_lookup.lookup_isbn("nope") is None)

    print("== orchestration ==")
    install_fake_http()
    original_text_layer = local_lookup.text_layer
    local_lookup.text_layer = lambda path: "front matter doi 10.1038/nature14539"
    fields = local_lookup.enrich_from_file("whatever.pdf")
    check("a DOI in the text layer is used", fields.get("title") == "Deep learning",
          repr(fields))
    local_lookup.text_layer = lambda path: ""
    check("an empty text layer yields nothing", local_lookup.enrich_from_file("x.pdf") == {})
    local_lookup.text_layer = original_text_layer

    local_lookup.text_layer = lambda path: "isbn 978-0-13-468599-1"
    stopped = local_lookup.enrich_from_file("x.pdf", should_stop=lambda: True)
    check("stop request ends the lookup", stopped == {}, repr(stopped))
    local_lookup.text_layer = original_text_layer

    print()
    if failures:
        print(f"FAILED: {len(failures)} check(s): {failures}")
        return 1
    print("ALL LOCAL-LOOKUP CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
