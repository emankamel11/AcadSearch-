"""Check that downloading works from the keyboard, with a real search behind it.

Verifies the three shortcuts the user needs: Enter on a row, d on a row, and
Alt+D from anywhere. Each is checked both with and without a downloadable file.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import QEvent, Qt, QTimer
from PySide6.QtGui import QKeyEvent, QShortcut
from PySide6.QtWidgets import QApplication

import main_window


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()

    log: list[tuple[str, str]] = []
    win._on_download = lambda url: log.append(("download", url))
    win._no_file = lambda page, row: log.append(("no_file", str(row)))

    def find_row(has_file: bool):
        for page in win.pages.values():
            for r in range(page.list.count()):
                if bool(page.cards_result(r).downloads) is has_file:
                    return page, r
        return None, None

    def press(widget, key) -> bool:
        ev = QKeyEvent(QEvent.KeyPress, key, Qt.NoModifier)
        widget.keyPressEvent(ev)
        return True

    def test() -> None:
        print("=== a real search finished ===")
        print("  rows per tab:", {c.value: p.list.count() for c, p in win.pages.items()})
        print()

        page, row = find_row(True)
        if page is None:
            print("  !! no row with a downloadable file was found")
            app.quit()
            return

        log.clear()
        page.list.setCurrentRow(row)
        handled = press(page.list, Qt.Key_Return)
        print(f"Enter on a row WITH a file -> handled={handled} log={log[-1] if log else None}")

        log.clear()
        handled = press(page.list, Qt.Key_D)
        print(f"d on a row WITH a file     -> handled={handled} log={log[-1] if log else None}")

        log.clear()
        win.download_current()
        print(f"Alt+D (download_current)   -> log={log[-1] if log else None}")

        page2, row2 = find_row(False)
        if page2 is not None:
            log.clear()
            page2.list.setCurrentRow(row2)
            handled = press(page2.list, Qt.Key_Return)
            print(f"Enter on a row WITHOUT file -> handled={handled} "
                  f"log={log[-1] if log else None}")

        combos = sorted(s.key().toString() for s in win.findChildren(QShortcut))
        print()
        print("shortcuts:", combos)
        app.quit()

    def go() -> None:
        win.query.setText("machine learning")
        win.start_search()

    QTimer.singleShot(400, go)
    QTimer.singleShot(38000, test)
    QTimer.singleShot(60000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())