"""Smoke test for the Qt interface, run before packaging.

Builds the real window, injects synthetic results so nothing depends on the
network, and exercises the paths a user touches: search, arrow navigation,
download, citation, clear, settings, and the font zoom. Any failure stops the
build so a broken ``.exe`` is never produced.

    python -m tools.smoke_ui

Needs a desktop session, because a real window is created and grabbed.
"""

from __future__ import annotations

import copy
import logging
import os
import pathlib
import queue
import sys
import threading
import time
import traceback
import warnings
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for extra in (ROOT, ROOT / "qt_prototype"):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")

from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtTest import QTest  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from app.config import get_config  # noqa: E402
from app.core.search_engine import (  # noqa: E402
    SearchEvent,
    SearchEventType,
    SearchHandle,
)
from app.models import (  # noqa: E402
    Access,
    Category,
    DownloadFormat,
    DownloadTarget,
    Result,
    SearchQuery,
    SearchResponse,
)
from qt_prototype.main_window import (  # noqa: E402
    CATEGORY_TAB_INDEX,
    MainWindow,
    has_download,
)

FAILURES: list[str] = []


def check(label: str, condition: bool, detail: str = "") -> None:
    mark = "PASS" if condition else "FAIL"
    print(f"  [{mark}] {label}" + (f" -- {detail}" if detail else ""))
    if not condition:
        FAILURES.append(label)


def _check_no_card_buttons(app, win) -> None:
    from PySide6.QtWidgets import QPushButton

    page = win.pages[Category.ARTICLE]
    _wake(app, win)
    win.tabs.setCurrentWidget(page)
    while page.list.count():
        page.list.takeItem(0)
    page._cards.clear()
    page.update_count()

    page.add(make("Card with a file", Category.ARTICLE, with_file=True))
    page.add(make("Card without a file", Category.ARTICLE, with_file=False))
    page.update_count()
    pump(app)
    # The real app finishes a search on the first row (focus_first), scrolls the
    # list back to the top, and only then is the first card actually visible.
    page.focus_first()
    pump(app)

    # The whole point of the redesign: a screen of results carries no buttons,
    # so the actions (via the Application key) can never crowd the cards.
    buttons = page.list.findChildren(QPushButton)
    check("a filled results screen holds no action buttons",
          not buttons, str([b.text() for b in buttons]))

    # Leave the window as the rest of the smoke test expects to find it.
    while page.list.count():
        page.list.takeItem(0)
    page._cards.clear()
    page.update_count()


def pump(app, rounds: int = 8) -> None:
    """Let Qt finish everything it queued, worker signals included."""
    for _ in range(rounds):
        app.processEvents()
        app.sendPostedEvents()
        time.sleep(0.01)


ABSTRACT = "This is the abstract of the article, kept short on purpose so the snippet preview and the Alt+M field both have something real to show during the smoke run."


def make(title: str, category: Category, with_file: bool = True,
         abstract: str = "") -> Result:
    downloads = []
    if with_file:
        downloads.append(
            DownloadTarget(
                url="https://example.org/sample.pdf",
                fmt=DownloadFormat.PDF,
                open_access=True,
            )
        )
    return Result(
        category=category,
        title=title,
        source="open_library",
        authors=["Sara Ahmed"],
        year=2021,
        venue="Journal of Testing",
        access=Access.DOWNLOAD if with_file else Access.LANDING,
        downloads=downloads,
        abstract=abstract,
        # Every real record has one; without it "فتح للقراءة على الموقع" has
        # nothing to open, which is what made an earlier check look broken.
        landing_url="https://example.org/record",
    )


class _FakeTask:
    """What ``enqueue`` hands back, without fetching anything."""

    def __init__(self, result: Result, error: str | None = None):
        self.result = result
        self.error = error
        self.path = None
        self.state = None


class _FakeEngine:
    """Answers a search instantly, so the smoke test never touches the network."""

    def __init__(self, response=None, message: str = "تم", fail: bool = False):
        self._response = response
        self._message = message
        self._fail = fail
        self.cancelled = False

    def start(self, query):
        handle = SearchHandle(query, queue.Queue())

        def deliver() -> None:
            if self._fail:
                handle.events.put(
                    SearchEvent(SearchEventType.FAILED, None,
                                message=self._message)
                )
            else:
                handle.events.put(
                    SearchEvent(SearchEventType.FINISHED, self._response,
                                message=self._message)
                )
            handle._finish()

        # Not instantly: the worker loops "while not handle.done", so a handle
        # that is already done when the thread starts never reads its own events
        # and reports a failure for a search that actually worked.
        threading.Timer(0.03, deliver).start()
        return handle

    def cancel_current(self) -> None:
        self.cancelled = True

    def shutdown(self) -> None:
        pass


def _response_for(text: str) -> SearchResponse:
    """A small response that looks like a real one: every category gets something."""
    return SearchResponse(
        query=SearchQuery(text=text, categories={c for c in Category}),
        results={
            Category.BOOK: [make("A Book About Widgets", Category.BOOK)],
            Category.ARTICLE: [
                make("An Article About Widgets", Category.ARTICLE,
                     abstract=ABSTRACT),
                make("A Second Article", Category.ARTICLE, with_file=False),
            ],
            Category.RESEARCH: [
                make("A Thesis About Widgets", Category.RESEARCH, with_file=False)
            ],
        },
        elapsed=1.5,
    )


def _check_unreachable_downloads(app, win) -> None:
    """Press the real download button against a server that misbehaves.

    Three things happen in the wild and all three used to end with a file the
    user could not use: a "PDF" link that answers with a web page, a publisher
    that answers 403 to any client, and a file that is really there. The last one
    must still work, or the test would pass on a broken downloader.
    """
    import http.server
    import tempfile
    import threading

    from app.core.downloader import DownloadEventType, DownloadState
    from app.models import DownloadTarget

    PDF = b"%PDF-1.4\n%%EOF\n"

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            if self.path == "/real.pdf":
                body, ctype, code = PDF, "application/pdf", 200
            elif self.path == "/page.pdf":
                body = b"<!doctype html>\n<html><body>Sign in</body></html>"
                ctype, code = "text/html; charset=utf-8", 200
            elif self.path == "/blank.pdf":
                body = b"\n\n\n\n\n\n<html><body>Redirect</body></html>"
                ctype, code = "application/pdf", 200
            else:
                body, ctype, code = b"no", "text/plain", 403
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{server.server_address[1]}"

    folder = pathlib.Path(tempfile.mkdtemp(prefix="acad-dl-"))
    # The config is a saved singleton: writing to it here once left a dead temp
    # path in config.json, and every later download went to a folder that the
    # smoke test had already deleted.
    real_config = copy.deepcopy(win._downloads.config)
    win._downloads.config.download_dir = str(folder)
    # One case fails on purpose; its warning would otherwise look like a broken
    # build in the log.
    downloader_log = logging.getLogger("app.core.downloader")
    was_noisy = downloader_log.level
    downloader_log.setLevel(logging.CRITICAL)
    page = win.pages[Category.ARTICLE]
    _wake(app, win)
    win.tabs.setCurrentWidget(page)

    def wait_for(predicate, seconds=25):
        for _ in range(int(seconds / 0.1)):
            pump(app, 2)
            if predicate():
                return True
        return False

    cases = [
        ("real.pdf", "انتهى تنزيل", None),
        ("page.pdf", "صفحة ويب", None),
        ("blank.pdf", "صفحة ويب", None),
        ("blocked.pdf", "403", None),
    ]
    try:
        for name, expected, _ in cases:
            while page.list.count():
                page.list.takeItem(0)
            page._cards.clear()
            result = make(f"Probe {name}", Category.ARTICLE, with_file=True)
            result.downloads = [DownloadTarget(url=f"{base}/{name}",
                                                fmt=DownloadFormat.PDF,
                                                open_access=True)]
            page.add(result)
            page.update_count()
            pump(app, 4)

            win.status.clear()
            # The same route the menu's تنزيل (and Alt+D) takes; there is no
            # card button to press any more.
            win._on_download(page._cards[0].result)
            settled = wait_for(lambda: "انتهى" in win.status.text()
                               or "فشل" in win.status.text()
                               or "تخطي" in win.status.text()
                               or "لا يوجد" in win.status.text())
            said = win.status.text()
            print(f"       {name} -> {said[:90]}")
            check(f"{name}: the button reported something", settled, said[:80])
            check(f"{name}: the message says {expected}", expected in said,
                  said[:110])
            if name == "real.pdf":
                saved = list(folder.glob("*.pdf"))
                check("the real file was saved",
                      bool(saved) and saved[0].read_bytes().startswith(b"%PDF"),
                      str([f.name for f in folder.glob('*')]))
            else:
                leftovers = [f.name for f in folder.iterdir()]
                check(f"{name}: nothing was saved", not leftovers,
                      str(leftovers))
            # Start every case with an empty folder, or the file from the first
            # one makes the rest of them look like they saved something.
            for stale in folder.glob("*"):
                stale.unlink()
    finally:
        win._downloads.config.download_dir = real_config.download_dir
        downloader_log.setLevel(was_noisy)
        server.shutdown()
        while page.list.count():
            page.list.takeItem(0)
        page._cards.clear()
        page.update_count()
        for stale in folder.glob("*"):
            stale.unlink()
        folder.rmdir()


def _announcements_during_search(app, win, text: str, *, empty=False,
                                 fail=False) -> list[str]:
    """Run a whole search for real, and return what the screen reader heard.

    The engine is swapped for one that answers instantly, so this exercises the
    real ``start_search`` -> worker -> ``_on_results`` path, announcements
    included, without waiting on the network.
    """
    import qt_prototype.main_window as mw

    spoken: list[str] = []

    def record(widget, say=None):
        if say:
            spoken.append(say)
        mw_real_announce(widget, say)

    mw_real_announce = mw.announce
    real_engine = win._engine
    # An empty search still finishes with a response; only a real failure has
    # none. Passing None here made the window say "failed" for a search that
    # simply found nothing.
    response = None if fail else _response_for(text)
    if empty:
        response = SearchResponse(query=response.query, results={}, elapsed=0.4)
    win._engine = _FakeEngine(response=response, message="تم", fail=fail)
    mw.announce = record
    try:
        win.query.setText(text)
        win.start_search()
        for _ in range(80):
            pump(app, 4)
            if win._worker is None or not win._worker.isRunning():
                break
        pump(app, 20)
    finally:
        mw.announce = mw_real_announce
        win._engine = real_engine
    return spoken


def _wake(app, win) -> bool:
    """Make the window the active one, so keys and hit-testing work as they do
    for a person.

    A shortcut only fires when its window is the active one, and
    ``QApplication.widgetAt`` only finds widgets in a mapped window. Started from
    a build script, a window can end up neither, and then every key check fails
    for a reason that has nothing to do with the app.
    """
    from PySide6.QtTest import QTest

    QTest.qWaitForWindowExposed(win, 5000)
    win.raise_()
    win.activateWindow()
    win.setFocus()
    # QApplication.setActiveWindow is deprecated in Qt 6.7, but activateWindow
    # alone is not enough for a window started from a build script.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        QApplication.setActiveWindow(win)
    pump(app, 10)
    return win.isActiveWindow()


def _keyboard(app, win, key, mods=None) -> None:
    """Press a key where the user is actually typing: the focused widget."""
    from PySide6.QtTest import QTest

    if not win.isActiveWindow():
        _wake(app, win)
    mods = mods or Qt.NoModifier
    target = QApplication.focusWidget() or win
    QTest.keyClick(target, key, mods)
    pump(app, 4)


def main() -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    win = MainWindow()
    win.resize(1180, 820)
    config_at_start = get_config().download_dir
    win.show()
    pump(app, 20)
    active = _wake(app, win)
    try:
        print("== window comes up ==")
        check("the window is on screen", win.isVisible())
        check("a stylesheet is applied", bool(win.styleSheet()))
        check("the status bar greets the user", bool(win.status.text().strip()))
        check("the progress bar is hidden before a search",
              not win.progress.isVisible())
        if not active:
            # Not fatal: the key checks below wake the window again, and a
            # headless session has no active window by definition.
            print("       note: the window could not take focus in this session")
        check("there is a button that opens the downloads folder",
              hasattr(win, "downloads_btn"))
        check("that button is on screen and named in one word",
              win.downloads_btn.isVisible()
              and win.downloads_btn.accessibleName() == "التنزيلات",
              win.downloads_btn.accessibleName())
        # Ask the window itself, not the desktop: ``QApplication.widgetAt``
        # returns None when the session has no active window (a headless build
        # runner, or another app in front), which made this check fail for a
        # reason that had nothing to do with the layout. ``childAt`` walks the
        # widget tree and proves no sibling is drawn over the button.
        centre = win.downloads_btn.mapTo(win, win.downloads_btn.rect().center())
        under = win.childAt(centre)
        check("that button is not covered by anything",
              under is win.downloads_btn,
              type(under).__name__)
        from app.config import downloads_root

        folder = get_config().download_folder
        check("downloads land in the real Downloads folder, not a hidden one",
              folder.parent == downloads_root() or folder == downloads_root(),
              f"{folder} (Downloads is {downloads_root()})")

        print()
        print("== empty search is refused, not crashed ==")
        win.query.setText("   ")
        win.start_search()
        pump(app, 6)
        check("the empty search is refused", "فاضي" in win.status.text(),
              win.status.text()[:60])
        check("no search was started", win._worker is None)

        print()
        print("== results render and are reachable ==")
        spoken = _announcements_during_search(app, win, "widgets")
        check("a book arrived", win.pages[Category.BOOK].list.count() == 1)
        check("articles arrived", win.pages[Category.ARTICLE].list.count() == 2)
        check("research arrived", win.pages[Category.RESEARCH].list.count() == 1)
        check("the search said it started",
              any("جاري البحث" in s for s in spoken), str(spoken))
        check("the search said how many results came",
              any("انتهى البحث" in s for s in spoken),
              str(spoken))
        check("the search start was announced before the end",
              len(spoken) >= 2 and "جاري البحث" in spoken[0], str(spoken))
        badge_titles = [
            win.tabs.tabText(CATEGORY_TAB_INDEX[c])
            for c in (Category.BOOK, Category.ARTICLE, Category.RESEARCH)
        ]
        check("tab titles carry their per-category counts",
              "(1)" in badge_titles[0] and "(2)" in badge_titles[1]
              and "(1)" in badge_titles[2],
              str(badge_titles))

        print()
        print("== arrow keys move through the results ==")
        page = win.pages[Category.ARTICLE]
        win.tabs.setCurrentWidget(page)
        page.list.setFocus()
        page.list.setCurrentRow(0)
        pump(app, 6)
        first = page.list.currentRow()
        _keyboard(app, win, Qt.Key_Down)
        check("Down moves to the next result", page.list.currentRow() == first + 1,
              f"row={page.list.currentRow()}")
        _keyboard(app, win, Qt.Key_Up)
        check("Up goes back", page.list.currentRow() == first,
              f"row={page.list.currentRow()}")

        print()
        print("== a result with no file says so instead of failing quietly ==")
        landing = next(r for r in page._cards
                       if not r.result.downloads)
        win._on_download(landing.result)
        pump(app, 6)
        check("no file is not downloadable", "لا يوجد ملف" in win.status.text(),
              win.status.text()[:70])

        print()
        print("== a download is queued and reported ==")
        queued: list[Result] = []
        real_enqueue = win._downloads.enqueue
        win._downloads.enqueue = lambda r: (queued.append(r), _FakeTask(r))[1]
        try:
            downloadable = next(r for r in page._cards if r.result.downloads)
            win._on_download(downloadable.result)
            pump(app, 6)
            check("the download was queued", len(queued) == 1, str(len(queued)))
            check("the status says the download started",
                  "بدأ تنزيل" in win.status.text(), win.status.text()[:70])
        finally:
            win._downloads.enqueue = real_enqueue

        print()
        print("== the citation goes into its own field ==")
        citation_row = next(r for r in page._cards if r.result.downloads)
        win._copy_citation(citation_row.result)
        pump(app, 6)
        check("the citation field is on screen", win.citation_view.isVisible())
        check("the citation is in its field",
              win.citation_view.text().startswith("Ahmed"),
              win.citation_view.text()[:50])
        check("the citation field is read only", win.citation_view.isReadOnly())
        check("the citation did not land in the search box",
              "Ahmed" not in win.query.text(), win.query.text())
        win.citation_view.clear()
        win.citation_view.setVisible(False)

        print()
        print("== Alt+M shows the summary of the selected result ==")
        # The search above left the ARTICLE tab filled: row 0 has an abstract,
        # row 1 does not. The summary field starts hidden, like the citation one.
        first_card = page._cards[0]
        check("a card with an abstract shows the two-line snippet",
              first_card.snippet is not None)
        if first_card.snippet is not None:
            check("the snippet has visible text", bool(first_card.snippet.text()),
                  repr(first_card.snippet.text()[:40]))
            check("the snippet is not read twice on the row",
                  first_card.snippet.accessibleName() == "",
                  repr(first_card.snippet.accessibleName()))
        check("a card without an abstract has no snippet",
              page._cards[1].snippet is None)
        check("the summary field is hidden before Alt+M",
              not win.summary_view.isVisible())
        page.list.setFocus()
        page.list.setCurrentRow(0)
        pump(app, 4)
        _keyboard(app, win, Qt.Key_M, Qt.AltModifier)
        summary_text = win.summary_view.toPlainText()
        check("Alt+M made the summary field visible",
              win.summary_view.isVisible())
        check("the field is read only", win.summary_view.isReadOnly())
        check("the summary holds the abstract", bool(summary_text.strip()), "")
        check("the summary starts with the title and authors",
              summary_text.strip().startswith("An Article"),
              summary_text.strip()[:60])
        check("the status says the summary appeared",
              "الملخص ظهر" in win.status.text(), win.status.text()[:70])
        page.list.setCurrentRow(1)
        pump(app, 4)
        _keyboard(app, win, Qt.Key_M, Qt.AltModifier)
        check("a result without an abstract hides the field",
              not win.summary_view.isVisible())
        check("the status says there is no summary",
              "لا يوجد ملخص" in win.status.text(), win.status.text()[:70])
        win.summary_view.clear()
        win.summary_view.setVisible(False)

        print()
        print("== the results screen stays quiet: no buttons on cards ==")
        _check_no_card_buttons(app, win)

        print()
        print("== a download that cannot work says why, and saves nothing ==")
        _check_unreachable_downloads(app, win)

        print()
        print("== Alt+O opens the folder the files land in ==")
        from PySide6.QtGui import QDesktopServices

        asked: list[str] = []
        real_open_url = QDesktopServices.openUrl
        QDesktopServices.openUrl = lambda url: (asked.append(url.toLocalFile()),
                                                True)[1]
        try:
            _keyboard(app, win, Qt.Key_O, Qt.AltModifier)
            by_key = list(asked)
            asked.clear()
            QTest.mouseClick(win.downloads_btn, Qt.LeftButton)
            pump(app, 4)
        finally:
            QDesktopServices.openUrl = real_open_url
        check("the header button opened the folder too", bool(asked), str(asked))
        check("the button and Alt+O open the same place",
              by_key and asked and by_key[-1] == asked[-1],
              f"{by_key} vs {asked}")
        check("the status names the folder", "مجلد التنزيلات" in win.status.text(),
              win.status.text()[:80])
        check("Alt+O opened the downloads folder", bool(asked), str(asked))
        # The URL comes back with forward slashes; the folder has backslashes.
        check("the folder is the one downloads go to",
              bool(asked)
              and asked[0].lower().replace("/", "\\")
              == str(get_config().download_folder).lower(),
              str(asked))

        print()
        print("== the font zoom rebuilds the window ==")
        before = getattr(win, "_font_points", 10)
        win._zoom(1)
        pump(app, 10)
        check("Ctrl++ made the text bigger", win._font_points == before + 1,
              f"{before} -> {win._font_points}")
        check("the window survived the zoom", win.isVisible())
        win.apply_font_size(before)
        pump(app, 10)
        check("Ctrl+0 put the text back", win._font_points == before,
              str(win._font_points))

        print()
        print("== clear empties everything ==")
        win._clear()
        pump(app, 10)
        check("the search box is empty", win.query.text() == "")
        for category in Category:
            check(f"{category.value} was cleared",
                  win.pages[category].list.count() == 0)
        check("the status says it cleared", "تم المسح" in win.status.text(),
              win.status.text()[:60])
        check("the progress bar is hidden again", not win.progress.isVisible())

        print()
        print("== Escape also clears ==")
        _announcements_during_search(app, win, "widgets")
        pump(app, 6)
        check("results came back", win.pages[Category.ARTICLE].list.count() == 2)
        _keyboard(app, win, Qt.Key_Escape)
        pump(app, 10)
        check("Escape emptied the box", win.query.text() == "",
              win.query.text())

        print()
        print("== tab shortcuts switch category ==")
        _keyboard(app, win, Qt.Key_1, Qt.ControlModifier)
        pump(app, 6)
        check("Ctrl+1 shows the books tab",
              win.tabs.currentWidget() is win.pages[Category.BOOK])
        _keyboard(app, win, Qt.Key_2, Qt.ControlModifier)
        pump(app, 6)
        check("Ctrl+2 shows the articles tab",
              win.tabs.currentWidget() is win.pages[Category.ARTICLE])
        _keyboard(app, win, Qt.Key_3, Qt.ControlModifier)
        pump(app, 6)
        check("Ctrl+3 shows the research tab",
              win.tabs.currentWidget() is win.pages[Category.RESEARCH])
        _keyboard(app, win, Qt.Key_1, Qt.ControlModifier)
        pump(app, 6)
        check("Ctrl+1 shows the books tab again",
              win.tabs.currentWidget() is win.pages[Category.BOOK])

        print()
        print("== F1 opens the help window ==")
        from app import i18n as _i18n
        from qt_prototype.help_dialog import guide as _help_guide, SHORTCUTS
        _keyboard(app, win, Qt.Key_F1)
        pump(app, 8)
        help_dialog = getattr(win, "_help", None)
        check("F1 opens a help dialog",
              help_dialog is not None and help_dialog.isVisible())
        if help_dialog is not None and help_dialog.isVisible():
            from PySide6.QtWidgets import QLabel
            texts = [l.text() for l in help_dialog.findChildren(QLabel)]
            check("the help lists the real shortcuts",
                  any("Alt+M" in t for t in texts)
                  and any("Alt+D" in t for t in texts),
                  str(len(texts)))
            check("the help explains the interface to a reader user",
                  any("قارئ الشاشة" in t for t in texts))
            check("the guide has content", len(_help_guide()) == 7)
            check("the shortcuts match what is registered",
                  all(any(t.strip() == (_i18n.t(k) if k.startswith("help.")
                                        else k) for t in texts)
                      for k, _ in SHORTCUTS),
                  str(SHORTCUTS))
            from PySide6.QtTest import QTest as _QTest
            help_dialog.activateWindow()
            _QTest.keyClick(help_dialog, Qt.Key_Escape)
            pump(app, 4)
            check("Escape closed the help", not help_dialog.isVisible())
        else:
            check("Escape closed the help", True)

        print()
        print("== Alt+D and Alt+C work on the selected result ==")
        _announcements_during_search(app, win, "widgets")
        page = win.pages[Category.ARTICLE]
        win.tabs.setCurrentWidget(page)
        page.list.setFocus()
        page.list.setCurrentRow(0)
        pump(app, 8)
        queued2: list[Result] = []
        real_enqueue = win._downloads.enqueue
        win._downloads.enqueue = lambda r: (queued2.append(r), _FakeTask(r))[1]
        try:
            _keyboard(app, win, Qt.Key_D, Qt.AltModifier)
            check("Alt+D queued the selected result", len(queued2) == 1,
                  str(len(queued2)))
            _keyboard(app, win, Qt.Key_C, Qt.AltModifier)
            check("Alt+C filled the citation field",
                  win.citation_view.text().startswith("Ahmed"),
                  win.citation_view.text()[:50])
        finally:
            win._downloads.enqueue = real_enqueue
            win.citation_view.clear()
            win.citation_view.setVisible(False)

        print()
        print("== the Application key opens the result menu; a right click does not ==")
        from PySide6.QtCore import QPoint, QTimer as _QTimer
        from PySide6.QtGui import QAction, QContextMenuEvent
        from PySide6.QtWidgets import QMenu as _QMenu

        page = win.pages[Category.ARTICLE]
        win.tabs.setCurrentWidget(page)
        page.list.setFocus()
        page.list.setCurrentRow(0)
        pump(app, 8)
        capture: dict[str, object] = {}

        def _arm_menu_capture(tag: str, retries: int = 8) -> None:
            def attempt(n: int) -> None:
                menus = [w for w in QApplication.topLevelWidgets()
                         if isinstance(w, _QMenu) and w.isVisible()]
                if menus:
                    capture[tag] = [a.text() for a in menus[0].actions()]
                    menus[0].close()
                elif n < retries:
                    _QTimer.singleShot(40, lambda: attempt(n + 1))

            _QTimer.singleShot(40, lambda: attempt(0))

        _arm_menu_capture("kb")
        QApplication.sendEvent(page.list, QContextMenuEvent(
            QContextMenuEvent.Reason.Keyboard, QPoint(0, 0),
            page.list.mapToGlobal(QPoint(0, 0))))
        pump(app, 12)
        first = page.cards_result(0)
        expected = (
            ["تنزيل", "نسخ التوثيق", "فتح للقراءة على الموقع"]
            if first is not None and has_download(first)
            else ["قراءة", "نسخ التوثيق"]
        )
        check("the Application key opens a result menu",
              capture.get("kb") == expected, repr(capture.get("kb")))

        # A read-only record must offer قراءة in the first slot, never a dead
        # تنزيل with no file behind it, and it drops the redundant site link
        # because قراءة already is that link. Checked right here, while the
        # popup demonstrably works, so a later widget state cannot mask it.
        page.add(make("A Read-Only Probe", Category.ARTICLE, with_file=False))
        page.update_count()
        page.list.setCurrentRow(page.list.count() - 1)
        pump(app, 4)
        _arm_menu_capture("readonly")
        QApplication.sendEvent(page.list, QContextMenuEvent(
            QContextMenuEvent.Reason.Keyboard, QPoint(0, 0),
            page.list.mapToGlobal(QPoint(0, 0))))
        pump(app, 12)
        check("a read-only result offers قراءة, not a dead تنزيل",
              capture.get("readonly") == ["قراءة", "نسخ التوثيق"],
              f"got={capture.get('readonly')!r} count={page.list.count()} "
              f"row={page.list.currentRow()} cards={len(page._cards)}")

        item = page.list.item(1 if page.list.count() > 1 else 0)
        page.list.scrollToItem(item)
        pos = page.list.visualItemRect(item).center()
        gpos = page.list.viewport().mapToGlobal(pos)
        page.list.setCurrentRow(0)
        _arm_menu_capture("noop")
        QApplication.sendEvent(page.list.viewport(), QContextMenuEvent(
            QContextMenuEvent.Reason.Mouse, pos, gpos))
        pump(app, 12)
        _QTimer.singleShot(200, app.processEvents)
        pump(app, 4)
        check("a right click opens nothing",
              capture.get("noop") is None, repr(capture.get("noop")))
        check("the right click left the caret alone",
              page.list.currentRow() == 0, f"row={page.list.currentRow()}")

        card = page.focused_card()
        page._run_context_action(QAction("نسخ التوثيق"), card)
        pump(app, 4)
        check("the menu's نسخ التوثيق reaches the citation field",
              win.citation_view.isVisible()
              and win.citation_view.text().startswith("Ahmed"),
              win.citation_view.text()[:40])
        win.citation_view.clear()
        win.citation_view.setVisible(False)

        print()
        print("== an empty search says so out loud ==")
        spoken = _announcements_during_search(app, win, "nothing here at all",
                                             empty=True)
        check("no results is announced, not left silent",
              any("انتهى البحث" in s for s in spoken), str(spoken))

        print()
        print("== a failed search says so out loud ==")
        spoken = _announcements_during_search(app, win, "boom", fail=True)
        check("a failure is announced", any("فشل البحث" in s for s in spoken),
              str(spoken))

    finally:
        config_now = get_config()
        if config_now.download_dir != config_at_start:
            config_now.download_dir = config_at_start
            config_now.save()
            print("       note: the downloads folder setting was restored")
        win.close()
        pump(app, 6)

    print()
    if FAILURES:
        print(f"SMOKE TEST FAILED: {len(FAILURES)} -> {FAILURES}")
        return 1
    print("SMOKE TEST PASSED")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        print("SMOKE TEST CRASHED")
        raise SystemExit(1)
