"""Application configuration.

Settings are resolved in this order (later wins):

1. Built-in defaults (this module).
2. ``config.json`` next to the executable / project root.
3. Environment variables (``ACADSEARCH_*``).

This lets the packaged ``.exe`` run with zero configuration while still
allowing an end user (or a university IT department) to drop in API keys.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

APP_NAME = "AcadSearch"
APP_ID = "acadsearch"
# One version, three places: this string, ``version_info.txt`` (the Windows file
# properties) and ``AppVersion`` in ``installer/Acadsearch.iss``. They drifted
# apart -- the shipped file said 2.0.0 while the app and its User-Agent header
# said 1.0.0 -- so every bug report and every server log carried a different
# number than the file the user downloaded. ``tools/check_version.py`` fails the
# build if they ever disagree again.
APP_VERSION = "2.0.10"
APP_TITLE_AR = "أكاد سِرتش — محرك البحث الأكاديمي"
APP_TITLE_EN = "AcadSearch — Academic Search Engine"

# Providers that can be toggled off by the user.
ALL_PROVIDER_IDS = (
    "open_library",
    "google_books",
    "internet_archive",
    "hal",
    "semantic_scholar",
    "openalex",
    "crossref",
    "arxiv",
    "openaire",
    "sudoc",
    "europe_pmc",
    "doaj",
    "core",
    "datacite",
    "zenodo",
    "base",
    "pubmed",
    "lens",
    "scilit",
    "scinapse",
    "springer",
    "openedition",
    "thesesfr",
    "dumas",
    "persee",
    "erudit",
    "mirabel",
    "hindawi",
    "noorbook",
    "asjp",
    "wikisource",
)

#: Ids shipped before ``known_providers`` existed. A config written by an older
#: build predates these, which is how an update tells its new providers apart
#: from the ones a user deliberately switched off.
LEGACY_PROVIDER_IDS = (
    "open_library",
    "google_books",
    "semantic_scholar",
    "openalex",
    "crossref",
    "arxiv",
    "openaire",
)


def app_dir() -> Path:
    """Directory that holds ``config.json``, the cache and the download folder.

    When frozen by PyInstaller the executable lives in ``dist/`` and we do not
    want to pollute it, so we use a per-user data directory instead.
    """
    if getattr(sys, "frozen", False):
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return Path(base) / "AcadSearch"
    return Path(__file__).resolve().parent.parent


def downloads_root() -> Path:
    r"""The user's Downloads folder, wherever Windows actually keeps it.

    Reading the shell-folder registry key is what makes this survive OneDrive
    and any "move my Documents to X" setting, both of which leave an empty
    ``C:\Users\<name>\Downloads`` behind.
    """
    if os.name == "nt":
        try:
            import winreg

            key_path = (r"Software\Microsoft\Windows\CurrentVersion"
                        r"\Explorer\Shell Folders")
            downloads_id = "{374DE290-123F-4565-9164-39C4925E467B}"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path) as key:
                raw, _ = winreg.QueryValueEx(key, downloads_id)
            path = Path(os.path.expandvars(raw))
            if path.is_dir():
                return path
        except (OSError, ImportError, ValueError):
            pass
    return Path.home() / "Downloads"


def migrate_legacy_downloads(config: "Config | None" = None) -> int:
    """Move files from the old hidden folder into the new one. Returns the count.

    Only runs when the new folder is still empty, so it can never overwrite or
    mix up files that are already where the user expects them.
    """
    import shutil

    config = config or get_config()
    try:
        new_folder = config.download_folder
    except OSError:
        return 0
    old_folder = app_dir() / "downloads"
    if old_folder == new_folder or not old_folder.is_dir():
        return 0
    try:
        if any(new_folder.iterdir()) or not any(old_folder.iterdir()):
            return 0
    except OSError:
        return 0

    moved = 0
    for item in list(old_folder.iterdir()):
        try:
            shutil.move(str(item), str(new_folder / item.name))
            moved += 1
        except (OSError, shutil.Error):
            pass
    return moved


def resource_dir() -> Path:
    """Read-only directory that contains bundled assets (PyInstaller ``_MEIPASS``)."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", app_dir()))
    return app_dir()


def _read_config_file() -> dict[str, Any]:
    for candidate in (app_dir() / "config.json", Path.cwd() / "config.json"):
        try:
            if candidate.is_file():
                # utf-8-sig also reads a plain UTF-8 file; it only strips a BOM.
                # Without it, a config.json saved by PowerShell/Out-File (which
                # adds a BOM) failed to parse, and the app silently fell back to
                # defaults -- the saved Gemini key looked lost.
                data = json.loads(candidate.read_text(encoding="utf-8-sig"))
                if isinstance(data, dict):
                    return data
        except (OSError, json.JSONDecodeError):
            # A malformed config must never prevent the app from starting.
            continue
    return {}


def _env(name: str, default: str = "") -> str:
    return os.environ.get(f"ACADSEARCH_{name}", default).strip()


def _bundled_keys() -> dict[str, str]:
    """API keys baked into this build by the distributor.

    ``app/private_keys.py`` is kept empty and secret-free in the repository;
    a distributor edits it before ``build_exe.bat`` so the resulting exe works
    with the keyed sources on machines that never open Preferences. A missing
    or broken module is a normal install, not an error.

    Precedence (highest wins): env var > user config file > these defaults.
    """
    try:
        from app.private_keys import BUNDLED_KEYS

        return {
            key: value.strip()
            for key, value in (BUNDLED_KEYS or {}).items()
            if isinstance(value, str) and value.strip()
        }
    except Exception:  # noqa: BLE001 - no bundled keys is a valid configuration
        return {}


@dataclass
class Config:
    """Runtime settings."""

    # --- Network -------------------------------------------------------
    timeout: float = 25.0
    max_retries: int = 3
    backoff_base: float = 1.2
    user_agent: str = (
        f"{APP_NAME}/{APP_VERSION} (academic metadata client; "
        "+https://github.com/academic-search/desktop)"
    )
    # Contact address unlocks the OpenAlex "polite pool" (10x rate limit).
    contact_email: str = ""

    # --- Optional API keys (raise rate limits / unlock extra fields) ---
    google_books_key: str = ""
    semantic_scholar_key: str = ""
    openalex_key: str = ""
    core_key: str = ""
    base_key: str = ""
    pubmed_key: str = ""
    lens_key: str = ""
    scilit_key: str = ""
    scinapse_key: str = ""
    springer_key: str = ""
    #: Google AI Studio key for the local-file assistant (summary / questions).
    gemini_key: str = ""
    #: Model that reads the document. 2.5-flash was the shipped default until
    #: Google retired it for new accounts (October 2026); the old value is
    #: upgraded in __post_init__ so an existing config.json keeps working.
    gemini_model: str = "gemini-3.5-flash"

    # --- Search behaviour ---------------------------------------------
    # 10 per source looked like a finished answer but it is a hard truncation:
    # arXiv alone holds >100k papers for "machine learning", so we were showing
    # 1% of what exists and the user could not tell the difference between
    # "there is nothing more" and "we stopped asking". Measured on
    # "machine learning": 10 -> 117 results, 40 -> 287, in ~3s.
    results_per_source: int = 40
    max_results_per_tab: int = 150
    cache_ttl_seconds: int = 60 * 60 * 12
    use_cache: bool = True
    #: How long one search waits for its slowest source before giving up on it.
    #: Measured: eleven sources answer "machine learning" in 2-8s uncached,
    #: while OpenAIRE intermittently stalls on the server and burns the full
    #: retry budget -- ``timeout`` x ``max_retries`` plus back-off, ~80s -- during
    #: which the user watches a search that already holds 148 results on screen
    #: refuse to finish. Past this deadline the straggler is reported as a
    #: timeout chip, its results are dropped and its worker is released; the rest
    #: of the search is kept. Raise it in ``config.json`` as ``searchDeadline``
    #: on a slow or throttled connection.
    search_deadline: float = 30.0

    # --- Search filters (remembered between sessions) --------------------
    #: ``"any"`` or an ISO-639-1 code from ``app.models.LANGUAGES``. The point is
    #: not to hide foreign results by default -- "any" stays the default so a
    #: search is never mysteriously empty -- but to let a reader who wants
    #: French theses, or Arabic only, say so once and keep it.
    search_language: str = "any"
    year_from: int | None = None
    year_to: int | None = None
    #: Filter by availability after results arrive. Values: ``any`` | ``download`` | ``read`` | ``download_or_read``.
    availability_filter: str = "any"

    # --- Providers -----------------------------------------------------
    enabled_providers: set[str] = field(default_factory=lambda: set(ALL_PROVIDER_IDS))
    #: Ids that already existed when this config was written; used to tell a
    #: provider the user disabled apart from one added by an app update.
    known_providers: set[str] = field(default_factory=lambda: set(ALL_PROVIDER_IDS))

    # --- UI ------------------------------------------------------------
    ui_language: str = "ar"          # "ar" | "en"
    theme: str = "system"            # "system" | "dark" | "light"
    citation_style: str = "apa"      # key into app.core.citation.STYLES
    results_per_page: int = 20
    font_family: str = ""            # empty -> platform default
    font_scale: float = 1.0
    abstract_chars: int = 320
    #: Play the program's own short cues (search start/end, result menu).
    #: Independent from the OS sound scheme on purpose.
    sound_enabled: bool = True

    # --- Downloads -----------------------------------------------------
    download_dir: str = ""           # empty -> <app_dir>/downloads
    max_download_mb: int = 200
    confirm_open_browser: bool = False

    def __post_init__(self) -> None:
        # Bundled keys are the lowest-precedence base: the user's own config
        # file and env vars may both replace them.
        for _key, _value in _bundled_keys().items():
            if _key in {
                "google_books_key", "semantic_scholar_key", "openalex_key",
                "core_key", "base_key", "pubmed_key", "lens_key",
                "scilit_key", "scinapse_key", "springer_key", "gemini_key",
            }:
                setattr(self, _key, _value)
        data = _read_config_file()
        known = {f for f in self.__dataclass_fields__}  # type: ignore[attr-defined]
        for key, value in data.items():
            snake = _camel_to_snake(key)
            if snake in known:
                setattr(self, snake, value)

        # Env vars win over the file so CI / scripts stay reproducible. This runs
        # even when no config.json exists, which is exactly the fresh-install
        # case where an ACADSEARCH_* key is the only way to configure one.
        self.contact_email = _env("CONTACT_EMAIL", self.contact_email)
        self.google_books_key = _env("GOOGLE_BOOKS_KEY", self.google_books_key)
        self.semantic_scholar_key = _env("S2_KEY", self.semantic_scholar_key)
        self.openalex_key = _env("OPENALEX_KEY", self.openalex_key)
        self.core_key = _env("CORE_KEY", self.core_key)
        self.base_key = _env("BASE_KEY", self.base_key)
        self.pubmed_key = _env("PUBMED_KEY", self.pubmed_key)
        self.lens_key = _env("LENS_KEY", self.lens_key)
        self.scilit_key = _env("SCILIT_KEY", self.scilit_key)
        self.scinapse_key = _env("SCINAPSE_KEY", self.scinapse_key)
        self.springer_key = _env("SPRINGER_KEY", self.springer_key)
        self.gemini_key = _env("GEMINI_KEY", self.gemini_key)

        # A config written before the coverage fix still carries 10/60, which
        # were never a deliberate choice by the user -- they were the shipped
        # defaults. Truncating a 100k-result database to 10 rows made the app
        # look complete when it was not, so those two exact legacy values are
        # upgraded. Any other value is treated as the user's own decision and
        # left alone.
        if self.results_per_source == 10:
            self.results_per_source = 40
        if self.max_results_per_tab == 60:
            self.max_results_per_tab = 150

        # 2.5-flash was the shipped Gemini model until Google retired it for
        # new accounts. A config written by an older build still carries it, so
        # the exact old defaults are upgraded instead of sending every reader
        # into a 404. A model the user chose themselves is left alone.
        retired_models = {"gemini-2.5-flash", "gemini-2.0-flash",
                          "gemini-1.5-flash"}
        if (not isinstance(self.gemini_model, str)
                or not self.gemini_model.strip()
                or self.gemini_model.strip() in retired_models):
            self.gemini_model = "gemini-3.5-flash"

        if not isinstance(self.enabled_providers, set):
            self.enabled_providers = set(self.enabled_providers or ALL_PROVIDER_IDS)
        self.enabled_providers = {
            p for p in self.enabled_providers if p in ALL_PROVIDER_IDS
        } or set(ALL_PROVIDER_IDS)

        # Enable providers added by an app update, but only the ones the user
        # has never seen. ``known_providers`` records which ids already existed
        # when this config was written, so a provider the user switched off
        # stays off instead of being re-enabled on every launch.
        if "known_providers" in data:
            seen = {p for p in (self.known_providers or ()) if p in ALL_PROVIDER_IDS}
        else:
            # Older build: it could only have known the legacy ids.
            seen = set(LEGACY_PROVIDER_IDS)
        fresh = [p for p in ALL_PROVIDER_IDS if p not in seen]
        if fresh:
            self.enabled_providers |= set(fresh)
        self.known_providers = set(ALL_PROVIDER_IDS)
        # Remember that this file predates the current source list so startup
        # can write the migrated config back once. Without it the app searches
        # 29 sources while config.json still lists 21, and the next launch has
        # to migrate again.
        self._migrated_providers = bool(fresh) or "known_providers" not in data

        if self.ui_language not in ("ar", "en"):
            self.ui_language = "ar"
        if self.theme not in ("system", "dark", "light"):
            self.theme = "system"
        if not isinstance(self.sound_enabled, bool):
            self.sound_enabled = True
        # Imported lazily: app.core.citation pulls in app.models and app.i18n.
        from app.core.citation import STYLES

        if self.citation_style not in STYLES:
            self.citation_style = "apa"

        # A hand-edited or older config can carry nonsense here, and a bad
        # language code would silently filter every provider down to nothing.
        from app.models import LANGUAGES

        valid_languages = {code for code, _, _ in LANGUAGES}
        if self.search_language not in valid_languages:
            self.search_language = "any"
        if not isinstance(self.year_from, int) or not 1000 <= self.year_from <= 2100:
            self.year_from = None
        if not isinstance(self.year_to, int) or not 1000 <= self.year_to <= 2100:
            self.year_to = None
        # A config.json that carries "searchDeadline": "soon" must not turn into
        # a TypeError inside the coordinator thread, which would kill the search
        # with no message at all.
        if not isinstance(self.search_deadline, (int, float)) or self.search_deadline <= 0:
            self.search_deadline = 30.0
        if (
            self.year_from
            and self.year_to
            and self.year_from > self.year_to
        ):
            # Swapped bounds are a slip, not a request for an empty result set.
            self.year_from, self.year_to = self.year_to, self.year_from

    # -- helpers ---------------------------------------------------------
    @property
    def year_range(self) -> tuple[int | None, int | None]:
        return self.year_from, self.year_to
    def is_enabled(self, provider_id: str) -> bool:
        return provider_id in self.enabled_providers

    @property
    def download_folder(self) -> Path:
        r"""Where finished files land.

        The default is the user's own Downloads folder, in an ``AcadSearch``
        sub-folder. It used to be ``%LOCALAPPDATA%\AcadSearch\downloads``,
        which is a hidden system folder: the files were there, and nobody could
        find them, so a download that worked looked like a download that did
        nothing.
        """
        if self.download_dir:
            path = Path(os.path.expandvars(self.download_dir)).expanduser()
        else:
            path = downloads_root() / APP_NAME
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def cache_folder(self) -> Path:
        path = app_dir() / "cache"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def save(self) -> None:
        """Persist user-facing preferences back to ``config.json``."""
        data = {
            k: v
            for k, v in self.__dict__.items()
            if not k.endswith("_key") and not k.startswith("_")
        }
        if self.google_books_key:
            data["googleBooksKey"] = self.google_books_key
        if self.semantic_scholar_key:
            data["semanticScholarKey"] = self.semantic_scholar_key
        if self.openalex_key:
            data["openalexKey"] = self.openalex_key
        if self.core_key:
            data["coreKey"] = self.core_key
        if self.base_key:
            data["baseKey"] = self.base_key
        if self.pubmed_key:
            data["pubmedKey"] = self.pubmed_key
        if self.lens_key:
            data["lensKey"] = self.lens_key
        if self.scilit_key:
            data["scilitKey"] = self.scilit_key
        if self.scinapse_key:
            data["scinapseKey"] = self.scinapse_key
        if self.springer_key:
            data["springerKey"] = self.springer_key
        if self.gemini_key:
            data["geminiKey"] = self.gemini_key
        target = app_dir() / "config.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(data, indent=2, ensure_ascii=False, default=list),
            encoding="utf-8",
        )


def _camel_to_snake(name: str) -> str:
    out: list[str] = []
    for ch in name:
        if ch.isupper():
            out.append("_")
            out.append(ch.lower())
        else:
            out.append(ch)
    return "".join(out)


_config: Config | None = None


def get_config() -> Config:
    """Return the process-wide singleton config."""
    global _config
    if _config is None:
        _config = Config()
    return _config
