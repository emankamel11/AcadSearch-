"""Inspect the packaged EXE through UI Automation.

Point: check the frozen build, not the source tree. A frozen app can come up
unstyled, missing its providers, or with a settings button that throws, and none
of that shows when running from source.

comtypes has to generate the UIA typelib before it can be imported, hence
GetModule first and the generated modules after.
"""

import time

import comtypes.client as cc

uia_client = cc.GetModule("UIAutomationClient.dll")
uia_core = cc.GetModule("UIAutomationCore.dll")

from comtypes.gen import UIAutomationClient as _u  # noqa: E402
from comtypes.gen import UIAutomationCore as _c  # noqa: E402

CONTROL_NAMES = {
    50000: "Button",
    50001: "Calendar",
    50002: "CheckBox",
    50003: "ComboBox",
    50004: "Edit",
    50005: "Hyperlink",
    50006: "Image",
    50007: "ListItem",
    50008: "Menu",
    50009: "MenuBar",
    50010: "MenuItem",
    50011: "ProgressBar",
    50012: "RadioButton",
    50013: "ScrollBar",
    50014: "Slider",
    50015: "SpinButton",
    50016: "StatusBar",
    50017: "Tab",
    50018: "TabItem",
    50019: "Text",
    50020: "ToolBar",
    50021: "ToolTip",
    50022: "Tree",
    50023: "TreeItem",
    50024: "Custom",
    50025: "Group",
    50026: "Thumb",
    50027: "DataGrid",
    50028: "DataItem",
    50029: "Document",
    50030: "SplitButton",
    50031: "Window",
    50032: "Pane",
    50033: "Header",
    50034: "HeaderItem",
    50035: "Table",
    50036: "TitleBar",
}


def label(value):
    return CONTROL_NAMES.get(value, str(value))


def make():
    return cc.CoCreateInstance(
        _u.CUIAutomation8._reg_clsid_, interface=_c.IUIAutomation
    )


def find_window(automation, needle_a, needle_b):
    root = automation.GetRootElement()
    walker = _c.TreeWalker_ControlViewWalker
    for _ in range(90):
        child = walker.GetFirstChildElement(root)
        while child is not None:
            try:
                name = child.CurrentName or ""
            except Exception:
                name = ""
            if needle_a in name or needle_b in name:
                return child
            child = walker.GetNextSiblingElement(child)
        time.sleep(1)
    return None


def walk(element, depth=0, limit=400):
    out = []
    if depth > 7 or len(out) >= limit:
        return out
    walker = _c.TreeWalker_ControlViewWalker
    child = walker.GetFirstChildElement(element)
    while child is not None and len(out) < limit:
        try:
            out.append(
                (
                    depth,
                    child.CurrentControlType,
                    child.CurrentName or "",
                    child.CurrentAutomationId or "",
                    child.CurrentIsOffscreen,
                )
            )
        except Exception:
            pass
        out.extend(walk(child, depth + 1, limit - len(out)))
        child = walker.GetNextSiblingElement(child)
    return out


automation = make()
window = find_window(automation, "أكاد", "AcadSearch")
if window is None:
    print("FAIL: AcadSearch window not found in the UIA tree")
    raise SystemExit(1)

print("window name :", repr(window.CurrentName))
print("class       :", window.CurrentClassName)
print("type        :", label(window.CurrentControlType))
print("offscreen   :", window.CurrentIsOffscreen)
print()

nodes = walk(window)
named = [n for n in nodes if n[2]]
print(f"== descendants {len(nodes)}, named {len(named)} ==")
for depth, ctype, name, aid, off in named:
    print(f"  {'  ' * depth}{label(ctype):12} {name!r}{'  [offscreen]' if off else ''}")

print()
buttons = [(label(t), n) for _, t, n, _, _ in nodes if label(t) == "Button" and n]
print(f"== buttons {len(buttons)} ==")
for _, n in buttons:
    print("   ", repr(n))

edits = [n for _, t, n, _, _ in nodes if label(t) == "Edit" and n]
print(f"== edit fields {len(edits)} ==")
for n in edits:
    print("   ", repr(n))

texts = [n for _, t, n, _, _ in nodes if label(t) == "Text" and n]
print(f"== text {len(texts)} ==")
for n in texts:
    print("   ", repr(n))

print()
has_settings = any("إعدادات" in n for _, n in buttons)
has_search_box = any("مربع البحث" in n for n in edits)
has_search_btn = any("زر البحث" in n for _, n in buttons)
print("settings button :", has_settings)
print("search box      :", has_search_box)
print("search button   :", has_search_btn)

ok = has_settings and has_search_box and has_search_btn
print()
print("OK" if ok else "MISSING KEY ELEMENTS")
raise SystemExit(0 if ok else 1)