"""Small text/normalisation helpers shared across providers."""

from __future__ import annotations

import html
import re
import unicodedata

_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")
_DOI_RE = re.compile(r"\b(10\.\d{4,9}/[-._;()/:A-Za-z0-9]+)\b")
_CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")

#: arXiv legacy category -> human readable subject.
ARXIV_ARCHIVES: dict[str, str] = {
    "astro-ph": "Astrophysics",
    "cond-mat": "Condensed Matter",
    "cs": "Computer Science",
    "econ": "Economics",
    "eess": "Electrical Engineering and Systems Science",
    "gr-qc": "General Relativity and Quantum Cosmology",
    "hep-ex": "High Energy Physics - Experiment",
    "hep-lat": "High Energy Physics - Lattice",
    "hep-ph": "High Energy Physics - Phenomenology",
    "hep-th": "High Energy Physics - Theory",
    "math": "Mathematics",
    "nlin": "Nonlinear Sciences",
    "nucl-ex": "Nuclear Experiment",
    "nucl-th": "Nuclear Theory",
    "physics": "Physics",
    "q-bio": "Quantitative Biology",
    "q-fin": "Quantitative Finance",
    "stat": "Statistics",
    "math-ph": "Mathematical Physics",
    "nlin.AO": "Adaptation and Self-Organizing Systems",
    "cs.LG": "Machine Learning",
    "cs.CL": "Computation and Language",
    "cs.CV": "Computer Vision",
    "cs.AI": "Artificial Intelligence",
    "cs.CR": "Cryptography and Security",
    "cs.DC": "Distributed Computing",
    "cs.RO": "Robotics",
    "cs.DB": "Databases",
    "cs.HC": "Human-Computer Interaction",
    "cs.SE": "Software Engineering",
    "q-bio.PE": "Populations and Evolution",
    "stat.ML": "Machine Learning",
    "eess.SP": "Signal Processing",
    "eess.IV": "Image and Video Processing",
}

#: ISO-639-1/3 -> native name (covers what our APIs actually return).
LANGUAGE_NAMES: dict[str, str] = {
    "ar": "العربية", "ara": "العربية", "eng": "English", "en": "English",
    "fre": "Français", "fra": "Français", "fr": "Français",
    "ger": "Deutsch", "deu": "Deutsch", "de": "Deutsch",
    "spa": "Español", "es": "Español", "ita": "Italiano", "it": "Italiano",
    "por": "Português", "pt": "Português", "rus": "Русский", "ru": "Русский",
    "chi": "中文", "zho": "中文", "zh": "中文", "jpn": "日本語", "ja": "日本語",
    "kor": "한국어", "ko": "한국어", "tur": "Türkçe", "tr": "Türkçe",
    "per": "فارسی", "fas": "فارسی", "fa": "فارسی", "urd": "اردو", "ur": "اردو",
    "heb": "עברית", "he": "עברית", "hin": "हिन्दी", "hi": "हिन्दी",
    "dut": "Nederlands", "nld": "Nederlands", "nl": "Nederlands",
    "pol": "Polski", "pl": "Polski", "swe": "Svenska", "sv": "Svenska",
    "ind": "Bahasa Indonesia", "id": "Bahasa Indonesia", "mul": "Multiple",
    "und": "غير محدّدة", "zxx": "لا لغة",
}

#: ISO-639-3 -> ISO-639-1, used to match the UI language filter.
LANG3_TO_LANG1: dict[str, str] = {
    "ara": "ar", "eng": "en", "fre": "fr", "fra": "fr", "ger": "de", "deu": "de",
    "spa": "es", "ita": "it", "por": "pt", "rus": "ru", "chi": "zh", "zho": "zh",
    "jpn": "ja", "kor": "ko", "tur": "tr", "per": "fa", "fas": "fa", "urd": "ur",
    "heb": "he", "hin": "hi", "dut": "nl", "nld": "nl", "pol": "pl", "swe": "sv",
    "ind": "id", "vie": "vi", "tha": "th", "ell": "el", "gre": "el", "ukr": "uk",
    "cze": "cs", "ces": "cs", "swe": "sv", "nor": "no", "dan": "da", "fin": "fi",
    "hun": "hu", "ron": "ro", "rum": "ro", "bul": "bg", "srp": "sr", "hrv": "hr",
    "cat": "ca", "eus": "eu", "gle": "ga", "lat": "la", "gle": "ga",
}


def clean_text(value: object, limit: int | None = None) -> str:
    """Strip markup/entities and collapse whitespace from an API field."""
    if value is None:
        return ""
    if not isinstance(value, str):
        value = str(value)
    text = html.unescape(value)
    text = _TAG_RE.sub(" ", text)
    text = _CONTROL_RE.sub("", text)
    text = text.replace("\u00ad", "")  # soft hyphens break Arabic shaping
    text = _WS_RE.sub(" ", text).strip()
    if limit and len(text) > limit:
        text = text[: limit - 1].rstrip() + "\u2026"
    return text


def normalise_language(code: object) -> str:
    """Map any provider language code to a canonical ISO-639-1 code."""
    if not code:
        return ""
    value = str(code).strip().lower()
    if not value or value in ("und", "zxx", "mul"):
        return ""
    if value in LANG3_TO_LANG1:
        return LANG3_TO_LANG1[value]
    if len(value) == 2:
        return value
    return value  # keep as-is; the UI falls back to the raw code


def language_display(code: str) -> str:
    if not code:
        return ""
    return LANGUAGE_NAMES.get(code.lower(), code.upper())


def extract_doi(value: object) -> str:
    """Pull a bare DOI out of a URL or free-text field."""
    if not value:
        return ""
    text = str(value)
    if text.lower().startswith("10."):
        match = _DOI_RE.search(text)
        return match.group(1).rstrip(".,;)") if match else ""
    match = _DOI_RE.search(text)
    return match.group(1).rstrip(".,;)") if match else ""


def arxiv_subject(entry_id: str) -> str:
    """``http://arxiv.org/abs/cs.LG/2301.00001v2`` -> ``Computer Science``."""
    if not entry_id or "arxiv.org" not in entry_id:
        return ""
    path = entry_id.split("arxiv.org", 1)[-1].lstrip("/abs/").lstrip("/")
    parts = path.split("/")
    if not parts:
        return ""
    code = parts[0]
    if code in ARXIV_ARCHIVES:
        return ARXIV_ARCHIVES[code]
    if "." in code:
        top = code.split(".")[0]
        return ARXIV_ARCHIVES.get(top, code)
    return ARXIV_ARCHIVES.get(code, code)


def arxiv_id(entry_id: str) -> str:
    if not entry_id:
        return ""
    tail = entry_id.split("arxiv.org", 1)[-1].lstrip("/abs/").lstrip("/")
    return tail.split("v")[0] if "v" in tail else tail


def truncate_words(text: str, limit: int = 300) -> str:
    """Truncate on a word boundary so abstracts do not end mid-word."""
    text = clean_text(text)
    if len(text) <= limit:
        return text
    cut = text[:limit]
    space = cut.rfind(" ")
    if space > limit * 0.6:
        cut = cut[:space]
    return cut.rstrip() + "\u2026"


def has_arabic(text: str) -> bool:
    return any("\u0600" <= ch <= "\u06ff" for ch in text)


def detect_script_languages(*values: object) -> str:
    """Very small script-based language guess for APIs that omit the field."""
    blob = " ".join(str(v) for v in values if v)
    if has_arabic(blob):
        return "ar"
    if any("\u4e00" <= ch <= "\u9fff" for ch in blob):
        return "zh"
    if any("\u3040" <= ch <= "\u30ff" for ch in blob):
        return "ja"
    if any("\uac00" <= ch <= "\ud7af" for ch in blob):
        return "ko"
    if any("\u0400" <= ch <= "\u04ff" for ch in blob):
        return "ru"
    return ""


def fold(value: str) -> str:
    """Case/accent-insensitive key for de-duplication."""
    normalised = unicodedata.normalize("NFKD", value or "")
    stripped = "".join(c for c in normalised if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9\u0600-\u06ff]+", " ", stripped.lower()).strip()


def first(values: object) -> str:
    if isinstance(values, (list, tuple)):
        for item in values:
            if item:
                return str(item)
        return ""
    return clean_text(values) if values else ""


def as_int(value: object) -> int | None:
    try:
        if value in (None, "", []):
            return None
        number = int(float(str(value).strip()))
        return number if number > 0 else None
    except (TypeError, ValueError):
        return None


def as_float(value: object) -> float | None:
    try:
        if value in (None, ""):
            return None
        number = float(value)
        return round(number, 2) if 0 <= number <= 5 else None
    except (TypeError, ValueError):
        return None
