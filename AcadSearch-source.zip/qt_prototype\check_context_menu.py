"""Check the per-result menu behaves like a plain Windows menu.

The Application key opens the menu on the row the caret stands on; the arrow
keys then move inside the open popup like in any menu; a right click is a
no-op (the results screen is deliberately free of buttons and of a right-click
menu); dismissing the popup fires nothing; and every action routes to the
same window handlers. The first item follows the result: تنزيل for a record
with a file, قراءة (open the source page) for a record without one.

The modal popup cannot be clicked headlessly, so navigation and contents are
asserted while the popup is open, it is closed again, and the action dispatch
is driven through ``_run_context_action`` -- the same method the popup calls
with what the user chose.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(r"D:\projects\برنامج بحث علمي")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "qt_prototype"))

from PySide6.QtCore import QEvent, QPoint, QTimer, Qt
from PySide6.QtGui import QAction, QContextMenuEvent, QKeyEvent
from PySide6.QtWidgets import QApplication, QMenu

import webbrowser

import main_window
from app.models import Category, DownloadFormat, DownloadTarget, Result

EXPECTED = ["تنزيل", "نسخ التوثيق", "فتح للقراءة على الموقع"]


def make_result(title: str = "Title Zero", abstract: str = "") -> Result:
    return Result(
        category=Category.BOOK,
        title=title,
        source="open_library",
        year=2021,
        authors=["Sara Ahmed"],
        venue="Journal of Testing",
        landing_url="https://example.org/record",
        abstract=abstract,
        downloads=[DownloadTarget(url=f"https://example.org/{title}.pdf",
                                  fmt=DownloadFormat.PDF, open_access=True)],
    )


def main() -> int:
    app = QApplication.instance() or QApplication([])
    win = main_window.MainWindow()
    win.resize(1180, 820)
    win.show()
    app.processEvents()

    failures: list[str] = []

    def check(label: str, ok: bool, detail: str = "") -> None:
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" -- {detail}" if detail else ""))
        if not ok:
            failures.append(label)

    page = win.pages[Category.BOOK]
    for t, a in (("Title Zero", ""),
             ("Title One", "A real summary about widgets."),
             ("Title Two", "")):
        page.add(make_result(t, a))
    page.update_count()
    win._jump_to(Category.BOOK)
    app.processEvents()
    page.list.setCurrentRow(0)

    seen: dict[str, object] = {}

    def arm_menu_capture(tag: str, drive_keys: bool, retries: int = 40) -> None:
        """Inside the blocking popup: check contents, exercise the arrow keys,
        then close it. Retries because a slow machine after a long build may
        take a moment before the popup reaches the screen.
        """

        def attempt(n: int) -> None:
            menus = [w for w in QApplication.topLevelWidgets()
                     if isinstance(w, QMenu) and w.isVisible()]
            if menus:
                menu = menus[0]
                seen[tag] = [a.text() for a in menu.actions()]
                seen[tag + ".acc"] = menu.accessibleName()
                if drive_keys:
                    # A real Windows menu gets keyboard focus the moment it
                    # opens. Repeat that here, or the arrow keys have no widget
                    # to land on and the navigation never moves.
                    menu.raise_()
                    menu.activateWindow()
                    menu.setFocus(Qt.OtherFocusReason)
                    app.processEvents()

                    def key(k: Qt.Key) -> None:
                        QApplication.sendEvent(
                            menu,
                            QKeyEvent(QEvent.KeyPress, k, Qt.NoModifier),
                        )
                        sel = menu.activeAction()
                        return sel.text() if sel else None
                    seen[tag + ".arrive"] = key(Qt.Key_Down)
                    seen[tag + ".down"] = key(Qt.Key_Down)
                    seen[tag + ".down2"] = key(Qt.Key_Down)
                    seen[tag + ".up"] = key(Qt.Key_Up)
                menu.close()
            elif n < retries:
                QTimer.singleShot(40, lambda: attempt(n + 1))

        QTimer.singleShot(40, lambda: attempt(0))

    print("== the Application key opens the menu on the caret row ==")
    win.raise_()
    win.activateWindow()
    arm_menu_capture("kb", drive_keys=True)
    QApplication.sendEvent(page.list, QContextMenuEvent(
        QContextMenuEvent.Reason.Keyboard, QPoint(0, 0),
        page.list.mapToGlobal(QPoint(0, 0))))
    app.processEvents()
    check("a menu with the three actions appeared",
          seen.get("kb") == EXPECTED, repr(seen.get("kb")))
    check("the menu keeps the standard Windows wording",
          seen.get("kb.acc") == "", repr(seen.get("kb.acc")))
    check("the caret stayed on row 0", page.list.currentRow() == 0,
          f"row={page.list.currentRow()}")
    check("the first Down lands the highlight on the first action",
          seen.get("kb.arrive") == "تنزيل", repr(seen.get("kb.arrive")))
    check("Down moves the highlight to the second action",
          seen.get("kb.down") == "نسخ التوثيق", repr(seen.get("kb.down")))
    check("Down again moves to the third action",
          seen.get("kb.down2") == "فتح للقراءة على الموقع",
          repr(seen.get("kb.down2")))
    check("Up moves the highlight back up",
          seen.get("kb.up") == "نسخ التوثيق", repr(seen.get("kb.up")))
    seen.clear()

    print("== a right click is a no-op, like every other screen ==")
    item1 = page.list.item(1)
    page.list.scrollToItem(item1)
    pos = page.list.visualItemRect(item1).center()
    gpos = page.list.viewport().mapToGlobal(pos)
    page.list.setCurrentRow(0)
    arm_menu_capture("noop", drive_keys=False, retries=5)
    QApplication.sendEvent(page.list.viewport(), QContextMenuEvent(
        QContextMenuEvent.Reason.Mouse, pos, gpos))
    app.processEvents()
    QTimer.singleShot(250, app.processEvents)
    app.processEvents()
    check("no menu opened for a right click",
          seen.get("noop") is None, repr(seen.get("noop")))
    check("the caret did not move", page.list.currentRow() == 0,
          f"row={page.list.currentRow()}")
    seen.clear()

    print("== dismissing the menu does nothing ==")
    card1 = page._cards[1]
    fired: dict[str, str] = {}
    for sig, name in (
        (page.download_requested, "download"),
        (page.citation_requested, "cite"),
        (page.open_requested, "open"),
    ):
        sig.connect(lambda r, n=name: fired.setdefault(n, r.title))
    page._run_context_action(None, card1)
    check("no action fires when the menu is dismissed", not fired, repr(fired))

    print("== the routes end in the window, not a dead end ==")
    opened: list[str] = []
    real_open = webbrowser.open
    webbrowser.open = lambda url, *a, **k: (opened.append(url), True)[1]
    queued: list[str] = []
    real_enqueue = win._downloads.enqueue
    win._downloads.enqueue = lambda r: (queued.append(r.title), _FakeTask(r))[1]
    try:
        page._run_context_action(QAction("نسخ التوثيق"), card1)
        pump(app)
        check("نسخ التوثيق fills the citation field",
              win.citation_view.isVisible()
              and "Ahmed, S." in win.citation_view.text()
              and "Title One" in win.citation_view.text(),
              win.citation_view.text()[:60])
        page._run_context_action(QAction("تنزيل"), card1)
        pump(app)
        check("تنزيل queues the file for download",
              queued == ["Title One"], repr(queued))
        page._run_context_action(QAction("فتح للقراءة على الموقع"), card1)
        check("فتح للقراءة opens the landing page",
              opened == ["https://example.org/record"], repr(opened))
    finally:
        webbrowser.open = real_open
        win._downloads.enqueue = real_enqueue
        win.citation_view.clear()
        win.citation_view.setVisible(False)

    print("== a read-only record offers قراءة instead of a dead تنزيل ==")
    read_only = Result(
        category=Category.BOOK,
        title="Title Three",
        source="open_library",
        year=2021,
        authors=["Sara Ahmed"],
        venue="Journal of Testing",
        landing_url="https://example.org/record3",
        downloads=[],
    )
    page.add(read_only)
    page.update_count()
    page.list.setCurrentRow(page.list.count() - 1)
    app.processEvents()
    arm_menu_capture("readonly", drive_keys=True)
    QApplication.sendEvent(page.list, QContextMenuEvent(
        QContextMenuEvent.Reason.Keyboard, QPoint(0, 0),
        page.list.mapToGlobal(QPoint(0, 0))))
    app.processEvents()
    check("the read-only menu is قراءة plus نسخ التوثيق",
          seen.get("readonly") == ["قراءة", "نسخ التوثيق"],
          repr(seen.get("readonly")))
    check("the read-only menu holds no تنزيل and no site link",
          "تنزيل" not in (seen.get("readonly") or [])
          and "فتح للقراءة على الموقع" not in (seen.get("readonly") or []),
          repr(seen.get("readonly")))
    seen.clear()

    card3 = page._cards[-1]
    opened_ro: list[str] = []
    real_open = webbrowser.open
    webbrowser.open = lambda url, *a, **k: (opened_ro.append(url), True)[1]
    try:
        page._run_context_action(QAction("قراءة"), card3)
        check("قراءة opens the landing page",
              opened_ro == ["https://example.org/record3"], repr(opened_ro))
    finally:
        webbrowser.open = real_open

    print("== a local file offers only the verbs that work ==")
    local = Result(
        category=Category.BOOK,
        title="My Local Book",
        source="local",
        year=2024,
        authors=["Sara Ahmed"],
        venue="",
        downloads=[],
    )
    page.add(local)
    page.update_count()
    page.list.setCurrentRow(page.list.count() - 1)
    app.processEvents()
    arm_menu_capture("local", drive_keys=False)
    QApplication.sendEvent(page.list, QContextMenuEvent(
        QContextMenuEvent.Reason.Keyboard, QPoint(0, 0),
        page.list.mapToGlobal(QPoint(0, 0))))
    app.processEvents()
    check("the local menu holds قراءة and نسخ التوثيق only",
          seen.get("local") == ["قراءة", "نسخ التوثيق"], repr(seen.get("local")))
    seen.clear()

    print()
    if failures:
        print(f"FAILED: {len(failures)} -> {failures}")
        return 1
    print("ALL CHECKS PASSED")
    return 0


class _FakeTask:
    def __init__(self, result: Result):
        self.result = result
        self.error = ""
        self.percent = 100.0
        self.path = ""


def pump(app) -> None:
    app.processEvents()


if __name__ == "__main__":
    raise SystemExit(main())