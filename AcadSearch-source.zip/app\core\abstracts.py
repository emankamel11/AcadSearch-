"""On-demand abstract lookup for results whose search record carried none.

Many providers return metadata-only records (Crossref for most journals,
DataCite, BASE records, and Semantic Scholar whenever it rate-limits), so a
result can arrive without an abstract and both the summary field and the copy
action have nothing to give. This module fetches the abstract by DOI *when the
user asks for it* — never during a search, so the search stays as fast as it is:

  1. OpenAlex  ``https://api.openalex.org/works/doi:<doi>`` — free, no key,
     abstract shipped as an inverted index (decoded by the OpenAlex provider).
  2. Crossref  ``https://api.crossref.org/works/<doi>`` — JATS-XML ``abstract``
     field when the publisher deposited one.
  3. Semantic Scholar  ``https://api.semanticscholar.org/graph/v1/paper/DOI:<doi>``
     — free tier, throttled, but generous abstract coverage as a last resort.

A record without a DOI (books, reports) stays abstract-less: we refuse to guess
an abstract by title, because a wrong summary is worse than an honest "there is
none".
"""

from __future__ import annotations

import re
from urllib.parse import quote

from app.core.http_client import get_http

#: Crossref wraps its abstract in JATS markup (<jats:p>...</jats:p>).
_JATS = re.compile(r"<[^>]+>")


def has_doi(result) -> bool:
    """True when the record can be looked up (it names a DOI)."""
    return bool((result.identifiers or {}).get("doi"))


def fetch_abstract(result) -> str:
    """Return the abstract for ``result``, fetching it by DOI when missing.

    The answer is cached on the result (``result.abstract``) so a second press
    is instant, and a failed lookup is remembered too, so a record that really
    has no abstract is not re-queried on every keystroke of the user's impatience.
    """
    text = (result.abstract or "").strip()
    if text:
        return text
    doi = (result.identifiers or {}).get("doi") or ""
    if not doi:
        return ""
    if result.raw.get("_abstract_lookup") == "miss":
        return ""

    http = get_http()

    # 1) OpenAlex: no key, the widest coverage of the two.
    openalex_text = ""
    try:
        from app.providers.openalex import OpenAlexProvider

        work = http.get_json(
            f"https://api.openalex.org/works/doi:{doi}",
            provider="openalex",
        )
        openalex_text = OpenAlexProvider._abstract(
            (work or {}).get("abstract_inverted_index")
        ).strip()
    except Exception:  # noqa: BLE001 - fall through to the next source
        pass
    # Very short strings are publisher stubs ("International audience") that
    # tell the reader nothing; prefer a real Crossref abstract to those.
    if len(openalex_text) >= 30:
        result.abstract = openalex_text
        return openalex_text

    # 2) Crossref: JATS blob, still no key.
    crossref_text = ""
    try:
        message = http.get_json(
            f"https://api.crossref.org/works/{doi}",
            provider="crossref",
        )
        blob = ((message or {}).get("message") or {}).get("abstract") or ""
        crossref_text = _JATS.sub(" ", blob).strip()
    except Exception:  # noqa: BLE001 - an empty answer is a normal answer
        pass

    text = openalex_text or crossref_text
    if crossref_text and len(crossref_text) > len(openalex_text):
        text = crossref_text

    # 3) Semantic Scholar: throttled without a key, but a generous last resort.
    # Consulted while the best answer is still tiny (a stub or nothing at all).
    if len(text) < 30:
        try:
            paper = http.get_json(
                "https://api.semanticscholar.org/graph/v1/paper/DOI:"
                f"{quote(doi)}?fields=abstract",
                provider="semantic_scholar",
            )
            s2_text = ((paper or {}).get("abstract") or "").strip()
        except Exception:  # noqa: BLE001 - throttling lands here, skip quietly
            s2_text = ""
        if s2_text and len(s2_text) > len(text):
            text = s2_text

    if text:
        result.abstract = text
        return text

    result.raw["_abstract_lookup"] = "miss"
    return ""
