"""Tab from a result row never lands on a button inside the row.

The cards carry no buttons at all (the screen stays quiet); the actions live
behind the Application key on the focused row. So Tab must leave the results
list and move somewhere else, never into the interior of a result card. The
arrows still move the caret, Enter still does nothing from the row, and the
Alt+D / Alt+C shortcuts still act on the focused result.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(r"D:\projects\برنامج\بحث علمي")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "qt_prototype"))

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

import main_window
from app.models import Category, DownloadFormat, DownloadTarget, Result


def main() -> int:
    app = QApplication.instance() or QApplication([])
    win = main_window.MainWindow()
    win.show()
    app.processEvents()

    failures: list[str] = []

    def check(label: str, ok: bool, detail: str = "") -> None:
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" -- {detail}" if detail else ""))
        if not ok:
            failures.append(label)

    result = Result(
        category=Category.ARTICLE,
        title="Deep learning for Arabic text",
        source="open_library",
        year=2024,
        authors=["Nour Hassan"],
        landing_url="https://example.org/x",
        downloads=[
            DownloadTarget(
                url="https://example.org/x.pdf",
                fmt=DownloadFormat.PDF,
                open_access=True,
            )
        ],
    )

    page = win.pages[Category.ARTICLE]
    page.add(result)
    page.add(Result(
        category=Category.ARTICLE,
        title="A second row so the arrow has somewhere to go",
        source="open_library",
        year=2023,
        authors=["Omar Ali"],
        landing_url="https://example.org/y",
    ))
    win.tabs.setCurrentWidget(page)
    win.resize(960, 700)
    for _ in range(4):
        app.processEvents()

    print("== Tab leaves a row without entering its card ==")
    page.list.setFocus()
    page.list.setCurrentRow(0)
    app.processEvents()

    saw_focus = False
    inside_card = False
    for _ in range(8):
        QTest.keyClick(page.list, Qt.Key_Tab)
        app.processEvents()
        widget = QApplication.focusWidget()
        if widget is None:
            continue
        saw_focus = True
        probe = widget
        while probe is not None and not isinstance(probe, main_window.ResultCard):
            probe = probe.parentWidget()
        if probe is not None:
            inside_card = True
            break
    check("Tab still moves somewhere", saw_focus)
    check("no Tab stop lives inside a result card", not inside_card)

    print("== arrows still move the caret, no download fired ==")
    fired: list[str] = []
    page.download_requested.connect(lambda r: fired.append(r.title))
    page.list.setFocus()
    page.list.setCurrentRow(0)
    QTest.keyClick(page.list, Qt.Key_Down)
    app.processEvents()
    check("Down does not trigger a download", not fired, str(fired))
    check("Enter does not download from the row itself", True)
    QTest.keyClick(page.list, Qt.Key_Return)
    app.processEvents()
    check(
        "Enter on the row no longer downloads (no double-download)",
        not fired,
        str(fired),
    )
    check("the caret moved with the arrow",
          page.list.currentRow() == 1, f"row={page.list.currentRow()}")

    print("== Alt+D and Alt+C shortcuts ==")
    page.list.setCurrentRow(0)
    QTest.keyClick(page.list, Qt.Key_D, Qt.AltModifier)
    app.processEvents()
    check("Alt+D downloads the caret result", len(fired) == 1, str(fired))

    copied: list[str] = []
    page.citation_requested.connect(lambda r: copied.append(r.title))
    QTest.keyClick(page.list, Qt.Key_C, Qt.AltModifier)
    app.processEvents()
    check("Alt+C copies the caret citation", len(copied) == 1, str(copied))

    print()
    if failures:
        print(f"FAILED: {len(failures)} -> {failures}")
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())