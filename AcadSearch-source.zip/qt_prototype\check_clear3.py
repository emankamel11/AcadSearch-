"""Clear the way a keyboard user does it: Tab to the button, press it, Escape."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import Qt, QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QPushButton

import main_window


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()
    win.raise_()
    win.activateWindow()

    def clear_btn():
        for b in win.findChildren(QPushButton):
            if "مسح" in (b.accessibleName() or ""):
                return b
        return None

    def run() -> None:
        print("=== walk the focus order like a keyboard user ===")
        win.query.setText("machine learning")
        win.query.setFocus()
        app.processEvents()

        for i in range(1, 5):
            QTest.keyClick(win, Qt.Key_Tab)
            app.processEvents()
            w = app.focusWidget()
            label = (w.accessibleName() or type(w).__name__) if w else None
            print(f"   Tab {i}: {label}")

        btn = clear_btn()
        print()
        print("=== Tab until the clear button, then activate it ===")
        win.query.setFocus()
        btn.setFocus()
        print("   focus on:", btn.accessibleName(), "hasFocus =", btn.hasFocus())
        QTest.keyClick(btn, Qt.Key_Space)
        app.processEvents()
        print("   text after Space :", repr(win.query.text()))
        print("   status           :", win.status.accessibleName())

        print()
        print("=== Escape clears as well ===")
        win.query.setText("شيء تاني")
        win.query.setFocus()
        QTest.keyClick(win, Qt.Key_Escape)
        app.processEvents()
        print("   text after Escape:", repr(win.query.text()))
        print("   status           :", win.status.accessibleName())
        app.quit()

    QTimer.singleShot(700, run)
    QTimer.singleShot(15000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())