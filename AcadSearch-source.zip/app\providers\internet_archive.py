"""Internet Archive — free full-text books, manuals and public-domain texts.

Why this exists next to Open Library: Open Library is a *catalogue*, so its
records usually only offer a landing page. Internet Archive is the host that
actually stores the files, and its ``/metadata/<id>`` endpoint lists the real
PDF/EPUB objects with their sizes. That lets us offer a genuine one-click
download instead of "go and find it yourself".

Endpoints used (all key-free, documented, no scraping):
  * ``https://archive.org/advancedsearch.php``  — Solr search over metadata
  * ``https://archive.org/metadata/<identifier>`` — per-item file manifest
  * ``https://archive.org/download/<identifier>/<file>`` — the file itself

Two traps this adapter handles explicitly:

* **Borrow-only items.** Anything in the ``internetarchivebooks`` /
  ``inlibrary`` / ``printdisabled`` collections is a *loan* copy: the file
  listing shows a PDF, but fetching it requires a signed-in account with an
  active loan. We therefore expose those as ``Access.BORROW`` with a landing
  page only, never as a download, instead of shipping a button that 403s.

* **Compilation items.** A single IA item can bundle dozens of unrelated books
  as separate files. Offering those files under the item's own title would be
  wrong, so when an item has many candidate files we expose the landing page
  and skip the file list.
"""

from __future__ import annotations

import re
import threading
import unicodedata
from urllib.parse import quote

from app.core.text_utils import (
    BOOK_QUERY_STOPWORDS,
    as_int,
    clean_text,
    fold,
    fold_word,
    normalise_language,
    strip_arabic_definite,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

SEARCH_ENDPOINT = "https://archive.org/advancedsearch.php"
METADATA_ENDPOINT = "https://archive.org/metadata/{identifier}"
DETAILS = "https://archive.org/details/{identifier}"
THUMB = "https://archive.org/services/img/{identifier}"

#: Collections whose items are lending copies rather than free downloads.
BORROW_COLLECTIONS = frozenset({
    "internetarchivebooks", "inlibrary", "printdisabled", "lendinglibrary",
    "borrowable", "inlendinglibrary",
})

#: Only these are worth offering; ``DjVuTXT`` is raw OCR and ``ACS Encrypted
#: PDF`` is the loan-wrapper that cannot be read without a loan.
FILE_FORMATS: dict[str, DownloadFormat] = {
    "text pdf": DownloadFormat.PDF,
    "additional text pdf": DownloadFormat.PDF,
    "epub": DownloadFormat.EPUB,
    "epub3": DownloadFormat.EPUB,
}
SKIP_NAME_PARTS = ("_encrypted", "_acs", "encrypted.pdf")

#: IA sometimes stores a full English name instead of a code ("english").
LANG_NAMES: dict[str, str] = {
    "english": "eng", "french": "fre", "german": "ger", "spanish": "spa",
    "italian": "ita", "portuguese": "por", "russian": "rus", "chinese": "chi",
    "japanese": "jpn", "korean": "kor", "turkish": "tur", "arabic": "ara",
    "persian": "per", "urdu": "urd", "hebrew": "heb", "hindi": "hin",
    "dutch": "dut", "polish": "pol", "swedish": "swe", "czech": "cze",
    "danish": "dan", "norwegian": "nor", "finnish": "fin", "greek": "gre",
    "latin": "lat", "hungarian": "hun", "romanian": "rum", "catalan": "cat",
}

#: An item with more candidate files than this is a compilation, not a book.
MAX_FILES_FOR_BOOK = 4

FIELDS = (
    "identifier", "title", "creator", "year", "date", "language",
    "downloads", "subject", "description", "mediatype",
    "access-restricted-item", "collection", "isbn",
)

#: ``"The art of war"`` -> ``title:"the art of war"``
_QUOTES = re.compile(r'["\\]')

#: Words that say *what kind* of book the reader wants, not which book. A
#: search for "رواية نادية" must still find a record titled "ناديا يوسف
#: السباعي", so requiring these words inside the title would hide the answer.
#: The list lives in ``text_utils`` because the Books tab applies the same rule
#: when it decides whether a record is about the search at all.
_GENERIC_BOOK_WORDS = BOOK_QUERY_STOPWORDS

#: Arabic spelling is not standardised in uploaded scans: the same name is
#: filed as "نادية", "ناديه" and "ناديا", and "السباعي" as "السباعى". Solr
#: compares bytes, so the exact phrase misses records a reader reads as the
#: same title. Every word is therefore searched as a small family of spellings.
_QUERY_LETTERS = str.maketrans({
    "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا",
    "ى": "ي", "ئ": "ي", "ؤ": "و", "ة": "ه", "ـ": "",
})

#: Endings readers swap when they spell the same word by ear.
_QUERY_ENDINGS: dict[str, tuple[str, ...]] = {
    "ه": ("ة", "ا"),
    "ة": ("ه", "ا"),
    "ا": ("ة", "ه"),
    "ي": ("ى",),
    "ى": ("ي",),
}

#: Titles that are really a filename, a course advert or a scraper site name.
#: IA is a dumping ground for user uploads, so a large share of ``mediatype:
#: texts`` is not a book at all: it is course dumps, theses, scanned slides and
#: re-uploads whose title is the uploader's file name. Catalogue sources
#: (Open Library, OpenAlex) do not have this problem.
_SCRAPED_TITLE = re.compile(
    r"_|"
    r"\b(pdfdrive|pdfcoffee|libgen|z-lib|scribd|slideshare|speakerdeck|"
    r"course-?hero|giga\s*course|coursera|udemy|edx|free-?course-?site|"
    r"notesplanet|docslib|vdocpub|studylib|1library)\b|"
    r"\.com\b|\.org\b|\.net\b|"
    r"\bthesis\b|\bdissertation\b|\bpaper\b|\blecture\b|\bslides\b|"
    r"\b(handout|assignment|homework|syllabus)\b",
    re.IGNORECASE,
)

#: "Zero to hero", "Complete ... in 2 hours", "Mega guide": advert copy.
_SPAM_TITLE = re.compile(
    r"\b(zero\s*to\b|mega\b|ultimate\b|complete\s+\w+\s+(bootcamp|course|"
    r"masterclass)|in\s+\d+\s*(hours?|days?)|\d+\s*in\s*1\b|crack(ed)?\b)",
    re.IGNORECASE,
)

#: All-lowercase runs are a slug; a real book capitalises its words.
_SLUGISH = re.compile(r"^[a-z0-9]+(?:[-_][a-z0-9]+)+$")

#: Report and document series that IA indexes as ``mediatype:texts`` but which
#: are not books: military and agency reports, ERIC bibliographies, NASA NTRS
#: numbers. They dominate relevance ranking because their titles repeat the
#: subject words many times.
_REPORT_SERIES = re.compile(
    r"^\s*("
    r"DTIC\s|AD\d{6}|ADA\d{5}|ERIC\s+ED\d|"
    r"NASA\s+Technical\s+Reports?|NTRS\s|RAND\s+(?:MR|WR|AR)[:\s]\d|"
    r"PB\s?\d{6,}|AADAT|TR\s+\d|"
    r"(?:A|An|The)\s+(?:Quantitative\s+)?Machine[- ]Learning\s+Approach\s+"
    r"(?:for|to)\s+the\s+Detection"
    r")",
    re.IGNORECASE,
)

#: An all-caps title is a stamped report, not a published book.
_SHOUTY = re.compile(r"^[A-Z0-9\s:,.'\-()]+$")

#: Uploaders name a paper file after its report number, and IA mirrors agency
#: documents under prefixes like ``nasa_``/``ntrs``. These resolve to a real
#: PDF, so they look downloadable, but they are papers rather than books.
_NOT_A_BOOK_ID = re.compile(
    r"(^|[_\-.])("
    r"nasa|ntrs|techdoc|techbrief|trs|rand|dtic|darpa|osti|"
    r"researchpaper|paper|draft\d*|thesis|dissertation|report|"
    r"workingpaper|preprint|seminar|lecture|presentation|poster"
    r")([_\-.]|$)",
    re.IGNORECASE,
)


@register
class InternetArchiveProvider(BaseProvider):
    """Free downloadable books from archive.org."""

    provider_id = "internet_archive"
    display_name = "Internet Archive"
    categories = (Category.BOOK,)
    weight = 20
    homepage = "https://archive.org"

    #: Resolving real files needs one extra request per item, so only the first
    #: few cards get a file list; the rest keep a landing page.
    #:
    #: This is the single biggest lever on whether a searched novel is
    #: *downloadable* in the UI. At 12 calls, the exact match was often beyond
    #: the budget because the search order is popularity, not relevance, and
    #: then the one card the user wanted kept a landing page. 20 covers the
    #: top slice while staying well inside archive.org's tolerance.
    max_metadata_calls = 20

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        wanted = max(1, min(query.per_source, 40))
        cleaned = self._clean(query.text)
        words = _query_words(query.text)

        docs: list[dict] = []
        # Search the exact phrase on its own as well as the word clause. A
        # title search for "بداية ونهاية" matches 89 books, and IA ranks by
        # downloads, so the novel itself sat below 40 fiqh books with the same
        # two words. The phrase query has its own, much smaller result set, so
        # the novel is present for the local ranking below to lift to the top.
        if len(_query_tokens(cleaned)) > 1:
            phrase_query = f'title:("{cleaned}") AND mediatype:texts'
            docs += self._search(phrase_query, max(wanted * 2, 30), cancel)
        docs += self._search(self._title_query(query.text), wanted * 3, cancel)
        if len(docs) < wanted * 3:
            # Titles are sparse in IA; widen to subjects/descriptions.
            docs += self._search(
                self._broad_query(query.text), wanted * 3 - len(docs), cancel
            )

        # De-duplicate on identifier, preserving relevance order.
        seen: set[str] = set()
        unique: list[dict] = []
        for doc in docs:
            ident = clean_text(doc.get("identifier"))
            if ident and ident not in seen:
                seen.add(ident)
                unique.append(doc)

        # The manifest budget is finite, and IA ranks by downloads, so a
        # popular-but-unrelated upload can sit above the novel being searched.
        # Rank locally before spending metadata requests: a title that starts
        # with the exact phrase wins, then the one that contains it, then the
        # one sharing more query words (and fewer extra title words). Only then
        # does IA's download order decide, because popularity is a good
        # tie-break but a poor definition of relevance.
        if words:
            phrase = fold(cleaned)
            unique.sort(key=lambda doc: _doc_rank(doc, words, phrase))

        # Reject the re-uploads before spending a metadata request on them, so
        # the manifest budget goes to records that may actually be books.
        clean_docs = [
            doc
            for doc in unique
            if not self._is_scrape(
                clean_text(doc.get("title")) or "",
                _creators(doc.get("creator")),
                clean_text(doc.get("identifier")),
                _strings(doc.get("collection")),
                words,
                _first(doc.get("description")),
            )
        ]

        results: list[Result] = []
        for index, doc in enumerate(clean_docs):
            if cancel is not None and cancel.is_set():
                break
            if len(results) >= wanted:
                break
            manifest = None
            if index < self.max_metadata_calls:
                manifest = self._manifest(clean_text(doc.get("identifier")), cancel)
            item = self._to_result(doc, manifest)
            if item is not None:
                # The manifest title is the real one; re-check it, because the
                # search document often carries the uploader's file name.
                if self._is_scrape(
                    item.title,
                    item.authors,
                    clean_text(doc.get("identifier")),
                    set(item.raw.get("collection") or ()),
                    words,
                    item.abstract,
                ):
                    continue
                results.append(item)
        return results

    # -- search -----------------------------------------------------------
    def _search(
        self, q: str, limit: int, cancel: threading.Event | None
    ) -> list[dict]:
        if not q or limit <= 0:
            return []
        params: list[tuple[str, str]] = [("q", q)]
        for field in FIELDS:
            params.append(("fl[]", field))
        params += [
            # Popularity is the best relevance proxy IA offers: a real book
            # gets read, an untitled upload does not. Ranking by Solr score
            # instead surfaces agency reports whose titles repeat the subject.
            ("sort[]", "downloads desc"),
            ("rows", str(limit)),
            ("page", "1"),
            ("output", "json"),
        ]
        payload = self.http.get_json(
            SEARCH_ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        response = payload.get("response") or {}
        return list(response.get("docs") or [])

    @staticmethod
    def _clean(text: str) -> str:
        return _QUOTES.sub(" ", (text or "").strip())

    def _title_query(self, text: str) -> str:
        cleaned = self._clean(text)
        if not cleaned:
            return ""
        clause = _title_clause(cleaned)
        if not clause:
            return f'title:("{cleaned}") AND mediatype:texts'
        # Exact phrase first, then the same words with Arabic spelling variants:
        # "نادية" must find an item titled "ناديا", and "رواية نادية" must not
        # require the word "رواية" to appear in the title at all.
        return (
            f'(title:("{cleaned}") OR title:({clause})) AND mediatype:texts'
        )

    def _broad_query(self, text: str) -> str:
        cleaned = self._clean(text)
        if not cleaned:
            return ""
        parts = [
            f'title:("{cleaned}")',
            f'subject:("{cleaned}")',
            f'description:("{cleaned}")',
            f'creator:("{cleaned}")',
        ]
        clause = _title_clause(cleaned)
        if clause:
            # The author is often the only place the searched name appears:
            # a search for "يوسف السباعي" should list his novels even when the
            # record's title is just "أرض النفاق".
            parts.append(f"creator:({clause})")
        return f'({" OR ".join(parts)}) AND mediatype:texts'

    def _manifest(
        self, identifier: str, cancel: threading.Event | None
    ) -> dict | None:
        if not identifier:
            return None
        try:
            return self.http.get_json(
                METADATA_ENDPOINT.format(identifier=quote(identifier)),
                provider=self.provider_id,
                cancel=cancel,
            )
        except Exception:  # noqa: BLE001 - a missing manifest is not fatal
            # Without the manifest we simply offer a landing page instead.
            return None

    # -- quality gate ----------------------------------------------------
    @staticmethod
    def _is_scrape(
        title: str,
        creator: list[str],
        identifier: str = "",
        collections: set[str] | None = None,
        query_words: tuple[str, ...] = (),
        extra: str = "",
    ) -> bool:
        """True when the record is not a book we should show a user.

        IA indexes whatever people uploaded, so a hit is only useful if the
        title looks like a published book: catalogued capitalisation, a named
        author, no scraper or course wording, and not a stamped agency report
        or an uploaded paper.
        """
        if not title:
            return True
        if _SCRAPED_TITLE.search(title) or _SPAM_TITLE.search(title):
            return True
        if _SLUGISH.match(title.strip()):
            return True
        if _REPORT_SERIES.search(title):
            return True
        if _NOT_A_BOOK_ID.search(identifier or ""):
            return True
        if len(title) > 18 and _SHOUTY.match(title):
            return True
        # A scanned file with no author is usually a cover image or a stray
        # upload — but not in the "books by language" collections, where real
        # novels are routinely uploaded without a creator field. Those were
        # being thrown away before anyone saw them: "ذاكرة الجسد" lost ten of
        # twelve matches, all of them books. Rescue only the narrow, provable
        # case: the item is in a *booksbylanguage* collection and the query
        # words appear in its title *or its description*. The description
        # matters because uploaders often title the item with a transliteration
        # or the author's name and put the real title in the description —
        # "365lionsyeleqbk" and "الكاتب احلام مستغمانى" are both
        # "الأسود يليق بك" with a real PDF and EPUB inside. Every other check
        # above still applies, so a course dump or a report is still rejected.
        if not creator:
            if not _books_by_language(collections) or not _mentions_words(
                f"{title} {extra}", query_words
            ):
                return True
        # "Machine learning, deep learning, ai, maths": a keyword dump, not
        # somebody's book title.
        if title.count(",") >= 3:
            return True
        if len(title.split()) > 18:
            return True
        return False

    # -- mapping ----------------------------------------------------------
    def _to_result(self, doc: dict, manifest: dict | None) -> Result | None:
        identifier = clean_text(doc.get("identifier"))
        title = clean_text(doc.get("title"))
        if not identifier or not title:
            return None

        meta = (manifest or {}).get("metadata") or {}
        # The manifest is authoritative when present (search docs are sparse).
        title = clean_text(meta.get("title")) or title
        creators = _creators(meta.get("creator") or doc.get("creator"))
        year = (
            as_int(meta.get("year"))
            or as_int(meta.get("date"))
            or as_int(doc.get("year"))
        )
        language = _first(meta.get("language")) or _first(doc.get("language"))
        subjects = _subjects(meta.get("subject") or doc.get("subject"))
        collections = _strings(meta.get("collection") or doc.get("collection"))
        restricted = _truthy(meta.get("access-restricted-item")) or _truthy(
            doc.get("access-restricted-item")
        )
        borrow_only = restricted or bool(
            collections & BORROW_COLLECTIONS
        )
        publisher = _first(meta.get("publisher")) or _first(doc.get("publisher"))

        landing = DETAILS.format(identifier=identifier)
        downloads: list = []
        if not borrow_only and manifest:
            downloads = _item_files(identifier, manifest)

        access = (
            Access.BORROW if borrow_only
            else Access.DOWNLOAD if downloads
            else Access.LANDING
        )
        downloads.append(
            target(
                landing,
                DownloadFormat.HTML,
                label="Internet Archive",
                open_access=not borrow_only,
            )
        )

        identifiers = {"ia": identifier}
        if manifest:
            for key in ("isbn", "oclc-id", "lccn", "identifier-access"):
                value = clean_text(meta.get(key))
                if value and key != "identifier-access":
                    identifiers["isbn" if key == "isbn" else key] = value
        for candidate in ("isbn", "oclc-id"):
            value = clean_text(doc.get(candidate))
            if value and candidate not in identifiers:
                identifiers[candidate] = value

        return Result(
            category=Category.BOOK,
            title=title,
            source=self.provider_id,
            authors=creators,
            year=year,
            abstract=self._summary(meta.get("description"), subjects, creators),
            venue=publisher,
            publisher=publisher,
            language=normalise_language(LANG_NAMES.get(language.lower(), language)),
            subjects=subjects[:8],
            identifiers=identifiers,
            access=access,
            downloads=downloads,
            landing_url=landing,
            cover_url=THUMB.format(identifier=identifier),
            item_type="Book",
            raw={"collection": collections, "borrow_only": borrow_only},
        )

    def _files(self, identifier: str, manifest: dict, title: str) -> list:
        """Backwards-compatible alias kept for callers outside this module."""
        return _item_files(identifier, manifest)

    @staticmethod
    def _summary(description: object, subjects: list[str], authors: list[str]) -> str:
        parts: list[str] = []
        text = clean_text(description)
        if text:
            # IA descriptions are sometimes multi-paragraph HTML-ish blobs.
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s+", " ", text).strip()
            parts.append(text)
        meta: list[str] = []
        if authors:
            meta.append(", ".join(authors[:2]))
        if subjects:
            meta.append(", ".join(subjects[:5]))
        if meta:
            parts.append(" · ".join(meta))
        return truncate_words(" ".join(parts), 320)


def _item_files(identifier: str, manifest: dict) -> list:
    """Real files for a single-book item, or ``[]`` for a compilation."""
    candidates: list[tuple[int, dict, DownloadFormat]] = []
    for entry in manifest.get("files") or []:
        name = clean_text(entry.get("name"))
        if not name or entry.get("private"):
            continue
        lowered = name.lower()
        if any(part in lowered for part in SKIP_NAME_PARTS):
            continue
        fmt = FILE_FORMATS.get(clean_text(entry.get("format")).lower())
        if fmt is None:
            if lowered.endswith(".pdf"):
                fmt = DownloadFormat.PDF
            elif lowered.endswith(".epub"):
                fmt = DownloadFormat.EPUB
            else:
                continue
        # Prefer the uploaded original over IA's re-encoded derivative.
        rank = 0 if entry.get("source") == "original" else 1
        candidates.append((rank, entry, fmt))

    if not candidates or len(candidates) > MAX_FILES_FOR_BOOK:
        return []

    candidates.sort(
        key=lambda item: (
            0 if item[2] is DownloadFormat.PDF else 1,
            item[0],
            -as_int(item[1].get("size")) or 0,
        )
    )
    out: list = []
    seen_formats: set[DownloadFormat] = set()
    for _rank, entry, fmt in candidates:
        if fmt in seen_formats:
            continue
        seen_formats.add(fmt)
        name = clean_text(entry.get("name"))
        out.append(
            target(
                f"https://archive.org/download/{identifier}/{quote(name)}",
                fmt,
                label=f"{fmt.value.upper()} ({_mb(entry.get('size'))})",
                open_access=True,
            )
        )
        if len(seen_formats) >= 2:
            break
    return out


def resolve_open_files(
    identifier: str, title: str = "", http=None
) -> list | None:
    """The open PDF/EPUB files an archive.org item can really download.

    Used by the downloader to enrich a book that only carries a landing page
    (the search behaves fast by not resolving every item's manifest): when the
    user asks to "read" such a book we resolve it and download the file when one
    exists, instead of opening the site. Returns ``None`` when there is nothing
    to fetch (borrow-only, compilation, or a network failure).
    """
    if not identifier:
        return None
    from app.core.http_client import get_http

    try:
        manifest = (http or get_http()).get_json(
            METADATA_ENDPOINT.format(identifier=quote(identifier)),
            provider="internet_archive",
        )
    except Exception:  # noqa: BLE001 - an unreachable manifest keeps the landing page
        return None
    if not manifest:
        return None
    meta = manifest.get("metadata") or {}
    borrow_only = _truthy(meta.get("access-restricted-item")) or bool(
        _strings(meta.get("collection")) & BORROW_COLLECTIONS
    )
    if borrow_only:
        return None
    files = _item_files(identifier, manifest)
    return files or None


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _first(value: object) -> str:
    """First non-empty value of a string or list field (IA uses both)."""
    if value is None:
        return ""
    if isinstance(value, str):
        return clean_text(value)
    if isinstance(value, (list, tuple, set)):
        for item in value:
            text = clean_text(item)
            if text:
                return text
        return ""
    return clean_text(value)


def _strings(value: object) -> set[str]:
    if value is None:
        return set()
    if isinstance(value, str):
        return {value.strip().lower()} if value.strip() else set()
    if isinstance(value, (list, tuple, set)):
        return {str(v).strip().lower() for v in value if str(v).strip()}
    return set()


def _truthy(value: object) -> bool:
    if value is None or value is False:
        return False
    if isinstance(value, str):
        return value.strip().lower() in ("true", "1", "yes")
    return bool(value)


def _books_by_language(collections: set[str] | None) -> bool:
    """True for archive.org's ``booksbylanguage`` upload collections.

    Those are the ones where a scanned novel is filed by language rather than
    by a catalogue record, and where the ``creator`` field is frequently blank
    even though the file is a real book.
    """
    for name in collections or ():
        if name == "booksbylanguage" or name.startswith("booksbylanguage_"):
            return True
    return False


def _query_tokens(text: str) -> list[str]:
    """Words of a query, Unicode-aware (Arabic included), without punctuation."""
    return [word for word in re.findall(r"[^\W_]+", text or "") if word]


def _search_words(text: str) -> list[str]:
    """Words the title query should require, minus "رواية"/"book" style words."""
    tokens = _query_tokens(text)
    kept = [word for word in tokens if fold_word(word) not in _GENERIC_BOOK_WORDS]
    return kept or tokens


def _word_variants(word: str) -> list[str]:
    """Spellings of one word that an uploader may have used on archive.org."""
    base = "".join(
        char
        for char in unicodedata.normalize("NFKD", word)
        if not unicodedata.combining(char)
    ).strip()
    if not base:
        return []
    forms: list[str] = [base]
    normalised = base.translate(_QUERY_LETTERS)
    if normalised not in forms:
        forms.append(normalised)
    for form in list(forms):
        for ending in _QUERY_ENDINGS.get(form[-1:], ()):
            variant = form[:-1] + ending
            if variant not in forms:
                forms.append(variant)
    # Keep the query short: every extra form is another OR term.
    return forms[:8]


def _word_clause(word: str) -> str:
    variants = _word_variants(word)
    if not variants:
        return ""
    if len(variants) == 1:
        return variants[0]
    return "(" + " OR ".join(variants) + ")"


def _title_clause(text: str) -> str:
    """``(نادية OR ناديه OR ناديا) AND يوسف AND (السباعي OR السباعى)``."""
    clauses = [_word_clause(word) for word in _search_words(text)]
    return " AND ".join(clause for clause in clauses if clause)


def _match_key(word: str) -> str:
    """Fold a word and drop an ending that readers spell differently.

    "نادية", "ناديه" and "ناديا" all become "نادي", so a title that writes the
    name one way still counts as mentioning a query written another way. Used
    only to rank and to rescue unattributed uploads, never to drop a record
    that the search itself returned.
    """
    key = strip_arabic_definite(fold_word(word))
    trimmed = key.rstrip("هيا")
    return trimmed if len(trimmed) >= 3 else key


def _query_words(text: str) -> tuple[str, ...]:
    """Significant words of the query, folded and without the Arabic "ال".

    Used only to prove that an unattributed upload's title really is the book
    the reader asked for. The article is stripped so a title that drops it
    ("حرافيش") still matches a query that keeps it ("الحرافيش").
    """
    out: list[str] = []
    for word in _query_tokens(text):
        if fold_word(word) in _GENERIC_BOOK_WORDS:
            continue
        folded = strip_arabic_definite(fold_word(word))
        if len(folded) >= 3 and folded not in out:
            out.append(folded)
    return tuple(out)


def _mentions_words(text: str, words: tuple[str, ...]) -> bool:
    """True when every significant query word occurs in the folded text."""
    if not words:
        return False
    folded = fold(text or "")
    if folded and all(word in folded for word in words):
        return True
    keys = {_match_key(word) for word in _query_tokens(text)}
    keys.discard("")
    return bool(keys) and all(_match_key(word) in keys for word in words)


def _word_hits(text: str, words: tuple[str, ...]) -> int:
    """How many of the significant query words occur in ``text``."""
    if not text or not words:
        return 0
    keys = {_match_key(word) for word in _query_tokens(text)}
    keys.discard("")
    return sum(1 for word in words if _match_key(word) in keys)


def _doc_rank(
    doc: dict, words: tuple[str, ...], phrase: str
) -> tuple[int, int, int, int, int, int]:
    """Rank one search document for the Books tab.

    IA's advanced search cannot boost an exact title, and sorting by downloads
    is why a scanned novel lost to a famous fiqh book that merely shares its two
    words. This ordering is what puts the book the reader typed first:

    1. the title starts with the typed phrase;
    2. the title contains the typed phrase;
    3. more query words appear in the title;
    4. more query words appear in the author (an author search should still
       list that author's novels, whose titles never repeat the name);
    5. the title has about as many words as the query (so "بداية ونهاية" beats
       "بداية المجتهد ونهاية المقتصد");
    6. more query words appear in the description.
    """
    title = clean_text(doc.get("title"))
    folded_title = fold(title)
    creator = " ".join(_creators(doc.get("creator")))
    description = _first(doc.get("description"))
    title_words = len(_query_tokens(title))
    return (
        0 if phrase and folded_title.startswith(phrase) else 1,
        0 if phrase and phrase in folded_title else 1,
        -_word_hits(title, words),
        -_word_hits(creator, words),
        abs(title_words - len(words)),
        -_word_hits(description, words),
    )


def _creators(value: object) -> list[str]:
    if not value:
        return []
    if isinstance(value, str):
        # IA often packs several creators into one "a; b" string.
        parts = re.split(r"\s*;\s*", value)
    else:
        parts = [str(v) for v in value]
    out: list[str] = []
    for part in parts:
        name = clean_text(part)
        # Strip IA's disambiguator, e.g. "Smith, John (1900-1980)".
        name = re.sub(r"\s*\([^)]*\)\s*$", "", name).strip()
        if name and name not in out:
            out.append(name)
    return out[:6]


def _subjects(value: object) -> list[str]:
    if not value:
        return []
    if isinstance(value, str):
        parts = re.split(r"\s*;\s*", value)
    else:
        parts = [str(v) for v in value]
    out: list[str] = []
    for part in parts:
        topic = clean_text(part)
        if topic and topic.lower() not in {t.lower() for t in out}:
            out.append(topic)
    return out[:10]


def _mb(size: object) -> str:
    value = as_int(size)
    if not value:
        return "?"
    if value >= 1024 * 1024:
        return f"{value / (1024 * 1024):.1f} MB"
    return f"{max(1, value // 1024)} KB"
