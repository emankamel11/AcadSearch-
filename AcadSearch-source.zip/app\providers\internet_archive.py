"""Internet Archive — free full-text books, manuals and public-domain texts.

Why this exists next to Open Library: Open Library is a *catalogue*, so its
records usually only offer a landing page. Internet Archive is the host that
actually stores the files, and its ``/metadata/<id>`` endpoint lists the real
PDF/EPUB objects with their sizes. That lets us offer a genuine one-click
download instead of "go and find it yourself".

Endpoints used (all key-free, documented, no scraping):
  * ``https://archive.org/advancedsearch.php``  — Solr search over metadata
  * ``https://archive.org/metadata/<identifier>`` — per-item file manifest
  * ``https://archive.org/download/<identifier>/<file>`` — the file itself

Two traps this adapter handles explicitly:

* **Borrow-only items.** Anything in the ``internetarchivebooks`` /
  ``inlibrary`` / ``printdisabled`` collections is a *loan* copy: the file
  listing shows a PDF, but fetching it requires a signed-in account with an
  active loan. We therefore expose those as ``Access.BORROW`` with a landing
  page only, never as a download, instead of shipping a button that 403s.

* **Compilation items.** A single IA item can bundle dozens of unrelated books
  as separate files. Offering those files under the item's own title would be
  wrong, so when an item has many candidate files we expose the landing page
  and skip the file list.
"""

from __future__ import annotations

import re
import threading
from urllib.parse import quote

from app.core.text_utils import (
    as_int,
    clean_text,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

SEARCH_ENDPOINT = "https://archive.org/advancedsearch.php"
METADATA_ENDPOINT = "https://archive.org/metadata/{identifier}"
DETAILS = "https://archive.org/details/{identifier}"
THUMB = "https://archive.org/services/img/{identifier}"

#: Collections whose items are lending copies rather than free downloads.
BORROW_COLLECTIONS = frozenset({
    "internetarchivebooks", "inlibrary", "printdisabled", "lendinglibrary",
    "borrowable", "inlendinglibrary",
})

#: Only these are worth offering; ``DjVuTXT`` is raw OCR and ``ACS Encrypted
#: PDF`` is the loan-wrapper that cannot be read without a loan.
FILE_FORMATS: dict[str, DownloadFormat] = {
    "text pdf": DownloadFormat.PDF,
    "additional text pdf": DownloadFormat.PDF,
    "epub": DownloadFormat.EPUB,
    "epub3": DownloadFormat.EPUB,
}
SKIP_NAME_PARTS = ("_encrypted", "_acs", "encrypted.pdf")

#: IA sometimes stores a full English name instead of a code ("english").
LANG_NAMES: dict[str, str] = {
    "english": "eng", "french": "fre", "german": "ger", "spanish": "spa",
    "italian": "ita", "portuguese": "por", "russian": "rus", "chinese": "chi",
    "japanese": "jpn", "korean": "kor", "turkish": "tur", "arabic": "ara",
    "persian": "per", "urdu": "urd", "hebrew": "heb", "hindi": "hin",
    "dutch": "dut", "polish": "pol", "swedish": "swe", "czech": "cze",
    "danish": "dan", "norwegian": "nor", "finnish": "fin", "greek": "gre",
    "latin": "lat", "hungarian": "hun", "romanian": "rum", "catalan": "cat",
}

#: An item with more candidate files than this is a compilation, not a book.
MAX_FILES_FOR_BOOK = 4

FIELDS = (
    "identifier", "title", "creator", "year", "date", "language",
    "downloads", "subject", "description", "mediatype",
    "access-restricted-item", "collection", "isbn",
)

#: ``"The art of war"`` -> ``title:"the art of war"``
_QUOTES = re.compile(r'["\\]')

#: Titles that are really a filename, a course advert or a scraper site name.
#: IA is a dumping ground for user uploads, so a large share of ``mediatype:
#: texts`` is not a book at all: it is course dumps, theses, scanned slides and
#: re-uploads whose title is the uploader's file name. Catalogue sources
#: (Open Library, OpenAlex) do not have this problem.
_SCRAPED_TITLE = re.compile(
    r"_|"
    r"\b(pdfdrive|pdfcoffee|libgen|z-lib|scribd|slideshare|speakerdeck|"
    r"course-?hero|giga\s*course|coursera|udemy|edx|free-?course-?site|"
    r"notesplanet|docslib|vdocpub|studylib|1library)\b|"
    r"\.com\b|\.org\b|\.net\b|"
    r"\bthesis\b|\bdissertation\b|\bpaper\b|\blecture\b|\bslides\b|"
    r"\b(handout|assignment|homework|syllabus)\b",
    re.IGNORECASE,
)

#: "Zero to hero", "Complete ... in 2 hours", "Mega guide": advert copy.
_SPAM_TITLE = re.compile(
    r"\b(zero\s*to\b|mega\b|ultimate\b|complete\s+\w+\s+(bootcamp|course|"
    r"masterclass)|in\s+\d+\s*(hours?|days?)|\d+\s*in\s*1\b|crack(ed)?\b)",
    re.IGNORECASE,
)

#: All-lowercase runs are a slug; a real book capitalises its words.
_SLUGISH = re.compile(r"^[a-z0-9]+(?:[-_][a-z0-9]+)+$")

#: Report and document series that IA indexes as ``mediatype:texts`` but which
#: are not books: military and agency reports, ERIC bibliographies, NASA NTRS
#: numbers. They dominate relevance ranking because their titles repeat the
#: subject words many times.
_REPORT_SERIES = re.compile(
    r"^\s*("
    r"DTIC\s|AD\d{6}|ADA\d{5}|ERIC\s+ED\d|"
    r"NASA\s+Technical\s+Reports?|NTRS\s|RAND\s+(?:MR|WR|AR)[:\s]\d|"
    r"PB\s?\d{6,}|AADAT|TR\s+\d|"
    r"(?:A|An|The)\s+(?:Quantitative\s+)?Machine[- ]Learning\s+Approach\s+"
    r"(?:for|to)\s+the\s+Detection"
    r")",
    re.IGNORECASE,
)

#: An all-caps title is a stamped report, not a published book.
_SHOUTY = re.compile(r"^[A-Z0-9\s:,.'\-()]+$")

#: Uploaders name a paper file after its report number, and IA mirrors agency
#: documents under prefixes like ``nasa_``/``ntrs``. These resolve to a real
#: PDF, so they look downloadable, but they are papers rather than books.
_NOT_A_BOOK_ID = re.compile(
    r"(^|[_\-.])("
    r"nasa|ntrs|techdoc|techbrief|trs|rand|dtic|darpa|osti|"
    r"researchpaper|paper|draft\d*|thesis|dissertation|report|"
    r"workingpaper|preprint|seminar|lecture|presentation|poster"
    r")([_\-.]|$)",
    re.IGNORECASE,
)


@register
class InternetArchiveProvider(BaseProvider):
    """Free downloadable books from archive.org."""

    provider_id = "internet_archive"
    display_name = "Internet Archive"
    categories = (Category.BOOK,)
    weight = 20
    homepage = "https://archive.org"

    #: Resolving real files needs one extra request per item, so only the first
    #: few cards get a file list; the rest keep a landing page.
    max_metadata_calls = 12

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        wanted = max(1, min(query.per_source, 20))

        docs = self._search(self._title_query(query.text), wanted * 3, cancel)
        if len(docs) < wanted * 3:
            # Titles are sparse in IA; widen to subjects/descriptions.
            docs += self._search(
                self._broad_query(query.text), wanted * 3 - len(docs), cancel
            )

        # De-duplicate on identifier, preserving relevance order.
        seen: set[str] = set()
        unique: list[dict] = []
        for doc in docs:
            ident = clean_text(doc.get("identifier"))
            if ident and ident not in seen:
                seen.add(ident)
                unique.append(doc)

        # Reject the re-uploads before spending a metadata request on them, so
        # the manifest budget goes to records that may actually be books.
        clean_docs = [
            doc
            for doc in unique
            if not self._is_scrape(
                clean_text(doc.get("title")) or "",
                _creators(doc.get("creator")),
                clean_text(doc.get("identifier")),
            )
        ]

        results: list[Result] = []
        for index, doc in enumerate(clean_docs):
            if cancel is not None and cancel.is_set():
                break
            if len(results) >= wanted:
                break
            manifest = None
            if index < self.max_metadata_calls:
                manifest = self._manifest(clean_text(doc.get("identifier")), cancel)
            item = self._to_result(doc, manifest)
            if item is not None:
                # The manifest title is the real one; re-check it, because the
                # search document often carries the uploader's file name.
                if self._is_scrape(
                    item.title, item.authors, clean_text(doc.get("identifier"))
                ):
                    continue
                results.append(item)
        return results

    # -- search -----------------------------------------------------------
    def _search(
        self, q: str, limit: int, cancel: threading.Event | None
    ) -> list[dict]:
        if not q or limit <= 0:
            return []
        params: list[tuple[str, str]] = [("q", q)]
        for field in FIELDS:
            params.append(("fl[]", field))
        params += [
            # Popularity is the best relevance proxy IA offers: a real book
            # gets read, an untitled upload does not. Ranking by Solr score
            # instead surfaces agency reports whose titles repeat the subject.
            ("sort[]", "downloads desc"),
            ("rows", str(limit)),
            ("page", "1"),
            ("output", "json"),
        ]
        payload = self.http.get_json(
            SEARCH_ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        response = payload.get("response") or {}
        return list(response.get("docs") or [])

    @staticmethod
    def _clean(text: str) -> str:
        return _QUOTES.sub(" ", (text or "").strip())

    def _title_query(self, text: str) -> str:
        cleaned = self._clean(text)
        if not cleaned:
            return ""
        return f'title:("{cleaned}") AND mediatype:texts'

    def _broad_query(self, text: str) -> str:
        cleaned = self._clean(text)
        if not cleaned:
            return ""
        return (
            f'(title:("{cleaned}") OR subject:("{cleaned}") '
            f'OR description:("{cleaned}")) AND mediatype:texts'
        )

    def _manifest(
        self, identifier: str, cancel: threading.Event | None
    ) -> dict | None:
        if not identifier:
            return None
        try:
            return self.http.get_json(
                METADATA_ENDPOINT.format(identifier=quote(identifier)),
                provider=self.provider_id,
                cancel=cancel,
            )
        except Exception:  # noqa: BLE001 - a missing manifest is not fatal
            # Without the manifest we simply offer a landing page instead.
            return None

    # -- quality gate ----------------------------------------------------
    @staticmethod
    def _is_scrape(title: str, creator: list[str], identifier: str = "") -> bool:
        """True when the record is not a book we should show a user.

        IA indexes whatever people uploaded, so a hit is only useful if the
        title looks like a published book: catalogued capitalisation, a named
        author, no scraper or course wording, and not a stamped agency report
        or an uploaded paper.
        """
        if not title:
            return True
        if _SCRAPED_TITLE.search(title) or _SPAM_TITLE.search(title):
            return True
        if _SLUGISH.match(title.strip()):
            return True
        if _REPORT_SERIES.search(title):
            return True
        if _NOT_A_BOOK_ID.search(identifier or ""):
            return True
        if len(title) > 18 and _SHOUTY.match(title):
            return True
        # A scanned file with no author is a cover image or a stray upload.
        if not creator:
            return True
        # "Machine learning, deep learning, ai, maths": a keyword dump, not
        # somebody's book title.
        if title.count(",") >= 3:
            return True
        if len(title.split()) > 18:
            return True
        return False

    # -- mapping ----------------------------------------------------------
    def _to_result(self, doc: dict, manifest: dict | None) -> Result | None:
        identifier = clean_text(doc.get("identifier"))
        title = clean_text(doc.get("title"))
        if not identifier or not title:
            return None

        meta = (manifest or {}).get("metadata") or {}
        # The manifest is authoritative when present (search docs are sparse).
        title = clean_text(meta.get("title")) or title
        creators = _creators(meta.get("creator") or doc.get("creator"))
        year = (
            as_int(meta.get("year"))
            or as_int(meta.get("date"))
            or as_int(doc.get("year"))
        )
        language = _first(meta.get("language")) or _first(doc.get("language"))
        subjects = _subjects(meta.get("subject") or doc.get("subject"))
        collections = _strings(meta.get("collection") or doc.get("collection"))
        restricted = _truthy(meta.get("access-restricted-item")) or _truthy(
            doc.get("access-restricted-item")
        )
        borrow_only = restricted or bool(
            collections & BORROW_COLLECTIONS
        )
        publisher = _first(meta.get("publisher")) or _first(doc.get("publisher"))

        landing = DETAILS.format(identifier=identifier)
        downloads: list = []
        if not borrow_only and manifest:
            downloads = _item_files(identifier, manifest)

        access = (
            Access.BORROW if borrow_only
            else Access.DOWNLOAD if downloads
            else Access.LANDING
        )
        downloads.append(
            target(
                landing,
                DownloadFormat.HTML,
                label="Internet Archive",
                open_access=not borrow_only,
            )
        )

        identifiers = {"ia": identifier}
        if manifest:
            for key in ("isbn", "oclc-id", "lccn", "identifier-access"):
                value = clean_text(meta.get(key))
                if value and key != "identifier-access":
                    identifiers["isbn" if key == "isbn" else key] = value
        for candidate in ("isbn", "oclc-id"):
            value = clean_text(doc.get(candidate))
            if value and candidate not in identifiers:
                identifiers[candidate] = value

        return Result(
            category=Category.BOOK,
            title=title,
            source=self.provider_id,
            authors=creators,
            year=year,
            abstract=self._summary(meta.get("description"), subjects, creators),
            venue=publisher,
            publisher=publisher,
            language=normalise_language(LANG_NAMES.get(language.lower(), language)),
            subjects=subjects[:8],
            identifiers=identifiers,
            access=access,
            downloads=downloads,
            landing_url=landing,
            cover_url=THUMB.format(identifier=identifier),
            item_type="Book",
            raw={"collection": collections, "borrow_only": borrow_only},
        )

    def _files(self, identifier: str, manifest: dict, title: str) -> list:
        """Backwards-compatible alias kept for callers outside this module."""
        return _item_files(identifier, manifest)

    @staticmethod
    def _summary(description: object, subjects: list[str], authors: list[str]) -> str:
        parts: list[str] = []
        text = clean_text(description)
        if text:
            # IA descriptions are sometimes multi-paragraph HTML-ish blobs.
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s+", " ", text).strip()
            parts.append(text)
        meta: list[str] = []
        if authors:
            meta.append(", ".join(authors[:2]))
        if subjects:
            meta.append(", ".join(subjects[:5]))
        if meta:
            parts.append(" · ".join(meta))
        return truncate_words(" ".join(parts), 320)


def _item_files(identifier: str, manifest: dict) -> list:
    """Real files for a single-book item, or ``[]`` for a compilation."""
    candidates: list[tuple[int, dict, DownloadFormat]] = []
    for entry in manifest.get("files") or []:
        name = clean_text(entry.get("name"))
        if not name or entry.get("private"):
            continue
        lowered = name.lower()
        if any(part in lowered for part in SKIP_NAME_PARTS):
            continue
        fmt = FILE_FORMATS.get(clean_text(entry.get("format")).lower())
        if fmt is None:
            if lowered.endswith(".pdf"):
                fmt = DownloadFormat.PDF
            elif lowered.endswith(".epub"):
                fmt = DownloadFormat.EPUB
            else:
                continue
        # Prefer the uploaded original over IA's re-encoded derivative.
        rank = 0 if entry.get("source") == "original" else 1
        candidates.append((rank, entry, fmt))

    if not candidates or len(candidates) > MAX_FILES_FOR_BOOK:
        return []

    candidates.sort(
        key=lambda item: (
            0 if item[2] is DownloadFormat.PDF else 1,
            item[0],
            -as_int(item[1].get("size")) or 0,
        )
    )
    out: list = []
    seen_formats: set[DownloadFormat] = set()
    for _rank, entry, fmt in candidates:
        if fmt in seen_formats:
            continue
        seen_formats.add(fmt)
        name = clean_text(entry.get("name"))
        out.append(
            target(
                f"https://archive.org/download/{identifier}/{quote(name)}",
                fmt,
                label=f"{fmt.value.upper()} ({_mb(entry.get('size'))})",
                open_access=True,
            )
        )
        if len(seen_formats) >= 2:
            break
    return out


def resolve_open_files(
    identifier: str, title: str = "", http=None
) -> list | None:
    """The open PDF/EPUB files an archive.org item can really download.

    Used by the downloader to enrich a book that only carries a landing page
    (the search behaves fast by not resolving every item's manifest): when the
    user asks to "read" such a book we resolve it and download the file when one
    exists, instead of opening the site. Returns ``None`` when there is nothing
    to fetch (borrow-only, compilation, or a network failure).
    """
    if not identifier:
        return None
    from app.core.http_client import get_http

    try:
        manifest = (http or get_http()).get_json(
            METADATA_ENDPOINT.format(identifier=quote(identifier)),
            provider="internet_archive",
        )
    except Exception:  # noqa: BLE001 - an unreachable manifest keeps the landing page
        return None
    if not manifest:
        return None
    meta = manifest.get("metadata") or {}
    borrow_only = _truthy(meta.get("access-restricted-item")) or bool(
        _strings(meta.get("collection")) & BORROW_COLLECTIONS
    )
    if borrow_only:
        return None
    files = _item_files(identifier, manifest)
    return files or None


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _first(value: object) -> str:
    """First non-empty value of a string or list field (IA uses both)."""
    if value is None:
        return ""
    if isinstance(value, str):
        return clean_text(value)
    if isinstance(value, (list, tuple, set)):
        for item in value:
            text = clean_text(item)
            if text:
                return text
        return ""
    return clean_text(value)


def _strings(value: object) -> set[str]:
    if value is None:
        return set()
    if isinstance(value, str):
        return {value.strip().lower()} if value.strip() else set()
    if isinstance(value, (list, tuple, set)):
        return {str(v).strip().lower() for v in value if str(v).strip()}
    return set()


def _truthy(value: object) -> bool:
    if value is None or value is False:
        return False
    if isinstance(value, str):
        return value.strip().lower() in ("true", "1", "yes")
    return bool(value)


def _creators(value: object) -> list[str]:
    if not value:
        return []
    if isinstance(value, str):
        # IA often packs several creators into one "a; b" string.
        parts = re.split(r"\s*;\s*", value)
    else:
        parts = [str(v) for v in value]
    out: list[str] = []
    for part in parts:
        name = clean_text(part)
        # Strip IA's disambiguator, e.g. "Smith, John (1900-1980)".
        name = re.sub(r"\s*\([^)]*\)\s*$", "", name).strip()
        if name and name not in out:
            out.append(name)
    return out[:6]


def _subjects(value: object) -> list[str]:
    if not value:
        return []
    if isinstance(value, str):
        parts = re.split(r"\s*;\s*", value)
    else:
        parts = [str(v) for v in value]
    out: list[str] = []
    for part in parts:
        topic = clean_text(part)
        if topic and topic.lower() not in {t.lower() for t in out}:
            out.append(topic)
    return out[:10]


def _mb(size: object) -> str:
    value = as_int(size)
    if not value:
        return "?"
    if value >= 1024 * 1024:
        return f"{value / (1024 * 1024):.1f} MB"
    return f"{max(1, value // 1024)} KB"
