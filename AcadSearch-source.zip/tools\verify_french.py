"""Does a French-language search actually return French references?

    python -X utf8 -m tools.verify_french
"""

from __future__ import annotations

import queue
import time

from app.config import Config
from app.core.search_engine import SearchEventType, get_engine
from app.models import Category, SearchQuery

FRENCH_MARKERS = {
    "le", "la", "les", "des", "une", "du", "de", "et", "pour", "dans",
    "sur", "avec", "aux", "au", "par", "est", "nous", "cette", "étude",
    "recherche", "apprentissage", "automatique", "science", "données",
}


def french_score(text: str) -> int:
    words = {w.strip(".,;:!?").lower() for w in text.split()}
    return len(words & FRENCH_MARKERS)


def main() -> int:
    cfg = Config()
    query = SearchQuery(
        text="apprentissage automatique",
        language="fr",
        categories={Category.BOOK, Category.ARTICLE, Category.RESEARCH},
        per_source=5,
    )
    print(f"query    : {query.text!r}  language={query.language!r}")
    print("=" * 72)

    engine = get_engine()
    handle = engine.start(query)
    while not handle.done and time.monotonic() - handle.started_at < 120:
        try:
            handle.events.get_nowait()
        except queue.Empty:
            time.sleep(0.05)

    final = None
    while True:
        try:
            ev = handle.events.get_nowait()
        except queue.Empty:
            break
        if ev.type is SearchEventType.FINISHED and ev.response:
            final = ev.response

    if final is None:
        print("no response")
        return 1

    results = [r for g in final.results.values() for r in g]
    print(f"results  : {len(results)}  in {final.elapsed:.1f}s")
    print("\nper-provider:")
    for rep in sorted(final.reports, key=lambda r: r.provider_id):
        print(f"  {rep.provider_id:18} {rep.status.value:10} count={rep.count}")

    if not results:
        print("\nNO RESULTS for a French query - this is a problem.")
        return 1

    print("\nresults with the declared language:")
    by_lang: dict[str, int] = {}
    for r in results:
        by_lang[r.language or "?"] = by_lang.get(r.language or "?", 0) + 1
    for lang, n in sorted(by_lang.items(), key=lambda kv: -kv[1]):
        print(f"  {lang:10} {n}")

    print("\nsample titles:")
    for r in results[:6]:
        blob = f"{r.title} {r.venue or ''} {' '.join(r.subjects)}"
        print(f"  [{r.source:14}] lang={r.language or '?':8} "
              f"fr_score={french_score(blob):2}  {r.title[:56]!r}")

    scored = [(french_score(f"{r.title} {r.venue or ''}"), r) for r in results]
    hits = [r for s, r in scored if s > 0]
    print(f"\nresults with French wording: {len(hits)}/{len(results)}")

    # Does the language filter reach the providers at all?
    passed = [r for r in results if r.language == "fr"]
    print(f"results tagged language == 'fr': {len(passed)}")
    if passed:
        print("\nexamples tagged 'fr':")
        for r in passed[:5]:
            print(f"  [{r.source:14}] {r.title[:60]!r}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
