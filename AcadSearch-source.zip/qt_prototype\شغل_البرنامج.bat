@echo off
REM Runs the new accessible Qt interface, empty and ready to search.
REM Double-click this file, or press Enter on it from the file list.

chcp 65001 >nul
cd /d "D:\projects\برنامج بحث علمي\qt_prototype"

where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "D:\projects\برنامج بحث علمي\qt_prototype\run_app.py"
) else (
    start "" python "D:\projects\برنامج بحث علمي\qt_prototype\run_app.py"
)

echo AcadSearch Qt interface is starting...