"""DUMAS — French Master's theses (open access).

DUMAS (Dépôt Universitaire de Mémoires Après Soutenance) is hosted
by CCSD/HAL and contains French Master's dissertations freely
available online.
"""

from __future__ import annotations

import re
import threading

from app.core.text_utils import as_int, clean_text, truncate_words
from app.models import (
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

ENDPOINT = "https://api.archives-ouvertes.fr/search/"

FIELDS = ",".join(
    (
        "halId_s",
        "title_s",
        "authFullName_s",
        "producedDateY_i",
        "producedDate_s",
        "uri_s",
        "fileMain_s",
        "files_s",
        "docType_s",
        "language_s",
        "abstract_s",
        "doiId_s",
        "school_s",
        "collCode_s",
    )
)

_TAG_RE = re.compile(r"<[^>]+>")


@register
class DumasProvider(BaseProvider):
    provider_id = "dumas"
    display_name = "DUMAS (مذكرات ماجستير فرنسية)"
    categories = (Category.RESEARCH,)
    weight = 37
    homepage = "https://dumas.ccsd.cnrs.fr/"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = query.text.strip()
        if not text:
            return []

        if cancel is not None and cancel.is_set():
            return []

        solr = f'collCode_s:DUMAS AND (title_t:"{text}" OR abstract_t:"{text}")'
        if query.language and query.language != "any":
            solr += f" AND language_s:{query.language}"
        if query.year_from or query.year_to:
            low = query.year_from or 1500
            high = query.year_to or 2100
            solr += f" AND producedDateY_i:[{low} TO {high}]"

        params = {
            "q": solr,
            "fl": FIELDS,
            "rows": str(max(10, min(query.per_source, 80))),
            "wt": "json",
        }

        try:
            payload = self.http.get_json(
                ENDPOINT, params=params, provider=self.provider_id, cancel=cancel
            )
        except ProviderError:
            raise
        except Exception as exc:
            raise ProviderError(f"dumas: {type(exc).__name__}", kind="error") from exc

        if cancel is not None and cancel.is_set():
            return []

        docs = ((payload or {}).get("response") or {}).get("docs") or []
        out: list[Result] = []
        for doc in docs:
            built = self._to_result(doc)
            if built is not None:
                out.append(built)
        return out

    def _to_result(self, doc: dict) -> Result | None:
        titles = _as_list(doc.get("title_s"))
        languages = _as_list(doc.get("language_s"))
        title = self._pick_title(titles, languages)
        if not title:
            return None

        authors = [clean_text(a) for a in _as_list(doc.get("authFullName_s"))]
        authors = [a for a in authors if a]

        year = as_int(doc.get("producedDateY_i"))
        if year is None:
            year = as_int(clean_text(doc.get("producedDate_s") or "")[:4])

        pdf = self._pick_pdf(doc)
        landing = clean_text(doc.get("uri_s") or "")

        identifiers: dict[str, str] = {"source": self.provider_id}
        hal_id = clean_text(doc.get("halId_s") or "")
        if hal_id:
            identifiers["hal"] = hal_id
        doi = clean_text(doc.get("doiId_s") or "")
        if doi:
            identifiers["doi"] = doi

        downloads = []
        if pdf:
            downloads.append(target(pdf, DownloadFormat.PDF, label="PDF", open_access=True))
        if landing:
            downloads.append(target(landing, DownloadFormat.HTML, label="DUMAS", open_access=True))

        language = clean_text(languages[0]) if languages else "fr"
        abstract = ""
        abs_list = _as_list(doc.get("abstract_s"))
        if abs_list:
            abstract = truncate_words(_strip_html(clean_text(abs_list[0])), 90)

        return Result(
            category=Category.RESEARCH,
            title=title,
            source=self.provider_id,
            authors=authors[:12],
            year=year,
            abstract=abstract,
            venue=clean_text(doc.get("school_s") or "DUMAS"),
            language=language,
            identifiers=identifiers,
            downloads=downloads,
            landing_url=landing or pdf or "",
        )

    def _pick_title(self, titles: list[str], languages: list[str]) -> str:
        cleaned = [clean_text(t) for t in titles if clean_text(t)]
        if not cleaned:
            return ""
        wanted = languages[0] if languages else ""
        from app.core.text_utils import detect_script_languages
        for title in cleaned:
            if wanted and detect_script_languages(title) == wanted:
                return title
        return cleaned[0]

    def _pick_pdf(self, doc: dict) -> str:
        files = [clean_text(f) for f in _as_list(doc.get("files_s"))]
        for url in files:
            if url.lower().split("?")[0].endswith(".pdf"):
                return url
        return clean_text(doc.get("fileMain_s") or "")


def _as_list(value: object) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [v for v in value if isinstance(v, (str, int))]
    return [value]


def _strip_html(value: str) -> str:
    if "<" not in value:
        return value
    text = _TAG_RE.sub(" ", value)
    return clean_text(text.replace("&nbsp;", " "))
