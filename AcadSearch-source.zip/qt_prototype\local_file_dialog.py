"""Cite a document that is already on the user's disk.

Selecting a PDF/Word file opens this form: the fields the file could tell us
about are pre-filled, everything else is left for the user to type, and the
citation preview updates as they edit. Nothing is uploaded; the file is only
read locally.

The copy button hands the formatted entry to the main window, which puts it in
the same read-only field and speaks the same confirmation as the per-card
"copy citation" action.
"""

from __future__ import annotations

import atexit
import time
from pathlib import Path

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtGui import QAccessible, QAccessibleEvent
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
)

from app import i18n
from app.config import get_config
from app.core.citation import STYLES, format_citation
from app.core.local_file import KINDS, build_result, extract_result

#: Live lookup threads. Kept here so closing the dialog cannot destroy a
#: running QThread (which aborts the process); each removes itself when done.
_LOOKUPS: set["_LookupWorker"] = set()
#: Same rule for the assistant: a running QThread must outlive the dialog.
_AI_TASKS: set["_AIWorker"] = set()


def _stop_workers(tasks: set[QThread], timeout_ms: int = 2000) -> None:
    """Stop every still-running worker, then forget it.

    Qt aborts the process when a running ``QThread`` is destroyed, which is
    what made the dialog look like it had closed while the process crashed on
    exit. Interruption is cooperative (the network call has a timeout), so a
    worker that does not stop in time is terminated as a last resort -- at
    shutdown there is nothing left for it to finish safely.
    """
    workers = list(tasks)
    for worker in workers:
        try:
            worker.requestInterruption()
        except RuntimeError:  # already deleted by Qt
            pass
    for worker in workers:
        try:
            if worker.isRunning():
                worker.wait(timeout_ms)
        except RuntimeError:
            pass
    for worker in workers:
        try:
            if worker.isRunning():
                worker.terminate()
                worker.wait(1000)
        except RuntimeError:
            pass
    tasks.clear()


def stop_background_tasks() -> None:
    """Called at process exit so no live thread outlives the Qt application."""
    _stop_workers(_AI_TASKS)
    _stop_workers(_LOOKUPS)


atexit.register(stop_background_tasks)


def _announce(widget, text: str) -> None:
    """Speak a status change without stealing focus, like the main window."""
    widget.setAccessibleName(text)
    for kind in (
        QAccessible.Event.NameChanged,
        QAccessible.Event.Alert,
    ):
        try:
            QAccessible.updateAccessibility(QAccessibleEvent(widget, kind))
        except (RuntimeError, TypeError):
            pass


class _LookupWorker(QThread):
    """Read the PDF text layer and fetch DOI/ISBN metadata off the GUI thread."""

    done = Signal(object)

    def __init__(self, path: Path):
        super().__init__()
        self._path = Path(path)

    def run(self) -> None:
        fields: dict = {}
        try:
            from app.core.local_lookup import enrich_from_file

            fields = enrich_from_file(
                self._path, should_stop=self.isInterruptionRequested
            )
        except Exception:  # noqa: BLE001 - a hiccup must never crash the dialog
            fields = {}
        self.done.emit(fields)


class _AIWorker(QThread):
    """Read the whole file and ask Gemini for a summary or an answer."""

    done_ok = Signal(object)
    done_fail = Signal(str, dict)
    #: Progress key and its placeholders, emitted from the worker thread. A
    #: scanned book takes minutes, so the dialog must be able to say what is
    #: happening while it happens; a silent answer box reads as "broken".
    progress = Signal(str, dict)

    def __init__(self, path: Path, question: str):
        super().__init__()
        self._path = Path(path)
        self._question = question

    def run(self) -> None:
        try:
            from app.core.doc_ai import DocAIError, ask, summarize
        except Exception:  # noqa: BLE001 - missing module: keep the dialog alive
            self.done_fail.emit("ai.error.generic", {})
            return

        def report(key: str, params: dict) -> None:
            if not self.isInterruptionRequested():
                self.progress.emit(key, dict(params))

        try:
            if self._question:
                answer = ask(
                    self._path,
                    self._question,
                    should_stop=self.isInterruptionRequested,
                    progress=report,
                )
            else:
                answer = summarize(
                    self._path,
                    should_stop=self.isInterruptionRequested,
                    progress=report,
                )
        except DocAIError as exc:
            self.done_fail.emit(exc.key, dict(exc.params))
            return
        except Exception:  # noqa: BLE001 - a hiccup must never crash the dialog
            self.done_fail.emit("ai.error.generic", {})
            return
        if not self.isInterruptionRequested():
            self.done_ok.emit(answer)


class LocalFileDialog(QDialog):
    """Editable bibliographic form built from a local file's own metadata."""

    citation_copied = Signal(str, str)  # (formatted text, style key)

    def __init__(self, path: str | Path, parent=None):
        super().__init__(parent)
        self._path = Path(path)
        record = extract_result(self._path)
        kind = str(record.raw.get("kind") or "book")
        self._kind = kind

        self.setWindowTitle(i18n.t("local.window.title"))
        self.setAccessibleName(i18n.t("local.window.accessible"))
        if i18n.is_rtl():
            self.setLayoutDirection(Qt.RightToLeft)
        self.resize(780, 780)
        self.setMinimumWidth(620)

        root = QVBoxLayout(self)

        intro = QLabel(i18n.t("local.autofill_note"))
        intro.setObjectName("HelpText")
        intro.setWordWrap(True)
        intro.setAccessibleName("")
        root.addWidget(intro)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight if i18n.is_rtl() else Qt.AlignLeft)
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)

        self.title_edit = self._line(record.title, "local.field.title")
        self.authors_edit = self._line("; ".join(record.authors), "local.field.authors")
        self.year_edit = self._line(str(record.year) if record.year else "", "local.field.year")
        self.venue_edit = self._line(record.venue or record.publisher, "local.field.venue")
        self.doi_edit = self._line(record.identifiers.get("doi", ""), "local.field.doi")

        self.kind_combo = QComboBox()
        for choice in KINDS:
            self.kind_combo.addItem(i18n.t(f"local.kind.{choice}"), choice)
        self.kind_combo.setCurrentIndex(max(0, KINDS.index(kind)) if kind in KINDS else 0)
        self.kind_combo.setAccessibleName(i18n.t("local.field.kind"))

        self.style_combo = QComboBox()
        for style in STYLES:
            self.style_combo.addItem(i18n.citation_style_label(style), style)
        current_style = get_config().citation_style
        if current_style in STYLES:
            self.style_combo.setCurrentIndex(STYLES.index(current_style))
        self.style_combo.setAccessibleName(i18n.t("local.field.style"))

        form.addRow(self._label("local.field.title"), self.title_edit)
        form.addRow(self._label("local.field.authors"), self.authors_edit)
        form.addRow(self._label("local.field.year"), self.year_edit)
        form.addRow(self._label("local.field.venue"), self.venue_edit)
        form.addRow(self._label("local.field.doi"), self.doi_edit)
        form.addRow(self._label("local.field.kind"), self.kind_combo)
        form.addRow(self._label("local.field.style"), self.style_combo)
        root.addLayout(form)

        preview_label = QLabel(i18n.t("local.preview.label"))
        preview_label.setObjectName("HelpGroup")
        preview_label.setAccessibleName("")
        root.addWidget(preview_label)

        self.preview = QPlainTextEdit()
        self.preview.setObjectName("CitationPreview")
        self.preview.setReadOnly(True)
        self.preview.setMaximumHeight(120)
        self.preview.setAccessibleName(i18n.t("local.preview.accessible"))
        root.addWidget(self.preview)

        self.status = QLabel("")
        self.status.setObjectName("StatusLabel")
        self.status.setWordWrap(True)
        self.status.setAccessibleName("")
        root.addWidget(self.status)

        copy_row = QHBoxLayout()
        copy_row.addStretch(1)
        self.copy_btn = QPushButton(i18n.t("local.copy"))
        self.copy_btn.setObjectName("PrimaryButton")
        self.copy_btn.setAccessibleName(i18n.t("local.copy"))
        self.copy_btn.setToolTip(i18n.t("local.copy.tooltip"))
        self.copy_btn.clicked.connect(self._copy)
        copy_row.addWidget(self.copy_btn)
        root.addLayout(copy_row)

        # ---- file assistant: read the document, summarise it, answer ----
        # Deliberately under the copy button: citing the file and *reading* it
        # are the same visit, and a screen-reader user reaches the question box
        # right after the citation they just copied.
        assistant_label = QLabel(i18n.t("local.ai.title"))
        assistant_label.setObjectName("HelpGroup")
        assistant_label.setAccessibleName("")
        root.addWidget(assistant_label)

        self.ai_view = QPlainTextEdit()
        self.ai_view.setObjectName("AssistantAnswer")
        self.ai_view.setReadOnly(True)
        self.ai_view.setMaximumHeight(180)
        self.ai_view.setAccessibleName(i18n.t("local.ai.answer_accessible"))
        self.ai_view.setPlaceholderText(i18n.t("local.ai.answer_placeholder"))
        root.addWidget(self.ai_view)

        self.ai_note = QLabel(i18n.t("local.ai.privacy"))
        self.ai_note.setObjectName("HelpText")
        self.ai_note.setWordWrap(True)
        self.ai_note.setAccessibleName("")
        root.addWidget(self.ai_note)

        ask_row = QHBoxLayout()
        self.question_edit = QLineEdit()
        self.question_edit.setAccessibleName(i18n.t("local.ai.question_accessible"))
        self.question_edit.setPlaceholderText(i18n.t("local.ai.question_placeholder"))
        self.question_edit.returnPressed.connect(self._ask)
        ask_row.addWidget(self.question_edit, 1)

        self.ask_btn = QPushButton(i18n.t("local.ai.ask"))
        self.ask_btn.setAccessibleName(i18n.t("local.ai.ask"))
        self.ask_btn.clicked.connect(self._ask)
        ask_row.addWidget(self.ask_btn)

        self.summarize_btn = QPushButton(i18n.t("local.ai.summarize"))
        self.summarize_btn.setAccessibleName(i18n.t("local.ai.summarize"))
        self.summarize_btn.clicked.connect(self._summarize)
        ask_row.addWidget(self.summarize_btn)

        # A missing key used to be a dead end: the status line said to open
        # Preferences, but the dialog swallowed the reader's place. The button
        # opens the same dialog in place, then lets them ask without closing
        # and finding the file again.
        self.ai_setup_btn = QPushButton(i18n.t("local.ai.setup"))
        self.ai_setup_btn.setAccessibleName(i18n.t("local.ai.setup"))
        self.ai_setup_btn.setToolTip(i18n.t("local.ai.setup.tooltip"))
        self.ai_setup_btn.clicked.connect(self._open_preferences)
        ask_row.addWidget(self.ai_setup_btn)
        root.addLayout(ask_row)

        self.ai_status = QLabel("")
        self.ai_status.setObjectName("StatusLabel")
        self.ai_status.setWordWrap(True)
        self.ai_status.setAccessibleName("")
        root.addWidget(self.ai_status)

        footer = QHBoxLayout()
        footer.addStretch(1)
        self.close_btn = QPushButton(i18n.t("local.close"))
        self.close_btn.setAccessibleName(i18n.t("local.close"))
        # This dialog is a form, not a question with an "accept" answer: Close
        # and the window X both mean "leave", never "finished, use my edits".
        # Connecting Close to accept made it look like a save button and, when
        # a lookup was still running, could leave the caller waiting.
        self.close_btn.clicked.connect(self.reject)
        footer.addWidget(self.close_btn)
        root.addLayout(footer)

        for widget in (self.title_edit, self.authors_edit, self.year_edit,
                       self.venue_edit, self.doi_edit):
            widget.textChanged.connect(self._refresh)
        self.kind_combo.currentIndexChanged.connect(self._refresh)
        self.style_combo.currentIndexChanged.connect(self._refresh)

        self._refresh()
        self._sync_ai_setup()

        self._worker: _LookupWorker | None = None
        self._ai_worker: _AIWorker | None = None
        self._closed = False
        # The answer box is where the reader listens, so "still working" and
        # the elapsed time belong there: the status line sits below the
        # buttons and an empty box reads as "nothing happened".
        self._ai_stage = ""
        self._ai_started = 0.0
        self._ai_timer = QTimer(self)
        self._ai_timer.setInterval(5000)
        self._ai_timer.timeout.connect(self._tick_ai_progress)
        self._initial_title = self.title_edit.text()
        self._title_is_placeholder = record.raw.get("title_source") == "filename"
        self._needs_lookup = (
            self._title_is_placeholder
            or not self.authors_edit.text().strip()
            or not self.year_edit.text().strip()
        )
        if self._needs_lookup:
            self._start_lookup()

    # -- helpers ---------------------------------------------------------
    @staticmethod
    def _label(key: str) -> QLabel:
        label = QLabel(i18n.t(key))
        label.setAccessibleName("")
        return label

    @staticmethod
    def _line(value: str, key: str) -> QLineEdit:
        field = QLineEdit(value or "")
        field.setAccessibleName(i18n.t(key))
        return field


    def _start_lookup(self) -> None:
        self.status.setText(i18n.t("local.lookup.running"))
        _announce(self.status, i18n.t("local.lookup.running"))
        worker = _LookupWorker(self._path)
        _LOOKUPS.add(worker)
        worker.done.connect(self._apply_lookup)
        worker.finished.connect(lambda: _LOOKUPS.discard(worker))
        worker.finished.connect(worker.deleteLater)
        self._worker = worker
        worker.start()

    def _apply_lookup(self, fields: object) -> None:
        if self._closed:
            return
        fields = fields if isinstance(fields, dict) else {}
        changed = False
        title = str(fields.get("title") or "").strip()
        if (
            title
            and self._title_is_placeholder
            and self.title_edit.text() == self._initial_title
        ):
            self.title_edit.setText(title)
            self._title_is_placeholder = False
            changed = True
        if not self.authors_edit.text().strip():
            authors = fields.get("authors") or []
            if authors:
                self.authors_edit.setText(
                    "; ".join(str(author) for author in authors)
                )
                changed = True
        if not self.year_edit.text().strip() and fields.get("year"):
            self.year_edit.setText(str(fields["year"]))
            changed = True
        if not self.venue_edit.text().strip() and fields.get("venue"):
            self.venue_edit.setText(str(fields["venue"]))
            changed = True
        if not self.doi_edit.text().strip() and fields.get("doi"):
            self.doi_edit.setText(str(fields["doi"]))
            changed = True
        if changed:
            source = "DOI" if fields.get("source") == "doi" else "ISBN"
            message = i18n.t("local.lookup.found", source=source)
        else:
            message = i18n.t("local.lookup.none")
        self.status.setText(message)
        _announce(self.status, message)

    # -- file assistant --------------------------------------------------
    def _ask(self) -> None:
        question = self.question_edit.text().strip()
        if not question:
            self._ai_say(i18n.t("local.ai.empty_question"))
            self.question_edit.setFocus()
            return
        self._start_ai(question)

    def _summarize(self) -> None:
        self._start_ai("")

    def _ai_say(self, message: str) -> None:
        self.ai_status.setText(message)
        _announce(self.ai_status, message)

    def _sync_ai_setup(self) -> None:
        """Show the "add a key" button only while the key is actually missing."""
        from app.core import doc_ai

        self.ai_setup_btn.setVisible(not doc_ai.available())

    def _open_preferences(self) -> None:
        """Open Preferences here so the key can be added without losing the file."""
        try:
            from qt_prototype.preferences import PreferencesDialog
        except ImportError:  # running from inside qt_prototype
            from preferences import PreferencesDialog  # type: ignore[no-redef]

        dialog = PreferencesDialog(self, focus_key="gemini")
        if dialog.exec() != QDialog.Accepted:
            return
        dialog.apply_to_config()
        self._sync_ai_setup()
        if self._setup_ready():
            self._ai_say(i18n.t("local.ai.key_ready"))
            self.question_edit.setFocus()

    def _setup_ready(self) -> bool:
        from app.core import doc_ai

        return doc_ai.available()

    def _start_ai(self, question: str) -> None:
        if self._ai_worker is not None and self._ai_worker.isRunning():
            return
        from app.core import doc_ai

        if not doc_ai.available():
            message = i18n.t("local.ai.no_key")
            # Put the explanation where the answer would appear as well as in
            # the status line: the answer box is the thing the reader is
            # listening to, and an empty box reads as "nothing happened".
            self.ai_view.setPlainText(message)
            self._ai_say(message)
            self._sync_ai_setup()
            self.question_edit.setFocus()
            return
        self._set_ai_busy(True)
        self._ai_stage = i18n.t("local.ai.thinking")
        self._ai_started = time.monotonic()
        self._ai_timer.start()
        self._render_ai_progress(announce=True)
        worker = _AIWorker(self._path, question)
        _AI_TASKS.add(worker)
        worker.done_ok.connect(self._on_ai_ok)
        worker.done_fail.connect(self._on_ai_fail)
        worker.progress.connect(self._on_ai_progress)
        # Discard on ``finished`` rather than on either result signal: the
        # thread is still alive for a moment after it emits its answer, and
        # dropping it from the guard set then is what let it be destroyed
        # while running at exit.
        worker.finished.connect(lambda: _AI_TASKS.discard(worker))
        worker.finished.connect(worker.deleteLater)
        self._ai_worker = worker
        worker.start()

    def _on_ai_progress(self, key: str, params: object) -> None:
        """Say what the assistant is doing, in the box the reader listens to."""
        if self._closed:
            return
        values = params if isinstance(params, dict) else {}
        self._ai_stage = i18n.t(key, **values)
        self._render_ai_progress(announce=True)

    def _tick_ai_progress(self) -> None:
        if self._ai_worker is None:
            self._ai_timer.stop()
            return
        self._render_ai_progress(announce=False)

    def _render_ai_progress(self, announce: bool) -> None:
        """Show the stage plus elapsed time, so a long wait never looks dead."""
        elapsed = max(0, int(time.monotonic() - self._ai_started))
        clock = f"{elapsed // 60}:{elapsed % 60:02d}"
        text = f"{self._ai_stage}\n\n{i18n.t('local.ai.elapsed', time=clock)}"
        self.ai_view.setPlainText(text)
        if announce:
            _announce(self.ai_view, text.replace("\n\n", " — "))

    def _set_ai_busy(self, busy: bool) -> None:
        self.ask_btn.setEnabled(not busy)
        self.summarize_btn.setEnabled(not busy)

    def _on_ai_ok(self, answer: object) -> None:
        self._ai_worker = None
        self._ai_timer.stop()
        if self._closed:
            return
        self._set_ai_busy(False)
        text = str(getattr(answer, "text", "") or "")
        notes: list[str] = []
        images = int(getattr(answer, "images", 0) or 0)
        if images:
            notes.append(i18n.t("local.ai.images_read", n=images))
        if getattr(answer, "truncated", False):
            notes.append(i18n.t("local.ai.truncated"))
        if notes:
            text = (text + "\n\n" + "\n".join(notes)).strip()
        self.ai_view.setPlainText(text)
        self._ai_say(i18n.t("local.ai.ready"))

    def _on_ai_fail(self, key: str, params: object) -> None:
        self._ai_worker = None
        self._ai_timer.stop()
        if self._closed:
            return
        self._set_ai_busy(False)
        values = params if isinstance(params, dict) else {}
        message = i18n.t(key, **values)
        # A failure in the status line alone is easy to miss when the reader's
        # focus is still in the question box; show it where the answer would be.
        self.ai_view.setPlainText(message)
        self._ai_say(message)
        self._sync_ai_setup()
        if key in ("ai.error.bad_key", "ai.error.no_key"):
            self.ai_setup_btn.setVisible(True)

    def _detach_worker(self, worker) -> None:
        """Drop the dialog's slots from a worker that is being abandoned."""
        for signal, slot in (
            (getattr(worker, "done", None), self._apply_lookup),
            (getattr(worker, "done_ok", None), self._on_ai_ok),
            (getattr(worker, "done_fail", None), self._on_ai_fail),
        ):
            if signal is None:
                continue
            try:
                signal.disconnect(slot)
            except (RuntimeError, TypeError):
                pass

    def done(self, result: int) -> None:
        self._closed = True
        self._ai_timer.stop()
        for worker in (self._worker, self._ai_worker):
            if worker is not None:
                try:
                    worker.requestInterruption()
                except RuntimeError:
                    pass
                self._detach_worker(worker)
        self._worker = None
        self._ai_worker = None
        super().done(result)

    def current_result(self):
        kind = self.kind_combo.currentData() or "book"
        year_text = self.year_edit.text().strip()
        year = int(year_text) if year_text.isdigit() else None
        authors = [
            part.strip()
            for part in self.authors_edit.text().split(";")
            if part.strip()
        ]
        return build_result(
            self._path,
            kind,
            title=self.title_edit.text(),
            authors=authors,
            year=year,
            venue=self.venue_edit.text(),
            doi=self.doi_edit.text(),
        )

    def _refresh(self) -> None:
        style = self.style_combo.currentData() or "apa"
        result = self.current_result()
        try:
            text = format_citation(result, style) if result.title else ""
        except Exception:  # noqa: BLE001 - a half-typed field must not crash
            text = ""
        self.preview.setPlainText(text)
        self.copy_btn.setEnabled(bool(result.title.strip()))

    def _copy(self) -> None:
        result = self.current_result()
        if not result.title.strip():
            self.status.setText(i18n.t("local.need_title"))
            return
        style = self.style_combo.currentData() or "apa"
        text = format_citation(result, style)
        QApplication.clipboard().setText(text)
        self.status.setText(
            i18n.t("local.copied", style=i18n.citation_style_label(style))
        )
        self.citation_copied.emit(text, style)
