"""Domain models shared by the providers, the search engine and the UI.

Everything the UI renders is normalised into :class:`Result`, so adding a new
data source never requires touching the GUI.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable


class Category(str, Enum):
    """The three result sections shown in the UI."""

    BOOK = "book"
    ARTICLE = "article"
    RESEARCH = "research"  # theses, dissertations, datasets, preprints


class Access(str, Enum):
    """How (and whether) full text can be obtained."""

    DOWNLOAD = "download"      # a direct PDF/EPUB link exists
    LANDING = "landing"        # user must use the publisher/source page
    BORROW = "borrow"          # lending library (Internet Archive)
    METADATA = "metadata"      # citation/record only, no full text


class DownloadFormat(str, Enum):
    PDF = "pdf"
    EPUB = "epub"
    HTML = "html"
    ZIP = "zip"
    SOURCE = "source"          # a landing page rather than a file


@dataclass(slots=True)
class DownloadTarget:
    """A single actionable link on a result card."""

    url: str
    fmt: DownloadFormat = DownloadFormat.SOURCE
    label: str = ""
    # True when the endpoint is a known-open repository (arXiv, IA, PMC, ...).
    open_access: bool = False
    size_hint: int | None = None

    @property
    def extension(self) -> str:
        if self.fmt is DownloadFormat.SOURCE:
            return ""
        return f".{self.fmt.value}"


@dataclass(slots=True)
class Author:
    name: str
    orcid: str | None = None

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.name


@dataclass
class Result:
    """A normalised bibliographic record."""

    category: Category
    title: str
    source: str                       # provider id, e.g. "semantic_scholar"
    authors: list[str] = field(default_factory=list)
    year: int | None = None
    abstract: str = ""
    venue: str = ""                   # journal, publisher or university
    language: str = ""                # ISO-639-1/3 code or natural name
    subjects: list[str] = field(default_factory=list)
    identifiers: dict[str, str] = field(default_factory=dict)
    access: Access = Access.METADATA
    downloads: list[DownloadTarget] = field(default_factory=list)
    landing_url: str = ""
    cover_url: str | None = None
    citations: int | None = None
    rating: float | None = None
    pages: int | None = None
    volume: str = ""
    issue: str = ""
    publisher: str = ""
    editors: list[str] = field(default_factory=list)
    edition: str = ""
    item_type: str = ""               # e.g. "JournalArticle", "Thesis", "Book"
    raw: dict[str, Any] = field(default_factory=dict, repr=False)
    score: float = 0.0

    # -- derived helpers -------------------------------------------------
    @property
    def uid(self) -> str:
        """Stable identity used to de-duplicate across providers."""
        basis = (
            self.identifiers.get("doi")
            or self.identifiers.get("arxiv")
            or self.identifiers.get("openalex")
            or self.identifiers.get("olid")
            or self.identifiers.get("nnt")      # Sudoc French thesis number
            or self.identifiers.get("isbn")
            or self.identifiers.get("ppn")      # Sudoc catalogue record
            or f"{self.title.strip().lower()}|{(self.authors or [''])[0].lower()}"
        )
        return hashlib.sha1(basis.encode("utf-8", "ignore")).hexdigest()[:16]

    @property
    def primary_download(self) -> DownloadTarget | None:
        """The best link to offer first on the card."""
        if not self.downloads:
            return None
        order = {
            DownloadFormat.PDF: 0,
            DownloadFormat.EPUB: 1,
            DownloadFormat.ZIP: 2,
            DownloadFormat.HTML: 3,
            DownloadFormat.SOURCE: 4,
        }
        return sorted(
            self.downloads,
            key=lambda d: (not d.open_access, order.get(d.fmt, 9)),
        )[0]

    def author_line(self, limit: int = 4) -> str:
        if not self.authors:
            return ""
        if len(self.authors) <= limit:
            return ", ".join(self.authors)
        return ", ".join(self.authors[:limit]) + " et al."

    def citation_string(self) -> str:
        """A quick copy/paste citation in a plain, widely accepted style."""
        parts = [self.author_line(3) or "-", f"({self.year or 'n.d.'}).", self.title + "."]
        if self.venue:
            parts.append(self.venue + ".")
        doi = self.identifiers.get("doi")
        if doi:
            parts.append(f"https://doi.org/{doi}")
        return " ".join(p for p in parts if p)

    def suggested_filename(self) -> str:
        stem = self.title or "document"
        stem = re.sub(r"[\\/:*?\"<>|\r\n\t]+", " ", stem)
        stem = re.sub(r"\s+", " ", stem).strip(" .")
        stem = stem[:110] or "document"
        target = self.primary_download
        ext = target.extension if target else ".pdf"
        return f"{stem}{ext}"


# ---------------------------------------------------------------------------
# Query / response containers
# ---------------------------------------------------------------------------

#: Language filter options exposed in the UI. ``any`` disables filtering.
LANGUAGES: tuple[tuple[str, str, str], ...] = (
    # (code, english name, native name)
    ("any", "All languages", "كل اللغات"),
    ("ar", "Arabic", "العربية"),
    ("en", "English", "الإنجليزية"),
    ("fr", "French", "الفرنسية"),
    ("de", "German", "الألمانية"),
    ("es", "Spanish", "الإسبانية"),
    ("it", "Italian", "الإيطالية"),
    ("pt", "Portuguese", "البرتغالية"),
    ("ru", "Russian", "الروسية"),
    ("zh", "Chinese", "الصينية"),
    ("ja", "Japanese", "اليابانية"),
    ("ko", "Korean", "الكورية"),
    ("tr", "Turkish", "التركية"),
    ("fa", "Persian", "الفارسية"),
    ("ur", "Urdu", "الأردية"),
    ("he", "Hebrew", "العبرية"),
    ("hi", "Hindi", "الهندية"),
    ("nl", "Dutch", "الهولندية"),
    ("pl", "Polish", "البولندية"),
    ("sv", "Swedish", "السويدية"),
    ("id", "Indonesian", "الإندونيسية"),
)

LANGUAGE_NAMES: dict[str, str] = {code: en for code, en, _ in LANGUAGES}


@dataclass
class SearchQuery:
    """A user-issued search request."""

    text: str
    language: str = "any"
    per_source: int = 10
    year_from: int | None = None
    year_to: int | None = None
    categories: set[Category] = field(
        default_factory=lambda: {Category.BOOK, Category.ARTICLE, Category.RESEARCH}
    )

    def __post_init__(self) -> None:
        self.text = (self.text or "").strip()
        if self.per_source < 1:
            self.per_source = 1
        self.per_source = min(self.per_source, 40)

    @property
    def year_range(self) -> tuple[int | None, int | None]:
        return self.year_from, self.year_to

    def matches_year(self, year: int | None) -> bool:
        if year is None:
            return True
        if self.year_from and year < self.year_from:
            return False
        if self.year_to and year > self.year_to:
            return False
        return True

    def cache_signature(self) -> str:
        return "|".join(
            [
                self.text.lower(),
                self.language,
                str(self.year_from or ""),
                str(self.year_to or ""),
                ",".join(sorted(c.value for c in self.categories)),
            ]
        )


class ProviderStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    OK = "ok"
    EMPTY = "empty"
    ERROR = "error"
    SKIPPED = "skipped"
    DISABLED = "disabled"


@dataclass
class ProviderReport:
    """Per-provider outcome, surfaced as a status chip in the UI."""

    provider_id: str
    status: ProviderStatus = ProviderStatus.PENDING
    count: int = 0
    seconds: float = 0.0
    message: str = ""

    @property
    def failed(self) -> bool:
        return self.status is ProviderStatus.ERROR


@dataclass
class SearchResponse:
    """Everything produced by one search run."""

    query: SearchQuery
    results: dict[Category, list[Result]] = field(default_factory=dict)
    reports: list[ProviderReport] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    elapsed: float = 0.0
    truncated: bool = False

    def by_category(self, category: Category) -> list[Result]:
        return self.results.get(category, [])

    def total(self) -> int:
        return sum(len(v) for v in self.results.values())

    def reports_for(self, category: Category) -> list[ProviderReport]:
        """Reports from providers that actually serve this category."""
        from app.providers import providers_for_category

        ids = {p.provider_id for p in providers_for_category(category)}
        return [r for r in self.reports if r.provider_id in ids]


def dedupe(results: Iterable[Result]) -> list[Result]:
    """Drop duplicate records, keeping the richest one.

    The same paper routinely appears in Semantic Scholar, OpenAlex, Crossref
    and arXiv. We merge identifiers so the surviving card keeps every link.
    """
    merged: dict[str, Result] = {}
    order: list[str] = []
    for item in results:
        key = item.uid
        existing = merged.get(key)
        if existing is None:
            merged[key] = item
            order.append(key)
            continue

        # Prefer the record with more information.
        if _richness(item) > _richness(existing):
            keep, drop = item, existing
        else:
            keep, drop = existing, item

        keep.identifiers = {**drop.identifiers, **keep.identifiers}
        keep.downloads = _merge_downloads(keep.downloads, drop.downloads)
        keep.subjects = list(dict.fromkeys(keep.subjects + drop.subjects))
        keep.authors = keep.authors or drop.authors
        keep.abstract = keep.abstract or drop.abstract
        keep.venue = keep.venue or drop.venue
        keep.cover_url = keep.cover_url or drop.cover_url
        keep.citations = max(x for x in (keep.citations, drop.citations) if x is not None) \
            if (keep.citations is not None or drop.citations is not None) else None
        keep.landing_url = keep.landing_url or drop.landing_url
        keep.score = max(keep.score, drop.score)
        if drop.access != keep.access:
            order_rank = {
                Access.DOWNLOAD: 0,
                Access.BORROW: 1,
                Access.LANDING: 2,
                Access.METADATA: 3,
            }
            if order_rank[drop.access] < order_rank[keep.access]:
                keep.access = drop.access
        merged[key] = keep
    return [merged[k] for k in order]


def _merge_downloads(a: list[DownloadTarget], b: list[DownloadTarget]) -> list[DownloadTarget]:
    seen: set[str] = set()
    out: list[DownloadTarget] = []
    for target in list(a) + list(b):
        if target.url and target.url not in seen:
            seen.add(target.url)
            out.append(target)
    return out


def _richness(item: Result) -> tuple[int, int, int]:
    return (
        len(item.abstract),
        len(item.downloads),
        bool(item.year) + bool(item.venue) + bool(item.cover_url),
    )
