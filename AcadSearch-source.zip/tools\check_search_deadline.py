"""Search-deadline regression check: a stalled source must not hold the search.

Why this check exists
---------------------
A search fans out to every provider. One of them (OpenAIRE, observed in the
field) occasionally stalls on the server and burns its whole retry budget --
``timeout`` x ``max_retries`` plus back-off, about 80 seconds -- while the other
eleven sources have already answered. The user watches a search that already
holds 138 results on screen refuse to finish. The engine therefore stops
waiting at ``Config.search_deadline`` and reports the straggler as a timeout.

What is asserted
----------------
* A provider that never returns is reported as ``timeout``/ERROR.
* The sources that *did* answer keep their results: the deadline trims the tail,
  it never discards the search.
* The run finishes close to the deadline instead of the retry budget.
* Every planned provider is still accounted for, so nothing disappears silently.

Run: ``python -X utf8 tools/check_search_deadline.py`` (no network: the two
providers below are registered locally and answer from memory).
"""

from __future__ import annotations

import queue
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import get_config
from app.core.search_engine import SearchEngine, SearchEventType
from app.models import Category, ProviderStatus, Result, SearchQuery
from app.providers import base

FAILURES: list[str] = []


def check(label: str, ok: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" -- {detail}" if detail else ""))
    if not ok:
        FAILURES.append(label)


# -- two stand-in providers -------------------------------------------------
@base.register
class _FastProvider(base.BaseProvider):
    provider_id = "fake_fast"
    display_name = "Fake Fast"
    categories = (Category.ARTICLE,)
    weight = 50

    def available(self) -> bool:
        return True

    def fetch(self, query, cancel=None):  # noqa: ANN001, ANN201 - test double
        time.sleep(0.2)
        return [
            Result(
                category=Category.ARTICLE,
                title=f"Fast result {i}",
                source=self.provider_id,
                authors=["A. Author"],
                year=2020 + i,
            )
            for i in range(3)
        ]


@base.register
class _StalledProvider(base.BaseProvider):
    """Answers only when cancelled -- the OpenAIRE failure mode, on demand."""

    provider_id = "fake_stalled"
    display_name = "Fake Stalled"
    categories = (Category.ARTICLE,)
    weight = 10

    def available(self) -> bool:
        return True

    def fetch(self, query, cancel=None):  # noqa: ANN001, ANN201 - test double
        while cancel is not None and not cancel.is_set():
            time.sleep(0.05)
        return []


def run(deadline: float) -> tuple[float, object, dict]:
    """Run one search with only the two doubles planned, then restore."""
    cfg = get_config()
    previous = cfg.search_deadline
    cfg.search_deadline = deadline

    # ``@register`` runs when the class body executes, i.e. at import time, so
    # the two doubles are already in the registry by the time this runs. Swap
    # them in rather than re-registering: the decorator cannot fire twice, and
    # _ensure_loaded() imports the twelve real providers by name on first use.
    base.all_providers()  # force _ensure_loaded() before the swap
    saved_registry = dict(base._REGISTRY)  # noqa: SLF001
    saved_order = list(base._ORDER)  # noqa: SLF001
    doubles = {pid: saved_registry[pid] for pid in ("fake_fast", "fake_stalled")}
    base._REGISTRY.clear()  # noqa: SLF001 - process-local test registry only
    base._REGISTRY.update(doubles)  # noqa: SLF001
    base._ORDER[:] = list(doubles)  # noqa: SLF001

    # BaseProvider.run() refuses any id the config does not list as enabled, so
    # the doubles are switched on for the duration of the run. Left out, they
    # fail with "disabled" and the deadline never gets a chance to matter.
    saved_enabled = set(cfg.enabled_providers)
    cfg.enabled_providers |= set(doubles)

    try:
        engine = SearchEngine()
        query = SearchQuery(text="deadline", categories={Category.ARTICLE}, per_source=10)
        started = time.monotonic()
        handle = engine.start(query)
        final = None
        while time.monotonic() - started < deadline + 30:
            try:
                ev = handle.events.get(timeout=0.2)
            except queue.Empty:
                if handle.done:
                    break
                continue
            if ev.type in (
                SearchEventType.FINISHED,
                SearchEventType.CANCELLED,
                SearchEventType.FAILED,
            ):
                final = ev
                break
        elapsed = time.monotonic() - started
        engine.shutdown()
    finally:
        base._REGISTRY.clear()  # noqa: SLF001
        base._REGISTRY.update(saved_registry)  # noqa: SLF001
        base._ORDER[:] = saved_order  # noqa: SLF001
        cfg.enabled_providers = saved_enabled
        cfg.search_deadline = previous
    return elapsed, final, doubles


def main() -> int:
    print("== a stalled source is cut off at the deadline ==")
    deadline = 2.0
    elapsed, final, registry = run(deadline)
    check("the run reached a terminal event", final is not None,
          "no FINISHED/CANCELLED/FAILED event")
    if final is None:
        return 1
    check("the run was not cancelled or crashed",
          final.type is SearchEventType.FINISHED, final.type.value)
    check("it finished at the deadline, not after the retry budget",
          elapsed < deadline + 3.0, f"{elapsed:.1f}s for a {deadline:.0f}s deadline")

    response = final.response
    assert response is not None
    reports = {r.provider_id: r for r in response.reports}
    check("both providers are accounted for", set(reports) == {"fake_fast", "fake_stalled"},
          str(sorted(reports)))
    check("each source has exactly one report", len(response.reports) == 2,
          str([(r.provider_id, r.status.value) for r in response.reports]))

    fast = reports.get("fake_fast")
    check("the working source kept its results",
          fast is not None and fast.status is ProviderStatus.OK and fast.count == 3,
          f"{fast.status.value if fast else 'missing'} count={fast.count if fast else '-'}")
    check("its results are in the response",
          len(response.results.get(Category.ARTICLE, [])) == 3,
          str(len(response.results.get(Category.ARTICLE, []))))

    stalled = reports.get("fake_stalled")
    check("the stalled source is reported as a timeout",
          stalled is not None and stalled.failed and stalled.message == "timeout",
          f"{stalled.status.value if stalled else 'missing'} msg={stalled.message if stalled else '-'}")
    check("the timeout is explained in the error list",
          any("fake_stalled" in e and "timeout" in e for e in response.errors),
          str(response.errors))

    print("\n== the abandoned worker is released ==")
    # The executor is sized to one slot per provider, so a worker still burning
    # its retry budget after the deadline holds a slot the next search needs.
    deadline_over = time.monotonic() + 5
    while time.monotonic() < deadline_over:
        live = [th.name for th in threading.enumerate() if th.name.startswith("acadsearch")]
        if not live:
            break
        time.sleep(0.1)
    check("no worker thread is left running", not live, str(live))

    print("\n== the deadline does not fire early ==")
    # A deadline that is far longer than the working source needs must leave it
    # untouched: trimming the tail is the whole point, and a deadline that cut
    # healthy sources would be worse than no deadline at all.
    _, final_fast, _ = run(deadline=30.0)
    fast_reports = (
        {r.provider_id: r for r in final_fast.response.reports}
        if final_fast is not None and final_fast.response is not None
        else {}
    )
    fast = fast_reports.get("fake_fast")
    check("a source that answers in time is not touched",
          fast is not None and fast.status is ProviderStatus.OK and fast.count == 3,
          f"{fast.status.value if fast else 'missing'} count={fast.count if fast else '-'}")
    check("its results survive the long deadline",
          final_fast is not None and final_fast.response is not None
          and len(final_fast.response.results.get(Category.ARTICLE, [])) == 3,
          str(len(final_fast.response.results.get(Category.ARTICLE, [])))
          if final_fast and final_fast.response else "no response")

    print()
    if FAILURES:
        print(f"FAILED: {len(FAILURES)} -> {FAILURES}")
        return 1
    print("SEARCH DEADLINE CHECK PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
