"""Development and verification helpers.

Packaged into the frozen build so that ``AcadSearch.exe --selftest`` can run
the same GUI smoke suite that guards the source tree.
"""
