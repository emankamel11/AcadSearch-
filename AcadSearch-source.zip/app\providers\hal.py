"""HAL — French open archive (no API key).

HAL (hal.science) is the French national open archive run by CNRS and the
higher-education institutes. For this app it is the missing piece of the
French coverage: Sudoc holds the catalogue records but most French papers and
theses were only findable by title there, whereas HAL holds the full text and
the document type.

Endpoint: https://api.archives-ouvertes.fr/search/
Auth:     none.
Licence:  CC BY for the metadata.

The API is Solr-based, so the document type is part of the query rather than a
separate parameter: ``docType_s:OUV AND title_t:"term"``. Books (``OUV``),
articles (``ART``) and theses (``THESE``/``MEM``) are therefore three targeted
requests instead of one broad one that returns mostly theses.

Every result carries a PDF whenever one was deposited, which is why roughly
two thirds of the hits come back downloadable rather than landing-page only.
"""

from __future__ import annotations

import re
import threading

from app.core.text_utils import as_int, clean_text, truncate_words
from app.models import (
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

ENDPOINT = "https://api.archives-ouvertes.fr/search/"

#: Only the fields the card and the citation actually use.
FIELDS = ",".join(
    (
        "halId_s",
        "title_s",
        "authFullName_s",
        "structName_s",
        "producedDateY_i",
        "producedDate_s",
        "uri_s",
        "fileMain_s",
        "files_s",
        "docType_s",
        "language_s",
        "abstract_s",
        "doiId_s",
        "journalTitle_s",
        "publisher_s",
        "publisher_s",
        "collName_s",
        "school_s",
        "edition_s",
        "docid",
    )
)

#: Document types per result section. A thesis is research, not an article, and
#: a book chapter belongs with the research papers rather than polluting the book
#: list with fragments that cannot be downloaded on their own.
_DOC_TYPES: dict[str, tuple[Category, ...]] = {
    "ART": (Category.ARTICLE,),
    "COMM": (Category.ARTICLE, Category.RESEARCH),
    "PROCEEDINGS": (Category.ARTICLE,),
    "BLOG": (Category.ARTICLE,),
    "POSTER": (Category.ARTICLE,),
    "COUV": (Category.RESEARCH,),
    "OUV": (Category.BOOK,),
    "THESE": (Category.RESEARCH,),
    "MEM": (Category.RESEARCH,),
    "OTHER": (Category.RESEARCH,),
    "UNDEFINED": (Category.RESEARCH,),
}

#: ``docType_s`` values that belong in each requested category, used to build
#: the Solr filter for a targeted request.
_TYPES_FOR: dict[Category, str] = {
    Category.BOOK: "docType_s:OUV",
    Category.ARTICLE: "docType_s:ART",
    Category.RESEARCH: "(docType_s:THESE OR docType_s:MEM)",
}

_TAG_RE = re.compile(r"<[^>]+>")


@register
class HalProvider(BaseProvider):
    provider_id = "hal"
    display_name = "HAL (الأرشيف الفرنسي)"
    categories = (Category.BOOK, Category.ARTICLE, Category.RESEARCH)
    weight = 40
    homepage = "https://hal.science"

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        text = query.text.strip()
        if not text:
            return []

        wanted = [c for c in query.categories if c in _TYPES_FOR]
        if not wanted:
            return []

        results: list[Result] = []
        for category in wanted:
            if cancel is not None and cancel.is_set():
                return []
            results.extend(self._fetch_category(query, text, category, cancel))
        return results

    # -- one request per category -----------------------------------------
    def _fetch_category(
        self,
        query: SearchQuery,
        text: str,
        category: Category,
        cancel: threading.Event | None,
    ) -> list[Result]:
        # Title match first, then the abstract: HAL's default field search also
        # hits full text and keywords, which buried the actual answer far down.
        solr = (
            f"({_TYPES_FOR[category]}) AND "
            f'(title_t:"{text}" OR abstract_t:"{text}")'
        )
        if query.language and query.language != "any":
            solr += f" AND language_s:{query.language}"
        if query.year_from or query.year_to:
            low = query.year_from or 1500
            high = query.year_to or 2100
            solr += f" AND producedDateY_i:[{low} TO {high}]"

        params = {
            "q": solr,
            "fl": FIELDS,
            "rows": str(max(10, min(query.per_source, 100))),
            "wt": "json",
        }

        try:
            payload = self.http.get_json(
                ENDPOINT, params=params, provider=self.provider_id, cancel=cancel
            )
        except ProviderError:
            raise
        except Exception as exc:  # pragma: no cover - network
            raise ProviderError(
                f"hal: {type(exc).__name__}", kind="error"
            ) from exc

        if cancel is not None and cancel.is_set():
            return []

        docs = ((payload or {}).get("response") or {}).get("docs") or []
        out: list[Result] = []
        for doc in docs:
            built = self._to_result(doc)
            # The requested category wins over HAL's own label, because the
            # request was already filtered on the matching document type.
            if built is not None and category in self._categories(doc):
                built.category = category
                out.append(built)
        return out

    def _categories(self, doc: dict) -> tuple[Category, ...]:
        return _DOC_TYPES.get(_text(doc.get("docType_s")), (Category.RESEARCH,))

    # -- mapping -----------------------------------------------------------
    def _to_result(self, doc: dict) -> Result | None:
        titles = _as_list(doc.get("title_s"))
        languages = _as_list(doc.get("language_s"))
        title = self._pick_title(titles, languages)
        if not title:
            return None

        authors = [clean_text(a) for a in _as_list(doc.get("authFullName_s"))]
        authors = [a for a in authors if a]

        year = as_int(doc.get("producedDateY_i"))
        if year is None:
            year = as_int(clean_text(doc.get("producedDate_s") or "")[:4])

        pdf = self._pick_pdf(doc)
        landing = clean_text(doc.get("uri_s") or "")

        identifiers: dict[str, str] = {"source": self.provider_id}
        hal_id = clean_text(doc.get("halId_s") or "")
        if hal_id:
            identifiers["hal"] = hal_id
        doi = clean_text(doc.get("doiId_s") or "")
        if doi:
            identifiers["doi"] = doi
        docid = clean_text(doc.get("docid") or "")
        if docid:
            identifiers["hal_docid"] = docid

        downloads = []
        if pdf:
            downloads.append(
                target(pdf, DownloadFormat.PDF, label="PDF", open_access=True)
            )

        language = clean_text(languages[0]) if languages else ""

        result = Result(
            category=self._categories(doc)[0],
            title=title,
            source=self.provider_id,
            authors=authors[:12],
            year=year,
            abstract=truncate_words(_strip_html(
                clean_text(_as_list(doc.get("abstract_s"))[0])
                if _as_list(doc.get("abstract_s"))
                else ""
            ), 90),
            venue=self._venue(doc),
            language=language,
            identifiers=identifiers,
            downloads=downloads,
            landing_url=landing or (f"https://doi.org/{doi}" if doi else ""),
        )
        return result

    # -- field helpers -----------------------------------------------------
    def _pick_title(self, titles: list[str], languages: list[str]) -> str:
        """HAL stores one title per language when a record has translations.

        Picking the first one blindly shows an English title for a French
        record, which is the one thing a French-language filter is supposed to
        prevent.
        """
        cleaned = [clean_text(t) for t in titles]
        cleaned = [t for t in cleaned if t]
        if not cleaned:
            return ""
        wanted = languages[0] if languages else ""
        for title in cleaned:
            if wanted and _title_language(title) == wanted:
                return title
        return cleaned[0]

    def _pick_pdf(self, doc: dict) -> str:
        files = [clean_text(f) for f in _as_list(doc.get("files_s"))]
        for url in files:
            if url.lower().split("?")[0].endswith(".pdf"):
                return url
        main = clean_text(doc.get("fileMain_s") or "")
        if main:
            return main
        return ""

    def _venue(self, doc: dict) -> str:
        kind = _text(doc.get("docType_s"))
        if kind in ("ART", "COMM", "PROCEEDINGS"):
            return _text(doc.get("journalTitle_s"))
        if kind == "OUV":
            return _text(doc.get("publisher_s"))
        if kind in ("THESE", "MEM"):
            return _text(doc.get("school_s")) or _text(doc.get("collName_s"))
        return _text(doc.get("structName_s")) or _text(doc.get("publisher_s"))


def _text(value: object) -> str:
    """Read a scalar field that HAL may store as a list of one value."""
    items = _as_list(value)
    for item in items:
        cleaned = clean_text(item)
        if cleaned:
            return cleaned
    return ""


def _as_list(value: object) -> list[str]:
    """HAL returns a bare string when there is one value and a list otherwise."""
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [v for v in value if isinstance(v, (str, int))]
    return [value]  # type: ignore[list-item]


def _strip_html(value: str) -> str:
    """HAL abstracts carry paragraph and emphasis tags from the deposit form."""
    if "<" not in value:
        return value
    text = _TAG_RE.sub(" ", value)
    return clean_text(text.replace("&nbsp;", " "))


def _title_language(title: str) -> str:
    from app.core.text_utils import detect_script_languages

    return detect_script_languages(title)