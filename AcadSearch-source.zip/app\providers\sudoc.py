"""Sudoc (ABES) — French theses via the official SRU catalogue.

theses.fr is a *presentation layer* on top of the Sudoc catalogue: its own
"open data" page points at the ABES APIs, and every French doctoral thesis
since 1985 sits in this catalogue. Querying Sudoc directly therefore yields the
same records (NNT, DOI, university, supervisor, French abstract and the
open-access PDF on theses.fr / HAL) through a documented, key-free SRU service.

Endpoint: https://www.sudoc.abes.fr/cbs/sru/   (SRU 1.1)
Indexes:  see ``operation=explain`` — we use the PICA index set
          (``pica.tou`` all words, ``pica.nth`` thesis note, ``pica.lai``
          document language, ``pica.apu`` publication year).
Schema:   ``recordSchema=pica`` returns full UNIMARC-style datafields.
          ``dc`` is sparser; ``unimarcxchange``/``mods`` are not authorised.

Data: Etalab open licence (public domain).

Two implementation notes that matter:

* The service replies ``Content-Type: text/xml`` **without** a charset, so a
  naive decode mangles every accent ("décision" -> "dÃ©cision"). We force
  ``encoding="utf-8"`` on the HTTP call.
* ``pica.nth`` is what marks a record as a thesis, which is how this provider
  stays restricted to doctoral work instead of duplicating Open Library.
"""

from __future__ import annotations

import re
import threading
import xml.etree.ElementTree as ET

from app.core.text_utils import as_int, clean_text, truncate_words
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, ProviderError, register, target

ENDPOINT = "https://www.sudoc.abes.fr/cbs/sru/"

_SRW = "http://www.loc.gov/zing/srw/"
_SRW_DIAG = "http://www.loc.gov/zing/srw/diagnostic/"

#: SRU ``version`` to request. 1.2 is the only value that reliably honours the
#: record window: on 1.1 a query with several hits can come back as
#: ``numberOfRecords=0`` plus "First record position out of range". 1.2 wraps
#: the PICA payload in ``{http://www.loc.gov/MARC21/slim}``, which is why the
#: field walker matches local tag names instead of plain ones.
_SRU_VERSION = "1.2"

#: Element names are compared on their local name, so the parser works whether
#: or not the response namespaces the payload.
def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _find_all(element: ET.Element, name: str) -> list[ET.Element]:
    """All descendants whose local tag name is ``name``, namespace or not."""
    return [el for el in element.iter() if _local(el.tag) == name]

#: PICA field tags we read.
F_PPN = "003@"        # Sudoc permanent identifier
F_DOI = "004Z"        # DOI ($2=DOI)
F_NNT = "006L"        # Numero national de these
F_LINK = "009P"       # full-text / related links
F_LINK_NAMED = "009Q"  # named source link (theses.fr, HAL, ...)
F_LANG = "010@"       # languages
F_YEAR = "011@"       # publication year
F_COUNTRY = "019@"
F_NOTE = "020A"       # $b type/note, $c discipline, $e university, $d year
F_TITLE = "021A"      # $a title, $d subtitle, $h author, $j supervisor
F_ALT_TITLE = "027N"  # translated title
F_AUTHOR_MAIN = "028A"
F_AUTHOR_ADD = "028B"
F_SUBJECT = "044U"
F_ABSTRACT = "047P"

#: Role codes in 028A/028B $B. 070 = author, 727 = supervisor, 555 = jury.
_ROLE_AUTHOR = "070"

#: ISO-639-2/B codes as Sudoc indexes them, for the server-side language filter.
LANG1_TO_PICA: dict[str, str] = {
    "ar": "ara", "en": "eng", "fr": "fre", "de": "ger", "es": "spa",
    "it": "ita", "pt": "por", "ru": "rus", "zh": "chi", "ja": "jpn",
    "ko": "kor", "tr": "tur", "fa": "per", "ur": "urd", "he": "heb",
    "hi": "hin", "nl": "dut", "pl": "pol", "sv": "swe", "id": "ind",
}

#: ``021A $a`` and ``027N $a`` are ISBD-transcribed. ``@`` marks the start of
#: the title proper and can sit in the middle ("The @uplink reception ..."), so
#: it is replaced by a space rather than deleted, which would weld words
#: together ("Theuplink").
_ISBD = re.compile(r"\s*[@:]\s*")
_SPACES = re.compile(r"\s{2,}")
#: ``028A/028B $8`` = "Surname, Given (1900-.... ; note)".
_AUTHOR = re.compile(r"^(?P<family>[^,]+),\s*(?P<given>.+?)\s*$")
_PAREN = re.compile(r"\s*\(.*\)\s*$")


@register
class SudocProvider(BaseProvider):
    """French doctoral theses from the ABES Sudoc catalogue."""

    provider_id = "sudoc"
    display_name = "Sudoc ( theses.fr )"
    categories = (Category.RESEARCH,)
    weight = 35
    homepage = "https://theses.fr"

    #: The SRU service is slow-ish; keep the page small.
    max_records = 20

    def fetch(
        self, query: SearchQuery, cancel: threading.Event | None = None
    ) -> list[Result]:
        cql = self._build_cql(query)
        params = {
            "version": _SRU_VERSION,
            "operation": "searchRetrieve",
            "query": cql,
            "startRecord": "1",
            "maximumRecords": str(min(query.per_source, self.max_records)),
            "recordSchema": "pica",
        }
        xml = self.http.get_text(
            ENDPOINT,
            params,
            provider=self.provider_id,
            cancel=cancel,
            encoding="utf-8",  # service omits the charset; see module docstring
        )
        return self._parse(xml, query)

    # -- query construction ----------------------------------------------
    def _build_cql(self, query: SearchQuery) -> str:
        terms = _cql_quote(query.text)
        if not terms:
            return ""
        # ``pica.nth`` (note de these) is what identifies a thesis record, which
        # keeps this provider from duplicating the general book catalogues.
        clauses = [f"pica.tou all {terms}", 'pica.nth all "thèse"']
        if query.language and query.language != "any":
            code = LANG1_TO_PICA.get(query.language)
            if code:
                clauses.append(f"pica.lai = {_cql_quote(code)}")
        return " and ".join(clauses)

    # -- parsing ----------------------------------------------------------
    def _parse(self, xml: str, query: SearchQuery) -> list[Result]:
        if not xml or not xml.strip():
            return []
        try:
            root = ET.fromstring(xml)
        except ET.ParseError as exc:
            raise ProviderError(
                f"sudoc: استجابة XML غير صالحة / malformed XML ({exc})",
                kind="error",
            ) from exc

        # SRU reports failures inside a 200 response, so the status code alone
        # is not enough to know the search worked. The diagnostic namespace
        # differs between SRU 1.1 and 1.2, so match on the local name.
        messages = [
            (el.text or "").strip()
            for el in _find_all(root, "message")
            if (el.text or "").strip()
        ]
        # "First record position out of range" means the query matched fewer
        # records than requested, which is an empty result set, not a failure.
        benign = ("Unsupported", "out of range", "no record", "no result")
        blocking = [
            m for m in messages if m and not any(b in m.lower() for b in benign)
        ]
        if blocking:
            raise ProviderError(
                f"sudoc: {blocking[0]}", kind="bad_request"
            )

        out: list[Result] = []
        for record in _find_all(root, "record"):
            # The SRW envelope wraps each payload in its own <record>; only the
            # PICA payload carries <datafield> children, so skip the wrapper.
            if not _find_all(record, "datafield"):
                continue
            item = self._to_result(record, query)
            if item is not None:
                out.append(item)
        return out

    def _fields(self, record: ET.Element) -> dict[str, list[dict[str, str]]]:
        """Group subfields by field tag, preserving document order."""
        grouped: dict[str, list[dict[str, str]]] = {}
        for datafield in _find_all(record, "datafield"):
            tag = (datafield.get("tag") or "").strip()
            if not tag:
                continue
            subs = {
                (s.get("code") or ""): (s.text or "")
                for s in _find_all(datafield, "subfield")
            }
            grouped.setdefault(tag, []).append(subs)
        return grouped

    def _to_result(
        self, record: ET.Element, query: SearchQuery
    ) -> Result | None:
        f = self._fields(record)
        if not f:
            return None

        ppn = _sub(f.get(F_PPN))

        # --- title -------------------------------------------------------
        title_field = _one(f.get(F_TITLE))
        title = _isbd(title_field.get("a", ""))
        if not title:
            return None
        subtitle = clean_text(title_field.get("d", ""))
        if subtitle and subtitle.lower() not in title.lower():
            title = f"{title}: {subtitle}"
        alt = ""
        for field in f.get(F_ALT_TITLE, []):
            alt = _isbd(field.get("a", ""))
            if alt:
                break

        # --- authors (role 070 only; supervisors/jury are not authors) ----
        authors: list[str] = []
        for tag in (F_AUTHOR_MAIN, F_AUTHOR_ADD):
            for field in f.get(tag, []):
                if field.get("B") != _ROLE_AUTHOR:
                    continue
                name = _person(field.get("8", ""))
                if name and name not in authors:
                    authors.append(name)
        if not authors:
            # 021A $h already holds the name in natural order.
            fallback = _person(title_field.get("h", ""), assume_natural=True)
            if fallback:
                authors = [fallback]

        supervisors = _person_list(title_field.get("j", ""))

        # --- year / language ---------------------------------------------
        year = as_int(_sub(f.get(F_YEAR), "a").split("-")[0]) or as_int(
            _sub(f.get(F_NOTE), "d")
        )
        lang_field = _one(f.get(F_LANG))
        language = clean_text(lang_field.get("a", "")).lower()

        note = _one(f.get(F_NOTE))
        university = clean_text(note.get("e", ""))
        discipline = clean_text(note.get("c", ""))
        thesis_kind = clean_text(note.get("b", ""))

        # --- abstract ----------------------------------------------------
        abstract = _abstract(f.get(F_ABSTRACT, []), language)

        # --- identifiers -------------------------------------------------
        doi = ""
        for field in f.get(F_DOI, []):
            if (field.get("2") or "").upper() == "DOI":
                doi = clean_text(field.get("0", ""))
                if doi:
                    break
        nnt = _sub(f.get(F_NNT))

        identifiers: dict[str, str] = {}
        if doi:
            identifiers["doi"] = doi
        if ppn:
            identifiers["ppn"] = ppn
        if nnt:
            identifiers["nnt"] = nnt
        if identifiers:
            identifiers["sudoc"] = f"https://www.sudoc.fr/{ppn}" if ppn else ""

        # --- links -------------------------------------------------------
        downloads = self._links(f)
        if ppn:
            downloads.append(
                target(
                    f"https://www.sudoc.fr/{ppn}",
                    DownloadFormat.HTML,
                    label="Sudoc",
                    open_access=False,
                )
            )

        subjects = [
            clean_text(field.get("a", ""))
            for field in f.get(F_SUBJECT, [])
            if clean_text(field.get("a", ""))
        ]
        if discipline and discipline not in subjects:
            subjects.insert(0, discipline)

        return Result(
            category=Category.RESEARCH,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=year,
            abstract=abstract,
            venue=university or discipline,
            publisher=university,
            language=language,
            subjects=subjects[:8],
            identifiers={k: v for k, v in identifiers.items() if v},
            access=Access.DOWNLOAD if _has_file(downloads) else Access.LANDING,
            downloads=downloads,
            landing_url=f"https://www.sudoc.fr/{ppn}" if ppn else "",
            item_type="Thesis",  # canonical: the French note stays in raw
            raw={
                "ppn": ppn,
                "nnt": nnt,
                "discipline": discipline,
                "university": university,
                "supervisors": supervisors,
                "translated_title": alt,
                "thesis_kind": thesis_kind,
            },
        )

    def _links(self, f: dict[str, list[dict[str, str]]]) -> list:
        """Turn 009P/009Q links into download targets.

        Sudoc marks an inline full text with ``$z = "Acces au texte integral"``
        and gives its size in ``$d``; ``$0`` holds the claimed format.
        """
        out: list = []
        seen: set[str] = set()

        def add(url: str, fmt: DownloadFormat, label: str, open_access: bool) -> None:
            url = url.strip()
            if not url or url in seen or not url.lower().startswith("http"):
                return
            seen.add(url)
            out.append(target(url, fmt, label=label, open_access=open_access))

        for field in f.get(F_LINK, []):
            url = field.get("a", "")
            note = field.get("z", "")
            declared = (field.get("0", "") or "").upper()
            if declared in ("PDF", "TEXTE INTEGRAL") or "texte int" in note.lower():
                add(url, DownloadFormat.PDF, "Full text (PDF)", True)
            elif url.lower().endswith(".pdf"):
                add(url, DownloadFormat.PDF, "Full text (PDF)", True)
            else:
                add(url, DownloadFormat.HTML, note or "Source", True)

        for field in f.get(F_LINK_NAMED, []):
            label = clean_text(field.get("2", "")) or "Source"
            add(field.get("a", ""), DownloadFormat.HTML, label, True)

        # Prefer real files first so the card's primary button is useful.
        out.sort(key=lambda t: 0 if t.fmt is DownloadFormat.PDF else 1)
        return out


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _one(
    fields: list[dict[str, str]] | None, sub_code: str = ""
) -> dict[str, str]:
    """First datafield, optionally requiring a given subfield code."""
    for field in fields or ():
        if not sub_code or sub_code in field:
            return field
    return {}


def _sub(fields: list[dict[str, str]] | None, sub_code: str = "0") -> str:
    """Text of one subfield, taken from the first datafield that carries it.

    ``fields`` is already grouped by field tag, so no tag is needed here.
    """
    return clean_text(_one(fields, sub_code).get(sub_code, ""))


def _isbd(value: str) -> str:
    """Strip ISBD punctuation: ``"The @Title : part"`` -> ``"The Title part"``."""
    return clean_text(_SPACES.sub(" ", _ISBD.sub(" ", value or "")))


def _person(value: str, assume_natural: bool = False) -> str:
    """``"Durand, Marie (1970-....)"`` -> ``"Marie Durand"``.

    Sudoc writes authorities as ``Family, Given (dates ; note)``; ``021A $h``
    is already in natural order.
    """
    text = clean_text(_PAREN.sub("", value or ""))
    if not text or assume_natural or "," not in text:
        return text
    match = _AUTHOR.match(text)
    if not match:
        return text
    family = match.group("family").strip()
    given = match.group("given").strip()
    return f"{given} {family}".strip() if family and given else (family or given)


def _person_list(value: str) -> list[str]:
    """``"sous la direction de A B et de C D"`` -> ``["A B", "C D"]``."""
    text = clean_text(value)
    if not text:
        return []
    text = re.sub(r"^\s*sous la direction de\s*", "", text, flags=re.I)
    parts = [p.strip() for p in re.split(r"\s+et de\s+|\s+et\s+", text) if p.strip()]
    return [p for p in parts if p]


def _abstract(fields: list[dict[str, str]], language: str) -> str:
    """Prefer the abstract written in the record's own language."""
    fallback = ""
    for field in fields:
        text = clean_text(field.get("a", ""))
        if not text:
            continue
        code = clean_text(field.get("z", "")).lower()
        if code and code.startswith(language[:2]):
            return truncate_words(text, 320)
        fallback = fallback or text
    return truncate_words(fallback, 320)


def _has_file(targets: list) -> bool:
    return any(t.fmt is DownloadFormat.PDF for t in targets)


def _cql_quote(value: str) -> str:
    """Wrap a term in CQL double quotes, escaping embedded quotes."""
    cleaned = re.sub(r'["\r\n]+', " ", value or "").strip()
    return f'"{cleaned}"' if cleaned else ""
