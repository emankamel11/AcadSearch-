"""Launch the Qt prototype and keep it alive for UIA measurement.

Adds three fake results immediately so the tabs and the download buttons are
present without waiting on the network.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PySide6.QtCore import QTimer

from app.models import Access, Category, DownloadFormat, DownloadTarget, Result

import prototype
from PySide6.QtWidgets import QApplication

FAKE = {
    Category.BOOK: [
        dict(title="Introduction to Machine Learning", authors=["Anil K. Jain", "Nitin Gupta"],
             year=2021, venue="MIT Press", source="open_library", access=Access.DOWNLOAD,
             downloads=[DownloadTarget(url="https://example.org/a.epub", fmt=DownloadFormat.EPUB, label="EPUB")]),
        dict(title="Deep Learning Handbook", authors=["Yann LeCun"], year=2019,
             venue="Springer", source="google_books", access=Access.BORROW, downloads=[]),
    ],
    Category.ARTICLE: [
        dict(title="Accessible Widget Design for Screen Readers", authors=["Sara Ahmed", "M. B. Khan"],
             year=2023, venue="Journal of HCI", source="crossref", access=Access.DOWNLOAD,
             downloads=[DownloadTarget(url="https://example.org/b.pdf", fmt=DownloadFormat.PDF, label="PDF")]),
    ],
    Category.RESEARCH: [
        dict(title="PhD Thesis: Arabic Text-to-Speech", authors=["Nour Hassan"], year=2024,
             venue="Cairo University", source="sudoc", access=Access.METADATA, downloads=[]),
    ],
}


def seed(win) -> None:
    for category, rows in FAKE.items():
        page = win.tab_pages[category]
        for row in rows:
            page.add(Result(category=category, **row))
        page.announce_count()
    win._set_status("تم العثور على 4 نتيجة (بيانات تجريبية)")
    page = win.tab_pages[Category.BOOK]
    page.list.setFocus()
    page.list.setCurrentRow(0)


def main() -> int:
    app = QApplication(sys.argv)
    win = prototype.MainWindow()
    win.show()
    win.raise_()
    QTimer.singleShot(1200, lambda: seed(win))
    QTimer.singleShot(45000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())