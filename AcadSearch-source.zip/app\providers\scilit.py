"""Scilit — MDPI's open scholarly index.

API: https://docs.scilit.com. Search needs a token issued on request
(header ``X-Scilit-Token``); Scilit carries no full text and no type field, so
records land in the articles tab with a link to the Scilit landing page.
"""

from __future__ import annotations

import threading

from app.core.text_utils import as_int, clean_text, extract_doi, truncate_words
from app.models import Access, Category, Result, SearchQuery
from app.providers.base import BaseProvider, register

ENDPOINT = "https://api.scilit.com/public/v1/publications"


@register
class ScilitProvider(BaseProvider):
    provider_id = "scilit"
    display_name = "Scilit"
    categories = (Category.ARTICLE, Category.RESEARCH)
    weight = 45
    requires_key = "scilit_key"
    homepage = "https://www.scilit.com"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        token = self.config.scilit_key
        if not token:
            return []
        body = {
            "title": query.text,
            "page_size": min(query.per_source, 50),
            "page": 1,
            "sort": "relevancy",
        }
        payload = self.http.post_json(
            ENDPOINT,
            body,
            provider=self.provider_id,
            use_cache=True,
            cancel=cancel,
        )
        return [self._to_result(r) for r in (payload.get("data") or [])]

    def _to_result(self, record: dict) -> Result:
        title = clean_text(record.get("title"))
        year = as_int(record.get("pub_year") or record.get("publish_year"))
        doi = extract_doi(record.get("doi"))
        landing = clean_text(record.get("publication_url"))

        authors = [
            clean_text(a) for a in (record.get("author_names") or []) if clean_text(a)
        ][:12]
        subjects = [
            clean_text(s) for s in (record.get("subjects") or []) if clean_text(s)
        ][:6]

        identifiers: dict[str, str] = {}
        if doi:
            identifiers["doi"] = doi
        scilit_id = as_int(record.get("id"))
        if scilit_id:
            identifiers["scilit"] = str(scilit_id)

        return Result(
            category=Category.ARTICLE,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=year,
            abstract=truncate_words(clean_text(record.get("abstract")), 320),
            venue=clean_text(record.get("container_title")),
            publisher=clean_text(record.get("publisher_name")),
            subjects=subjects,
            identifiers=identifiers,
            access=Access.LANDING if landing else Access.METADATA,
            downloads=[],
            landing_url=landing,
            item_type="Article",
            raw=record,
        )