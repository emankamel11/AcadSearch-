"""Check the settings dialog: language, citation style, API keys, and the
standalone About window.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(r"D:\projects\برنامج\بحث علمي")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "qt_prototype"))

from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialogButtonBox,
    QLabel,
    QLineEdit,
    QPushButton,
)

import main_window
import preferences
import about_dialog
from app.config import APP_VERSION, get_config
from app.core.citation import format_citation
from app.models import Category, Result


def main() -> int:
    app = QApplication.instance() or QApplication([])
    win = main_window.MainWindow()
    win.show()
    app.processEvents()

    failures: list[str] = []

    def check(label: str, ok: bool, detail: str = "") -> None:
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" -- {detail}" if detail else ""))
        if not ok:
            failures.append(label)

    print("== settings button exists and is reachable ==")
    check("settings button in the window", hasattr(win, "prefs_btn"))
    # Names are bare labels and the hint lives in the tooltip: NVDA reads a
    # description out loud on every visit, which is what made this app chatty.
    check(
        "settings button is named for NVDA",
        win.prefs_btn.accessibleName() == "إعدادات",
        win.prefs_btn.accessibleName(),
    )
    check(
        "settings button says nothing more than its name",
        not (win.prefs_btn.accessibleDescription() or ""),
    )
    check(
        "settings button keeps its hint as a tooltip",
        "Alt+S" in (win.prefs_btn.toolTip() or ""),
        win.prefs_btn.toolTip(),
    )

    print("== dialog contents ==")
    dlg = preferences.PreferencesDialog(win)

    combos = dlg.findChildren(QComboBox)
    check("two combo boxes (language, style)", len(combos) == 2, str(len(combos)))

    lang = combos[0]
    check("language combo named", lang.accessibleName() == "اللغة", lang.accessibleName())
    check(
        "language offers Arabic and English",
        [lang.itemData(i) for i in range(lang.count())] == ["ar", "en"],
    )
    check(
        "language combo keeps the restart hint as a tooltip",
        "إعادة تشغيل" in (lang.toolTip() or ""),
        lang.toolTip(),
    )
    check("language combo is not read out at length",
          not (lang.accessibleDescription() or ""))

    style = combos[1]
    check("style combo named", style.accessibleName() == "التوثيق", style.accessibleName())
    check(
        "style offers all 7 citation styles",
        style.count() == 7,
        str([style.itemData(i) for i in range(style.count())]),
    )
    check(
        "style combo keeps its hint as a tooltip",
        "نسخ توثيق" in (style.toolTip() or ""),
        style.toolTip(),
    )

    edits = dlg.findChildren(QLineEdit)
    check("ten key fields", len(edits) == 10, str(len(edits)))
    check(
        "API key fields are masked",
        all(e.echoMode() == QLineEdit.Password
            for e in (dlg.gb_key, dlg.s2_key, dlg.core_key, dlg.base_key,
                      dlg.pubmed_key, dlg.lens_key, dlg.scilit_key,
                      dlg.scinapse_key, dlg.springer_key))
        and dlg.oa_email.echoMode() != QLineEdit.Password,
        "9 masked + email plain",
    )
    check(
        "every field has an accessible name",
        all(e.accessibleName() for e in edits),
        str([e.accessibleName() for e in edits]),
    )

    print("== about window ==")
    check("About button exists in the main window",
          hasattr(win, "about_btn"))
    check("About button is named for NVDA",
          win.about_btn.accessibleName() == "عن البرنامج",
          win.about_btn.accessibleName())
    check("About button says nothing more than its name",
          not (win.about_btn.accessibleDescription() or ""))

    adlg = about_dialog.AboutDialog(win)
    labels = adlg.findChildren(QLabel)
    texts = [lb.text() for lb in labels]
    check("version shown is the real APP_VERSION",
          APP_VERSION in texts, f"labels={texts}")
    check("build date is a date, not a guess",
          any(re.fullmatch(r"\d{4}-\d{2}-\d{2}", t) for t in texts)
          or "—" in texts,
          str(texts))
    check("active sources matches the config",
          str(len(get_config().enabled_providers)) in texts,
          str(texts))
    check("About holds no editable control",
          not adlg.findChildren(QLineEdit)
          and not adlg.findChildren(QComboBox),
          "read-only labels only")

    print("== values reach the config ==")
    # Start from a known state: the config file persists between runs, so a
    # previous run may already have switched the language.
    cfg = get_config()
    cfg.ui_language = "ar"
    cfg.citation_style = "apa"

    # The real values, kept so the test cannot leave a fake key behind. It used
    # to: "TEST-GOOGLE-KEY" stayed in config.json, and Google Books then answered
    # every request with HTTP 400, which looked exactly like a broken provider
    # and silently removed one of the twelve sources from every search.
    backup = {
        "google_books_key": cfg.google_books_key,
        "semantic_scholar_key": cfg.semantic_scholar_key,
        "openalex_key": cfg.openalex_key,
        "core_key": cfg.core_key,
        "base_key": cfg.base_key,
        "pubmed_key": cfg.pubmed_key,
        "lens_key": cfg.lens_key,
        "scilit_key": cfg.scilit_key,
        "scinapse_key": cfg.scinapse_key,
        "springer_key": cfg.springer_key,
        "contact_email": cfg.contact_email,
        "ui_language": cfg.ui_language,
        "citation_style": cfg.citation_style,
    }
    try:
        style.setCurrentIndex(preferences.CITATION_STYLES.index("mla"))
        lang.setCurrentIndex(1)  # English
        dlg.gb_key.setText("TEST-GOOGLE-KEY")
        dlg.oa_email.setText("student@example.com")

        _old, changed = dlg.apply_to_config()
        cfg = get_config()

        check(
            "citation style saved",
            cfg.citation_style == "mla",
            cfg.citation_style,
        )
        check(
            "interface language saved",
            cfg.ui_language == "en",
            cfg.ui_language,
        )
        check("language change is reported", changed is True)
        check(
            "google key saved",
            cfg.google_books_key == "TEST-GOOGLE-KEY",
            cfg.google_books_key,
        )
        check(
            "contact email saved",
            cfg.contact_email == "student@example.com",
            cfg.contact_email,
        )

        print("== the saved style really changes the citation ==")
        result = Result(
            category=Category.ARTICLE,
            title="A paper",
            source="open_library",
            year=2022,
            authors=["Sara Ahmed"],
            venue="Journal",
        )
        mla = format_citation(result, cfg.citation_style)
        apa = format_citation(result, "apa")
        check("MLA and APA differ", mla != apa, f"MLA={mla!r} APA={apa!r}")
    finally:
        for field, value in backup.items():
            setattr(get_config(), field, value)
        get_config().save()
        print()
        print("== the real settings are back ==")
        check(
            "the test key did not survive",
            get_config().google_books_key == backup["google_books_key"],
            "restored" if get_config().google_books_key == backup["google_books_key"]
            else "STILL SET",
        )

    print()
    if failures:
        print(f"FAILED: {len(failures)} -> {failures}")
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())