"""PubMed — the National Library of Medicine's article index.

E-utilities (https://www.ncbi.nlm.nih.gov/books/NBK25500/) need no key for
modest use; a free NCBI api_key raises the rate limit. esearch returns the
PMID list, esummary the metadata, and efetch (XML) the abstract, because the
JSON summary only sometimes carries one.
"""

from __future__ import annotations

import re
import threading
import xml.etree.ElementTree as ET

from app.config import get_config
from app.core.text_utils import as_int, clean_text, extract_doi, truncate_words
from app.models import Access, Category, DownloadFormat, Result, SearchQuery
from app.providers.base import BaseProvider, register, target

EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
YEAR_RE = re.compile(r"\b(\d{4})\b")
ARTICLE_TYPES = (
    "journal article", "review", "meta-analysis", "clinical trial",
    "randomized controlled trial",
)


@register
class PubMedProvider(BaseProvider):
    provider_id = "pubmed"
    display_name = "PubMed"
    categories = (Category.ARTICLE, Category.RESEARCH)
    weight = 45
    homepage = "https://pubmed.ncbi.nlm.nih.gov"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        ids = self._search(query, cancel)
        if not ids:
            return []
        meta = self._summaries(ids, cancel)
        abstracts = self._abstracts(ids, cancel)
        if cancel is not None and cancel.is_set():
            return []
        out: list[Result] = []
        for uid in ids:
            row = meta.get(uid)
            if not row:
                continue
            out.append(self._to_result(uid, row, abstracts.get(uid)))
        return out

    @staticmethod
    def _api_params() -> dict[str, str]:
        params: dict[str, str] = {
            "db": "pubmed",
            "retmode": "json",
            "tool": "AcadSearch",
            "email": "research@acadsearch.local",
        }
        key = get_config().pubmed_key
        if key:
            params["api_key"] = key
        return params

    def _search(self, query: SearchQuery, cancel: threading.Event | None) -> list[str]:
        params = self._api_params()
        params["term"] = query.text
        params["retmax"] = str(min(query.per_source, 60))
        payload = self.http.get_json(
            f"{EUTILS}/esearch.fcgi", params, provider=self.provider_id, cancel=cancel
        )
        return (payload.get("esearchresult") or {}).get("idlist") or []

    def _summaries(self, ids: list[str], cancel: threading.Event | None) -> dict[str, dict]:
        if not ids:
            return {}
        params = self._api_params()
        params["id"] = ",".join(ids)
        payload = self.http.get_json(
            f"{EUTILS}/esummary.fcgi", params, provider=self.provider_id, cancel=cancel
        )
        return (payload.get("result") or {})

    def _abstracts(self, ids: list[str], cancel: threading.Event | None) -> dict[str, str]:
        if not ids:
            return {}
        params = self._api_params()
        params["id"] = ",".join(ids)
        params["retmode"] = "xml"
        params["rettype"] = "abstract"
        text = self.http.get_text(
            f"{EUTILS}/efetch.fcgi", params, provider=self.provider_id, cancel=cancel
        )
        try:
            root = ET.fromstring(text.encode("utf-8", "ignore"))
        except ET.ParseError:
            return {}
        out: dict[str, str] = {}
        for article in root.iter("PubmedArticle"):
            pmid = ""
            for ident in article.iter("PMID"):
                pmid = (ident.text or "").strip()
                break
            parts: list[str] = []
            for node in article.iter("AbstractText"):
                parts.append("".join(node.itertext()).strip())
            abstract = " ".join(p for p in parts if p)
            if pmid and abstract:
                out[pmid] = abstract
        return out

    def _to_result(self, pmid: str, row: dict, abstract: str) -> Result:
        title = clean_text(row.get("title"))
        authors = [
            clean_text(a.get("name"))
            for a in (row.get("authors") or [])
            if clean_text(a.get("name"))
        ][:12]

        pubdate = clean_text(row.get("sortpubdate")) or clean_text(row.get("pubdate"))
        year = None
        if pubdate:
            match = YEAR_RE.search(pubdate)
            if match:
                year = as_int(match.group(1))

        doi = ""
        for ident in (row.get("articleids") or []):
            if str(ident.get("idtype", "")).lower() == "doi":
                doi = extract_doi(ident.get("value"))
                break
        if not doi:
            doi = extract_doi(row.get("elocationid"))

        pubtypes = [str(t).lower() for t in (row.get("pubtype") or [])]
        is_article = any(k in pubtypes for k in ARTICLE_TYPES) or not pubtypes

        identifiers: dict[str, str] = {}
        if doi:
            identifiers["doi"] = doi
        identifiers["pubmed"] = pmid

        pmcid = ""
        for ident in (row.get("articleids") or []):
            if str(ident.get("idtype", "")).lower() == "pmc":
                pmcid = str(ident.get("value") or "")
                break

        landing = f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/"
        downloads: list = []
        if pmcid:
            downloads.append(
                target(
                    f"https://www.ncbi.nlm.nih.gov/pmc/articles/{pmcid}/",
                    DownloadFormat.HTML,
                    label="PMC",
                    open_access=True,
                )
            )

        venue = clean_text(row.get("fulljournalname")) or clean_text(row.get("source"))
        pages = str(row.get("volume") or "") or ""
        issue = str(row.get("issue") or "") or ""
        if pages and issue:
            pages = f"{pages}({issue})"
        elif issue:
            pages = issue

        return Result(
            category=Category.ARTICLE if is_article else Category.RESEARCH,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=year,
            abstract=truncate_words(abstract, 320),
            venue=venue,
            volume=pages,
            publisher="PubMed",
            identifiers=identifiers,
            access=Access.LANDING if downloads else Access.METADATA,
            downloads=downloads,
            landing_url=landing,
            item_type="Journal Article",
            raw=row,
        )