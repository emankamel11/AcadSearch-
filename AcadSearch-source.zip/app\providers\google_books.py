"""Google Books — covers, categories, ratings and *direct* PDF/EPUB links.

Docs: https://developers.google.com/books/api/v1
Works without a key, but anonymous quota is shared and small; adding a free key
from Preferences → Network makes the source far more reliable.

Only links that Google explicitly marks as available in ``accessInfo`` are
surfaced as downloads. Anything else falls back to the official preview page.

The JSON API's anonymous quota is *per day and per project*, so it is regularly
exhausted for every user at once (HTTP 429 "Quota exceeded"). When that happens
the provider retries through the older GData Atom feed, which is still served
and still carries everything a book card needs: title, author, date, language,
publisher, page count, cover and — for public-domain volumes — a direct PDF
link. That is what keeps Arabic novels visible when the JSON endpoint is out.
"""

from __future__ import annotations

import logging
import re
import threading
import xml.etree.ElementTree as ET

from app.core.http_client import ProviderError
from app.core.text_utils import (
    as_float,
    as_int,
    clean_text,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

log = logging.getLogger(__name__)

ENDPOINT = "https://www.googleapis.com/books/v1/volumes"
#: The legacy GData feed. Not the documented JSON API, but still live, free and
#: richer than any other keyless book source we have for Arabic.
GDATA_ENDPOINT = "https://books.google.com/books/feeds/volumes"

#: Errors after which trying the Atom feed is worthwhile. ``cancelled`` and
#: network failures are not: the user or the connection is gone.
FALLBACK_KINDS = ("rate_limited", "key_missing", "bad_request")

ATOM = "{http://www.w3.org/2005/Atom}"
DC = "{http://purl.org/dc/terms}"
GBS = "{http://schemas.google.com/books/2008}"

_ISBN = re.compile(r"^ISBN:?\s*([0-9Xx\-]+)$")
_PAGES = re.compile(r"(\d+)\s*pages?", re.I)


@register
class GoogleBooksProvider(BaseProvider):
    provider_id = "google_books"
    display_name = "Google Books"
    categories = (Category.BOOK,)
    weight = 20
    requires_key = "google_books_key"
    homepage = "https://books.google.com"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        failure: ProviderError | None = None
        try:
            results = self._fetch_json(query, cancel)
        except ProviderError as exc:
            if exc.kind == "cancelled" or exc.kind not in FALLBACK_KINDS:
                raise
            failure = exc
            results = []

        # A keyless JSON request can also answer 200 with zero items once the
        # shared daily quota is gone; the feed still has the books. A keyed 200
        # with zero items, on the other hand, is a real "no such book" answer.
        if results:
            return results
        if failure is None and self.config.google_books_key:
            return results
        if cancel is not None and cancel.is_set():
            raise ProviderError("cancelled", kind="cancelled")

        try:
            return self._fetch_gdata(query, cancel)
        except ProviderError:
            # Report the JSON 429 when both failed: it is the real reason, and
            # "rate_limited" is a status the reader can understand.
            if failure is not None:
                raise failure
            raise

    # -- JSON API ---------------------------------------------------------
    def _fetch_json(
        self, query: SearchQuery, cancel: threading.Event | None
    ) -> list[Result]:
        params: dict[str, object] = {
            "q": query.text,
            "maxResults": min(query.per_source, 40),
        }
        if self.config.google_books_key:
            params["key"] = self.config.google_books_key
        if query.language and query.language != "any":
            params["langRestrict"] = query.language
        if query.year_from or query.year_to:
            low = query.year_from or 1000
            high = query.year_to or 3000
            params["q"] = f"{query.text} publishedDate:{low}-{high}"

        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        items = payload.get("items") or []
        return [self._to_result(item) for item in items]

    # -- GData Atom feed --------------------------------------------------
    def _fetch_gdata(
        self, query: SearchQuery, cancel: threading.Event | None
    ) -> list[Result]:
        """Same results, via the Atom feed, paged with ``start-index``.

        The feed caps a page at about 20 entries no matter what ``max-results``
        says, and it ignores the JSON API's ``langRestrict``. Arabic records
        are therefore collected across pages and sorted to the front, so the
        shared language filter downstream keeps the right ones instead of a
        page of English translations.
        """
        wanted = max(1, min(query.per_source, 40))
        wanted_lang = query.language if query.language != "any" else ""

        out: list[Result] = []
        seen: set[str] = set()
        start = 1
        for _page in range(3):
            if cancel is not None and cancel.is_set():
                raise ProviderError("cancelled", kind="cancelled")
            params: dict[str, object] = {
                "q": query.text,
                "max-results": 20,
                "start-index": start,
            }
            text = self.http.get_text(
                GDATA_ENDPOINT, params, provider=self.provider_id, cancel=cancel
            )
            page = parse_gdata(text)
            added = 0
            for item in page:
                volume_id = item.identifiers.get("gbid", "")
                if volume_id and volume_id in seen:
                    continue
                if volume_id:
                    seen.add(volume_id)
                out.append(item)
                added += 1
            # A short page means the feed has nothing after it.
            if added == 0 or len(page) < 20 or len(out) >= wanted:
                break
            start += len(page)

        if wanted_lang:
            out.sort(key=lambda r: 0 if r.language == wanted_lang else 1)
        return out[:wanted]

    # -- mapping ----------------------------------------------------------
    def _to_result(self, item: dict) -> Result:
        info = item.get("volumeInfo") or {}
        access = item.get("accessInfo") or {}
        volume_id = clean_text(item.get("id"))

        title = clean_text(info.get("title"))
        subtitle = clean_text(info.get("subtitle"))
        if subtitle and subtitle.lower() not in title.lower():
            title = f"{title}: {subtitle}"

        authors = [clean_text(a) for a in (info.get("authors") or []) if a]
        subjects = [clean_text(c) for c in (info.get("categories") or [])[:6] if c]
        page_count = as_int(info.get("pageCount"))
        published = clean_text(info.get("publishedDate"))
        year = as_int(published[:4]) if published else None

        landing = (
            clean_text(access.get("webReaderLink"))
            or (f"https://books.google.com/books?id={volume_id}" if volume_id else "")
        )

        downloads = self._downloads(access, volume_id)
        identifiers: dict[str, str] = {}
        if volume_id:
            identifiers["gbid"] = volume_id
        for kind in ("ISBN_13", "ISBN_10"):
            block = (info.get("industryIdentifiers") or [])
            match = next(
                (b for b in block if b.get("type") == kind and b.get("identifier")), None
            )
            if match:
                identifiers["isbn"] = clean_text(match["identifier"])
                break

        self_link = clean_text(item.get("selfLink"))
        return Result(
            category=Category.BOOK,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=year,
            abstract=truncate_words(clean_text(info.get("description")), 320),
            venue=clean_text(info.get("publisher")),
            publisher=clean_text(info.get("publisher")),
            language=normalise_language(clean_text(info.get("language"))),
            subjects=subjects,
            identifiers=identifiers,
            access=(
                Access.DOWNLOAD
                if any(d.fmt in (DownloadFormat.PDF, DownloadFormat.EPUB) for d in downloads)
                else Access.LANDING
            ),
            downloads=downloads,
            landing_url=landing or self_link,
            cover_url=self._cover(info, volume_id),
            rating=as_float(info.get("averageRating")),
            pages=page_count,
            item_type="Book",
            raw={"volumeInfo": info, "accessInfo": access},
        )

    @staticmethod
    def _downloads(access: dict, volume_id: str) -> list:
        out: list = []
        viewability = clean_text(access.get("viewability")).upper()

        pdf = access.get("pdf") or {}
        if pdf.get("isAvailable") and pdf.get("downloadLink"):
            out.append(
                target(
                    clean_text(pdf["downloadLink"]),
                    DownloadFormat.PDF,
                    label="PDF (Google Books)",
                    open_access=True,
                )
            )
        epub = access.get("epub") or {}
        if epub.get("isAvailable") and epub.get("downloadLink"):
            out.append(
                target(
                    clean_text(epub["downloadLink"]),
                    DownloadFormat.EPUB,
                    label="EPUB (Google Books)",
                    open_access=True,
                )
            )
        # "FULL_PUBLIC_DOMAIN" and text-to-speech permission mean the file itself
        # is openly licensed even when no direct link is exposed.
        if clean_text(access.get("publicDomain")).lower() == "true" and volume_id:
            out.append(
                target(
                    f"https://books.google.com/books/download?id={volume_id}&output=txt",
                    DownloadFormat.HTML,
                    label="Public domain full text",
                    open_access=True,
                )
            )
        reader = clean_text(access.get("webReaderLink"))
        if reader and viewability not in ("NO_PAGES",):
            out.append(
                target(
                    reader,
                    DownloadFormat.HTML,
                    label="Preview (Google Books)",
                    open_access=viewability in ("ALL", "PUBLIC_DOMAIN"),
                )
            )
        return out

    @staticmethod
    def _cover(info: dict, volume_id: str) -> str | None:
        links = info.get("imageLinks") or {}
        thumb = clean_text(links.get("thumbnail") or links.get("smallThumbnail"))
        if thumb:
            # Request a larger rendition than the default zoom=1.
            return thumb.replace("&edge=curl", "&zoom=2&w=500")
        if volume_id:
            return f"https://books.google.com/books/content?id={volume_id}&printsec=frontcover&img=1&zoom=2"
        return None


# ---------------------------------------------------------------------------
# GData (Atom) parsing — pure functions so they can be tested without network
# ---------------------------------------------------------------------------
def parse_gdata(text: str) -> list[Result]:
    """Turn a ``books/feeds/volumes`` Atom document into results.

    Kept module-level and network-free so the feed shape can be regression
    tested from a fixture. A malformed page returns ``[]`` rather than raising:
    one bad response should not take the whole provider down.
    """
    if not text or not text.strip():
        return []
    try:
        root = ET.fromstring(text.lstrip("\ufeff"))
    except ET.ParseError:
        return []
    out: list[Result] = []
    for entry in root.findall(f"{ATOM}entry"):
        item = _gdata_entry(entry)
        if item is not None:
            out.append(item)
    return out


def _gdata_entry(entry: ET.Element) -> Result | None:
    """One Atom ``<entry>`` -> :class:`Result`, or ``None`` when unusable."""
    title = _gdata_text(entry, f"{DC}title") or _gdata_text(entry, f"{ATOM}title")
    if not title:
        return None

    identifiers: dict[str, str] = {}
    volume_id = ""
    for node in entry.findall(f"{DC}identifier"):
        value = clean_text(node.text)
        if not value:
            continue
        match = _ISBN.match(value)
        if match:
            digits = re.sub(r"[^0-9Xx]", "", match.group(1))
            if digits:
                identifiers.setdefault("isbn", digits)
        elif not volume_id:
            volume_id = value
    if not volume_id:
        entry_id = _gdata_text(entry, f"{ATOM}id")
        if "/" in entry_id:
            volume_id = entry_id.rstrip("/").rsplit("/", 1)[-1]
    if volume_id:
        identifiers.setdefault("gbid", volume_id)

    authors = _gdata_all(entry, f"{DC}creator")
    subjects = _gdata_all(entry, f"{DC}subject")[:6]
    description = _gdata_text(entry, f"{DC}description")
    publisher = _gdata_text(entry, f"{DC}publisher")
    language = normalise_language(_gdata_text(entry, f"{DC}language"))

    year = None
    date_match = re.search(r"(\d{4})", _gdata_text(entry, f"{DC}date"))
    if date_match:
        year = as_int(date_match.group(1))

    pages = None
    for node in entry.findall(f"{DC}format"):
        page_match = _PAGES.search(clean_text(node.text))
        if page_match:
            pages = as_int(page_match.group(1))
            break

    links: dict[str, str] = {}
    for node in entry.findall(f"{ATOM}link"):
        rel = clean_text(node.get("rel"))
        href = _https(clean_text(node.get("href")))
        if rel and href:
            links[rel.rstrip("/").rsplit("/", 1)[-1]] = href

    open_access = _gdata_value(entry, "openAccess") == "enabled"
    full_view = _gdata_value(entry, "viewability") == "view_all_pages"

    downloads: list = []
    if open_access and full_view and volume_id:
        # Google's own download link carries a signature and is the reliable
        # form; the bare ``?id=...&output=pdf`` URL is the fallback. Both are
        # only ever offered for a volume the feed marks as fully open.
        pdf_url = links.get("pdfdownload") or (
            f"https://books.google.com/books/download?id={volume_id}&output=pdf"
        )
        downloads.append(
            target(
                pdf_url,
                DownloadFormat.PDF,
                label="PDF (Google Books)",
                open_access=True,
            )
        )
        epub_url = links.get("epubdownload")
        if epub_url:
            downloads.append(
                target(
                    epub_url,
                    DownloadFormat.EPUB,
                    label="EPUB (Google Books)",
                    open_access=True,
                )
            )
    elif open_access and volume_id:
        # Public domain but not fully viewable: the plain-text rendition is
        # still openly available even though the scan is not.
        downloads.append(
            target(
                f"https://books.google.com/books/download?id={volume_id}&output=txt",
                DownloadFormat.HTML,
                label="Public domain full text",
                open_access=True,
            )
        )

    landing = links.get("info") or (
        f"https://books.google.com/books?id={volume_id}" if volume_id else ""
    )
    if landing:
        downloads.append(
            target(
                landing,
                DownloadFormat.HTML,
                label="Preview (Google Books)",
                open_access=open_access,
            )
        )

    cover = links.get("thumbnail")
    if cover:
        cover = cover.replace("&edge=curl", "&zoom=2&w=500")

    has_file = any(
        d.fmt in (DownloadFormat.PDF, DownloadFormat.EPUB) for d in downloads
    )
    return Result(
        category=Category.BOOK,
        title=title,
        source="google_books",
        authors=authors,
        year=year,
        abstract=truncate_words(description, 320),
        venue=publisher,
        publisher=publisher,
        language=language,
        subjects=subjects,
        identifiers=identifiers,
        access=Access.DOWNLOAD if has_file else Access.LANDING,
        downloads=downloads,
        landing_url=landing,
        cover_url=cover or None,
        pages=pages,
        item_type="Book",
        raw={"gdata": True},
    )


def _gdata_text(entry: ET.Element, path: str) -> str:
    node = entry.find(path)
    return clean_text(node.text) if node is not None else ""


def _gdata_all(entry: ET.Element, path: str) -> list[str]:
    values = [clean_text(node.text) for node in entry.findall(path)]
    return [value for value in values if value]


def _gdata_value(entry: ET.Element, tag: str) -> str:
    """The tail of a ``gbs:*`` value URI, e.g. ``...#view_all_pages``."""
    node = entry.find(f"{GBS}{tag}")
    if node is None:
        return ""
    return clean_text(node.get("value")).rsplit("#", 1)[-1]


def _https(url: str) -> str:
    """Google still emits ``http://`` links; the site only serves https."""
    if url.startswith("http://"):
        return "https://" + url[len("http://") :]
    return url
