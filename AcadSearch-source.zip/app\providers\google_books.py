"""Google Books — covers, categories, ratings and *direct* PDF/EPUB links.

Docs: https://developers.google.com/books/api/v1
Works without a key, but anonymous quota is shared and small; adding a free key
from Preferences → Network makes the source far more reliable.

Only links that Google explicitly marks as available in ``accessInfo`` are
surfaced as downloads. Anything else falls back to the official preview page.
"""

from __future__ import annotations

import threading

from app.core.text_utils import (
    as_float,
    as_int,
    clean_text,
    normalise_language,
    truncate_words,
)
from app.models import (
    Access,
    Category,
    DownloadFormat,
    Result,
    SearchQuery,
)
from app.providers.base import BaseProvider, register, target

ENDPOINT = "https://www.googleapis.com/books/v1/volumes"


@register
class GoogleBooksProvider(BaseProvider):
    provider_id = "google_books"
    display_name = "Google Books"
    categories = (Category.BOOK,)
    weight = 20
    requires_key = "google_books_key"
    homepage = "https://books.google.com"

    def fetch(self, query: SearchQuery, cancel: threading.Event | None = None) -> list[Result]:
        params: dict[str, object] = {"q": query.text, "maxResults": min(query.per_source, 40)}
        if self.config.google_books_key:
            params["key"] = self.config.google_books_key
        if query.language and query.language != "any":
            params["langRestrict"] = query.language
        if query.year_from or query.year_to:
            low = query.year_from or 1000
            high = query.year_to or 3000
            params["q"] = f"{query.text} publishedDate:{low}-{high}"

        payload = self.http.get_json(
            ENDPOINT, params, provider=self.provider_id, cancel=cancel
        )
        items = payload.get("items") or []
        return [self._to_result(item) for item in items]

    # -- mapping ----------------------------------------------------------
    def _to_result(self, item: dict) -> Result:
        info = item.get("volumeInfo") or {}
        access = item.get("accessInfo") or {}
        volume_id = clean_text(item.get("id"))

        title = clean_text(info.get("title"))
        subtitle = clean_text(info.get("subtitle"))
        if subtitle and subtitle.lower() not in title.lower():
            title = f"{title}: {subtitle}"

        authors = [clean_text(a) for a in (info.get("authors") or []) if a]
        subjects = [clean_text(c) for c in (info.get("categories") or [])[:6] if c]
        page_count = as_int(info.get("pageCount"))
        published = clean_text(info.get("publishedDate"))
        year = as_int(published[:4]) if published else None

        landing = (
            clean_text(access.get("webReaderLink"))
            or (f"https://books.google.com/books?id={volume_id}" if volume_id else "")
        )

        downloads = self._downloads(access, volume_id)
        identifiers: dict[str, str] = {}
        if volume_id:
            identifiers["gbid"] = volume_id
        for kind in ("ISBN_13", "ISBN_10"):
            block = (info.get("industryIdentifiers") or [])
            match = next(
                (b for b in block if b.get("type") == kind and b.get("identifier")), None
            )
            if match:
                identifiers["isbn"] = clean_text(match["identifier"])
                break

        self_link = clean_text(item.get("selfLink"))
        return Result(
            category=Category.BOOK,
            title=title,
            source=self.provider_id,
            authors=authors,
            year=year,
            abstract=truncate_words(clean_text(info.get("description")), 320),
            venue=clean_text(info.get("publisher")),
            publisher=clean_text(info.get("publisher")),
            language=normalise_language(clean_text(info.get("language"))),
            subjects=subjects,
            identifiers=identifiers,
            access=(
                Access.DOWNLOAD
                if any(d.fmt in (DownloadFormat.PDF, DownloadFormat.EPUB) for d in downloads)
                else Access.LANDING
            ),
            downloads=downloads,
            landing_url=landing or self_link,
            cover_url=self._cover(info, volume_id),
            rating=as_float(info.get("averageRating")),
            pages=page_count,
            item_type="Book",
            raw={"volumeInfo": info, "accessInfo": access},
        )

    @staticmethod
    def _downloads(access: dict, volume_id: str) -> list:
        out: list = []
        viewability = clean_text(access.get("viewability")).upper()

        pdf = access.get("pdf") or {}
        if pdf.get("isAvailable") and pdf.get("downloadLink"):
            out.append(
                target(
                    clean_text(pdf["downloadLink"]),
                    DownloadFormat.PDF,
                    label="PDF (Google Books)",
                    open_access=True,
                )
            )
        epub = access.get("epub") or {}
        if epub.get("isAvailable") and epub.get("downloadLink"):
            out.append(
                target(
                    clean_text(epub["downloadLink"]),
                    DownloadFormat.EPUB,
                    label="EPUB (Google Books)",
                    open_access=True,
                )
            )
        # "FULL_PUBLIC_DOMAIN" and text-to-speech permission mean the file itself
        # is openly licensed even when no direct link is exposed.
        if clean_text(access.get("publicDomain")).lower() == "true" and volume_id:
            out.append(
                target(
                    f"https://books.google.com/books/download?id={volume_id}&output=txt",
                    DownloadFormat.HTML,
                    label="Public domain full text",
                    open_access=True,
                )
            )
        reader = clean_text(access.get("webReaderLink"))
        if reader and viewability not in ("NO_PAGES",):
            out.append(
                target(
                    reader,
                    DownloadFormat.HTML,
                    label="Preview (Google Books)",
                    open_access=viewability in ("ALL", "PUBLIC_DOMAIN"),
                )
            )
        return out

    @staticmethod
    def _cover(info: dict, volume_id: str) -> str | None:
        links = info.get("imageLinks") or {}
        thumb = clean_text(links.get("thumbnail") or links.get("smallThumbnail"))
        if thumb:
            # Request a larger rendition than the default zoom=1.
            return thumb.replace("&edge=curl", "&zoom=2&w=500")
        if volume_id:
            return f"https://books.google.com/books/content?id={volume_id}&printsec=frontcover&img=1&zoom=2"
        return None
