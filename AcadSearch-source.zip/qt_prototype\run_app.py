"""Launch the Qt interface empty and ready to search.

This is the real launcher. The demo-data version lives in ``run_main.py`` and is
only for checking the tabs, because it loads sample results at startup, which
made the user think the program had already searched for something.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PySide6.QtWidgets import QApplication

import main_window


def main() -> int:
    app = QApplication(sys.argv)
    win = main_window.MainWindow()
    win.show()
    win.raise_()
    win.activateWindow()

    # Say what to do rather than showing an empty window with no hint. Focus
    # goes to the search box on its own, so the user can start typing.
    win._status(
        "أهلاً. اكتبي كلمة البحث في المربع ثم اضغطي Enter. "
        "البحث بيجمع من 11 مصدر علمي"
    )
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())