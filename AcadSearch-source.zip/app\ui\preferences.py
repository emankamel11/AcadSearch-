"""Preferences dialog: appearance, providers, network and API keys.

Also available on the command line::

    python main.py --preferences
"""

from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox

import customtkinter as ctk

from app import i18n
from app.config import Config
from app.providers import all_providers
from app.ui.theme import Metrics, get_palette

#: UI language codes mapped to the labels shown in the segmented button.
#: These labels never change with the UI language — each one names itself.
_LANGUAGE_LABELS = {"ar": "العربية", "en": "English"}

TABS = (
    ("prefs.tab.appearance", "appearance"),
    ("prefs.tab.providers", "providers"),
    ("prefs.tab.network", "network"),
    ("prefs.tab.general", "general"),
)


class PreferencesDialog(ctk.CTkToplevel):
    """Modal-ish preferences window with a tab per concern."""

    def __init__(self, master, config: Config):
        super().__init__(master)
        self.config = config
        self._palette = get_palette()
        self._metrics = Metrics.scaled(config.font_scale)
        self._fonts = master.fonts if hasattr(master, "fonts") else None
        if self._fonts is None:  # pragma: no cover - only when opened standalone
            from app.ui.theme import Fonts

            self._fonts = Fonts(config.font_family, config.font_scale)
        self._sandbox: dict[str, ctk.BooleanVar] = {}
        self._changes: dict[str, object] = {}
        self._rows: dict[str, int] = {}

        self.title(i18n.t("prefs.title"))
        self.geometry("720x560")
        self.minsize(640, 480)
        self.configure(fg_color=self._palette.bg)
        self.transient(master)
        self.grab_set()
        self._build()
        self.bind("<Escape>", lambda _e: self._cancel())
        self.bind("<Control-s>", lambda _e: self._save())
        self.protocol("WM_DELETE_WINDOW", self._cancel)

    # -- layout ------------------------------------------------------------
    def _build(self) -> None:
        grid = ctk.CTkFrame(self, fg_color="transparent")
        grid.pack(fill="both", expand=True, padx=self._metrics.lg, pady=self._metrics.md)
        grid.grid_columnconfigure(0, weight=1)
        grid.grid_rowconfigure(1, weight=1)

        self.tabview = ctk.CTkTabview(
            grid,
            fg_color="transparent",
            segmented_button_fg_color=self._palette.surface_alt,
            segmented_button_selected_color=self._palette.accent,
            segmented_button_selected_hover_color=self._palette.accent_hover,
            segmented_button_unselected_color=self._palette.surface_alt,
            segmented_button_unselected_hover_color=self._palette.surface_hover,
            text_color=self._palette.text,
            anchor="w",
        )
        self.tabview.grid(row=1, column=0, sticky="nsew", pady=(0, self._metrics.md))
        for key, _name in TABS:
            self.tabview.add(i18n.t(key))

        self._build_appearance(self.tabview.tab(i18n.t(TABS[0][0])))
        self._build_providers(self.tabview.tab(i18n.t(TABS[1][0])))
        self._build_network(self.tabview.tab(i18n.t(TABS[2][0])))
        self._build_general(self.tabview.tab(i18n.t(TABS[3][0])))

        buttons = ctk.CTkFrame(grid, fg_color="transparent")
        buttons.grid(row=2, column=0, sticky="ew")
        buttons.grid_columnconfigure(0, weight=1)

        ctk.CTkButton(
            buttons,
            text=i18n.t("prefs.cancel"),
            width=110,
            height=self._metrics.button_h,
            corner_radius=self._metrics.radius_sm,
            fg_color=self._palette.surface_alt,
            hover_color=self._palette.surface_hover,
            border_width=1,
            border_color=self._palette.border,
            text_color=self._palette.text,
            font=self._fonts.role("body"),
            command=self._cancel,
        ).grid(row=0, column=0, sticky="e", padx=(0, self._metrics.sm))

        ctk.CTkButton(
            buttons,
            text=i18n.t("prefs.save"),
            width=110,
            height=self._metrics.button_h,
            corner_radius=self._metrics.radius_sm,
            fg_color=self._palette.accent,
            hover_color=self._palette.accent_hover,
            text_color=self._palette.text_on_accent,
            font=self._fonts.role("body_bold"),
            command=self._save,
        ).grid(row=0, column=1, sticky="e")

    # -- tabs --------------------------------------------------------------
    # Each tab keeps its own auto-flowing row cursor. Hand-numbered ``row=``
    # arguments were easy to get wrong and silently overlapped widgets.
    def _cursor(self, parent) -> int:
        return self._rows.setdefault(str(parent), 0)

    def _advance(self, parent, count: int = 1) -> None:
        self._rows[str(parent)] = self._cursor(parent) + count

    def _next_row(self, parent, count: int = 1) -> int:
        """Reserve ``count`` rows and return the first one."""
        row = self._cursor(parent)
        self._advance(parent, count)
        return row

    def _section(self, parent, text: str, columnspan: int = 1) -> int:
        """Place a bold field label and return the row for its control."""
        row = self._next_row(parent, 2)
        self._field_label(parent, text, row=row, columnspan=columnspan)
        return row + 1

    def _field_label(self, parent, text: str, row: int = 0, columnspan: int = 1) -> None:
        ctk.CTkLabel(
            parent,
            text=text,
            text_color=self._palette.text,
            font=self._fonts.role("body_bold"),
            anchor="w",
        ).grid(
            row=row, column=0, columnspan=columnspan, sticky="ew",
            pady=(self._metrics.md, self._metrics.xs),
        )

    def _hint(self, parent, text: str, row: int, columnspan: int = 1) -> None:
        ctk.CTkLabel(
            parent,
            text=text,
            text_color=self._palette.text_muted,
            font=self._fonts.role("caption"),
            anchor="w",
            justify="left",
            wraplength=560,
        ).grid(
            row=row, column=0, columnspan=columnspan, sticky="ew",
            pady=(0, self._metrics.sm),
        )

    def _entry(self, parent, value: str, row: int, show: str = "", width: int = 320) -> ctk.CTkEntry:
        entry = ctk.CTkEntry(
            parent,
            width=width,
            height=self._metrics.button_h,
            corner_radius=self._metrics.radius_sm,
            fg_color=self._palette.surface,
            border_color=self._palette.border,
            text_color=self._palette.text,
            font=self._fonts.role("body"),
            show=show,
        )
        entry.insert(0, value or "")
        entry.grid(
            row=row, column=0, columnspan=2, sticky="ew",
            pady=(0, self._metrics.sm),
        )
        return entry

    def _build_appearance(self, tab) -> None:
        tab.grid_columnconfigure(0, weight=1)

        self.theme_var = tk.StringVar(value=self.config.theme)
        frame = ctk.CTkFrame(tab, fg_color="transparent")
        frame.grid(row=self._section(tab, i18n.t("prefs.theme")), column=0,
                   columnspan=2, sticky="ew", pady=(0, self._metrics.md))
        for index, option in enumerate(("system", "dark", "light")):
            ctk.CTkRadioButton(
                frame,
                text=i18n.t(f"prefs.theme.{option}"),
                variable=self.theme_var,
                value=option,
                fg_color=self._palette.accent,
                hover_color=self._palette.accent_hover,
                text_color=self._palette.text,
                font=self._fonts.role("body"),
            ).grid(row=0, column=index, sticky="w", padx=(0, self._metrics.lg))

        # The segmented button shows labels, but the config stores language
        # *codes*, so the code is tracked separately and resolved on change.
        self._lang_code = self.config.ui_language
        self.lang_var = tk.StringVar(value=_LANGUAGE_LABELS[self._lang_code])
        self._language_button = ctk.CTkSegmentedButton(
            tab,
            values=[_LANGUAGE_LABELS["ar"], _LANGUAGE_LABELS["en"]],
            variable=self.lang_var,
            command=self._preview_language,
            height=34,
            corner_radius=self._metrics.radius_sm,
            fg_color=self._palette.surface_alt,
            selected_color=self._palette.accent,
            selected_hover_color=self._palette.accent_hover,
            unselected_color=self._palette.surface_alt,
            unselected_hover_color=self._palette.surface_hover,
            text_color=self._palette.text,
            font=self._fonts.role("body_bold"),
        ).grid(row=self._section(tab, i18n.t("prefs.ui_language")), column=0,
               columnspan=2, sticky="w", pady=(0, self._metrics.md))

        self.scale_var = tk.DoubleVar(value=self.config.font_scale)
        self.scale_value = ctk.CTkLabel(
            tab, text=f"{self.config.font_scale:.2f}×",
            text_color=self._palette.text_muted, font=self._fonts.role("small"), width=50,
        )
        scale_row = self._section(tab, i18n.t("prefs.font_scale"))
        ctk.CTkSlider(
            tab,
            from_=0.8, to=1.6, number_of_steps=8, variable=self.scale_var,
            width=280, height=16, fg_color=self._palette.surface_alt,
            progress_color=self._palette.accent, button_color=self._palette.accent,
            button_hover_color=self._palette.accent_hover,
            command=self._preview_scale,
        ).grid(row=scale_row, column=0, sticky="w", pady=(0, self._metrics.md))
        self.scale_value.grid(row=scale_row, column=1, sticky="w",
                              padx=(self._metrics.sm, 0))

        self.abstract_var = tk.IntVar(value=self.config.abstract_chars)
        ctk.CTkSlider(
            tab,
            from_=120, to=900, number_of_steps=13, variable=self.abstract_var,
            width=280, height=16, fg_color=self._palette.surface_alt,
            progress_color=self._palette.accent, button_color=self._palette.accent,
            button_hover_color=self._palette.accent_hover,
        ).grid(row=self._section(tab, i18n.t("prefs.abstract_length")), column=0,
               columnspan=2, sticky="w")

    def _build_providers(self, tab) -> None:
        tab.grid_columnconfigure(1, weight=1)
        self._field_label(tab, i18n.t("prefs.enable_provider"), row=self._next_row(tab))
        self._hint(tab, i18n.t("help.howto.keys"), self._next_row(tab), columnspan=2)

        for provider in all_providers():
            var = tk.BooleanVar(
                value=self.config.is_enabled(provider.provider_id)
            )
            self._sandbox[provider.provider_id] = var
            name = i18n.t(f"provider.{provider.provider_id}")

            row = ctk.CTkFrame(tab, fg_color="transparent")
            row.grid_columnconfigure(1, weight=1)
            row.grid(
                row=self._next_row(tab), column=0, columnspan=2, sticky="ew",
                pady=(0, self._metrics.sm),
            )
            ctk.CTkSwitch(
                row,
                text=name,
                variable=var,
                command=lambda pid=provider.provider_id, v=var: self._toggle_provider(pid, v),
                fg_color=self._palette.accent,
                progress_color=self._palette.accent,
                button_color=self._palette.text_on_accent,
                text_color=self._palette.text,
                font=self._fonts.role("body"),
                width=46,
            ).grid(row=0, column=0, sticky="w")
            detail = provider.homepage or ""
            if provider.requires_key:
                detail = f"{detail}  ·  API key optional"
            ctk.CTkLabel(
                row,
                text=detail,
                text_color=self._palette.text_faint,
                font=self._fonts.role("caption"),
                anchor="w",
            ).grid(row=0, column=1, sticky="w", padx=(self._metrics.sm, 0))

    def _toggle_provider(self, provider_id: str, var: tk.BooleanVar) -> None:
        current = set(self.config.enabled_providers)
        if var.get():
            current.add(provider_id)
        else:
            current.discard(provider_id)
        self._changes["enabled_providers"] = current or set(
            p.provider_id for p in all_providers()
        )

    def _build_network(self, tab) -> None:
        tab.grid_columnconfigure(0, weight=1)

        self._field_label(tab, i18n.t("prefs.api_keys"), row=self._next_row(tab))
        self._hint(tab, i18n.t("prefs.api_keys.help"), self._next_row(tab), columnspan=2)

        key_fields = (
            ("gb_key", self.config.google_books_key, "prefs.google_books_key", ""),
            ("s2_key", self.config.semantic_scholar_key, "prefs.semantic_scholar_key", "•"),
            ("oa_key", self.config.openalex_key, "prefs.openalex_key", "•"),
            ("core_key", self.config.core_key, "prefs.core_key", "•"),
            ("base_key", self.config.base_key, "prefs.base_key", "•"),
            ("pubmed_key", self.config.pubmed_key, "prefs.pubmed_label", "•"),
            ("lens_key", self.config.lens_key, "prefs.lens_label", "•"),
            ("scilit_key", self.config.scilit_key, "prefs.scilit_label", "•"),
            ("scinapse_key", self.config.scinapse_key, "prefs.scinapse_label", "•"),
            ("springer_key", self.config.springer_key, "prefs.springer_label", "•"),
        )
        for attribute, value, label_key, show in key_fields:
            row = self._next_row(tab)
            setattr(
                self, attribute,
                self._entry(tab, value, row, show=show),
            )
            ctk.CTkLabel(
                tab,
                text=i18n.t(label_key),
                text_color=self._palette.text_muted,
                font=self._fonts.role("caption"),
                anchor="w",
            ).grid(row=row, column=2, sticky="w", padx=(self._metrics.sm, 0))

        self._field_label(
            tab, i18n.t("prefs.contact_email"), row=self._next_row(tab)
        )
        self._hint(
            tab, i18n.t("prefs.contact_email.help"), self._next_row(tab), columnspan=2
        )
        self.contact_entry = self._entry(tab, self.config.contact_email, self._next_row(tab))

    def _build_general(self, tab) -> None:
        tab.grid_columnconfigure(0, weight=1)
        self._field_label(tab, i18n.t("prefs.download_dir"), row=self._next_row(tab))
        row = ctk.CTkFrame(tab, fg_color="transparent")
        row.grid(row=self._next_row(tab), column=0, columnspan=3, sticky="ew",
                 pady=(0, self._metrics.md))
        row.grid_columnconfigure(0, weight=1)

        self.download_entry = ctk.CTkEntry(
            row,
            height=self._metrics.button_h,
            corner_radius=self._metrics.radius_sm,
            fg_color=self._palette.surface,
            border_color=self._palette.border,
            text_color=self._palette.text,
            font=self._fonts.role("body"),
        )
        self.download_entry.insert(0, str(self.config.download_folder))
        self.download_entry.grid(row=0, column=0, sticky="ew",
                                 padx=(0, self._metrics.sm))
        ctk.CTkButton(
            row,
            text=i18n.t("prefs.browse"),
            width=100,
            height=self._metrics.button_h,
            corner_radius=self._metrics.radius_sm,
            fg_color=self._palette.surface_alt,
            hover_color=self._palette.surface_hover,
            border_width=1,
            border_color=self._palette.border,
            text_color=self._palette.text,
            font=self._fonts.role("body"),
            command=self._browse,
        ).grid(row=0, column=1)

        self.cache_var = tk.BooleanVar(value=self.config.use_cache)
        ctk.CTkSwitch(
            tab,
            text=i18n.t("prefs.cache"),
            variable=self.cache_var,
            fg_color=self._palette.accent,
            progress_color=self._palette.accent,
            button_color=self._palette.text_on_accent,
            text_color=self._palette.text,
            font=self._fonts.role("body"),
        ).grid(row=self._next_row(tab), column=0, sticky="w", pady=(0, self._metrics.sm))
        self._hint(tab, i18n.t("prefs.cache.help"), self._next_row(tab))

        self.confirm_var = tk.BooleanVar(value=self.config.confirm_open_browser)
        ctk.CTkSwitch(
            tab,
            text=i18n.t("download.confirm_open", url="…"),
            variable=self.confirm_var,
            fg_color=self._palette.accent,
            progress_color=self._palette.accent,
            button_color=self._palette.text_on_accent,
            text_color=self._palette.text,
            font=self._fonts.role("body"),
        ).grid(row=self._next_row(tab), column=0, sticky="w", pady=(0, self._metrics.md))

    # -- live preview ------------------------------------------------------
    def _preview_language(self, value: str = "") -> None:
        for code, label in _LANGUAGE_LABELS.items():
            if label == self.lang_var.get():
                self._lang_code = code
                break
        master = self.master
        if hasattr(master, "set_language"):
            master.set_language(self._lang_code)

    def _preview_scale(self, value: float) -> None:
        self.scale_value.configure(text=f"{float(value):.2f}×")
        master = self.master
        if hasattr(master, "fonts"):
            master.fonts.set_scale(float(value))

    def _browse(self) -> None:
        chosen = filedialog.askdirectory(
            parent=self, title=i18n.t("prefs.download_dir"),
            initialdir=self.download_entry.get() or str(self.config.download_folder),
        )
        if chosen:
            self.download_entry.delete(0, "end")
            self.download_entry.insert(0, chosen)

    # -- commit / cancel ---------------------------------------------------
    def _save(self) -> None:
        self.config.theme = self.theme_var.get()
        self.config.ui_language = self._lang_code
        self.config.font_scale = float(self.scale_var.get())
        self.config.abstract_chars = int(self.abstract_var.get())
        self.config.google_books_key = self.gb_key.get().strip()
        self.config.semantic_scholar_key = self.s2_key.get().strip()
        self.config.openalex_key = self.oa_key.get().strip()
        self.config.core_key = self.core_key.get().strip()
        self.config.base_key = self.base_key.get().strip()
        self.config.pubmed_key = self.pubmed_key.get().strip()
        self.config.lens_key = self.lens_key.get().strip()
        self.config.scilit_key = self.scilit_key.get().strip()
        self.config.scinapse_key = self.scinapse_key.get().strip()
        self.config.springer_key = self.springer_key.get().strip()
        self.config.contact_email = self.contact_entry.get().strip()
        self.config.use_cache = bool(self.cache_var.get())
        self.config.confirm_open_browser = bool(self.confirm_var.get())
        folder = self.download_entry.get().strip()
        if folder:
            self.config.download_dir = folder

        if "enabled_providers" in self._changes:
            self.config.enabled_providers = set(self._changes["enabled_providers"])

        try:
            self.config.save()
        except OSError as exc:
            messagebox.showerror(
                i18n.t("generic.error_title"), str(exc), parent=self
            )
            return

        master = self.master
        if hasattr(master, "set_theme"):
            master.set_theme(self.config.theme)
        if hasattr(master, "_build_chips"):
            master._build_chips()
        if hasattr(master, "fonts"):
            master.fonts.set_scale(self.config.font_scale)
        self._announce_on_master(i18n.t("prefs.saved"))
        self.destroy()

    def _cancel(self) -> None:
        master = self.master
        # Revert any live preview applied while the dialog was open.
        if hasattr(master, "fonts"):
            master.fonts.set_scale(self.config.font_scale)
        if hasattr(master, "set_theme"):
            master.set_theme(self.config.theme)
        if hasattr(master, "set_language"):
            master.set_language(self.config.ui_language)
        self.destroy()

    def _announce_on_master(self, message: str) -> None:
        if hasattr(self.master, "_announce"):
            self.master._announce(message)
