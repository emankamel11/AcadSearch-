"""F1 help dialog: what the buttons do and how to drive the window.

Mirrors the whole interface: everything is real, selectable text and nothing
relies on colour. The dialog is reachable with F1 only, like the old canvas
helper, but it describes the Qt window as it actually is -- the shortcuts here
are the ones registered in main_window.py, not a copy of another UI.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)


from app import i18n


def _silent(widget) -> None:
    """The text on the widget is the announcement; no second reading of it."""
    widget.setAccessibleName("")


def guide() -> tuple[str, ...]:
    """How the program is used, one paragraph each, in the interface language."""
    return tuple(i18n.t(key) for key in (
        "help.guide.p1",
        "help.guide.p2",
        "help.guide.p3",
        "help.guide.p4",
        "help.guide.p5",
        "help.guide.p6",
    ))


#: (key or i18n key, i18n key for what it does). These are the exact bindings
#: in main_window. A ``help.``-prefixed first element is itself translated
#: (the Application-key label and the zoom line have words in them).
SHORTCUTS: tuple[tuple[str, str], ...] = (
    ("F1", "help.sc.F1"),
    ("help.key.appkey", "help.sc.appkey"),
    ("Enter", "help.sc.enter"),
    ("Ctrl+K", "help.sc.ctrlk"),
    ("Escape", "help.sc.esc"),
    ("Ctrl+1 · Ctrl+2 · Ctrl+3", "help.sc.ctrltabs"),
    ("↑ ↓", "help.sc.arrows"),
    ("Tab · Shift+Tab", "help.sc.tab"),
    ("Alt+D", "help.sc.altd"),
    ("Alt+C", "help.sc.altc"),
    ("Alt+M", "help.sc.altm"),
    ("Alt+O", "help.sc.alto"),
    ("Alt+S", "help.sc.alts"),
    ("help.key.zoom", "help.sc.zoom"),
    ("Ctrl+0", "help.sc.reset"),
)


class HelpDialog(QDialog):
    """Two readable lists: how the program works, then every shortcut."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(i18n.t("help.window.title"))
        self.setAccessibleName(i18n.t("help.window.accessible"))
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(780, 580)
        self.setMinimumWidth(640)

        root = QVBoxLayout(self)

        title = QLabel(i18n.t("help.title.text"))
        title.setObjectName("HelpTitle")
        _silent(title)
        root.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(10)

        self._heading(lay, i18n.t("help.group.guide"))
        for paragraph in guide():
            self._paragraph(lay, paragraph)

        self._heading(lay, i18n.t("help.group.shortcuts"))
        for key, what_key in SHORTCUTS:
            key_label = i18n.t(key) if key.startswith("help.") else key
            self._shortcut(lay, key_label, i18n.t(what_key))

        lay.addStretch(1)
        scroll.setWidget(body)
        root.addWidget(scroll, 1)

        footer = QHBoxLayout()
        footer.addStretch(1)
        close = QPushButton(i18n.t("help.close.text"))
        close.setObjectName("PrimaryButton")
        close.setAccessibleName(i18n.t("help.close.accessible"))
        close.setToolTip(i18n.t("help.close.tooltip"))
        close.setDefault(True)
        close.clicked.connect(self.accept)
        footer.addWidget(close)
        root.addLayout(footer)

    # -- content builders ------------------------------------------------
    @staticmethod
    def _heading(lay: QVBoxLayout, text: str) -> None:
        label = QLabel(text)
        label.setObjectName("HelpGroup")
        _silent(label)
        lay.addWidget(label)

    @staticmethod
    def _paragraph(lay: QVBoxLayout, text: str) -> None:
        label = QLabel(text)
        label.setObjectName("HelpText")
        label.setWordWrap(True)
        label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        _silent(label)
        lay.addWidget(label)

    @staticmethod
    def _shortcut(lay: QVBoxLayout, key: str, what: str) -> None:
        row = QHBoxLayout()
        row.setSpacing(14)
        key_label = QLabel(key)
        key_label.setObjectName("HelpKey")
        _silent(key_label)
        row.addWidget(key_label)
        row.addStretch(1)
        what_label = QLabel(what)
        what_label.setObjectName("HelpText")
        what_label.setWordWrap(True)
        _silent(what_label)
        row.addWidget(what_label, 1)
        lay.addLayout(row)

    # -- behaviour ------------------------------------------------------
    def keyPressEvent(self, event):  # noqa: N802 - Qt naming
        """Escape closes, and F1 closes too, like every help pane on Windows."""
        if event.key() in (Qt.Key_Escape, Qt.Key_F1) and not event.isAutoRepeat():
            self.accept()
            return
        super().keyPressEvent(event)