"""Check result quality: how many are relevant to the query, and do they
carry a source, and are years/authors missing?

Uses a real search so the numbers describe what the user actually sees.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.search_engine import SearchEngine, SearchEventType
from app.models import Category, SearchQuery

QUERIES = ["machine learning", "الذكاء الاصطناعي", "photosynthesis"]


def main() -> int:
    engine = SearchEngine()
    for text in QUERIES:
        query = SearchQuery(
            text=text,
            categories={Category.BOOK, Category.ARTICLE, Category.RESEARCH},
            per_source=10,
        )
        handle = engine.start(query)
        response = None
        while not handle.done:
            time.sleep(0.2)
        # drain
        import queue as q
        try:
            while True:
                e = handle.events.get_nowait()
                if e.type == SearchEventType.FINISHED:
                    response = e.response
        except q.Empty:
            pass

        if response is None:
            print(f'"{text}": no response')
            continue

        print("=" * 60)
        print(f'"{text}"  -> {response.total()} results')
        words = {w.lower() for w in text.split()}

        for category, items in response.results.items():
            if not items:
                continue
            no_source = sum(1 for r in items if not r.source)
            no_year = sum(1 for r in items if not r.year)
            no_author = sum(1 for r in items if not r.authors)
            with_dl = sum(1 for r in items if r.downloads)
            # relevance: title contains at least one query word
            rel = sum(
                1 for r in items
                if any(w in (r.title or "").lower() for w in words)
            )
            print(f"  {category.value:9} n={len(items):3d} "
                  f"relevant={rel:3d} ({rel*100//max(len(items),1)}%) "
                  f"no_source={no_source} no_year={no_year} "
                  f"no_author={no_author} downloadable={with_dl}")
        print()
        time.sleep(1)
    engine.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())