"""Reproduce the two newest complaints.

1. Typing a full title returns no second title (exact-phrase handling).
2. Pressing clear leaves the text in the search box.
"""

from __future__ import annotations

import queue
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtCore import Qt, QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QPushButton

import main_window

TITLES = [
    "machine learning",
    "introduction to machine learning",
    "the structured world",
]


def clear_button(win):
    for b in win.findChildren(QPushButton):
        if "مسح" in (b.accessibleName() or ""):
            return b
    return None


def main() -> int:
    app = QApplication([])
    win = main_window.MainWindow()
    win.show()

    def test_clear_first() -> None:
        print("=== clear button, three ways ===")
        btn = clear_button(win)
        print("  button found:", btn is not None, "->",
              btn.accessibleName() if btn else None)

        win.query.setText("machine learning")
        QTest.mouseClick(btn, Qt.LeftButton)
        app.processEvents()
        print(f"  after mouse click   : {win.query.text()!r}")

        win.query.setText("abc")
        win._clear()
        print(f"  after _clear()      : {win.query.text()!r}")

        win.query.setText("xyz")
        if btn is not None:
            btn.click()
            app.processEvents()
        print(f"  after btn.click()   : {win.query.text()!r}")
        print(f"  rows                : "
              f"{[p.list.count() for p in win.pages.values()]}")
        print()

        print("=== title queries ===")
        run_titles()

    def run_titles() -> None:
        state = {"index": 0}

        def next_title() -> None:
            if state["index"] >= len(TITLES):
                app.quit()
                return
            text = TITLES[state["index"]]
            state["index"] += 1
            print(f'  query "{text}"')
            win.query.setText(text)
            win.start_search()
            QTimer.singleShot(26000, lambda: report(text, next_title))

        def report(text: str, then) -> None:
            counts = {c.value: p.list.count() for c, p in win.pages.items()}
            print(f"    results per tab: {counts}  total={sum(counts.values())}")
            win._clear()
            then()

    QTimer.singleShot(500, test_clear_first)
    QTimer.singleShot(120000, app.quit)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())