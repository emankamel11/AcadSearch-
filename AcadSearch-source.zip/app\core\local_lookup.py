"""Fill a citation from a DOI or ISBN found inside a local file.

The file itself never leaves the machine: only the identifier printed inside it
(the DOI or ISBN) is sent, and only to fetch the official record from Crossref,
Google Books or Open Library. Every lookup is best-effort -- a timeout, a 404 or
a malformed reply returns ``None`` so the dialog keeps the editable fields the
user already has. Nothing is guessed from the body text.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Callable
from urllib.parse import quote

import requests

from app.core.local_file import find_doi, find_isbn, text_layer

_CROSSREF = "https://api.crossref.org/works/{doi}"
_GOOGLE_BOOKS = "https://www.googleapis.com/books/v1/volumes"
_OPEN_LIBRARY_SEARCH = "https://openlibrary.org/search.json"
_USER_AGENT = "AcadSearch/2.0 (+https://github.com/emankamel11/AcadSearch-)"

Fields = dict


def enrich_from_file(
    path: str | Path,
    timeout: float = 5.0,
    should_stop: Callable[[], bool] | None = None,
) -> Fields:
    """Read the text layer of ``path`` and look up its DOI or ISBN.

    Returns a dict with ``title``, ``authors``, ``year``, ``venue``, ``doi`` and
    ``source`` (``"doi"`` or ``"isbn"``), or ``{}`` when nothing was found.
    """
    stop = should_stop or (lambda: False)
    text = text_layer(path)
    if not text:
        return {}

    doi = find_doi(text)
    if doi:
        fields = lookup_doi(doi, timeout=timeout)
        if fields:
            return fields
    if stop():
        return {}

    isbn = find_isbn(text)
    if isbn:
        fields = lookup_isbn(isbn, timeout=timeout)
        if fields:
            return fields
    return {}


# ---------------------------------------------------------------------------
# crossref (journal articles, chapters, conference papers)
# ---------------------------------------------------------------------------
def lookup_doi(doi: str, timeout: float = 5.0) -> Fields | None:
    doi = (doi or "").strip()
    if not doi:
        return None
    message = _get_json(_CROSSREF.format(doi=quote(doi, safe="")), timeout)
    if not message:
        return None
    message = message.get("message") or {}
    title = _first_text(message.get("title"))
    if not title:
        return None

    authors: list[str] = []
    for author in message.get("author") or []:
        if not isinstance(author, dict):
            continue
        given = str(author.get("given") or "").strip()
        family = str(author.get("family") or "").strip()
        name = str(author.get("name") or "").strip()
        if family and given:
            authors.append(f"{given} {family}")
        elif family:
            authors.append(family)
        elif name:
            authors.append(name)

    return {
        "title": title,
        "authors": authors,
        "year": _crossref_year(message),
        "venue": _first_text(message.get("container-title"))
        or str(message.get("publisher") or "").strip(),
        "doi": str(message.get("DOI") or doi).strip(),
        "source": "doi",
    }


def _crossref_year(message: dict) -> int | None:
    for key in ("issued", "published-print", "published-online", "created"):
        parts = (message.get(key) or {}).get("date-parts") or []
        if parts and parts[0] and parts[0][0]:
            try:
                return int(parts[0][0])
            except (TypeError, ValueError):
                continue
    return None


# ---------------------------------------------------------------------------
# ISBN (books) -- Google Books first (one request), Open Library as a fallback
# ---------------------------------------------------------------------------
def lookup_isbn(isbn: str, timeout: float = 5.0) -> Fields | None:
    isbn = re.sub(r"[^0-9Xx]", "", isbn or "").upper()
    if len(isbn) not in (10, 13):
        return None
    primary = _google_books(isbn, timeout)
    if primary and primary.get("authors") and primary.get("year"):
        return primary
    fallback = _open_library(isbn, timeout)
    if primary is None:
        return fallback
    if fallback:
        for key in ("authors", "year", "venue"):
            if not primary.get(key) and fallback.get(key):
                primary[key] = fallback[key]
    return primary


def _google_books(isbn: str, timeout: float) -> Fields | None:
    data = _get_json(
        _GOOGLE_BOOKS, timeout, params={"q": f"isbn:{isbn}", "maxResults": 1}
    )
    items = (data or {}).get("items") or []
    if not items:
        return None
    info = items[0].get("volumeInfo") or {}
    title = str(info.get("title") or "").strip()
    subtitle = str(info.get("subtitle") or "").strip()
    if subtitle and subtitle.lower() not in title.lower():
        title = f"{title}: {subtitle}" if title else subtitle
    if not title:
        return None
    authors = [
        str(author).strip()
        for author in (info.get("authors") or [])
        if str(author).strip()
    ]
    return {
        "title": title,
        "authors": authors,
        "year": _year_from(str(info.get("publishedDate") or "")),
        "venue": str(info.get("publisher") or "").strip(),
        "doi": "",
        "source": "isbn",
    }


def _open_library(isbn: str, timeout: float) -> Fields | None:
    # The edition record rarely carries authors (they live on the work), so ask
    # the search endpoint, which returns them in the same reply.
    data = _get_json(
        _OPEN_LIBRARY_SEARCH,
        timeout,
        params={
            "isbn": isbn,
            "fields": "title,author_name,first_publish_year,publish_year,publisher",
            "limit": 1,
        },
    )
    docs = (data or {}).get("docs") or []
    if not docs:
        return None
    doc = docs[0]
    title = str(doc.get("title") or "").strip()
    if not title:
        return None

    authors = [
        str(author).strip()
        for author in (doc.get("author_name") or [])
        if str(author).strip()
    ]

    year = doc.get("first_publish_year")
    try:
        year = int(year) if year else None
    except (TypeError, ValueError):
        year = None
    if year is None:
        for value in doc.get("publish_year") or []:
            try:
                year = int(value)
                break
            except (TypeError, ValueError):
                continue

    publishers = doc.get("publisher") or []
    venue = str(publishers[0]).strip() if publishers else ""

    return {
        "title": title,
        "authors": authors,
        "year": year,
        "venue": venue,
        "doi": "",
        "source": "isbn",
    }


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _get_json(url: str, timeout: float, params: dict | None = None) -> dict | None:
    try:
        response = requests.get(
            url,
            params=params,
            timeout=(3.0, timeout),
            headers={"User-Agent": _USER_AGENT},
        )
    except requests.RequestException:
        return None
    if response.status_code != 200:
        return None
    try:
        payload = response.json()
    except ValueError:
        return None
    return payload if isinstance(payload, dict) else None


def _first_text(value: object) -> str:
    if isinstance(value, (list, tuple)):
        for item in value:
            text = _first_text(item)
            if text:
                return text
        return ""
    if isinstance(value, str):
        return value.strip()
    return ""


def _year_from(value: str) -> int | None:
    match = re.search(r"(1[5-9]\d{2}|20\d{2}|21\d{2})", value or "")
    return int(match.group(1)) if match else None
