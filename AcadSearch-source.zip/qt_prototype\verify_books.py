"""Verify the book results are real records, not junk, by asking the sources.

Three checks per result:
  1. does the identifier resolve at the source? (OpenAlex DOI, Open Library work)
  2. does the landing URL actually exist?
  3. does the title look like real bibliographic data or like a scraped
     filename / course advert / site name?
"""

import sys
import json
import re
import urllib.request
import time
import queue
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from app.core.search_engine import SearchEngine, SearchEventType
from app.models import SearchQuery, Category

UA = {"User-Agent": "Mozilla/5.0 (AcadSearch verification)"}

# Signs that a "title" was scraped rather than catalogued.
JUNK_PATTERNS = [
    (r"_", "underscore = a filename"),
    (r"\.(com|org|net|io)\b", "site name inside the title"),
    (r"\bPDFDr\b|\bpdfcoffee\b|\bGiga Course\b|\bCoursera\b|\bUdemy\b", "course/piracy advert"),
    (r"^(machine|introduction|handson|handson|complete|understanding|python)-", "slug, not a title"),
    (r"\bZero To\b|\bMega\b|\bUltimate\b", "spam course title"),
]


def looks_junk(title: str) -> str:
    low = title.lower()
    for pattern, why in JUNK_PATTERNS:
        if re.search(pattern, low):
            return why
    if len(title) > 90:
        return "title too long, likely truncated junk"
    return ""


def head(url: str) -> str:
    try:
        req = urllib.request.Request(url, headers=UA, method="GET")
        with urllib.request.urlopen(req, timeout=20) as resp:
            return str(resp.status)
    except Exception as exc:
        return f"{type(exc).__name__}"


eng = SearchEngine()
q = SearchQuery(text="machine learning", categories={Category.BOOK}, per_source=40)
h = eng.start(q)
resp = None
while not h.done:
    time.sleep(0.25)
    try:
        while True:
            e = h.events.get_nowait()
            if e.type == SearchEventType.FINISHED:
                resp = e.response
    except queue.Empty:
        pass

books = resp.results[Category.BOOK]
eng.shutdown()

print(f"total books: {len(books)}\n")

print("=== A. identifier resolves at the source ===")
for r in books:
    if r.source == "openalex" and r.identifiers.get("doi"):
        doi = r.identifiers["doi"]
        status = head(f"https://api.crossref.org/works/{doi}")
        print(f"  crossref {doi[:40]:42} -> {status}  {r.title[:36]}")
    elif r.source == "open_library" and "works/" in (r.landing_url or ""):
        work = r.landing_url.rsplit("/", 1)[-1]
        status = head(f"https://openlibrary.org/works/{work}.json")
        print(f"  openlib  {work:20} -> {status}  {r.title[:36]}")
    elif r.source == "internet_archive":
        ident = (r.landing_url or "").rsplit("/", 1)[-1]
        status = head(f"https://archive.org/metadata/{ident}")
        if status == "200":
            try:
                req = urllib.request.Request(
                    f"https://archive.org/metadata/{ident}", headers=UA
                )
                meta = json.loads(urllib.request.urlopen(req, timeout=20).read())
                server = meta.get("metadata", {})
                real = server.get("title", "")
                mediatype = server.get("mediatype", "?")
                print(f"  archive  {ident[:34]:36} -> {status} [{mediatype}] real title={real[:40]!r}")
            except Exception as exc:
                print(f"  archive  {ident[:34]:36} -> parse fail {type(exc).__name__}")

print()
print("=== B. title quality ===")
clean = 0
dirty = []
for r in books:
    why = looks_junk(r.title)
    if why:
        dirty.append((r.source, r.title, why))
    else:
        clean += 1
print(f"  clean titles: {clean}")
print(f"  junk-looking titles: {len(dirty)}")
for src, title, why in dirty:
    print(f"    [{src:16}] {title[:56]:58} <- {why}")

print()
print("=== C. per-source summary ===")
for src in ("openalex", "open_library", "internet_archive"):
    rows = [r for r in books if r.source == src]
    bad = [r for r in rows if looks_junk(r.title)]
    with_id = sum(
        1 for r in rows if r.identifiers.get("doi") or r.identifiers.get("isbn")
        or r.identifiers.get("isbn13")
    )
    print(
        f"  {src:16} n={len(rows):3d}  with_isbn_or_doi={with_id:3d}  junk_title={len(bad):3d}"
    )