"""Keyboard-shortcut reference and a short user guide (F1)."""

from __future__ import annotations

import tkinter as tk

import customtkinter as ctk

from app import i18n
from app.ui.theme import Metrics, get_palette

SHORTCUTS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("help.search", ("help.kbd.enter", "help.kbd.ctrl_k", "help.kbd.f5", "help.kbd.esc")),
    ("help.nav", ("help.kbd.tab", "help.kbd.shift_tab", "help.kbd.f2", "help.kbd.f3",
                  "help.kbd.f4", "help.kbd.f6", "help.kbd.up_down", "help.kbd.ctrl_home",
                  "help.kbd.ctrl_end", "help.kbd.page")),
    ("help.general", ("help.kbd.alt_d", "help.kbd.alt_o", "help.kbd.alt_c",
                      "help.kbd.ctrl_shift_c", "help.kbd.ctrl_d",
                      "help.kbd.ctrl_l", "help.kbd.f1", "help.kbd.ctrl_a")),
    ("help.speech", ("help.kbd.alt_s", "help.kbd.alt_r")),
)

GUIDE_KEYS = (
    "help.howto.search",
    "help.howto.sections",
    "help.howto.download",
    "help.howto.cite",
    "help.howto.access",
    "help.howto.speech",
    "help.howto.keys",
)


class ShortcutDialog(ctk.CTkToplevel):
    """Two columns: how the app works on the left, shortcuts on the right."""

    def __init__(self, master):
        super().__init__(master)
        self._palette = get_palette()
        self._fonts = getattr(master, "fonts", None)
        if self._fonts is None:  # pragma: no cover
            from app.ui.theme import Fonts

            self._fonts = Fonts()
        self.metrics = Metrics.scaled(1.0)

        self.title(i18n.t("help.contents"))
        self.geometry("940x640")
        self.minsize(760, 520)
        self.configure(fg_color=self._palette.bg)
        self.transient(master)

        grid = ctk.CTkFrame(self, fg_color="transparent")
        grid.pack(fill="both", expand=True, padx=self.metrics.lg, pady=self.metrics.lg)
        grid.grid_columnconfigure(0, weight=3)
        grid.grid_columnconfigure(1, weight=2)
        grid.grid_rowconfigure(0, weight=1)

        self._build_guide(grid)
        self._build_shortcuts(grid)

        footer = ctk.CTkFrame(grid, fg_color="transparent")
        footer.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(self.metrics.md, 0))
        footer.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            footer,
            text=i18n.t("app.menu_about_text").splitlines()[0],
            text_color=self._palette.text_faint,
            font=self._fonts.role("caption"),
            anchor="w",
        ).grid(row=0, column=0, sticky="w")
        self.close_button = ctk.CTkButton(
            footer,
            text=i18n.t("generic.close"),
            width=110,
            height=self.metrics.button_h,
            corner_radius=self.metrics.radius_sm,
            fg_color=self._palette.accent,
            hover_color=self._palette.accent_hover,
            text_color=self._palette.text_on_accent,
            font=self._fonts.role("body_bold"),
            command=self.destroy,
        )
        self.close_button.grid(row=0, column=1, sticky="e")

        self.bind("<Escape>", lambda _e: self.destroy())
        self.bind("<F1>", lambda _e: self.destroy())
        self.after(60, self._focus_first)

    def _focus_first(self) -> None:
        try:
            self.close_button.focus_set()
        except (AttributeError, tk.TclError):  # pragma: no cover
            pass

    # -- columns ------------------------------------------------------------
    def _build_guide(self, parent) -> None:
        holder = ctk.CTkFrame(
            parent,
            fg_color=self._palette.surface,
            corner_radius=self.metrics.radius,
            border_width=1,
            border_color=self._palette.border,
        )
        holder.grid(row=0, column=0, sticky="nsew",
                    padx=(0, self.metrics.sm))
        holder.grid_columnconfigure(0, weight=1)
        holder.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(
            holder,
            text=i18n.t("help.contents"),
            text_color=self._palette.text,
            font=self._fonts.role("title"),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew",
               padx=self.metrics.card_pad, pady=(self.metrics.card_pad, self.metrics.sm))

        body = ctk.CTkScrollableFrame(
            holder,
            fg_color="transparent",
            scrollbar_button_color=self._palette.border_strong,
        )
        body.grid(row=1, column=0, sticky="nsew",
                  padx=(self.metrics.card_pad, 0), pady=(0, self.metrics.card_pad))
        body.grid_columnconfigure(0, weight=1)

        row = 0
        for key in GUIDE_KEYS:
            ctk.CTkLabel(
                body,
                text=i18n.t(key),
                text_color=self._palette.text_muted,
                font=self._fonts.role("small"),
                anchor="w",
                justify="left",
                wraplength=420,
            ).grid(row=row, column=0, sticky="ew", pady=(0, self.metrics.md))
            row += 1

        ctk.CTkLabel(
            body,
            text=f"{i18n.t('search.language')}: " + " · ".join(
                label for _, label in i18n.language_options()[:8]
            ),
            text_color=self._palette.text_faint,
            font=self._fonts.role("caption"),
            anchor="w",
            justify="left",
            wraplength=420,
        ).grid(row=row, column=0, sticky="ew", pady=(0, self.metrics.md))

    def _build_shortcuts(self, parent) -> None:
        holder = ctk.CTkFrame(
            parent,
            fg_color=self._palette.surface,
            corner_radius=self.metrics.radius,
            border_width=1,
            border_color=self._palette.border,
        )
        holder.grid(row=0, column=1, sticky="nsew")
        holder.grid_columnconfigure(0, weight=1)
        holder.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(
            holder,
            text=i18n.t("help.title"),
            text_color=self._palette.text,
            font=self._fonts.role("title"),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew",
               padx=self.metrics.card_pad, pady=(self.metrics.card_pad, self.metrics.sm))

        body = ctk.CTkScrollableFrame(
            holder,
            fg_color="transparent",
            scrollbar_button_color=self._palette.border_strong,
        )
        body.grid(row=1, column=0, sticky="nsew",
                  padx=(self.metrics.card_pad, 0), pady=(0, self.metrics.card_pad))
        body.grid_columnconfigure(0, weight=1)

        row = 0
        for group, keys in SHORTCUTS:
            ctk.CTkLabel(
                body,
                text=i18n.t(group),
                text_color=self._palette.accent,
                font=self._fonts.role("small_bold"),
                anchor="w",
            ).grid(row=row, column=0, sticky="ew",
                   pady=(self.metrics.sm, self.metrics.xs))
            row += 1
            for key in keys:
                line = ctk.CTkFrame(body, fg_color="transparent")
                line.grid(row=row, column=0, sticky="ew")
                line.grid_columnconfigure(0, weight=1)
                ctk.CTkLabel(
                    line,
                    text=i18n.t(key),
                    text_color=self._palette.text_muted,
                    font=self._fonts.role("caption"),
                    anchor="w",
                    justify="left",
                    wraplength=240,
                ).grid(row=0, column=0, sticky="w")
                row += 1
            row += 1
