"""Version consistency check: one number, everywhere.

Why this check exists
---------------------
The version lives in three files that nothing keeps in sync: ``app/config.py``
(what the app shows and what the User-Agent header sends), ``version_info.txt``
(what Windows shows in the file properties of the built exe) and
``installer/Acadsearch.iss`` (the installer name and the Programs-and-Features
entry). They had drifted to 1.0.0 / 2.0.0 / 2.0.0, which means a user who
reports a bug names one version, the file they downloaded says another, and the
provider logs say a third. That is the kind of mismatch that turns a five-minute
fix into an afternoon of "which build is this?".

What is asserted
----------------
* ``APP_VERSION`` and ``app.__version__`` agree.
* ``version_info.txt`` reports the same number for FileVersion and
  ProductVersion.
* The installer compiles with the same ``AppVersion``.
* The built exe, when present, carries the same FileVersion -- this is the only
  place the *shipped* number can be read, so it is the check that matters.

Run: ``python -X utf8 tools/check_version.py``
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.config import APP_VERSION  # noqa: E402

FAILURES: list[str] = []


def check(label: str, ok: bool, detail: str = "") -> None:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" -- {detail}" if detail else ""))
    if not ok:
        FAILURES.append(label)


def main() -> int:
    print("== the number the app uses ==")
    check("APP_VERSION looks like a release version",
          bool(re.fullmatch(r"\d+\.\d+\.\d+", APP_VERSION)), APP_VERSION)

    import app

    check("app.__version__ matches APP_VERSION",
          app.__version__ == APP_VERSION, f"{app.__version__} vs {APP_VERSION}")

    print("\n== the number the executable carries ==")
    version_info = ROOT / "version_info.txt"
    if version_info.is_file():
        text = version_info.read_text(encoding="utf-8", errors="replace")
        found = set(re.findall(r"'(?:FileVersion|ProductVersion)',\s*'([\d.]+)'", text))
        # 2.0.0 and 2.0.0.0 are the same release; compare on the first three parts.
        normalised = {".".join(v.split(".")[:3]) for v in found}
        check("version_info.txt agrees with APP_VERSION",
              normalised == {APP_VERSION}, str(sorted(found)))
    else:
        check("version_info.txt exists", False, str(version_info))

    print("\n== the number the installer ships ==")
    iss = ROOT / "installer" / "Acadsearch.iss"
    if iss.is_file():
        text = iss.read_text(encoding="utf-8", errors="replace")
        match = re.search(r'#define\s+AppVersion\s+"([\d.]+)"', text)
        check("the installer compiles with the same version",
              match is not None and match.group(1) == APP_VERSION,
              match.group(1) if match else "AppVersion not found")
    else:
        check("installer/Acadsearch.iss exists", False, str(iss))

    print("\n== the number in the built binary ==")
    exe = ROOT / "dist" / "AcadSearch.exe"
    if exe.is_file():
        try:
            import win32api  # type: ignore[import-not-found]

            info = win32api.GetFileVersionInfo(str(exe), "\\")

            def _quad(ms: int, ls: int) -> str:
                return f"{ms >> 16}.{ms & 0xFFFF}.{ls >> 16}.{ls & 0xFFFF}"

            built = _quad(info["FileVersionMS"], info["FileVersionLS"])
            product = _quad(info["ProductVersionMS"], info["ProductVersionLS"])
            check("dist/AcadSearch.exe FileVersion matches",
                  built.startswith(APP_VERSION), built)
            check("dist/AcadSearch.exe ProductVersion matches",
                  product.startswith(APP_VERSION), product)
        except ImportError:
            print("  [SKIP] pywin32 is not installed; the binary was not inspected")
        except Exception as exc:  # noqa: BLE001
            check("dist/AcadSearch.exe reports the same version", False,
                  f"{type(exc).__name__}: {exc}")
    else:
        print("  [SKIP] dist/AcadSearch.exe not built yet")

    print()
    if FAILURES:
        print(f"FAILED: {len(FAILURES)} -> {FAILURES}")
        return 1
    print("VERSION CHECK PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
